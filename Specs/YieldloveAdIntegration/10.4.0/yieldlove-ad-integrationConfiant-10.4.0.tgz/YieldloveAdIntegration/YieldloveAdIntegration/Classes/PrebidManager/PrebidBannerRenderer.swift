//
//  PrebidBannerRenderer.swift
//  Pods
//
//  Created by Shafee Rehman on 30/10/2025.
//


import UIKit
import GoogleMobileAds
import PrebidMobile

typealias PBMBannerView         = PrebidMobile.BannerView
typealias PBMBannerViewDelegate = PrebidMobile.BannerViewDelegate

/// Renders a banner either via Prebid (Direct Rendering) or via GAM, decided at bid time.
/// - No fetchDemand
/// - No PrebidMobileGAMEventHandlers
/// - Uses DRBannerEventHandler to choose the path.
final class PrebidBannerRenderer: NSObject, PBMBannerViewDelegate {
    
    // Inputs / wiring
    private weak var publisherVC: UIViewController?
    private let timeEventRecorder: TimeEventRecorder?
    private let adUnitData: YLAdUnitData
    private weak var publisherDelegate: YLBannerViewDelegate?
    private let baseRequest: AdManagerRequest
    private let sizes: [AdSize]
    private let debugSession: BannerDebugSession?
    private var didFinish = false
    internal private(set) var drHandler: DRBannerEventHandler?
    
    // required
    private var pbBanner: PBMBannerView?
    
    // Async completion
    private var onSuccess: ((YLBannerView) -> Void)?
    private var onFailure: ((Error) -> Void)?
    
    private var reuseView: YLBannerView?
    
    private let dbgId = UUID().uuidString.prefix(6)
    
    init(publisherVC: UIViewController?,
         adUnitData: YLAdUnitData,
         publisherDelegate: YLBannerViewDelegate?,
         baseRequest: AdManagerRequest,
         sizes: [AdSize],
         timeEventRecorder: TimeEventRecorder?,
         reuseView: YLBannerView?,
         bidTrackingListener: BidTrackingListener?) {
        self.publisherVC = publisherVC
        self.adUnitData = adUnitData
        self.publisherDelegate = publisherDelegate
        self.baseRequest = baseRequest
        self.sizes = sizes
        self.timeEventRecorder = timeEventRecorder
        self.debugSession = bidTrackingListener as? BannerDebugSession
        self.reuseView = reuseView
        
        super.init()
        
        //Prebid Init has already happend
        IdentityManager.shared.setUserIdToPrebid()
        
        if ConfigurationManager.isDebugMode(){
            Prebid.shared.logLevel = LogLevel.severe
        }
        
        Prebid.shared.timeoutMillis = PrebidConstants.prebidTimeoutMillis
        Prebid.shared.prebidServerAccountId = adUnitData.accountId ?? ""
        Prebid.shared.useCacheForReportingWithRenderingAPI = true
        BannerTrafficDelegator.shared.attachPrebidEventDelegate()
        
        self.setPrebidCustomHeaders()
        SLogger.i("[PrebidBannerRenderer:\(dbgId)] init adUnit=\(adUnitData.adUnit) config=\(adUnitData.configId) reuseView=\(reuseView != nil) publisherVC_nil=\(publisherVC == nil) skipPrebid=\(adUnitData.skipPrebid)")
    }
    
    @MainActor
    func load(prebidConfigId: String, ylBanner: YLBanner) async throws -> BannerRenderResult {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<BannerRenderResult, Error>) in
            SLogger.i("[PrebidBannerRenderer:\(dbgId)] load START prebidConfigId=\(prebidConfigId) didFinish=\(didFinish)")
            if adUnitData.skipPrebid {
                debugSession?.markPrebidSkipped(
                    targeting: [
                        "adUnit": adUnitData.adUnit,
                        "configId": adUnitData.configId,
                        "sizes": adUnitData.bannerSizes.map { "\($0.size.width)x\($0.size.height)" }.joined(separator: ",")
                    ],
                    adType: "banner",
                    adUnit: adUnitData.adUnit
                )
                
                let data = GamRequestData(
                    adUnitData: adUnitData,
                    gamRequest: baseRequest,
                    publisherViewController: publisherVC,
                    publisherDelegate: publisherDelegate
                )
                guard !didFinish else { return }
                SLogger.i("[PrebidBannerRenderer:\(dbgId)] skipPrebid => GAM (resume cont) didFinish_before=\(didFinish)")
                didFinish = true
                self.clearContinuations()
                cont.resume(returning: .gam(requestData: data))
                self.destroy()
                return
            }
            
            let handler = DRBannerEventHandler(
                adSizes: sizes.map { $0.size },
                baseRequest: baseRequest,
                adUnitData: adUnitData,
                publisherVC: publisherVC,
                publisherDelegate: publisherDelegate,
                reuseView: reuseView,
                debugSession: debugSession
            )
            SLogger.i("[PrebidBannerRenderer:\(dbgId)] created DRBannerEventHandler, reuseView=\(reuseView != nil)")
            drHandler = handler
            
            // When PBM DR succeeds/fails, we finish from delegate callbacks.
            self.onSuccess = { view in
                guard !self.didFinish else { return }
                self.didFinish = true
                self.clearContinuations()
                cont.resume(returning: .prebid(view: view))
                self.destroy()
            }
            self.onFailure = { err in
                guard !self.didFinish else { return }
                self.didFinish = true
                self.clearContinuations()
                cont.resume(throwing: err)
                self.destroy()
            }
            
            handler.onDecision = { [weak self, weak handler] decision in
                guard let self else { return }
                switch decision {
                case .prebidDirect(let view, let error):
                    if let view {
                        // instead of handler?.signalPrebidWin Tell PBM to continue down "ad server won" path so it doesn't try to render PBM view
                        handler?.signalAdServerWin()
                        SLogger.i("[PrebidBannerRenderer:\(dbgId)] CONT resume => PREBID")
                        self.handleRecievedAdFromPrebid(view: view)
                    } else {
                        self.handleRecievedErrorFromPrebid(error: error ?? YLError.errorWasReportedByDelegate)
                    }
                    
                case .gam(let requestData):
                    handler?.signalAdServerWin()
                    guard !didFinish else { return }
                    didFinish = true
                    self.clearContinuations()
                    SLogger.i("[PrebidBannerRenderer:\(dbgId)] CONT resume => GAM (didFinish set true)")
                    cont.resume(returning: .gam(requestData: requestData))
                    self.destroy()
                }
            }
            
            let first = sizes.first?.size ?? AdSizeBanner.size
            let banner = PBMBannerView(
                frame: CGRect(origin: .zero, size: first),
                configID: prebidConfigId,
                adSize: first,
                eventHandler: handler
            )
            
            banner.delegate = self
            if sizes.count > 1 {
                banner.additionalSizes = Array(sizes.dropFirst().map { $0.size })
            }
            self.pbBanner = banner
            
            self.timeEventRecorder?.recordGamRequested()
            
            debugSession?.didSendToPrebid(
                targeting: makePrebidSendInput(adUnitData: adUnitData, baseRequest: baseRequest, ylBanner: ylBanner),
                adType: "banner",
                adUnit: adUnitData.adUnit
            )
            
            banner.bannerParameters.api = adUnitData.frameworks
            banner.adUnitConfig.setPbAdSlot(adUnitData.adUnit)

            //add "adslot" next to "pbadslot"
            let adslot = adUnitData.adUnit
            let impOrtb = """
            {
              "ext": {
                "data": {
                  "adslot": "\(adslot)"
                }
              }
            }
            """
            banner.setImpORTBConfig(impOrtb)
            setGlobalOrtbConfig()
            
            banner.loadAd()
        }
    }
    
    // MARK: - PBMBannerViewDelegate (Prebid Direct Rendering path)
    
    func bannerViewPresentationController() -> UIViewController? {
        publisherVC
    }
    
    func handleRecievedAdFromPrebid(view: YLBannerView) {
        guard !didFinish else { return }
        timeEventRecorder?.recordGamRespondedSuccessfully()
        
        view.publisherViewController = publisherVC
        attachDebugOrDoubleTap(to: view)
        
        if debugSession != nil {
            let info: [String: String] = [
                "event": "Rendered Success",
                "adUnit": adUnitData.adUnit,
                "frameSize": "\(Int(view.frame.width))x\(Int(view.frame.height))"
            ]
            
            debugSession?.didRenderViaPrebid(targeting: info, adType: "banner", adUnit: adUnitData.adUnit)
        }
        
        SLogger.i("[PrebidBannerRenderer:\(dbgId)] PBM callback SUCCESS didFinish=\(didFinish)")
        onSuccess?(view)
    }
    
    func handleRecievedErrorFromPrebid(error: Error) {
        guard !didFinish else { return }
        timeEventRecorder?.recordGamRespondedWithError(error: error)
        
        if debugSession != nil {
             let info: [String: String] = [
                 "event": "Render Failed",
                 "errorDescription": error.localizedDescription,
                 "errorType": String(describing: type(of: error))
             ]

             debugSession?.didRenderViaPrebid(
                 targeting: info,
                 adType: "banner",
                 adUnit: adUnitData.adUnit
             )
         }
        
        if ConfigurationManager.isInspectionMode() {
            let view = YLBannerView(bannerInfo: adUnitData)
            view.setBannerView(bannerView: UIView(frame: CGRect(x: 0, y: 0, width: 150, height: 50)))
            view.publisherViewController = publisherVC
            attachDebugOrDoubleTap(to: view)
            SLogger.e("[PrebidBannerRenderer:\(dbgId)] PBM callback FAIL didFinish=\(didFinish) error=\(error.localizedDescription)")
            onSuccess?(view)
        } else {
            SLogger.e("[PrebidBannerRenderer:\(dbgId)] PBM callback FAIL didFinish=\(didFinish) error=\(error.localizedDescription)")
            onFailure?(error)
        }
    }
    
    func setGlobalOrtbConfig() {
        let globalOrtb: String

        if let contentURL = baseRequest.contentURL, !contentURL.isEmpty {
            Targeting.shared.contentUrl = contentURL

            globalOrtb = """
            {
              "app": {
                "content": {
                  "url": "\(contentURL)"
                },
                "ext": {
                  "data": {
                    "keyvalues": {
                      "demo": ["mobilesdktest"]
                    }
                  }
                }
              }
            }
            """
        } else {
            globalOrtb = """
            {
              "app": {
                "ext": {
                  "data": {
                    "keyvalues": {
                      "demo": ["mobilesdktest"]
                    }
                  }
                }
              }
            }
            """
        }

        Targeting.shared.setGlobalORTBConfig(globalOrtb)
    }
    
    // MARK: - Helpers
    
    private func clearContinuations() {
        onSuccess = nil
        onFailure = nil
    }
    
    private func attachDebugOrDoubleTap(to bannerView: YLBannerView) {
        if ConfigurationManager.isInspectionMode() {
            var served = TimeInterval()
            if let s = timeEventRecorder?.session {
                served = YLTimeSessionCalculator.getServedInTime(session: s)
            }
            let dbg = DebugInfoForStroeer(
                ConfigurationManager.shared.getAppName() ?? "unknown",
                adUnitData,
                served
            )
            let sessionToPresent = debugSession
            let consoleStore = ConsoleLogStore.shared
            
            let label = DebugInfoLabelView()
            label.buildLabel(adUnitData.publisherCallString, .bannerAd, served) { [weak bannerView] in
                    DispatchQueue.main.async {
                        let presenter = bannerView?.publisherViewController
                        guard let presenter else {
                            SLogger.e("[DebugLabel] No presenter VC available to show debug panel.")
                            return
                        }

                        if let sessionToPresent {
                            let panel = DebugLoggerViewController(session: sessionToPresent, consoleStore: consoleStore)
                            presenter.present(panel, animated: true)
                        } else {
                            let panel = DebugInfoPanelViewController(dbg)
                            presenter.present(panel, animated: true)
                        }
                    }
            }
            
            bannerView.createDebugLabelView(debugView: label)
        } else {
            bannerView.addDoubleTapRecognizer()
        }
    }
    
    func destroy() {
        SLogger.i("[PrebidBannerRenderer:\(dbgId)] destroy pbBanner_nil_before=\(pbBanner == nil) drHandler_nil_before=\(drHandler == nil)")
        self.pbBanner?.delegate = nil
        self.pbBanner = nil
        drHandler?.onDecision = nil
        drHandler = nil
        clearContinuations()
    }
    
    private func setPrebidCustomHeaders() {
        Prebid.shared.addCustomHeader(name: "X-SDK-Version", value: YLConstants.version)
        if let bundleId = Bundle.main.bundleIdentifier {
            Prebid.shared.addCustomHeader(name: "X-Bundle", value: bundleId)
        }
    }
    
    func makePrebidSendInput(
        adUnitData: YLAdUnitData,
        baseRequest: AdManagerRequest,
        ylBanner: YLBanner
    ) -> [String: String] {
        
        var input: [String: String] = [
            "adUnit": adUnitData.adUnit,
            "configId": adUnitData.configId,
            "sizes": adUnitData.bannerSizes.map {
                "\($0.size.width)x\($0.size.height)"
            }.joined(separator: ",")
        ]

        input["pbAdSlot"] = adUnitData.adUnit
        input["adType"] = "banner"
        input["refreshable"] = "\(ylBanner is YLRefreshableBanner)"
        input["SdkVersion"] = YLConstants.version
        input["contentUrl"] = baseRequest.contentURL ?? ""
        let publisherTargeting =
            (baseRequest.customTargeting as? [String: String]) ?? [:]
        input["publisherTargeting"] = publisherTargeting
            .map { "\($0.key)=\($0.value)" }
            .sorted()
            .joined(separator: ",")
        input["consent_present"] =
        UserDefaults.standard.string(forKey: "IABTCF_TCString") != nil ? "true" : "false"
        input["bundleId"] = Bundle.main.bundleIdentifier ?? ""
        input["appVersion"] =
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
        input["build"] =
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? ""
        input["os"] = "iOS"
        input["osVersion"] = UIDevice.current.systemVersion
        input["deviceModel"] = UIDevice.current.model
        
        return input
    }
    
    deinit {
        SLogger.i("[PrebidBannerRenderer:\(dbgId)] deinit")
        destroy()
    }
}

enum BannerRenderResult {
    case prebid(view: YLBannerView)
    case gam(requestData: GamRequestData)
}
