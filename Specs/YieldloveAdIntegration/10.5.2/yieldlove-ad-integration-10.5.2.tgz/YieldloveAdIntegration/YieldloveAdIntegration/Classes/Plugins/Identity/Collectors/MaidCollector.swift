//
//  MaidCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation
import AdSupport
import AppTrackingTransparency


/// Collects the mobile advertising ID (IDFA) on iOS.
class MaidCollector: IIdentityCollector {
    func retrieveData() async -> String? {
        // Read the IDFA on the main actor: collectors run concurrently
        // (see `ID5RequestBodyBuilder.getRequestBody()`) and ASIdentifierManager
        // is safest accessed from the main thread.
        let idfa = await MainActor.run {
            ASIdentifierManager.shared().advertisingIdentifier.uuidString
        }
        if idfa == "00000000-0000-0000-0000-000000000000" {
            return nil
        }

        return idfa
    }
}
