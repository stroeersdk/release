//
//  CountryCodeCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation


import CoreTelephony

/// Returns the country code collected from the SIM card, network, or device's default locale.
class CountryCodeCollector: IIdentityCollector {
    func retrieveData() async -> String {
        // `CTTelephonyNetworkInfo` is not thread-safe and crashes inside CoreTelephony
        // when accessed off the main thread. Collectors run concurrently
        // (see `ID5RequestBodyBuilder.getRequestBody()`), so read it on the main actor.
        await MainActor.run {
            // Get the telephony manager
            let networkInfo = CTTelephonyNetworkInfo()

            // 1. Try getting country from SIM card
            if let carrier = networkInfo.serviceSubscriberCellularProviders?.values.first,
               let countryCode = carrier.isoCountryCode, !countryCode.isEmpty {
                return countryCode.uppercased() // Return uppercase ISO country code
            }

            // 2. Fallback: Get country from the device's default locale
            return Locale.current.regionCode?.uppercased() ?? "Unknown"
        }
    }
}
