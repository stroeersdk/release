//
//  GraviteHandler.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 07/01/2025.
//

import Foundation
import GoogleMobileAds


class GraviteHandler {
    var isLoaded = true
    // var debugInfoLabel : DebugInfoViewLabel?
    func requestGravite(error: Error, ylBannerView:YLBannerView, bannerConfiguration: YLBannerConfiguration) -> Bool{
        if error is BackFillError || GraviteLoader.shared.isGraviteStarted() {
            isLoaded = false
            
            if(GraviteLoader.shared.isGraviteStarted()) {
                if (loadGraviteBanner(ylBannerView: ylBannerView, bannerConfiguration: bannerConfiguration)){
                    return true
                }
            }
        }
        return false
    }
    
    func loadGraviteBanner(ylBannerView:YLBannerView, bannerConfiguration: YLBannerConfiguration) -> Bool{
        if(!isLoaded){
            if let adUnitData = bannerConfiguration.adUnitData, let adView = GraviteLoader.shared.getBannerLoader()?.getBanner(ylAdUnitData: adUnitData, adContainerView: bannerConfiguration.viewController?.view ?? UIView())
            {
                ylBannerView.setBannerView(bannerView: adView)
                ylBannerView.bannerInfo.source = GraviteLoader.shared.getAdSource() // apply gravite source
                ylBannerView.publisherViewController = bannerConfiguration.viewController
                if ConfigurationManager.isInspectionMode() {
                    let label = DebugInfoLabelView()
                    label.buildLabel(adUnitData.publisherCallString, .bannerAd, GraviteLoader.shared.getDebugInfo()?.getServedInTime() ?? 0) { [weak ylBannerView] in
                        DispatchQueue.main.async {
                            let presenter = ylBannerView?.publisherViewController
                            guard let presenter else {
                                SLogger.e("[DebugLabel] No presenter VC available to show debug panel.")
                                return
                            }
                            
                            guard let info = GraviteLoader.shared.getDebugInfo() else {
                                SLogger.e("[DebugLabel] Gravite debug info missing.")
                                return
                            }
                            let panel = DebugInfoPanelViewController(info)
                            presenter.present(panel, animated: true)
                        }
                    }

                    ylBannerView.createDebugLabelView(debugView: label)
                }
                else{
                    ylBannerView.addDoubleTapRecognizer()
                }
                
                ylBannerView.updateSize(to: adView.intrinsicContentSize)

                isLoaded = true
                bannerConfiguration.publisherDelegate?.bannerViewDidReceiveAd?(ylBannerView)
            
                return true
            }
        }
        return false
    }
    
}
