import Foundation
import GoogleMobileAds
import PrebidMobile
import PromiseKit


class YLInterstitial: YLAd {

    private var interstitialDelegate: YLInterstitialAdDelegate?
    private weak var viewController: UIViewController?

    public init(config: Config, interstitialDelegate: YLInterstitialAdDelegate? = nil, request: AdManagerRequest, timeEventRecorder: TimeEventRecorder? = nil) {
        self.interstitialDelegate = interstitialDelegate
        super.init(config: config, adType: .interstitial, gamRequest: request, timeEventRecorder: timeEventRecorder)
    }
    
    public func load(adSlotId: String, viewController: UIViewController) {
        self.viewController = viewController
        
        self.getConfigurableAdUnitData(publisherAdSlot: adSlotId)
                .map(transformAdUnitData)
                .map(setAdUnitData)
                .map(recordAdUnitLoaded)
                .map(applyTargeting)
                .then(collectBids)
                .then(callGam)
                .done(callSuccessCompletion)
                .catch(handleError)
                .finally(stopSession)
    }

    private func callGam() throws -> Promise<AdManagerInterstitialAd> {
        let adUnitData = try getAdUnitData()
        let requestData = (adUnitData, mergedGamRequest)
        return self.gamAdLoader.loadInterstitial(gamRequestData: requestData, timeEventRecorder: timeEventRecorder)
    }

    private func transformAdUnitData(configurableAdUnitData: ConfigurableAdUnitData) -> YLAdUnitData {
        let unitData = YLAdUnitDataTransformer.transformInterstitialAdUnitData(configurableAdUnitData: configurableAdUnitData)
        
        if GraviteLoader.shared.isGraviteStarted()
        {
            let config = GraviteInterstitialConfig()
            config.ylAdUnitData = unitData
            config.interstitialDelegate = interstitialDelegate
            config.viewController = viewController
            GraviteLoader.shared.getInterstitialLoader()?.loadInterstitial(config: config)
        }
        
        return unitData
    }
    
    private func callSuccessCompletion(gamInterstitial: AdManagerInterstitialAd) throws {

        if(GraviteLoader.shared.isForceToExcute())
        {
            throw BackFillError.forceToExecute
        }
        
        let intertitialAd = YLInterstitialAd(interstitialAd: gamInterstitial)
        DispatchQueue.main.async {
            self.interstitialDelegate?.onAdLoaded?(interstitial: intertitialAd)
        }
    }
    
    private func handleError(error: Error) {
        
        if(error is BackFillError || GraviteLoader.shared.isGraviteStarted())
        {
            SLogger.i("[Interstitial] Calling backfill : reason - \(error)")
            
            if let ylAdUnitData = ylAdUnitData {
                if(GraviteLoader.shared.getInterstitialLoader()!.isInterstitialAvailable(ylAdUnitData: ylAdUnitData))
                {
                    let interstitialAd = YLInterstitialAd()
                    interstitialAd.adSource = GraviteLoader.shared.getAdSource()
                    interstitialAd.ylAdUnitData = ylAdUnitData
                    
                    self.interstitialDelegate?.onAdLoaded?(interstitial: interstitialAd)
                    
                    return;
                }
                else
                {
                    SLogger.i("[Interstitial] Interstitial is not avilable")
                }
            }
        }
        
        self.config.remoteReporter.report(err: error)
        self.interstitialDelegate?.onAdFailedToLoad?(interstitial: nil, error:error)
    }
    
    private func recordAdUnitLoaded() {
        self.timeEventRecorder.recordAdUnitLoaded()
    }
}
