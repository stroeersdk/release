import GoogleMobileAds
import PromiseKit


struct YLBannerConfiguration {
    
    let adSlotId: String
    let config: Config
    weak var viewController: UIViewController?
    weak var publisherDelegate: YLBannerViewDelegate?
    var adUnitData: YLAdUnitData?
    var session:TimeSession?
    
    //Keep the init for view controller and publisherDelegate non optional
    init(_ adSlotId: String, _ config: Config, _ viewController: UIViewController, _ publisherDelegate: YLBannerViewDelegate) {
        self.adSlotId = adSlotId
        self.config = config
        self.viewController = viewController
        self.publisherDelegate = publisherDelegate
    }
    
    init(_ adSlotId: String, _ config: Config, _ viewController: UIViewController, _ publisherDelegate: YLBannerViewDelegate, _ adUnitData: YLAdUnitData) {
        self.adSlotId = adSlotId
        self.config = config
        self.viewController = viewController
        self.publisherDelegate = publisherDelegate
        self.adUnitData = adUnitData
    }
    
    mutating func initialize() throws -> Promise<YLBannerConfiguration>{
        var snapshot = self
        return config.configurationManager.getAdUnitData(publisherAdSlot: adSlotId, adType: .bannerAd)
            .map(transformAdUnitData)
            .map{
                adUnitData -> YLBannerConfiguration in
                adUnitData.TCString = YLConsentReader().getTCString()
                snapshot.adUnitData = adUnitData
                return snapshot
            }
    }
    
    private func transformAdUnitData(configurableAdUnitData: ConfigurableAdUnitData) throws -> YLAdUnitData {
        return try YLAdUnitDataTransformer.transformBannerAdUnitData(configurableAdUnitData: configurableAdUnitData)
    }
    
}
