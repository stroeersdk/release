//
//  AdSource.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 19/12/2024.
//

import Foundation

@objc public enum AdSource : Int {
    case Unknown = 0
    case Stroeer = 1
    case Gravite = 2
    
    public var displayName: String {
           switch self {
           case .Unknown: return AdSource.UNKNOWN
           case .Stroeer: return AdSource.STROEER
           case .Gravite: return AdSource.GRAVITE
           }
    }
    
    public static let UNKNOWN = "Unkown"
    public static let STROEER = "Stroeer"
    public static let GRAVITE = "Gravite"
    public static let GOOGLE = "Google"
}


@objcMembers public class AdSourceInfo : NSObject{
    
    public var adSource:AdSource
    public var adSubSource: String
    public var version:String;
    
    override init()
    {
        adSource = AdSource.Stroeer
        adSubSource = AdSource.UNKNOWN
        version = Self.getVersion()
        super.init()
    }
    
    public init(adSource:AdSource, version:String)
    {
        self.adSource = adSource
        self.adSubSource = AdSource.UNKNOWN
        self.version = version
        super.init()
    }

    private static func getVersion() -> String {
        return YLConstants.version
    }
    
    class func getDefaultAdSource() -> AdSourceInfo {
        return AdSourceInfo()
    }
    
    class func getUnknowAdSource() -> AdSourceInfo {
        return AdSourceInfo(adSource: .Unknown, version: AdSource.UNKNOWN)
    }
    
    override public var description: String {
        return "AdSourceInfo{ source='\(adSource.displayName)', subSource='\(adSubSource)', version='\(version)'}'";
    }
}
