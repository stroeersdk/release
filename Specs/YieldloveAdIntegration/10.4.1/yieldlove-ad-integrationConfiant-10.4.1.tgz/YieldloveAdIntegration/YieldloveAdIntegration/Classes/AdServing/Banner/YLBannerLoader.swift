import PromiseKit
import GoogleMobileAds


class YLBannerLoader {
    
    private var bannerConfiguration: YLBannerConfiguration
    private let bannerFactory: BannerFactory
    private weak var ylAdUnitData: YLAdUnitData?
    private var graviteHandler: GraviteHandler
    
    
    init(bannerConfiguration: YLBannerConfiguration, bannerFactory: BannerFactory = YLBannerFactory()) {
        self.bannerConfiguration = bannerConfiguration
        self.bannerFactory = bannerFactory
        graviteHandler = GraviteHandler()
   }
    
    func loadBanner() {
        graviteHandler.isLoaded = true
        bannerConfiguration.publisherDelegate?.bannerViewDidStartLoadingAd?()
        firstly{
            try bannerConfiguration.initialize()
        }
        .done{ updateConfiguration in
            self.bannerConfiguration = updateConfiguration
        }
        .map(callLoad)
        .catch(handleError)
    }
    
    private func callLoad() throws {
        if let adUnitData = bannerConfiguration.adUnitData {
            
            var debugSession: BannerDebugSession? = nil
            if ConfigurationManager.isInspectionMode() {
                debugSession = BannerTrafficDelegator.shared.startSession(for: adUnitData.adUnit)
                ConsoleLogStore.shared.startIfNeeded()
            }
            
            let banner = createBanner(ylAdUnitData: adUnitData)
            
            banner.load(
                adSlotId: bannerConfiguration.adSlotId,
                graviteHandler: graviteHandler,
                debugSession: debugSession
            )
        }
        else
        {
            throw YLError.adUnitDataWasNotSet
        }
    }
    
    private func createBanner(ylAdUnitData: YLAdUnitData) -> LoadableBanner {
        return bannerFactory.make(ylAdUnitData: ylAdUnitData, bannerConfiguration: bannerConfiguration)
    }
    
    private func handleError(error: Error) {
        SLogger.e("[BannerLoader] Calling backfill : reason - \(error.localizedDescription)")
        if let bannerInfo = bannerConfiguration.adUnitData {
            let ylBannerView = YLBannerView(bannerInfo: bannerInfo)
            ylBannerView.publisherViewController = bannerConfiguration.viewController
            
            if(graviteHandler.requestGravite(error: error, ylBannerView: ylBannerView, bannerConfiguration : bannerConfiguration)){
                return
            }
            DispatchQueue.main.async {
                self.bannerConfiguration.publisherDelegate?.bannerView?(ylBannerView, didFailToReceiveAdWithError: error)
            }
        }
        
        DispatchQueue.main.async {
            self.bannerConfiguration.publisherDelegate?.bannerView?(YLBannerView(), didFailToReceiveAdWithError: error)
        }
    }
}
