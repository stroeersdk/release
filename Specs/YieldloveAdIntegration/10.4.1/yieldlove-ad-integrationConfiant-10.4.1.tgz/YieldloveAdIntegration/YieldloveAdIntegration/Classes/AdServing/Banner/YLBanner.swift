import Foundation
import GoogleMobileAds
import PrebidMobile
import PromiseKit


protocol LoadableBanner: AnyObject {
    func load(adSlotId: String, graviteHandler: GraviteHandler?, debugSession: BannerDebugSession?)
 }

class YLBanner: YLAd, LoadableBanner{
    
    weak var ylBannerView : YLBannerView?
    weak var currentView : UIView?
    var graviteHandler : GraviteHandler?
    var bannerConfiguration : YLBannerConfiguration
    var debugSession: BannerDebugSession?
    
    init(bannerConfiguration: YLBannerConfiguration, timeEventRecorder: TimeEventRecorder? = nil) {
        self.bannerConfiguration = bannerConfiguration
        let gamRequest = bannerConfiguration.publisherDelegate?.getGAMRequest?() ?? AdManagerRequest()
        super.init(config: bannerConfiguration.config, adType: .bannerAd, gamRequest: gamRequest, timeEventRecorder: timeEventRecorder)
        super.publisherCallString = bannerConfiguration.adSlotId
    }

    func load(adSlotId: String, graviteHandler: GraviteHandler?, debugSession: BannerDebugSession? = nil) {
        self.graviteHandler = graviteHandler
        self.debugSession = debugSession
        
        bannerConfiguration.publisherDelegate?.bannerViewDidStartLoadingAd?()
        //OLD
//        Promise.value(Void())
//            .map(processAdUnitData)
//            .then(requestAd)
//            .catch(handleError)
//            .finally(stopSession)
   
        //NEW
        Task { @MainActor in
            defer { stopSession() }
            await requestAdDR()
        }
    }
    
    func processAdUnitData() throws {
        
        if let ylAdUnitData = bannerConfiguration.adUnitData{
            let config = GraviteBannerConfig()
            config.loaded = self
            config.viewController = bannerConfiguration.viewController
            config.ylAdUnitData = ylAdUnitData
            GraviteLoader.shared.getBannerLoader()?.loadBanner(config: config)
            setAdUnitData(adUnitData: ylAdUnitData)
            recordAdUnitLoaded()
            try applyTargeting()
        }
        else
        {
            throw YLError.adUnitDataWasNotSet
        }
    }
    
    func markBannerView(ylBannerView: UIView)
    {
        currentView = ylBannerView
        ConfiantLoader.shared.mark(adReloader: self)
    }
    
    func processBannerView(ylBannerView: YLBannerView) throws -> YLBannerView {
        if let refreshable = self as? YLRefreshableBanner {
            ylBannerView.refreshController = refreshable
        }
        try passBannerToPublisher(ylBannerView: ylBannerView)
        return ylBannerView
    }
    
    func handleError(error: Error) {
        DispatchQueue.main.async {
            self.passBannerErrorToPublisher(bannerView: BannerView(), error: error)
        }
        if !isErrorPartOfNormalGAMOperation(error) {
            config.remoteReporter.report(err: error)
        }
    }
    
    func getGamRequestData() throws -> GamRequestData {
        let ylAdUnitData = try getAdUnitData()
        return GamRequestData(adUnitData: ylAdUnitData,
                              gamRequest: mergedGamRequest,
                              publisherViewController: bannerConfiguration.viewController,
                              publisherDelegate: bannerConfiguration.publisherDelegate)
    }
    
    func analyzeAd(ylBannerView: YLBannerView) -> Promise<YLBannerView> {
        return AdWinnerAnalyzer.instance.getWinner(ylBannerView: ylBannerView)
            .map { [weak self] winner in
                guard let self = self else { return ylBannerView}
                self.recordAdAnalyzed(winner: winner)
                if let ylAdUnitData = self.ylAdUnitData {
                    SLogger.d("[Banner] Ad winner: \(winner.rawValue) for \(ylAdUnitData.getAdSlotName())")
                }
                
                
                return ylBannerView
            }
    }
    
    func callGam() throws -> Promise<YLBannerView> {
        let requestData = try getGamRequestData()
        let view = gamAdLoader.loadBanner(gamRequestData: requestData, ylBanner: self)
        ylBannerView = view.value
        return view
        
    }
    
    private func requestAd() throws -> Promise<Void> {
        
        return try collectBids()
                //.map(reportContextualTargeting)
                .then(callGam)
                //.then(analyzeAd)
                .map(processBannerView)
                .asVoid()
    }
    
    private func passBannerToPublisher(ylBannerView: YLBannerView) throws {
        if GraviteLoader.shared.isForceToExcute()
        {
            throw BackFillError.forceToExecute
        }
        
        //Keep this strong, do not use [weak self] here
        DispatchQueue.main.async {
            self.bannerConfiguration.publisherDelegate?.bannerViewDidReceiveAd?(ylBannerView)
        }
    }
    
    private func passBannerErrorToPublisher(bannerView: GoogleMobileAds.BannerView, error: Error) {
        
        if let adUnitData = bannerConfiguration.adUnitData {
            let ylBannerView = YLBannerView(bannerView: bannerView, bannerInfo: bannerConfiguration.adUnitData!)
            ylBannerView.publisherViewController = bannerConfiguration.viewController
            if let result = graviteHandler?.requestGravite(error: error, ylBannerView: YLBannerView(bannerView: BannerView(), bannerInfo: adUnitData), bannerConfiguration: bannerConfiguration), result {
                return
            }
            
            bannerConfiguration.publisherDelegate?.bannerView?(ylBannerView, didFailToReceiveAdWithError: error)
        }
    }
    
    private func isErrorPartOfNormalGAMOperation(_ error: Error) -> Bool {
        if case YLError.errorWasReportedByDelegate = error {
            return true
        }
        return false
    }
    
    private func recordAdUnitLoaded() {
        if !skipRecordingMonitoringEvents {
            timeEventRecorder.recordAdUnitLoaded()
        }
    }
    
    private func recordAdAnalyzed(winner: AdWinner) {
        if !skipRecordingMonitoringEvents {
            timeEventRecorder.recordAdAnalyzed(winner: winner.rawValue)
        }
    }
}

extension YLBanner : IFirstBannerLoaded{
    func onFirstBannerLoaded() {
        // Just in case the first banner is loaded after all initialize process is done
        if let ylBannerView = ylBannerView {
            let _ = self.graviteHandler?.loadGraviteBanner(ylBannerView: ylBannerView, bannerConfiguration:bannerConfiguration)
        }
        else
        {
            let _ = self.graviteHandler?.loadGraviteBanner(ylBannerView: YLBannerView(bannerInfo: bannerConfiguration.adUnitData!), bannerConfiguration:bannerConfiguration)
        }
    }
}

//MARK: - Async functions for DR
extension YLBanner {
    @MainActor
    func requestAdDR() async {
        do {
            SLogger.i("[Banner] Requesting ad")
            try processAdUnitData()
            let ylData = try getAdUnitData()

            if GraviteLoader.shared.isDirectGraviteCall() {
                throw BackFillError.directCallToGravite
            }

            let renderer = PrebidBannerRenderer(
                publisherVC: bannerConfiguration.viewController,
                adUnitData: ylData,
                publisherDelegate: bannerConfiguration.publisherDelegate,
                baseRequest: mergedGamRequest,
                sizes: ylData.bannerSizes,
                timeEventRecorder: timeEventRecorder,
                reuseView: nil,
                bidTrackingListener: debugSession
            )

            let result = try await renderer.load(prebidConfigId: ylData.configId, ylBanner: self)

            switch result {
            case .prebid(let view):
                _ = try processBannerView(ylBannerView: view)

            case .gam(let requestData):
                let view = try await GamManager.shared.loadBanner(
                    requestData: requestData,
                    banner: self,
                    debugSession: debugSession
                )
                _ = try processBannerView(ylBannerView: view)
            }

        } catch {
            handleError(error: error)
        }
    }
}


