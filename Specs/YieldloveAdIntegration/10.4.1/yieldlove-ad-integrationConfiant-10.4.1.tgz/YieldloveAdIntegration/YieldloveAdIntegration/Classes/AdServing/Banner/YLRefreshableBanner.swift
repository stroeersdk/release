import Foundation
import UIKit
import GoogleMobileAds

final class YLRefreshableBanner: YLBanner, RefreshTimerDelegate {

    private var isRefreshing = false

    /// One timer per banner instance.
    private var refreshTimer: RefreshTimer?
    private var didStartTimer = false

    /* keep it weak to avoid retain cycle below
    YLBannerView.refreshController strong → YLRefreshableBanner
    YLRefreshableBanner.alreadyServedBannerView strong → YLBannerView */
    private weak var alreadyServedBannerView: YLBannerView?

    override func load(adSlotId: String, graviteHandler: GraviteHandler?, debugSession: BannerDebugSession? = nil) {
        self.graviteHandler = graviteHandler
        self.debugSession = debugSession

        bannerConfiguration.publisherDelegate?.bannerViewDidStartLoadingAd?()

        Task { @MainActor in
            defer { stopSession() }
            await initialLoadMain()
        }
    }

    func refresh() {
        Task { @MainActor in
            await refreshMain()
        }
    }

    // MARK: - Initial load path

    @MainActor
    private func initialLoadMain() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }
        skipRecordingMonitoringEvents = false

        do {
            try processAdUnitData()
            try applyTargeting()
            let ylData = try getAdUnitData()

            if GraviteLoader.shared.isDirectGraviteCall() {
                throw BackFillError.directCallToGravite
            }

            let renderer = PrebidBannerRenderer(
                publisherVC: bannerConfiguration.viewController,
                adUnitData: ylData,
                publisherDelegate: bannerConfiguration.publisherDelegate,
                baseRequest: mergedGamRequest,
                sizes: ylData.bannerSizes,
                timeEventRecorder: timeEventRecorder,
                reuseView: alreadyServedBannerView,
                bidTrackingListener: debugSession
            )

            let result = try await renderer.load(prebidConfigId: ylData.configId, ylBanner: self)

            switch result {
            case .prebid(let view):
                alreadyServedBannerView = view
                _ = try processBannerView(ylBannerView: view)
                startRefreshTimerIfNeeded(wrapper: view)

            case .gam(let requestData):
                let view = try await loadOrRefreshGAM(requestData: requestData)
                _ = try processBannerView(ylBannerView: view)
                startRefreshTimerIfNeeded(wrapper: view)
            }

        } catch {
            handleError(error: error)
        }
    }

    // MARK: - Refresh tick path

    @MainActor
    private func refreshMain() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        skipRecordingMonitoringEvents = true
        bannerConfiguration.publisherDelegate?.bannerViewDidStartLoadingAd?()
        
        await requestRefreshableAdDR()
    }

    @MainActor
    private func requestRefreshableAdDR() async {
        do {
            try applyTargeting()
            let ylData = try getAdUnitData()

            if GraviteLoader.shared.isDirectGraviteCall() {
                throw BackFillError.directCallToGravite
            }

            let renderer = PrebidBannerRenderer(
                publisherVC: bannerConfiguration.viewController,
                adUnitData: ylData,
                publisherDelegate: bannerConfiguration.publisherDelegate,
                baseRequest: mergedGamRequest,
                sizes: ylData.bannerSizes,
                timeEventRecorder: timeEventRecorder,
                reuseView: alreadyServedBannerView,
                bidTrackingListener: debugSession
            )

            let result = try await renderer.load(prebidConfigId: ylData.configId, ylBanner: self)

            switch result {
            case .prebid(let view):
                alreadyServedBannerView = view
                _ = try processBannerView(ylBannerView: view)

            case .gam(let requestData):
                let view = try await loadOrRefreshGAM(requestData: requestData)
                _ = try processBannerView(ylBannerView: view)
            }

        } catch {
            handleError(error: error)
        }
    }

    @MainActor
    private func loadOrRefreshGAM(requestData: GamRequestData) async throws -> YLBannerView {

        let view: YLBannerView

        if let served = alreadyServedBannerView,
           served.getBannerView() is AdManagerBannerView {

            view = try await GamManager.shared.refreshBanner(
                requestData: requestData,
                ylBanner: self,
                bannerView: served,
                debugSession: debugSession
            )
        } else {
            view = try await GamManager.shared.loadBanner(
                requestData: requestData,
                banner: self,
                reuseView: alreadyServedBannerView,
                debugSession: debugSession
            )
        }

        alreadyServedBannerView = view

        return view
    }
    
    // MARK: - Timer (ONE per banner)
    @MainActor
    private func startRefreshTimerIfNeeded(wrapper: YLBannerView) {
        guard !didStartTimer else { return }

        guard let adUnit = try? getAdUnitData(),
              let autoRefreshTimeMs = adUnit.autoRefreshTimeMs
        else {
            return
        }

        didStartTimer = true

        let t = config.refreshTimerFactory.makeTimer(
            autoRefreshTimeMs: autoRefreshTimeMs,
            delegate: self,
            wrapper: wrapper
        )
        refreshTimer = t
        t.start()
    }
    
    deinit {
        refreshTimer?.stop()
    }
}
