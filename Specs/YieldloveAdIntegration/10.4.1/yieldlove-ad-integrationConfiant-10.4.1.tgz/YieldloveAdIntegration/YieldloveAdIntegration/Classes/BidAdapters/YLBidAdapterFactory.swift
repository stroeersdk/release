protocol BidAdapterFactory {
    func makeBidAdapters(bidTuple: BidTuple) -> [BidAdapter]
}

class YLBidAdapterFactory: BidAdapterFactory {
    
    let prebidAdUnitFactory: PrebidAdUnitFactory?
    
    init(prebidAdUnitFactory: PrebidAdUnitFactory?) {
        self.prebidAdUnitFactory = prebidAdUnitFactory
    }
    
    func makeBidAdapters(bidTuple: BidTuple) -> [BidAdapter] {
        let (originalRequest, adUnitData) = bidTuple
        var adapters: [BidAdapter] = []
        if let accountId = adUnitData.accountId, let prebidAdUnitFactory = self.prebidAdUnitFactory {
            var prebidFactory = prebidAdUnitFactory
            prebidFactory.accountId = accountId
            let prebidAdapter = YLPrebidBidAdapter(requestData: originalRequest, adUnitFactory: prebidFactory, bidTrackingListener: Yieldlove.instance.bidTrackingListener)
            adapters.append(prebidAdapter)
        }
        return adapters
    }
}
