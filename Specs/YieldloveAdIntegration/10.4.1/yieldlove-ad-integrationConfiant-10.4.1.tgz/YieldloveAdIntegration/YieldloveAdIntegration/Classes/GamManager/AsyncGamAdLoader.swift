//
//  AsyncGamAdLoader.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 04/08/2025.
//

import Foundation
import GoogleMobileAds

/// Handles loading GAM banners asynchronously without PromiseKit.
final class AsyncGamAdLoader {

    private let debugSession: BannerDebugSession?
    private let dbgId = UUID().uuidString.prefix(6)

    init(debugSession: BannerDebugSession? = nil) {
        self.debugSession = debugSession
    }

    // MARK: - Public API
    //Note: the reason why we have reuse view on loadbanner is because if the dr flag flips on timer
    //then it comes to loadBanner instead of refreshBanner
    func loadBanner(requestData: GamRequestData,
                    banner: YLBanner,
                    reuseView: YLBannerView?) async throws -> YLBannerView {
        try await createAndLoadBannerView(requestData: requestData, ylBanner: banner, reuseView: reuseView)
    }
    
    @MainActor
     func refreshBanner(
         requestData: GamRequestData,
         ylBanner: YLBanner,
         bannerView: YLBannerView
     ) async throws -> YLBannerView {
         let gamRequest = requestData.gamRequest
         
         return try await withCheckedThrowingContinuation { [weak self] continuation in
             SLogger.i("[AsyncGamAdLoader:\(self?.dbgId ?? "")] refreshBanner START adUnit=\(requestData.adUnitData.adUnit)")
             guard let gamBanner = bannerView.getBannerView() as? AdManagerBannerView else {
                 continuation.resume(throwing: YLError.adUnitDataWasNotSet)
                 return
             }
             
             let delegateWrapper = AsyncGamBannerDelegate(
                 adUnitData: requestData.adUnitData,
                 timeEventRecorder: ylBanner.timeEventRecorder,
                 publisherViewController: requestData.publisherViewController,
                 publisherDelegate: requestData.publisherDelegate,
                 debugSession: self?.debugSession
             )
             
             gamBanner.delegate = nil
             gamBanner.delegate = delegateWrapper
             
             // Keep GAM objects alive for the request lifetime (unchanged)
             let referenceHolder = YLReferenceHolder(bannerView: gamBanner, delegate: delegateWrapper)
             self?.keepReference(referenceHolder, ylAd: ylBanner)
             
             // Ensures the continuation is resumed exactly once.
             // The request can finish via the GAM delegate or via a timeout.
             // This guard prevents double-resume crashes and leaked continuations.
             var didResume = false
             
             // Safety timeout in case GAM never calls its delegate.
             // Guarantees the continuation always completes and avoids leaks.
             // Ignored if the delegate responds first.
             let timeoutTask = Task { @MainActor [weak delegateWrapper] in
                 do {
                     try await Task.sleep(nanoseconds: 10_000_000_000)
                 } catch {
                     return
                 }
                 
                 guard !Task.isCancelled else { return }
                 guard !didResume else { return }
                 didResume = true
                 SLogger.e("[AsyncGamAdLoader:\(self?.dbgId ?? "")] REFRESH TIMEOUT holderId=\(referenceHolder.id) removing reference + resuming error")
                 delegateWrapper?.isRequestInFlight = false
                 delegateWrapper?.completion = nil
                 self?.removeReference(referenceHolder, ylAd: ylBanner)
                 continuation.resume(throwing: YLError.timeout)
             }
             
             delegateWrapper.completion = { result in
                 guard !didResume else { return }
                 didResume = true
                 timeoutTask.cancel()
                 SLogger.i("[AsyncGamAdLoader:\(self?.dbgId ?? "")] REFRESH completion CALLED didResume=\(didResume) (will remove holderId=\(referenceHolder.id))")
                 delegateWrapper.completion = nil
                 self?.removeReference(referenceHolder, ylAd: ylBanner)

                 switch result {
                 case .success(let refreshedView):
                     SLogger.i("[AsyncGamAdLoader:\(self?.dbgId ?? "")] completion SUCCESS holderId=\(referenceHolder.id)")
                     continuation.resume(returning: refreshedView)
                 case .failure(let error):
                     SLogger.e("[AsyncGamAdLoader:\(self?.dbgId ?? "")] completion FAIL holderId=\(referenceHolder.id) err=\(error.localizedDescription)")
                     continuation.resume(throwing: error)
                 }
             }
             
             delegateWrapper.ylBannerView = bannerView
             delegateWrapper.isRequestInFlight = true
             
             ylBanner.timeEventRecorder.recordGamRequested()
             gamBanner.load(gamRequest)
         }
     }

    // MARK: - Private
    @MainActor
    private func createAndLoadBannerView(
        requestData: GamRequestData,
        ylBanner: YLBanner,
        reuseView: YLBannerView?
    ) async throws -> YLBannerView {

        try await withCheckedThrowingContinuation { [weak self] continuation in
            SLogger.i("[AsyncGamAdLoader:\(self?.dbgId ?? "")] loadBanner START adUnit=\(requestData.adUnitData.adUnit) reuseView=\(reuseView != nil)")
            let delegateWrapper = AsyncGamBannerDelegate(
                adUnitData: requestData.adUnitData,
                timeEventRecorder: ylBanner.timeEventRecorder,
                publisherViewController: requestData.publisherViewController,
                publisherDelegate: requestData.publisherDelegate,
                debugSession: self?.debugSession
            )
            
            let gamBanner = AdManagerBannerView(adSize: requestData.adUnitData.bannerSizes[0])
            gamBanner.validAdSizes = requestData.adUnitData.bannerSizes.map { nsValue(for: $0) }
            gamBanner.rootViewController = requestData.publisherViewController
            gamBanner.delegate = delegateWrapper
            gamBanner.adUnitID = requestData.adUnitData.adUnit

            var didResume = false
            
            // Keep GAM objects alive for the request lifetime (unchanged)
            let referenceHolder = YLReferenceHolder(bannerView: gamBanner, delegate: delegateWrapper)
            self?.keepReference(referenceHolder, ylAd: ylBanner)
            
            // Safety timeout
            let timeoutTask = Task { @MainActor [weak delegateWrapper] in
                do {
                    try await Task.sleep(nanoseconds: 10_000_000_000)
                } catch {
                    return
                }
                guard !didResume else { return }
                didResume = true
                SLogger.e("[AsyncGamAdLoader:\(self?.dbgId ?? "")] TIMEOUT holderId=\(referenceHolder.id) removing reference + resuming error")
                delegateWrapper?.isRequestInFlight = false
                delegateWrapper?.completion = nil
                self?.removeReference(referenceHolder, ylAd: ylBanner)
                continuation.resume(throwing: YLError.timeout)
            }

            delegateWrapper.completion = { result in
                guard !didResume else { return }
                didResume = true
                SLogger.i("[AsyncGamAdLoader:\(self?.dbgId ?? "")] completion CALLED didResume=\(didResume) (will remove holderId=\(referenceHolder.id))")
                timeoutTask.cancel()

                delegateWrapper.completion = nil
                self?.removeReference(referenceHolder, ylAd: ylBanner)

                switch result {
                case .success(let view):
                    SLogger.i("[AsyncGamAdLoader:\(self?.dbgId ?? "")] completion SUCCESS holderId=\(referenceHolder.id)")
                    continuation.resume(returning: view)
                case .failure(let error):
                    SLogger.e("[AsyncGamAdLoader:\(self?.dbgId ?? "")] completion FAIL holderId=\(referenceHolder.id) err=\(error.localizedDescription)")
                    continuation.resume(throwing: error)
                }
            }

            ylBanner.markBannerView(ylBannerView: gamBanner)

            let wrapper: YLBannerView
            if let reuse = reuseView {
                reuse.bannerInfo = requestData.adUnitData
                reuse.publisherViewController = requestData.publisherViewController
                reuse.publisherDelegate = requestData.publisherDelegate
                reuse.setBannerView(bannerView: gamBanner)
                wrapper = reuse
            } else {
                let v = YLBannerView(bannerView: gamBanner, bannerInfo: requestData.adUnitData)
                v.publisherViewController = requestData.publisherViewController
                v.publisherDelegate = requestData.publisherDelegate
                wrapper = v
            }
            
            delegateWrapper.ylBannerView = wrapper
            delegateWrapper.isRequestInFlight = true

            ylBanner.timeEventRecorder.recordGamRequested()
            gamBanner.load(requestData.gamRequest)
        }
    }

    /*
     * Why keep a reference to GAMBannerView and YieldloveAdDelegate?
     * If YieldloveAdDelegate is released from memory during ad request,
     * there will be no object on which to call bannerViewDidReceiveAd()
     * or bannerViewDidFailToReceiveAdWithError()
     * If GAMBannerView is released from memory during ad request,
     * none of the delegate methods will be called. Releasing this object
     * signals to the GAM that app has moved on and is not waiting for ad.
     */
    private func keepReference(_ referenceHolder: YLReferenceHolder, ylAd: YLAd) {
        let referenceManager = ylAd.config.referenceManager
        referenceManager.add(referenceHolder: referenceHolder)
        SLogger.i("[AsyncGamAdLoader:\(dbgId)] keepReference ADD holderId=\(referenceHolder.id)")
    }
    
    private func removeReference(_ referenceHolder: YLReferenceHolder, ylAd: YLAd) {
        ylAd.config.referenceManager.remove(referenceHolder: referenceHolder)
        SLogger.i("[AsyncGamAdLoader:\(dbgId)] keepReference REMOVE holderId=\(referenceHolder.id)")
    }
}

// MARK: - Interstitial
extension AsyncGamAdLoader {

    func loadInterstitial(
        requestData: GamInstlRequestData,
        timeEventRecorder: TimeEventRecorder
    ) async throws -> AdManagerInterstitialAd {
        recordGamRequest(timeEventRecorder: timeEventRecorder)
        return try await AdManagerInterstitialAd.load(with: requestData.adUnitData.adUnit, request: requestData.gamRequest)
    }

    private func recordGamRequest(timeEventRecorder: TimeEventRecorder?) {
        timeEventRecorder?.recordGamRequested()
    }

    private func recordGamResponse(timeEventRecorder: TimeEventRecorder, error: Error?) {
        if let err = error {
            timeEventRecorder.recordGamRespondedWithError(error: err)
        } else {
            timeEventRecorder.recordGamRespondedSuccessfully()
        }
    }
}

// MARK: - Rewarded
extension AsyncGamAdLoader {

    func loadRewarded(
        requestData: RewardedRequestData,
        timeEventRecorder: TimeEventRecorder
    ) async throws -> RewardedAd {
        recordGamRequest(timeEventRecorder: timeEventRecorder)
        return try await RewardedAd.load(with: requestData.adUnitData.adUnit, request: requestData.gamRequest)
    }
}
