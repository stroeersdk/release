//
//  GamManager.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 04/08/2025.
//
import Foundation
import GoogleMobileAds

final class GamManager {
    
    private func makeLoader(debugSession: BannerDebugSession?) -> AsyncGamAdLoader {
        AsyncGamAdLoader(debugSession: debugSession)
    }
    // MARK: - Banner APIs (async)
    private init() {}
    static let shared = GamManager()

    func loadBanner(requestData: GamRequestData,
                    banner: YLBanner,
                    reuseView: YLBannerView? = nil,
                    debugSession: BannerDebugSession? = nil) async throws -> YLBannerView {
        let loader = makeLoader(debugSession: debugSession)
        return try await loader.loadBanner(requestData: requestData, banner: banner, reuseView: reuseView)
    }
    
    func refreshBanner(requestData: GamRequestData,
                       ylBanner: YLBanner,
                       bannerView: YLBannerView,
                       debugSession: BannerDebugSession? = nil) async throws -> YLBannerView {
        let loader = makeLoader(debugSession: debugSession)
        return try await loader.refreshBanner(requestData: requestData, ylBanner: ylBanner, bannerView: bannerView)
    }

    func loadInterstitial(
        requestData: GamInstlRequestData,
        timeEventRecorder: TimeEventRecorder,
        debugSession: BannerDebugSession? = nil
    ) async throws -> AdManagerInterstitialAd {
        let loader = makeLoader(debugSession: debugSession)
        return try await loader.loadInterstitial(
            requestData: requestData,
            timeEventRecorder: timeEventRecorder
        )
    }
    
    func loadRewarded(
        requestData: RewardedRequestData,
        timeEventRecorder: TimeEventRecorder,
        debugSession: BannerDebugSession? = nil
    ) async throws -> RewardedAd {
        let loader = makeLoader(debugSession: debugSession)
        return try await loader.loadRewarded(
            requestData: requestData,
            timeEventRecorder: timeEventRecorder
        )
    }
}
