//
//  AsyncGamBannerDelegate.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 04/08/2025.
//


import Foundation
import GoogleMobileAds

/// Forwards GAM delegate events to the publisher delegate, records timing, handles inspection.
final class AsyncGamBannerDelegate: NSObject, BannerViewDelegate, AdDelegate {
    var isRequestInFlight: Bool = false
    
    func isPublisherDelegateNil() -> Bool {
        return publisherDelegate == nil
    }
    

    // MARK: - References
    private let adUnitData: YLAdUnitData
    private let timeEventRecorder: TimeEventRecorder?
    private weak var publisherViewController: UIViewController?
    private weak var publisherDelegate: YLBannerViewDelegate?
    private let debugSession: BannerDebugSession?
    var completion: ((Result<YLBannerView, Error>) -> Void)?
    private let dbgId = UUID().uuidString.prefix(6)

    weak var ylBannerView: YLBannerView?

    // MARK: - Internal

    private var loadCount = 0
    var refreshed: Bool {
        loadCount > 1
    }

    // MARK: - Init

    init(
        adUnitData: YLAdUnitData,
        timeEventRecorder: TimeEventRecorder?,
        publisherViewController: UIViewController?,
        publisherDelegate: YLBannerViewDelegate?,
        debugSession: BannerDebugSession?
    ) {
        self.adUnitData = adUnitData
        self.timeEventRecorder = timeEventRecorder
        self.publisherViewController = publisherViewController
        self.publisherDelegate = publisherDelegate
        self.debugSession = debugSession
        super.init()
        SLogger.i("[AsyncGamBannerDelegate:\(dbgId)] init adUnit=\(adUnitData.adUnit)")
    }

    // MARK: - Delegate Methods

    func bannerViewDidReceiveAd(_ bannerView: BannerView) {
        SLogger.i("[AsyncGamBannerDelegate:\(dbgId)] didReceiveAd)")
        loadCount += 1
        recordGamResponse(error: nil)
        isRequestInFlight = false

        adUnitData.responseIdentifier = bannerView.responseInfo?.responseIdentifier

        let view = resolvedYLBannerView(for: bannerView)
        view.bannerInfo.wasRefreshed = refreshed

        //ensure wrapper updates when refreshed creative size changes
        view.updateSize(to: bannerView.adSize.size)

        attachDebugOrDoubleTap(to: view)
        
        var targeting: [String: String] = [
            "ad unit": bannerView.adUnitID ?? "",
            "banner size": "\(bannerView.adSize)",
            "responseId": bannerView.responseInfo?.responseIdentifier ?? ""
        ]
        
        if let debugSession {
            AdWinnerAnalyzer.instance
                .getWinner(ylBannerView: view)
                .done { winner in
                    targeting["winner"] = "\(winner.rawValue)"
                    debugSession.didReceiveFromGAM(targeting: targeting, adType: "banner", adUnit: self.adUnitData.adUnit)
                }
                .catch { error in
                    targeting["winner"] = "unknown"
                    debugSession.didReceiveFromGAM(targeting: targeting, adType: "banner", adUnit: self.adUnitData.adUnit)
                }
        }

        // Notify delegate + continuation
        SLogger.i("[AsyncGamBannerDelegate:\(dbgId)] completing SUCCESS")
        completion?(.success(view))
        completion = nil
    }

    func bannerView(_ bannerView: BannerView, didFailToReceiveAdWithError error: Error) {
        SLogger.e("[AsyncGamBannerDelegate:\(dbgId)] didFail")
        loadCount += 1
        recordGamResponse(error: error)
        isRequestInFlight = false

        let responseInfo = (error as NSError).userInfo[GADErrorUserInfoKeyResponseInfo] as? ResponseInfo
        adUnitData.responseIdentifier = responseInfo?.responseIdentifier

        SLogger.e("[AsyncGamBannerDelegate] \(adUnitData.adUnit) Error: \(error.localizedDescription)")

        let view = resolvedYLBannerView(for: bannerView)
        view.bannerInfo.wasRefreshed = refreshed

        //keep wrapper size same even on failures/inspection
        view.updateSize(to: bannerView.adSize.size)

        attachDebugOrDoubleTap(to: view)
        
        let targeting: [String: String] = [
            "ad unit": bannerView.adUnitID ?? "",
            "banner size": "\(bannerView.adSize)",
            "responseId": bannerView.responseInfo?.responseIdentifier ?? "",
            "errorMessage": error.localizedDescription
        ]
        
        self.debugSession?.didReceiveFromGAM(targeting: targeting, adType: "banner", adUnit: adUnitData.adUnit)

        if ConfigurationManager.isInspectionMode() {
            completion?(.success(view))
        } else {
            completion?(.failure(error))
        }
        completion = nil
    }

    func bannerViewWillPresentScreen(_ bannerView: BannerView) {
        guard let view = ylBannerView else { return }
        publisherDelegate?.bannerViewWillPresentScreen?(view)
    }

    func bannerViewWillDismissScreen(_ bannerView: BannerView) {
        guard let view = ylBannerView else { return }
        publisherDelegate?.bannerViewWillDismissScreen?(view)
    }

    func bannerViewDidDismissScreen(_ bannerView: BannerView) {
        guard let view = ylBannerView else { return }
        publisherDelegate?.bannerViewDidDismissScreen?(view)
    }
    
    func bannerViewDidRecordClick(_ bannerView: BannerView) {
        guard let view = ylBannerView else { return }
        SLogger.i("[AsyncGamBannerDelegate:\(dbgId)] click")
        publisherDelegate?.bannerViewDidRecordClick?(view)
    }
    
    func bannerViewDidRecordImpression(_ bannerView: BannerView) {
        guard let view = ylBannerView else { return }
        SLogger.i("[AsyncGamBannerDelegate:\(dbgId)] impression")
        publisherDelegate?.bannerViewDidRecordImpression?(view)
    }
    
    // MARK: - Helpers
    private func attachDebugOrDoubleTap(to bannerView: YLBannerView) {
        if ConfigurationManager.isInspectionMode() {
            var timeToServe = TimeInterval()
            if let session = timeEventRecorder?.session {
                timeToServe = YLTimeSessionCalculator.getServedInTime(session: session)
            }
            
            let debugInfo = DebugInfoForStroeer(ConfigurationManager.shared.getAppName() ?? "unknown", adUnitData, timeToServe)
            
            let label = DebugInfoLabelView()
            let sessionToPresent = debugSession
            let consoleStore = ConsoleLogStore.shared
            
            label.buildLabel(adUnitData.publisherCallString, .bannerAd, timeToServe) { [weak bannerView] in
                DispatchQueue.main.async {
                    let presenter = bannerView?.publisherViewController
                    guard let presenter else {
                        SLogger.e("[DebugLabel] No presenter VC available to show debug panel.")
                        return
                    }

                    if let sessionToPresent {
                        let panel = DebugLoggerViewController(session: sessionToPresent, consoleStore: consoleStore)
                        presenter.present(panel, animated: true)
                    } else {
                        let panel = DebugInfoPanelViewController(debugInfo)
                        presenter.present(panel, animated: true)
                    }
                }
            }

            bannerView.createDebugLabelView(debugView: label)
        } else {
            bannerView.addDoubleTapRecognizer()
        }
    }

    private func recordGamResponse(error: Error?) {
        if let err = error {
            timeEventRecorder?.recordGamRespondedWithError(error: err)
        } else {
            timeEventRecorder?.recordGamRespondedSuccessfully()
        }
    }
    
    private func resolvedYLBannerView(for bannerView: BannerView) -> YLBannerView {
        if let existing = ylBannerView {
            existing.publisherViewController = publisherViewController
            existing.publisherDelegate = publisherDelegate
            existing.setBannerView(bannerView: bannerView)
            return existing
        }

        let view = YLBannerView(bannerView: bannerView, bannerInfo: adUnitData)
        view.publisherViewController = publisherViewController
        view.publisherDelegate = publisherDelegate
        ylBannerView = view
        return view
    }
    
    deinit {
        SLogger.i("[AsyncGamBannerDelegate:\(dbgId)] deinit loadCount=\(loadCount) completion_nil=\(completion == nil) inFlight=\(isRequestInFlight)")
    }
}

