enum MonitoringError: LocalizedError {
    case multipleCallsToStartSession
    case multipleCallsToStopSession
    case sessionNotStarted
    case unknownEvent
    case invalidMonitoringUrl
    case addingEventToCompletedSessionNotAllowed
    
    var errorDescription: String? {
        switch self {
        case .multipleCallsToStartSession:
            return "Multiple calls to start session"
        case .multipleCallsToStopSession:
            return "Multiple calls to stop session"
        case .sessionNotStarted:
            return "Session not started"
        case .unknownEvent:
            return "Unknown event"
        case .invalidMonitoringUrl:
            return "Invalid monitoring URL"
        case .addingEventToCompletedSessionNotAllowed:
            return "Adding event to completed session is not allowed"
        }
    }
}
