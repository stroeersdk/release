enum YLError: LocalizedError {
    case bannerSizeNotPassed
    case adRequestDataNil
    case cantInitializePrebid
    case cantResizeBanner
    case invalidBannerSize
    case adUnitDataWasNotSet
    case errorWasReportedByDelegate
    case timeout
    
    var errorDescription: String {
        switch self {
        case .bannerSizeNotPassed:
            return "Banner size not passed"
        case .adRequestDataNil:
            return "Ad request data is nil"
        case .cantInitializePrebid:
            return "Can't initialize Prebid"
        case .cantResizeBanner:
            return "Can't resize banner"
        case .invalidBannerSize:
            return "Invalid banner size"
        case .adUnitDataWasNotSet:
            return "Ad unit data was not set"
        case .errorWasReportedByDelegate:
            return "Error was reported by delegate"
        case .timeout:
            return "No Response from Delegate, Timed Out"
        }
    }
}
