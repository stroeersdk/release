import GoogleMobileAds
import PromiseKit

typealias AdResizeCompletion = () -> Void

protocol AdResizer {
    func resizeAd(banner: YLBannerView, completion: AdResizeCompletion?)
}

class YLAdResizer: AdResizer {
    
    func resizeAd(banner: YLBannerView, completion: AdResizeCompletion?) {
        guard let bannerAd = banner.getBannerView() as? AdManagerBannerView else {
            completion?()
            return
        }
        
        _ = AdWinnerAnalyzer.instance.getWinner(ylBannerView: banner)
            .map { winner in
                if (banner.getSource().adSubSource == AdSource.STROEER) {
                    if let prebidSize = banner.bannerInfo.prebidAdSize, prebidSize != .zero {
                        let newAdSize = adSizeFor(cgSize: prebidSize)
                        bannerAd.resize(newAdSize)
                        bannerAd.adSize = newAdSize
                        banner.updateSize(to: prebidSize)
                        banner.invalidateIntrinsicContentSize()
                        banner.setNeedsLayout()
                        banner.superview?.setNeedsLayout()
                    }
                }
            }
            .done {
                completion?()
            }
    }
}
