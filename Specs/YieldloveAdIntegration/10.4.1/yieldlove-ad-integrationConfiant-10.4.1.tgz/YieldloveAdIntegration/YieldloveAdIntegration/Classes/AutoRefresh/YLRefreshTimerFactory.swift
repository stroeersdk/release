

protocol RefreshTimerFactory {
    func makeTimer(autoRefreshTimeMs: Int, delegate: RefreshTimerDelegate, wrapper: YLBannerView) -> RefreshTimer
}

class YLRefreshTimerFactory: RefreshTimerFactory {
    
    func makeTimer(autoRefreshTimeMs: Int, delegate: RefreshTimerDelegate, wrapper: YLBannerView) -> RefreshTimer {
        let config = YLRefreshTimerConfig(refreshTimeMs: autoRefreshTimeMs, delegate: delegate, wrapper: wrapper)
        return YLRefreshTimer(config: config)
    }

}
