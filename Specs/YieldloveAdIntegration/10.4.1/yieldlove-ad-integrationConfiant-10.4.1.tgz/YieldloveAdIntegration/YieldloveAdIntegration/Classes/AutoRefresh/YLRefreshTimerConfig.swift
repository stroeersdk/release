struct YLRefreshTimerConfig {
    
    let refreshTimeMs: Int
    weak var delegate: RefreshTimerDelegate?
    weak var wrapper: YLBannerView?
    let timerProvider: Timer.Type
    let observableCenter: ObservableCenter
    
    init(refreshTimeMs: Int,
         delegate: RefreshTimerDelegate,
         wrapper: YLBannerView,
         timerProvider: Timer.Type = Timer.self,
         observableCenter: ObservableCenter = NotificationCenter.default
    ) {
        self.refreshTimeMs = refreshTimeMs
        self.delegate = delegate
        self.wrapper = wrapper
        self.timerProvider = timerProvider
        self.observableCenter = observableCenter
    }
}
