import UIKit


protocol RefreshTimerDelegate: AnyObject {
    func refresh()
}

protocol RefreshTimer: AnyObject {
    func start()
    func stop()
}

protocol ObservableCenter {
    func addObserver(_ observer: Any, selector aSelector: Selector, name aName: NSNotification.Name?, object anObject: Any?)
}

extension NotificationCenter: ObservableCenter {
}

class YLRefreshTimer: NSObject, RefreshTimer {

    private static let msInSecond = 1000
    private static let tolerance = 1.0 // timer tolerance saves resources
    
    private weak var delegate: RefreshTimerDelegate?
    private let refreshInSeconds: Double
    private let timerProvider: Timer.Type
    private let observableCenter: ObservableCenter
    private weak var wrapper: AnyObject?
    
    private var state: RefreshTimerState = .initialized

    // Track the active timer so we can prevent duplicates and stop immediately
    private var timer: Timer?

    init(config: YLRefreshTimerConfig) {
        self.refreshInSeconds = Double(config.refreshTimeMs / Self.msInSecond)
        self.delegate = config.delegate
        self.wrapper = config.wrapper
        self.timerProvider = config.timerProvider
        self.observableCenter = config.observableCenter
        super.init()
        listenToAppNotifications()
    }
    
    func start() {
        guard state.isStartable else { return }
        state = .running

        let scheduleOnMain = { [weak self] in
            guard let self else { return }

            // Prevent duplicate timers
            self.timer?.invalidate()
            self.timer = nil

            let t = self.timerProvider.scheduledTimer(withTimeInterval: self.refreshInSeconds, repeats: true) { [weak self] timer in
                self?.fireTimer(timer)
            }
            t.tolerance = Self.tolerance
            self.timer = t
        }

        if Thread.isMainThread {
            scheduleOnMain()
        } else {
            DispatchQueue.main.async(execute: scheduleOnMain)
        }
    }
    
    func stop() {
        guard state.isStoppable else { return }
        state = .stopped
        timer?.invalidate()
        timer = nil
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func fireTimer(_ timer: Timer) {
        switch state {
        case .initialized:
            return
        case .running:
            refresh(timer)
        case .paused:
            timer.invalidate()
            self.timer = nil
        case .stopped:
            destroy(timer)
            self.timer = nil
        }
    }
    
    private func pause() {
        state = .paused
        timer?.invalidate()
        timer = nil
    }
    
    private func refresh(_ timer: Timer) {
        guard wrapper != nil else {
            destroy(timer)
            self.timer = nil
            return
        }
        delegate?.refresh()
    }
    
    private func listenToAppNotifications() {
        observableCenter.addObserver(self,
                                       selector: #selector(appMovedToBackground),
                                       name: UIApplication.willResignActiveNotification,
                                       object: nil)
        observableCenter.addObserver(self,
                                       selector: #selector(appMovedToForeground),
                                       name: UIApplication.didBecomeActiveNotification,
                                       object: nil)
    }
    
    private func destroy(_ timer: Timer) {
        timer.invalidate()
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func appMovedToBackground() {
        pause()
    }
    
    @objc private func appMovedToForeground() {
        start()
    }

    deinit {
        timer?.invalidate()
        timer = nil
        NotificationCenter.default.removeObserver(self)
    }
}
