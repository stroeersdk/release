//
//  JsonBase.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class JsonUtils {
    /// Converts the object to a JSON string.
    static func toJson<T:Codable>(_ instance: T) -> String? {
        do {
            let encoder = JSONEncoder()
            let jsonData = try encoder.encode(instance)
            return String(data: jsonData, encoding: .utf8)
        } catch {
            SLogger.e("[JsonUtils] Failed to convert \(type(of: instance)) to JSON", error)
            return nil
        }
    }
    
    /// Converts the object to a prettified JSON string.
    static func toPrettyJson<T: Codable>(_ instance: T) -> String {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            
            let jsonData = try encoder.encode(instance)
            return String(data: jsonData, encoding: .utf8) ?? ""
        } catch {
            SLogger.e("[JsonUtils] Failed to convert \(type(of: instance)) to pretty JSON", error)
        }
        return ""
    }
    
    /// Parses a JSON string into an object of type `T`.
    static func fromJson<T:Codable> (_ type:T.Type, _ json: String) -> T? {
        guard let jsonData = json.data(using: .utf8) else { return nil }
        do {
            let decoder = JSONDecoder()
            return try decoder.decode(T.self, from: jsonData)
        } catch {
            SLogger.e("[JsonUtils] Failed to parse \(T.self) from JSON", error)
            return nil
        }
    }
}
