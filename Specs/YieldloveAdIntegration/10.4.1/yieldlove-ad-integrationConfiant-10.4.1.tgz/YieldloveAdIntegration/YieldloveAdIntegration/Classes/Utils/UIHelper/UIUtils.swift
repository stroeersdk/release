
//
//  UIUtiles.swift
//  Pods
//
//  Created by Hyungon Kim on 26/06/2025.
//
import UIKit

public class UIUtils{
    
    public static func getRootViewController() -> UIViewController? {
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = scene.windows.first {
            return  window.rootViewController
        }
        return nil
    }
}


extension UIView {
    /// Removes all direct subviews from this view.
    func removeAllSubviews() {
        subviews.forEach { $0.removeFromSuperview() }
    }
}
