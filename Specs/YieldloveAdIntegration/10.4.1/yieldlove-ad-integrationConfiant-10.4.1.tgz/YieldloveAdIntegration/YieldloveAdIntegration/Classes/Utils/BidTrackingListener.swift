//
//  BidTrackingListener.swift
//  Pods
//
//  Created by Shafee Rehman on 04/07/2025.
//
import Foundation

public protocol BidTrackingListener {
    func didSendToPrebid(targeting: [String: String], adType: String, adUnit: String)
    func didReceiveFromPrebid(targeting: [String: String], adUnit: String)
    func didSendToGAM(targeting: [String: String], adUnit: String)
    func didReceiveFromGAM(targeting: [String: String], adType: String, adUnit: String)
    func didRenderViaPrebid(targeting: [String: String], adType: String, adUnit: String)
    func markPrebidSkipped(targeting: ([String: String]), adType: String, adUnit: String)
}
