//
//  ToastMessage.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 19/05/2025.
//

import Foundation
import UIKit

class ToastMessage {
    
    class func show(parentView: UIView,message: String) {
        let toast = UILabel()
        toast.text = message
        toast.textColor = .white
        toast.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        toast.font = .systemFont(ofSize: 14, weight: .medium)
        toast.textAlignment = .center
        toast.alpha = 0
        toast.layer.cornerRadius = 8
        toast.layer.masksToBounds = true
        toast.translatesAutoresizingMaskIntoConstraints = false

        parentView.addSubview(toast)
        
        NSLayoutConstraint.activate([
            toast.centerXAnchor.constraint(equalTo: parentView.centerXAnchor),
            toast.bottomAnchor.constraint(equalTo: parentView.bottomAnchor, constant: -20),
            toast.widthAnchor.constraint(greaterThanOrEqualToConstant: 80),
            toast.heightAnchor.constraint(equalToConstant: 30)
        ])
        
        UIView.animate(withDuration: 0.3, animations: {
            toast.alpha = 1.0
        }) { _ in
            UIView.animate(withDuration: 0.3, delay: 1.0, options: [], animations: {
                toast.alpha = 0.0
            }, completion: { _ in
                toast.removeFromSuperview()
            })
        }
    }
    
    class func alert(viewController: UIViewController, title: String, message: String, complete: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in
            complete?()
        }))

        viewController.present(alert, animated: true, completion: nil)
    }
}
