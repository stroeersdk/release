//
//  ConsentStringDecoder.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 17/03/2025.
//

import Foundation

@objcMembers
public class ConsentStringDecoder{
    public class func isVendorConsentGiven(consentString: String?, vendorId: Int) -> Bool {
        // Check consent vendors
        if let iabAPI = SPTIabTCFApi.decode(TCString: consentString){
            return iabAPI.isVendorConsentGivenFor(vendorId: Int32(ID5Constants.shared.vendorID))
        }
        return false;
    }
}
