import Foundation
import OSLog


public enum LogType: Int, Comparable{
    case info
    case debug
    case error
    case fatal
    
    // Implement Comparable
    public static func < (a: LogType, b: LogType) -> Bool {
        return a.rawValue < b.rawValue
    }
    public static func <= (a: LogType, b: LogType) -> Bool {
        return a.rawValue <= b.rawValue
    }
    public static func >= (a: LogType, b: LogType) -> Bool {
        return a.rawValue >= b.rawValue
    }
}

public enum TraceType: Int{
    case slient
    case stacktrace
}

protocol PSLogger
{
    func info(message: String)
    func debug(message: String)
    func error(message: String)
    func fatal(message: String) -> Never
}

public class SLogger
{
    private static var instance : PSLogger = staticInstantiate()
    private static var formatter = DateFormatter()
    
    
    static func staticInstantiate() -> PSLogger
    {
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        formatter.timeZone = TimeZone.current
        
        if #available(iOS 14.0, *) {
            return SLogger14()
        } else {
            return BaseSLogger()
        }
    }
    
    public static var logType : LogType = LogType.info
    {
        didSet {
            if(oldValue != logType)
            {
                SLogger.i("[StroeerAdMob] Log Mode : \(oldValue) -> \( logType)")
            }
        }
    }
    
    public static var enableTrace : Bool = false
    {
        didSet {
            if(oldValue != enableTrace)
            {
                SLogger.i("[StroeerAdMob] StackTrace Mode : \(oldValue) -> \( enableTrace)")
            }
        }
    }
    
    public static var enableDebug : Bool = false {
        
        didSet {
            if(enableDebug == true)
            {
                logType = LogType.debug
            }
            else
            {
                logType = LogType.info
            }
        }
    }
    
    static func createMessage(_ logType:LogType,_ message:String) -> String {
        var emo : String = ""
        var strType : String = ""
        switch logType {
            case LogType.info:
                emo = "📋"
                strType = "Infos"
            case LogType.debug:
                emo = "🔧"
                strType = "Debug"
            case LogType.error:
                emo = "❗️"
                strType = "Error"
            case LogType.fatal:
                emo = "🧨"
                strType = "Fatal"
        }
        return "\(formatter.string(from: Date())) \(emo)[STRÖER-\(strType)] \(message)"
    }
    
    private static func createStackTrace() -> String {
        return Thread.callStackSymbols.joined(separator: ("\n"))
    }
    
    static func createErrorMessage(_ logType:LogType,_ message:String, error:Error? = nil) -> String
    {
        var msg = createMessage(LogType.error, message)
        if error != nil{
            msg += "\n \(error!.localizedDescription)"
        }
        
        if enableTrace
        {
            msg += createStackTrace()
        }
        return msg
    }
    
    public static func i(_ message: String)
    {
        let msg = createMessage(LogType.info, message)
        SLogger.instance.info(message: msg)
        mirrorToConsoleStore(msg)
    }
    public static func d(_ message: String)
    {
        if(logType >= LogType.debug)
        {
            let msg = createMessage(LogType.debug, message)
            SLogger.instance.debug(message: msg)
            mirrorToConsoleStore(msg)
        }
    }
    public static func e(_ message: String, _ error: Error? = nil)
    {
        let msg = createErrorMessage(LogType.error, message, error: error)
        SLogger.instance.error(message: msg)
        mirrorToConsoleStore(msg)
    }
    public static func f(_ message: String) -> Never
    {
        let msg = createErrorMessage(LogType.fatal, message)
        mirrorToConsoleStore(msg)
        SLogger.instance.fatal(message: msg)
    }
    
    private static func mirrorToConsoleStore(_ msg: String) {
        if ConfigurationManager.isInspectionMode() {
            ConsoleLogStore.shared.append(msg)
        }
    }
}

public class BaseSLogger : PSLogger
{
    public  func info(message: String)
    {
        print(message)
    }
    public func debug(message: String)
    {
        print(message)
    }
    public func error(message: String)
    {
        print(message)
    }
    public func fatal(message: String) -> Never
    {
        print(message)
        exit(0)
    }
}



@available(iOS 14.0,*)
public class SLogger14 :  PSLogger
{
    var logger : os.Logger = os.Logger()
    
    public func info(message: String)
    {
        logger.info("\(message)")
    }
    public func debug(message: String)
    {
        logger.debug("\(message)")
    }
    public func error(message: String)
    {
        logger.error("\(message)")
    }
    public func fatal(message: String) -> Never
    {
        logger.fault("\(message)")
        exit(0)
    }
}
