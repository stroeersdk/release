import GoogleMobileAds

protocol GamBannerViewFactory {
    func makeGAMBannerView(adUnitData: YLAdUnitData, delegate: YLAdDelegate) -> AdManagerBannerView
}

class YLGamBannerViewFactory: GamBannerViewFactory {
    func makeGAMBannerView(adUnitData: YLAdUnitData, delegate: YLAdDelegate) -> AdManagerBannerView {
        let gamBannerView = AdManagerBannerView(adSize: adUnitData.bannerSizes[0])
        gamBannerView.validAdSizes = []
        for adSize in adUnitData.bannerSizes {
            gamBannerView.validAdSizes?.append(nsValue(for: adSize))
        }
        
        gamBannerView.rootViewController = delegate.publisherViewController
        gamBannerView.delegate = delegate
        gamBannerView.adUnitID = adUnitData.adUnit
        
        return gamBannerView
    }
}
