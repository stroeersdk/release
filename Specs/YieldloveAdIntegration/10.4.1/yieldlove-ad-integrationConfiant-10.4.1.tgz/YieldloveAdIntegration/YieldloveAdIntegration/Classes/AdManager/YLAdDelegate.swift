import GoogleMobileAds
import PromiseKit

/*
 since new AsyncGamBannerDelegate uses this AdDelegate, i removed using AdDelegatePromiseBridge and made it to AnyObject
 and added the AdPromiseDelegate below to support both approaches.
 */
protocol AdDelegate: AnyObject /*AdDelegatePromiseBridge*/ {
    var refreshed: Bool { get }
    var ylBannerView: YLBannerView? { get set }
    func isPublisherDelegateNil() -> Bool
    var isRequestInFlight: Bool { get set }
}

/*
 This is used now in refreshBanner in YlGamAdLoader
 */
protocol AdPromiseDelegate: AdDelegate {
    var promise: Promise<YLBannerView> { get }
    func replacePromise()
}

class YLAdDelegate: AdDelegatePromiseBridge, AdPromiseDelegate {
    var isRequestInFlight: Bool = false
    private let adUnitData: YLAdUnitData
    private let timeEventRecorder: TimeEventRecorder?

    weak var publisherViewController: UIViewController?
    weak var publisherDelegate: YLBannerViewDelegate?
    var bidTrackingListener: BidTrackingListener?
    
    var ylBannerView: YLBannerView?
    private var error: Error?
    private var loadCount = 0
   
    var refreshed: Bool {
        return loadCount > 1
    }
    
    init(gamRequestData: GamRequestData, timeEventRecorder: TimeEventRecorder, bannerConfiguration: YLBannerConfiguration, bidTrackingListener: BidTrackingListener? = nil) {
        self.adUnitData = gamRequestData.adUnitData
        self.publisherViewController = gamRequestData.publisherViewController
        self.publisherDelegate = gamRequestData.publisherDelegate
        self.timeEventRecorder = timeEventRecorder
        self.bidTrackingListener = bidTrackingListener
    }
    
    func bannerViewDidReceiveAd(_ bannerView: BannerView) {
        loadCount += 1
        recordGamResponse(timeEventRecorder: timeEventRecorder, error: nil)

        
        let responseInfo = bannerView.responseInfo
        adUnitData.responseIdentifier = responseInfo?.responseIdentifier
        
        let ylBannerView = YLBannerView(bannerView: bannerView, bannerInfo: adUnitData)
        ylBannerView.bannerInfo.wasRefreshed = refreshed
        ylBannerView.publisherViewController = publisherViewController
        
        if ConfigurationManager.isInspectionMode() {
            var timeToServe = TimeInterval()
            if let session = timeEventRecorder?.session {
                timeToServe = YLTimeSessionCalculator.getServedInTime(session: session)
            }
            
            //let debugInfo = DebugInfoForStroeer(ConfigurationManager.shared.getAppName()!, adUnitData, timeToServe)
           // let debugLogger = BannerTrafficDelegator.shared.currentLogger
            
           // let debugInfoController = DebugInfoLabelViewController(adSlotName: adUnitData.publisherCallString!, adType: .bannerAd, debugInfo: debugInfo, debugLogger: debugLogger)
         //   ylBannerView.createDebugLabelView(debugViewController: debugInfoController)

        } else{
            // Add Double Tap Gesture Recognizer to the bannerView
            ylBannerView.addDoubleTapRecognizer()
        }

        
        fulfill(value: ylBannerView)

        if publisherViewController == nil {
            return /* ignore event - ad is to be deallocated */
        }

        self.ylBannerView = ylBannerView
    }
    
    func bannerView(_ bannerView: BannerView, didFailToReceiveAdWithError error: Error) {
        recordGamResponse(timeEventRecorder: timeEventRecorder, error: error)
        loadCount += 1
        
        let responseInfo = (error as NSError).userInfo[GADErrorUserInfoKeyResponseInfo] as? ResponseInfo
        adUnitData.responseIdentifier = responseInfo?.responseIdentifier
        
        SLogger.e("[YLAdDelegate] Error: \(error.localizedDescription)")
        self.error = error
        
        //Creating banner view for inspection label
        let ylBannerView = YLBannerView(bannerView: bannerView, bannerInfo: adUnitData)
        ylBannerView.bannerInfo.wasRefreshed = refreshed
        ylBannerView.publisherViewController = publisherViewController
        
        if ConfigurationManager.isInspectionMode() {
            var timeToServe = TimeInterval()
            if let session = timeEventRecorder?.session {
                timeToServe = YLTimeSessionCalculator.getServedInTime(session: session)
            }
            
            let debugInfo = DebugInfoForStroeer(ConfigurationManager.shared.getAppName()!, adUnitData, timeToServe)
//            let debugLogger = BannerTrafficDelegator.shared.currentLogger
//
//            let debugInfoController = DebugInfoLabelViewController(adSlotName: adUnitData.publisherCallString!, adType: .bannerAd, debugInfo: debugInfo, debugLogger: debugLogger)
//            ylBannerView.createDebugLabelView(debugViewController: debugInfoController)
            
            fulfill(value: ylBannerView)
        } else{
            reject(error: YLError.errorWasReportedByDelegate)
        }
        
        if publisherViewController == nil {
            return /* ignore event - ad is to be deallocated */
        }
    }
    
    func bannerViewWillPresentScreen(_ bannerView: BannerView) {
        if publisherViewController == nil {
            return /* ignore event - ad is to be deallocated */
        }
        let banner = YLBannerView(bannerView: bannerView, bannerInfo: adUnitData)
        publisherDelegate?.bannerViewWillPresentScreen?(banner)
    }
    
    func bannerViewWillDismissScreen(_ bannerView: BannerView) {
        if publisherViewController == nil {
            return /* ignore event - ad is to be deallocated */
        }
        let banner = YLBannerView(bannerView: bannerView, bannerInfo: adUnitData)
        publisherDelegate?.bannerViewWillDismissScreen?(banner)
    }
    
    func bannerViewDidDismissScreen(_ bannerView: BannerView) {
        if publisherViewController == nil {
            return /* ignore event - ad is to be deallocated */
        }
        let banner = YLBannerView(bannerView: bannerView, bannerInfo: adUnitData)
        publisherDelegate?.bannerViewDidDismissScreen?(banner)
    }
    
    func isPublisherDelegateNil() -> Bool {
        return publisherDelegate == nil
    }
    
    private func recordGamResponse(timeEventRecorder: TimeEventRecorder?, error: Error?) {
        if let err = error {
            timeEventRecorder?.recordGamRespondedWithError(error: err)
        } else {
            timeEventRecorder?.recordGamRespondedSuccessfully()
        }
    }
}
