import PromiseKit
import GoogleMobileAds

class AdWinnerAnalyzer {

    static let instance = AdWinnerAnalyzer()

    func getWinner(ylBannerView: YLBannerView) -> Promise<AdWinner> {
        return creativeContainsPrebidCacheId(ylBannerView: ylBannerView)
            .map { containsPrebid in
                if(containsPrebid == true){
                    ylBannerView.bannerInfo.source.adSubSource = AdSource.STROEER
                    return AdWinner.Prebid
                }
                else
                {
                    ylBannerView.bannerInfo.source.adSubSource = AdSource.GOOGLE
                    return AdWinner.GAM
                }
            }
    }

    private func creativeContains(ylBannerView: YLBannerView, searchString: String?) -> Promise<Bool> {
        return Promise { seal in
            if let bannerView = ylBannerView.getBannerView() {
                YLCreativeStringFinder.find(bannerView, searchString,
                                            success: { _ in seal.fulfill(true) },
                                            failure: { _ in seal.fulfill(false) })
            }
            else{
                seal.fulfill(false)
            }
        }
    }

    private func creativeContainsPrebidCacheId(ylBannerView: YLBannerView) -> Promise<Bool> {
        return creativeContains(ylBannerView: ylBannerView, searchString: ylBannerView.bannerInfo.prebidCacheId)
    }
}
