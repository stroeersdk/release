enum AdWinner: String {
    case Prebid
    case GAM
}
