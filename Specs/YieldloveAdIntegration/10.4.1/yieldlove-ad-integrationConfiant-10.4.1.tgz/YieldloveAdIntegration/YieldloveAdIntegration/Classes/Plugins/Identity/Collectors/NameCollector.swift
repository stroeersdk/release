//
//  NameCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation
class NameCollector: IIdentityCollector{
    func retrieveData() async -> String? {
        let config = await ConfigurationManager.shared.getConfigAsync();
        if let config = config {
            return config.common?.dfpiOSAppName
        }
        return "Not Found"
    }
}
