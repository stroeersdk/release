//
//  ID5Constants.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

/// Singleton class for managing ID5 API constants.
class ID5Constants {
    
    /// Returns the shared singleton instance
    static var shared: ID5Constants = ID5Constants();
        
    /// Returns the base URI for the ID5 API
    var baseUri: String {
        return ID5Constants.BASE_URI
    }
    
    /// Returns the name of the shared preference used to store the ID5 cache
    var prefId5Cache: String {
        return ID5Constants.PREF_ID5_CACHE
    }
    
    /// Returns the name of the shared preference used to store the ID5 cache date
    var prefId5CacheDate: String {
        return ID5Constants.PREF_ID5_CACHE_DATE
    }
    
    var prefId5Signature: String {
        return ID5Constants.PREF_ID5_SIGNATURE
    }
    
    /// Returns the timeout in seconds for the ID5 API requests
    var timeoutInSecs: Int {
        return ID5Constants.TIMEOUT_IN_SECS
    }
    
    /// Returns the refresh interval in seconds for the ID5 cache, default is 8 hours
    var refreshIntervalInSecs: Int {
        return ID5Constants.REFRESH_INTERVAL_IN_SECS
    }
    
    /// Returns the delete interval in seconds for the ID5 cache, default is 30 days
    var deleteIntervalInSecs: Double {
        return ID5Constants.DELETE_INTERVAL_IN_SECS
    }
    
    /// Returns the source name for the ID5 API. This is used for Prebid External User ID.
    var source: String {
        return ID5Constants.SOURCE
    }
    
    var vendorID: Int {
        return 131
    }
    
    /// Private initializer to enforce singleton pattern
    private init() {}

    /// Static constants
    private static let BASE_URI = "https://api.id5-sync.com/ga/v1"
    private static let SOURCE = "id5-sync.com"
    private static let TIMEOUT_IN_SECS = 3
    private static let REFRESH_INTERVAL_IN_SECS = 8 * 60 * 60 // 8 hours
    private static var DELETE_INTERVAL_IN_SECS: TimeInterval = 30 * 24 * 60 * 60 // 30 days
    private static let PREF_ID5_CACHE = "ID5_CACHE"
    private static let PREF_ID5_CACHE_DATE = "ID5_CACHE_DATE"
    private static let PREF_ID5_SIGNATURE = "ID5_SIGNATURE"
}
