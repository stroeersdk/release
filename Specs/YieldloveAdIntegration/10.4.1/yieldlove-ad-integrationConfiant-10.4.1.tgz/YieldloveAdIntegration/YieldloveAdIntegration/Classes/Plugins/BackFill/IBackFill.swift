//
//  IBackFill.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 18/11/2024.
//

import Foundation

//
//  IBackfill.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 29/07/2024.
//

import Foundation
import UIKit
import GoogleMobileAds

public protocol IBackFill : AnyObject{
        
    /**
     some SDK require to release the memory. This must be called to release backfill plan memory.
     */
    
    func initialize() -> Void
    
    func viewDidAppear(viewUIController: UIViewController) -> Void
    
    func viewWillDisappear() -> Void
    
    func getBannerLoader() -> IBackFillBanner?
    
    func getInterstitialLoader() -> IBackFillInterstitial?
    
    func enableDebugMode()
    
    func enableTestMode(bundleId: String?, accountId: Int?, forceToExecute: Bool)
    
    func enableInspectionMode()
    
    func setCustomTargeting(targets: [String: [String]])
    
    func setCacheSize(size: Int)
    
    func setPlacementMapTable(stroeerToGravite:Dictionary<String, String>)
    
    func getVersion() -> String
    
    func getDebugInfo() -> IDebugInfo
    
    func getAdsourceInfo() -> AdSourceInfo
}

public class GraviteBannerConfig {
    public var ylAdUnitData: YLAdUnitData?
    public var loaded: IFirstBannerLoaded?
    public var viewController: UIViewController?
}

public protocol IBackFillBanner{
    /**
     Load the banner for back fill
     */
    func loadBanner(config : GraviteBannerConfig) -> Void
    
    /**
     Get a banner created by backfill
     */
    func getBanner(ylAdUnitData: YLAdUnitData, adContainerView: UIView) -> UIView?
}


public class GraviteInterstitialConfig{
    public var ylAdUnitData: YLAdUnitData?
    public var interstitialDelegate: YLInterstitialAdDelegate?
    public var viewController: UIViewController?
}

public protocol IBackFillInterstitial{
    func loadInterstitial(config: GraviteInterstitialConfig) -> Void
    func showInterstitial(ylAdUnitData: YLAdUnitData)
    func isInterstitialAvailable(ylAdUnitData: YLAdUnitData) -> Bool
}
