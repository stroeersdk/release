//
//  BundleCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class BundleCollector: IIdentityCollector {
    func retrieveData() async -> String {
        return Bundle.main.bundleIdentifier ?? "Unknown"
    }
}
