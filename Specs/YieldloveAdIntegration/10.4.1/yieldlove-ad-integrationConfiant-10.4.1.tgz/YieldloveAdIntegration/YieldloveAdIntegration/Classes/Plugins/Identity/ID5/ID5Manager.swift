//
//  ID5Manager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation
import WebKit
import PrebidMobile

class ID5Manager: IIdentityManager {
    
    static var shared: ID5Manager = ID5Manager()

    private var identityData: IdentityCache?
    private var data: ID5Data?
    private var prebidUserId = ExternalUserId(source: ID5Constants.shared.source, uids: [
        UserUniqueID(id: "", aType: NSNumber(value: 1))
    ], ext: [:])

    /// Initializes the ID5Manager with application context and listener.
    func initialize() {
    }

    /// Loads the consent string from storage.
    func loadConsentStringFromStorage() {
        UserDefaults.standard.synchronize()
        let cacheString = UserDefaults.standard.string(forKey: ID5Constants.shared.prefId5Cache)
        let cacheDate = UserDefaults.standard.object(forKey: ID5Constants.shared.prefId5CacheDate) as? TimeInterval ?? TimeInterval.zero
        
        if let cacheString = cacheString, !cacheString.isEmpty {
            
            identityData = IdentityCache()
            identityData!.identityString = cacheString
            data = JsonUtils.fromJson(ID5Data.self, cacheString)
            
            if let data = data {
                identityData?.cacheCreationDate = Date(timeIntervalSince1970: cacheDate)
                
                if ConfigurationManager.isDebugMode() {
                    SLogger.d("[ID5Manager] loadConsentStringFromStorage: Cache found - \(JsonUtils.toPrettyJson(data))")
                } else {
                    SLogger.i("[ID5Manager] loadConsentStringFromStorage: Cache found")
                }
            }
        }else {
            identityData = nil
            SLogger.i("[ID5Manager] loadConsentStringFromStorage: No cache found")
        }
    }

    /// Fetches the consent string via an HTTP request.
    func loadConsentStringFromHttp(retry: Bool) async {
        let requestBody = await ID5RequestBodyBuilder.shared.getRequestBody()
        
        if ((requestBody.gdpr_consent != nil && !requestBody.gdpr_consent!.isEmpty) ||
            (requestBody.gpp_string != nil && !requestBody.gpp_string!.isEmpty)) {
            
            // Check consent vendors
            if !ConsentStringDecoder.isVendorConsentGiven(consentString: requestBody.gdpr_consent, vendorId: ID5Constants.shared.vendorID){
                SLogger.d("[ID5Manager] ID5 is not allowed to use. Disabled by GDPR.")
                identityData = nil
                data = nil
                return;
            }
            
            SLogger.i("[ID5Manager] Loading ID5 from HTTP.")
            
            let request = ID5HttpRequest()
            data = await request.send(requestBody:requestBody)
            
            if let data = data {
                identityData = IdentityCache()
                identityData?.cacheCreationDate = Date()
                identityData?.identityString = JsonUtils.toJson(data) ?? ""
               
                storeIdentityData()
                
                SLogger.d("[ID5Manager] Sucessfuly loaded from HTTP.\n\(JsonUtils.toPrettyJson(data))")
                
            } else {
                SLogger.e("[ID5Manager] Failed to load from HTTP.")
            }
        } else {
            SLogger.d("[ID5Manager] No gdpr/gpp string found. Removing from request body.")
            identityData = nil
            data = nil
        }
    }

    /// Checks if the ID5 request body has been updated.
    func isUpdated() -> Bool {
        return ID5RequestBodyBuilder.shared.isUpdated()
    }

    /// Retrieves the identity data.
    func getIdentityData() -> IdentityCache? {
        return identityData
    }

    /// Sets the Prebid user ID based on ID5 data.
    func setUserIdToPrebid() {
        // Validate cached data
        guard let data = data, let uid = data.universal_uid, uid != "0" else {
            removeExternalUserId(source: ID5Constants.shared.source)
            SLogger.d("[ID5Manager] No valid ID5 data found.")
            return
        }

        // Optional ext for the ExternalUserId
        var eidExt: [String: Any]? = nil
        if let linkType = data.ext?.linkType {
            eidExt = ["linkType": linkType]
        }

        // Build UID entry
        let uuid = UserUniqueID(
            id: uid,
            aType: NSNumber(value: 1),
            ext: eidExt
        )
        
        let eid = ExternalUserId(
            source: ID5Constants.shared.source,   // e.g. "id5-sync.com"
            uids: [uuid],
            ext: nil
        )
        
        prebidUserId = eid
        
        // Get existing from Targeting and map to models
        var eids = mapJsonToExternalUserIds(Targeting.shared.getExternalUserIds() ?? [])

        if let idx = eids.firstIndex(where: { $0.source == eid.source }) {
            eids[idx] = eid
        } else {
            eids.append(eid)
        }

        Targeting.shared.setExternalUserIds(eids)
    }

    /// Gets the current ID5 data.
    func getData() -> ID5Data? {
        return data
    }

    /// Sets custom identity information from provided details.
    func setCustomInfo(customInfo: IdentityCustomInfo?) {
        if let customInfo = customInfo {
            if let email = customInfo.email { ID5RequestBodyBuilder.shared.setEmail(email) }
            if let phone = customInfo.phone { ID5RequestBodyBuilder.shared.setPhone(phone) }
            if let puid = customInfo.puid { ID5RequestBodyBuilder.shared.setPuid(puid) }
            if let regionCode = customInfo.regionCode { ID5RequestBodyBuilder.shared.setRegionCode(regionCode) }
            if let cityCode = customInfo.cityCode { ID5RequestBodyBuilder.shared.setCityCode(cityCode) }
        }
    }
    
    func removeExternalUserId(source: String) {
        var eids = mapJsonToExternalUserIds(Targeting.shared.getExternalUserIds() ?? [])
        eids.removeAll { $0.source == source }
        Targeting.shared.setExternalUserIds(eids)
    }
    
    func storeIdentityData(){
        UserDefaults.standard.set(identityData?.identityString, forKey: ID5Constants.shared.prefId5Cache)
        UserDefaults.standard.set(identityData?.cacheCreationDate.timeIntervalSince1970, forKey: ID5Constants.shared.prefId5CacheDate)
        UserDefaults.standard.set(data?.signature, forKey: ID5Constants.shared.prefId5Signature)
    }
    
    /// Converts JSON dictionaries (from Targeting.shared.getExternalUserIds())
    /// back into model objects ([ExternalUserId]).
    private func mapJsonToExternalUserIds(_ json: [[String: Any]]) -> [ExternalUserId] {
        return json.compactMap { dict in
            // Required: source
            guard let source = dict["source"] as? String else { return nil }

            // Optional ext at the ExternalUserId level
            let eidExt = dict["ext"] as? [String: Any]

            // Parse uids array
            let uidsJson = dict["uids"] as? [[String: Any]] ?? []
            let uids: [UserUniqueID] = uidsJson.compactMap { u in
                guard let id = u["id"] as? String else { return nil }

                // atype can be NSNumber or Int depending on serialization
                let atype: NSNumber = {
                    if let n = u["atype"] as? NSNumber { return n }
                    if let i = u["atype"] as? Int { return NSNumber(value: i) }
                    return NSNumber(value: 1) // safe default
                }()

                let ext = u["ext"] as? [String: Any]
                return UserUniqueID(id: id, aType: atype, ext: ext)
            }

            // Build ExternalUserId model
            return ExternalUserId(source: source, uids: uids, ext: eidExt)
        }
    }
}
