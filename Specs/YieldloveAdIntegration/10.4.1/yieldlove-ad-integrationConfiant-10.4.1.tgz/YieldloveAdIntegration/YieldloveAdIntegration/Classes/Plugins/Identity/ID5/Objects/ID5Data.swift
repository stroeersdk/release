//
//  ID5Data.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class ID5Data: Codable {
    var signature: String?
    var created_at: Date?
    var original_uid: String?
    var universal_uid: String?
    var privacy: ID5DataPrivacy?
    var ext: ID5DataExt?

    enum CodingKeys: String, CodingKey {
        case signature, created_at, original_uid, universal_uid, privacy, ext
    }

    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        signature = try container.decodeIfPresent(String.self, forKey: .signature)
        original_uid = try container.decodeIfPresent(String.self, forKey: .original_uid)
        universal_uid = try container.decodeIfPresent(String.self, forKey: .universal_uid)
        privacy = try container.decodeIfPresent(ID5DataPrivacy.self, forKey: .privacy)
        ext = try container.decodeIfPresent(ID5DataExt.self, forKey: .ext)

        if let dateString = try container.decodeIfPresent(String.self, forKey: .created_at) {
            created_at = ID5Data.decodeISO8601Date(dateString)
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)

        try container.encodeIfPresent(signature, forKey: .signature)
        try container.encodeIfPresent(original_uid, forKey: .original_uid)
        try container.encodeIfPresent(universal_uid, forKey: .universal_uid)
        try container.encodeIfPresent(privacy, forKey: .privacy)
        try container.encodeIfPresent(ext, forKey: .ext)

        if let createdAt = created_at {
            let dateString = ID5Data.encodeISO8601Date(createdAt)
            try container.encode(dateString, forKey: .created_at)
        }
    }

    private static let iso8601WithNanoseconds: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    private static func decodeISO8601Date(_ dateString: String) -> Date? {
        return iso8601WithNanoseconds.date(from: dateString)
    }

    private static func encodeISO8601Date(_ date: Date) -> String {
        return iso8601WithNanoseconds.string(from: date)
    }
}
