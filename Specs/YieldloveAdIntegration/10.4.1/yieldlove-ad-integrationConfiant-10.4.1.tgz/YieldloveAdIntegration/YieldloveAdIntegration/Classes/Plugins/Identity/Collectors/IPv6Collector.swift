//
//  IPv6Collector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation
import Network
import UIKit

/// Collects the IPv6 address (local or public).
class IPv6Collector: IPv4Collector {
    
    func retrieveData() async -> String? {
        async let publicIp = getPublicIPAddress()
        async let localIp = getIPAddress()

        let (pIp, lIp) = await (publicIp, localIp)

        if let pIp = pIp, isIPv6Format(pIp) {
            return pIp
        } else if let lIp = lIp, isIPv6Format(lIp) {
            return lIp
        }
        
        return nil
    }

    /// Retrieves the local IPv6 address (Wi-Fi or cellular).
    func getIPAddress() async -> String? {
        return getNetworkIPAddress(ipv6: true)
    }

    /// Retrieves the public IPv6 address by making a network request.
    func getPublicIPAddress() async -> String? {
        guard let url = URL(string: "https://api64.ipify.org") else { return nil }
        var request = URLRequest(url: url)
        request.timeoutInterval = timeoutInSecs

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                return String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
            }
        } catch {
            SLogger.e("[IPv6Collector] Failed to fetch public IPv6", error)
        }
        return nil
    }

    /// Checks if a given IP is in IPv6 format.
    private func isIPv6Format(_ ip: String) -> Bool {
        let pattern = #"^([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}$"#
        return ip.range(of: pattern, options: .regularExpression) != nil
    }
}
