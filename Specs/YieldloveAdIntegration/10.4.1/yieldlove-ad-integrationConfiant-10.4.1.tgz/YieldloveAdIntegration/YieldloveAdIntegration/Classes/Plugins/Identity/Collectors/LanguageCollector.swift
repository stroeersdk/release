//
//  LanguageCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class LanguageCollector: IIdentityCollector {
    func retrieveData() async -> String {
        let preferredLanguages = Locale.preferredLanguages
        var acceptLanguage = ""

        for (index, languageCode) in preferredLanguages.enumerated() {
            if index == 0 {
                acceptLanguage += "\(languageCode)," // Primary language (default q=1.0)
            } else {
                let priority = String(format: "%.1f", 1.0 - (Double(index) * 0.1))
                acceptLanguage += "\(languageCode);q=\(priority)"
                if index < preferredLanguages.count - 1 {
                    acceptLanguage += ","
                }
            }
        }

        return acceptLanguage
    }
}
