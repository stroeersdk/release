//
//  IPv4Collector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

import Network
import UIKit

/// Collects the IPv4 address (local or public).
class IPv4Collector: IIdentityCollector {
    let emptyIP = "0.0.0.0"
    let awsIPCheckerURL = URL(string: "https://checkip.amazonaws.com/")!
    let timeoutInSecs: TimeInterval = 3

    func retrieveData() async -> String {
        async let publicIp = getPublicIPAddress()
        async let localIp = getIPAddress()

        let (pIp, lIp) = await (publicIp, localIp)

        if let pIp = pIp, isIPv4Format(pIp) {
            return pIp
        } else if let lIp = lIp, isIPv4Format(lIp) {
            return lIp
        }
        return emptyIP
    }

    /// Retrieves the local IP address (Wi-Fi or cellular).
    private func getIPAddress() async -> String? {
        return getNetworkIPAddress(ipv6: false)
    }

    /// Retrieves the public IP address by making a network request.
    private func getPublicIPAddress() async -> String? {
        var request = URLRequest(url: awsIPCheckerURL)
        request.timeoutInterval = timeoutInSecs

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                return String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
            }
        } catch {
            SLogger.e("[IPv4Collector] Failed to fetch public IP", error)
        }
        return nil
    }

    /// Retrieves the device's local IP address (Wi-Fi or cellular).
    func getNetworkIPAddress(ipv6: Bool) -> String? {
        var address: String?

        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0 {
            var ptr = ifaddr
            while ptr != nil {
                defer { ptr = ptr?.pointee.ifa_next }
                let interface = ptr?.pointee

                let addrFamily = interface?.ifa_addr.pointee.sa_family
                if addrFamily == UInt8(AF_INET) || addrFamily == UInt8(AF_INET6) {
                    let name = String(cString: (interface?.ifa_name)!)
                    if name == "en0" { // Wi-Fi interface
                        var addr = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        getnameinfo(interface?.ifa_addr, socklen_t(interface?.ifa_addr.pointee.sa_len ?? 0),
                                    &addr, socklen_t(addr.count), nil, 0, NI_NUMERICHOST)
                        let ipAddress = String(cString: addr)
                        if ipv6 && ipAddress.contains(":") {
                            address = ipAddress
                        } else if !ipv6 && ipAddress.contains(".") {
                            address = ipAddress
                        }
                    }
                }
            }
            freeifaddrs(ifaddr)
        }
        return address
    }

    /// Checks if a given IP is in IPv4 format.
    private func isIPv4Format(_ ip: String) -> Bool {
        let pattern = #"^\b(?:\d{1,3}\.){3}\d{1,3}\b$"#
        return ip.range(of: pattern, options: .regularExpression) != nil
    }
}
