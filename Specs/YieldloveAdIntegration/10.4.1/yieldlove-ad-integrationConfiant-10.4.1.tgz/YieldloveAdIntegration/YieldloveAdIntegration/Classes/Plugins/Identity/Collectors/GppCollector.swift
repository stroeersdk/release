//
//  GppCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class GppCollector: IIdentityCollector {
    private let PREFERENCES_NAME = "IABTCF_GPP"

    func retrieveData() async -> String? {
        let consentString = UserDefaults.standard.string(forKey: PREFERENCES_NAME)
        return consentString?.isEmpty == true ? nil : consentString
    }
}
