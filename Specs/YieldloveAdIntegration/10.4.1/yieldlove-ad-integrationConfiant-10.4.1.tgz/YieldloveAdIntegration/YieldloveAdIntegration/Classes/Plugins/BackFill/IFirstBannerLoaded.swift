//
//  IFirstBannerLoaded.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 19/12/2024.
//

import Foundation

public protocol IFirstBannerLoaded {
    func onFirstBannerLoaded()
}
