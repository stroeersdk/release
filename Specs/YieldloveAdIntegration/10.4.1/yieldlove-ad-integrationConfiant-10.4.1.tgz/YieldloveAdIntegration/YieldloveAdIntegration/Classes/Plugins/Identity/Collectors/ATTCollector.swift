//
//  AATCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 07/03/2025.
//

import Foundation
import AppTrackingTransparency

class ATTCollector: IIdentityCollector{
    func retrieveData() async -> Int {
        let status = ATTrackingManager.trackingAuthorizationStatus
        return status == .authorized ? 1 : 0
    }
}
