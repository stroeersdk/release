//
//  IAdReloader.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 11/10/2024.
//

import Foundation
import UIKit

/// Protocol defining the contract for an Ad Reloader.
/// Classes conforming to this protocol are responsible for managing ad reloading and providing relevant ad slot information.
public protocol IAdReloader: AnyObject {

    /// Retrieves the view associated with the ad.
    /// - Returns: The `UIView` that displays the ad.
    func getView() -> UIView

    /// Retrieves the ad slot identifier.
    /// - Returns: A `String` representing the ad slot ID.
    func getAdSlot() -> String

    /// Reloads an ad for a given slot view and placement ID.
    /// - Parameters:
    ///   - slotView: The `UIView` associated with the ad slot to be reloaded.
    ///   - placementId: A `String` identifying the placement ID for the ad.
    func reloadAd(slotView: UIView, placementId: String) -> Void
}
