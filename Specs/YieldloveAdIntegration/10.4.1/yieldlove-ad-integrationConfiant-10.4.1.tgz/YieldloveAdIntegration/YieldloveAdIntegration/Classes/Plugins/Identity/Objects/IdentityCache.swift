//
//  IdentityCache.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class IdentityCache: Codable {
    private var DEFAULT_REFRESH_INTERVAL: Int = 8 * 60 * 60 // 8 hours in seconds
    
    public var refreshInterval: Int = 0
    public var deleteCacheInterval: Int = 30 * 24 * 60 * 60 // 30 days in seconds
    public var identityString: String = ""
    public var cacheCreationDate: Date = Date()

    func getRefreshInterval() -> Int {
        if refreshInterval == 0 {
            SLogger.d("[IdentityCache] Refresh interval is not set. Using the default value.")
            setDefaultRefreshInterval()
        }
        return refreshInterval
    }

    func setDefaultRefreshInterval() {
        guard let config = ConfigurationManager.shared.getConfig(),
              let id5Module = config.modules?.id5 else {
            SLogger.e("[IdentityCache] ID5 configuration is not set. Using the default refresh interval.")
            self.refreshInterval = DEFAULT_REFRESH_INTERVAL
            return
        }
        self.refreshInterval = id5Module.refreshIntervalInSecs
    }
}
