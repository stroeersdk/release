//
//  AdMonitorRefresher.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 11/10/2024.
//

import Foundation
import SwiftUI

/// A class responsible for managing ad reload operations with retry logic and scheduling.
public class AdMonitorRefresher {

    // MARK: - Constants

    /// Maximum number of retry attempts allowed.
    private let MAX_RETRY_NUM = 2

    // MARK: - Nested Classes

    /// A scheduler class for resetting counters and managing reload tasks for ad slots.
    private class ResetScheduler {
        
        /// Time interval after which the counter will be reset.
        private let RESET_TIME: TimeInterval = 10
        
        /// Counter for tracking reload attempts.
        public var reloaderCounter = 0
        
        /// Timer for scheduling counter resets.
        public var scheduler: Timer?
        
        /// Lock to ensure thread-safe counter operations.
        public let lock = NSLock()
        
        /// Weak reference to the associated ad reloader.
        weak var adReloader: IAdReloader?

        /// Initializes the ResetScheduler with an optional ad reloader.
        /// - Parameter adReloader: An optional `IAdReloader` instance.
        init(adReloader: IAdReloader?) {
            self.adReloader = adReloader
        }

        /// Resets the reload counter to zero.
        func resetCounter() {
            lock.lock()
            reloaderCounter = 0
            lock.unlock()
        }

        /// Increments the reload counter by one.
        func updateCounter() {
            lock.lock()
            reloaderCounter += 1
            lock.unlock()
        }

        /// Starts the scheduler to reset the counter after the specified reset time.
        func startScheduler() {
            // Cancel any previously scheduled reset task.
            scheduler?.invalidate()

            updateCounter()

            // Schedule the counter reset after `RESET_TIME` seconds.
            scheduler = Timer.scheduledTimer(withTimeInterval: RESET_TIME, repeats: false) {
                [weak self] _ in
                guard let monitor = self else { return }
                monitor.resetCounter()
            }
        }
    }

    // MARK: - Properties

    /// Shared singleton instance of `AdMonitorRefresher`.
    public static var shared: AdMonitorRefresher = AdMonitorRefresher()

    /// A dictionary mapping ad slots to their respective reset schedulers.
    private var monitorMaps: [String: ResetScheduler] = [:]

    // MARK: - Initializer

    /// Private initializer to enforce Singleton pattern.
    private init() {}

    // MARK: - Public Methods

    /// Adds a new ad reloader to the monitoring system.
    /// - Parameter adReloader: An `IAdReloader` instance to be monitored.
    public func addNewReloader(adReloader: IAdReloader) {
        let adSlot = adReloader.getAdSlot()

        if let monitor = monitorMaps[adSlot] {
            monitor.adReloader = nil
            monitor.adReloader = adReloader
        } else {
            monitorMaps[adSlot] = ResetScheduler(adReloader: adReloader)
        }
    }

    /// Reloads an ad for the specified slot view and placement ID.
    /// - Parameters:
    ///   - slotView: The `UIView` associated with the ad slot.
    ///   - placementId: The placement ID for the ad slot.
    public func reload(slotView: UIView, placementId: String?) {
        guard let placementId = placementId, let monitor = monitorMaps[placementId] else {
            SLogger.i("[MonitoringPlugin] AdReloader is not initialized")
            return
        }

        // Check if the retry limit has been reached.
        guard monitor.reloaderCounter < MAX_RETRY_NUM else {
            return
        }

        monitor.startScheduler()

        // Call the reload method.
        SLogger.i("[MonitoringPlugin] Attempted to reload - \(placementId) (\(monitor.reloaderCounter) attempt(s))")
        monitor.adReloader?.reloadAd(slotView: slotView, placementId: placementId)
    }
    
    func reset()
    {
        monitorMaps.removeAll()
    }
    
    func getSizeOfMaps() -> Int
    {
        return monitorMaps.count
    }
}
