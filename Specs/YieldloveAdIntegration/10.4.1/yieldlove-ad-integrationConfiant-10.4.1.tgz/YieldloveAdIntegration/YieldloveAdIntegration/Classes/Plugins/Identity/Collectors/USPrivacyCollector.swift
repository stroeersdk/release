//
//  USPravicyCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 07/03/2025.
//

import Foundation

class USPrivacyCollector: IIdentityCollector {
    private let US_PRIVACY_KEY = "IABUSPrivacy_String"

    func retrieveData() async -> String? {
        let usp = UserDefaults.standard.string(forKey: US_PRIVACY_KEY)
        return usp?.isEmpty == true ? nil : usp
    }
}
