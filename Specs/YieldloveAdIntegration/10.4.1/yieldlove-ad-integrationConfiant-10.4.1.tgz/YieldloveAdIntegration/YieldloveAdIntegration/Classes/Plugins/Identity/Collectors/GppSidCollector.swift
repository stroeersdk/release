//
//  GppSidCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

/// Collects the GPP SID from UserDefaults.
class GppSidCollector: IIdentityCollector {
    private let GPP_SID_KEY = "IABGPP_GppSID"

    func retrieveData() async -> String? {
        let gppsid = UserDefaults.standard.string(forKey: GPP_SID_KEY)
        return gppsid?.isEmpty == true ? nil : gppsid 
    }
}
