//
//  ConfiantPlugin.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 11/10/2024.
//

import Foundation

@objcMembers public class ConfiantLoader : NSObject {
    enum ConfiantState: Int, Comparable{
        case notInitialized
        case initialized
        case initializing
        case failed_initialization
        case failed_not_activated
        case failed_no_sdk
        case failed_no_plugin
        case failed_invalid_config
        
        static func < (lhs: ConfiantState, rhs: ConfiantState) -> Bool {
                return lhs.rawValue < rhs.rawValue
            }
    }

    private let tag = "[ConfiantPlugin]"
    // MARK: - Singleton Instance

    /// Shared singleton instance of ConfiantAdapter
    public static var shared = ConfiantLoader()

    // MARK: - Properties

    private var hasConfiant = false
    private var confiantPropertyId: String?
    private var confiantWrapperInstance: IAdMonitoring?
    private var status : ConfiantState = .notInitialized
    private var callback: ((Bool) -> Void)?
    
    private var testMode = false
    private var reloadMode = false

    // MARK: - Initializer

    /// Private initializer to enforce Singleton pattern
    private override init() {}

    // MARK: - Public Methods
        
    /// Initializes the Confiant Plugin
    /// - Parameters:
    ///   - confiantPropertyId: The property ID used by the Confiant SDK.
    ///   - enableReload: A flag to enable or disable reload mode.
    ///   - completion: A closure called with the initialization result (true/false).
    public func initialize(confiantPropertyId: String, enableReload: Bool = false, completion: ((Bool) -> Void)? = nil) {
        
        self.confiantPropertyId = confiantPropertyId
        self.reloadMode = enableReload
        self.callback = completion
        initializeAsync();
    }
    
    private func initializeAsync(){
        Task {
            await self.initialize()
        }
    }
    
    private func initialize() async {
        
        if status >= .failed_not_activated || status == .initializing || isRunnable(){
            return;
        }
        
        if confiantPropertyId == nil || confiantPropertyId!.isEmpty {
            SLogger.e("\(tag) Confiant Property ID is nil or empty")
            status = .failed_invalid_config
            callback?(false)
            return
        }
        
        if isRunnable() || confiantPropertyId == nil || confiantPropertyId!.isEmpty || status != .notInitialized {
            
            if(confiantPropertyId == nil || confiantPropertyId!.isEmpty){
                SLogger.e("\(tag) Confiant Property ID is nil or empty")
                callback?(false)
            }
            
            return
        }
        
        status = .initializing
        
        _ = await ConfigurationManager.shared.getConfigAsync()
                  
        // Configuration is not loaded
        if !ConfigurationManager.shared.isLoaded() {
            SLogger.i("\(tag) Configuration not loaded yet")
            status = .failed_initialization
            callback?(false)
            return
        }
        
        // Check if Confiant is active
        if ConfigurationManager.shared.getConfig()?.modules?.confiant == nil || ConfigurationManager.shared.getConfig()?.modules?.confiant?.active == false{
            status = .failed_not_activated
            SLogger.i("\(tag) Confiant is not active")
            callback?(false)
            return
        }else{
            SLogger.i("\(tag) Confiant is active")
        }
         
        // Load wrapper instance
        if !loadConfiantClasses() {
            self.callback?(false)
            return
        }
        
        if reloadMode {
            confiantWrapperInstance!.enableReload()
        }

        if testMode {
            confiantWrapperInstance!.enableTestMode()
        }

        // Initialize the Confiant plugin instance
        confiantWrapperInstance!.initialize(confiantPropertyId: self.confiantPropertyId!, completetion: {
            [weak self] result in
            guard let self = self else {
                SLogger.e("[ConfiantLoader] Confiant instance is nil")
                return
            }
            self.status = result ? .initialized : .failed_initialization
            callback?(result)
        })
    }

    /// Checks if the Confiant SDK exists
    /// - Returns: A Boolean indicating whether the Confiant SDK is available
    public func doesExist() -> Bool {
        return hasConfiant
    }

    /// Enables test mode for the Confiant SDK
    public func enableTestMode() {
        testMode = true
    }

    /// Marks an ad slot for monitoring
    /// - Parameter adReloader: An optional IAdReloader instance to manage ad reloads
    public func mark(adReloader: IAdReloader) {
        initializeAsync()
        
        if isRunnable() && reloadMode {
            AdMonitorRefresher.shared.addNewReloader(adReloader: adReloader)
            confiantWrapperInstance!.mark(slotView: adReloader.getView(), withPlacementId: adReloader.getAdSlot())
        }
    }
    
    func isRunnable() -> Bool {
        return hasConfiant && status == .initialized && confiantWrapperInstance != nil
    }


    // MARK: - Dependency Injection for Testing

    /// Initializes a ConfiantAdapter instance with a custom IAdMonitoring instance for testing
    /// - Parameter confiantWrapperInstance: An optional IAdMonitoring instance
    init(confiantWrapperInstance: IAdMonitoring? = nil) {
        SLogger.e("\(tag) Initializing ConfiantLoader with custom instance. This should not be called in production.")
        self.confiantWrapperInstance = confiantWrapperInstance
        hasConfiant = true
    }
    
    func reset(){
        SLogger.e("\(tag) Resetting ConfiantLoader. This should not be called in production.")
        ConfiantLoader.shared = ConfiantLoader()
        hasConfiant = false
    }
    
    func updateStatus(status: ConfiantState){
        SLogger.e("\(tag) Updating status. This should not be called in production.")
        self.status = status
    }
    
    private func loadConfiantClasses() -> Bool{
        if confiantWrapperInstance != nil {
            return true
        }
            
        // Attempt to load the ConfiantWrapper class dynamically
        guard let confiantWrapperClass = loadConfiantWrapper() else {
            SLogger.i("\(tag) Confiant Plugin not found")
            status = .failed_no_plugin
            hasConfiant = false
            return false
        }

        SLogger.i("\(tag) Confiant Plugin found")
        
        // Try to initialize the ConfiantWrapper instance
        guard let instance = confiantWrapperClass.init() as? IAdMonitoring else {
            SLogger.i("\(tag) Failed to create Confiant Instance")
            status = .failed_no_sdk
            hasConfiant = false
            return false
        }
        
        SLogger.i("\(tag) Confiant Plugin is Loaded")
        confiantWrapperInstance = instance
        hasConfiant = true
        
        return true
    }
    
    private func loadConfiantWrapper() -> NSObject.Type? {
        SLogger.i("Getting ConfiantWrapper")
        // Try the plugin module first, keep legacy as fallback
        for name in ["YieldloveAdIntegration_Confiant.ConfiantWrapper",
                     "YieldloveAdIntegration.ConfiantWrapper"] {
            SLogger.i("Checking for ConfiantWrapper in module: \(name)")
            if let t = NSClassFromString(name) as? NSObject.Type { return t }
        }
        return nil
    }
}
