//
//  VersionCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

/// Collects the app version name from the Info.plist.
class VersionCollector: IIdentityCollector {
    func retrieveData() async -> String {
        if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            return version
        } else {
            SLogger.e("[VersionCollector] Failed to get version name")
            return "Unknown"
        }
    }
}
