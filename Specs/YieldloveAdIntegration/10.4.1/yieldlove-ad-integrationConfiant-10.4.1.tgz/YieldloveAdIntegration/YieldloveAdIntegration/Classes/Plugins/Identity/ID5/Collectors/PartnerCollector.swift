//
//  PartnerCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class PartnerCollector: IIdentityCollector {
    func retrieveData() async -> Int {
        return 433;
    }
}
