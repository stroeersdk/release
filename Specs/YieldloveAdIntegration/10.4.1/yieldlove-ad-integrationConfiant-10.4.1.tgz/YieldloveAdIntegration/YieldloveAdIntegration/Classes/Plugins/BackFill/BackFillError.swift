//
//  BackFillError.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 15/08/2024.
//

import Foundation

enum BackFillError: Error {
    case forceToExecute
    case directCallToGravite
}
