//
//  GravitePlugin.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 26/09/2024.
//

import Foundation
import UIKit
import UIKit

/**
 A singleton class that manages the initialization and configuration of the Gravite plugin.
 
 Responsibilities:
 - Check if the Gravite plugin is available.
 - Create and hold a reference to the Gravite wrapper (`IBackFill`).
 - Configure settings like debug mode, test mode, cache size, etc.
 - Provide helper functions to set up custom targeting, retrieve loaders, and get version info.
 */
@objcMembers public class GraviteLoader: NSObject {
    
    // MARK: - Properties
    
    /// Tag used to prefix log statements for easier debugging.
    private let tag = "[GravitePlugin]"
    
    /// Shared singleton instance.
    public static let shared = GraviteLoader()
    
    /// Holds the Gravite wrapper instance that conforms to `IBackFill` protocol.
    private var graviteWrapperInstance: IBackFill?
    
    /// If `true`, runs the plugin in debug mode for additional log output.
    private var debugMode = false
    
    /// If `true`, runs the plugin in test mode for special testing configurations.
    private var testMode = false
    
    /// Account ID used for test mode.
    private var testAcountId: Int?
    
    /// Bundle ID used for test mode.
    private var testBundleId: String?
    
    /// If `true`, forces execution of the test mode (useful for debugging).
    private var forceToExecute: Bool = false
    
    /// Indicates whether Gravite has started.
    private var isStarted: Bool = false
    
    /// If `true`, it allows direct calling of Gravite (bypassing certain normal flow).
    private var directGraviteCall: Bool = false
    
    /// Size of the cache to be used by Gravite.
    private var cacheSize: Int = 1
    
    /// Optional dictionary that maps Stroeer placements to Gravite placements.
    private var stroeerToGravitePlacementMapTable: [String: String]? = nil
    
    // MARK: - Initializers
    
    /**
     Private initializer to ensure only one instance of `GraviteLoader` exists.
     */
    private override init() {}
    
    // MARK: - Public Methods
    
    /**
     Initializes the Gravite plugin and configures it based on the properties set on this class.
     
     - Parameter completion: An optional closure that returns a `Bool` indicating whether initialization was successful.
     */
    public func initialize(completion: ((Bool) -> Void)? = nil) {
        // Try to find the Gravite wrapper class by its string name.
        guard let graviteWrapperClass = loadGraviteWrapper() else {
            SLogger.i("\(tag) GravitePlugin not found")
            completion?(false)
            return
        }
        
        SLogger.i("\(tag) GravitePlugin found")
        
        // Attempt to create an instance of the wrapper that conforms to IBackFill.
        guard let instance = graviteWrapperClass.init() as? IBackFill else {
            SLogger.e("\(tag) Failed to create Gravite Instance")
            completion?(false)
            return
        }
        
        // Store the instance for further usage.
        graviteWrapperInstance = instance
        
        // Enable debug mode if specified.
        if debugMode {
            instance.enableDebugMode()
        }
        
        // Enable test mode if specified, passing in optional parameters.
        if testMode {
            instance.enableTestMode(bundleId: testBundleId, accountId: testAcountId, forceToExecute: forceToExecute)
        }
        
        // Initialize the Gravite instance.
        instance.initialize()
        
        // Set the cache size.
        instance.setCacheSize(size: cacheSize)
        
        // If a placement map table is provided, set it on the Gravite instance.
        if let placementMapTable = stroeerToGravitePlacementMapTable {
            instance.setPlacementMapTable(stroeerToGravite: placementMapTable)
        }
        
        isStarted = true
        completion?(true)
    }
    
    /**
     Enables test mode with optional parameters.
     
     - Parameter bundleId: Optional bundle identifier for the test mode.
     - Parameter accountId: Optional account identifier for the test mode.
     - Parameter forceToExecute: If `true`, forces the Gravite plugin to run in test mode regardless of other settings.
     */
    public func enableTestMode(bundleId: NSString?, accountId: NSNumber?, forceToExecute: Bool = false) {
        testMode = true
        testAcountId = accountId?.intValue
        testBundleId = bundleId as String?
        self.forceToExecute = forceToExecute
    }
    
    
    /// Enables debug mode, producing additional log output for troubleshooting.
    public func enableDebugMode() {
        debugMode = true
    }
    
    /// Enables direct call to Gravite, bypassing some parts of the normal flow.
    public func enableDirectGraviteCall() {
        directGraviteCall = true
    }
    
    /**
     Sets the size of the cache for Gravite.
     
     - Parameter size: The size of the cache to be used.
     */
    public func setCacheSize(size: Int) {
        SLogger.i("\(tag) Cache size is set to \(size)")
        cacheSize = size
    }
    
    /**
     Accepts a dictionary mapping Stroeer placements to Gravite placements, logs it for debugging,
     and stores it for future reference.
     
     - Parameter stroeerToGravite: Dictionary of Stroeer-to-Gravite placement mappings.
     */
    public func setPlacementMapTable(stroeerToGravite: [String: String]) {
        // Build a multi-line string of the mapping table
        var sb = ""
        for (key, value) in stroeerToGravite {
            sb += "(\(key) -> \(value)),"
        }
        
        // Log the result
        SLogger.i("\(tag) Placement Map Table: \(sb)")
        
        // Store the mapping table
        stroeerToGravitePlacementMapTable = stroeerToGravite
    }
    
    /**
     Notifies the Gravite plugin that a view controller has appeared, allowing it
     to handle lifecycle events if needed.
     
     - Parameter viewController: The `UIViewController` that has just appeared on screen.
     */
    public func viewDidAppear(viewController: UIViewController) {
        graviteWrapperInstance?.viewDidAppear(viewUIController: viewController)
    }
    
    /**
     Notifies the Gravite plugin that a view controller is about to disappear,
     allowing it to handle lifecycle events if needed.
     
     - Parameter viewController: The `UIViewController` that is about to disappear.
     */
    public func viewWillDisappear(viewController: UIViewController) {
        graviteWrapperInstance?.viewWillDisappear()
    }
    
    /**
     Retrieves a banner loader that conforms to `IBackFillBanner` for banner ad requests.
     
     - Returns: An optional `IBackFillBanner` instance, or `nil` if unavailable.
     */
    public func getBannerLoader() -> IBackFillBanner? {
        return graviteWrapperInstance?.getBannerLoader()
    }
    
    /**
     Retrieves an interstitial loader that conforms to `IBackFillInterstitial` for interstitial ad requests.
     
     - Returns: An optional `IBackFillInterstitial` instance, or `nil` if unavailable.
     */
    public func getInterstitialLoader() -> IBackFillInterstitial? {
        return graviteWrapperInstance?.getInterstitialLoader()
    }
    
    /**
     Indicates whether Gravite is started and forced to execute (e.g., in test mode).
     
     - Returns: `true` if Gravite has started and forced execution is enabled, otherwise `false`.
     */
    public func isForceToExcute() -> Bool {
        return isStarted && forceToExecute
    }
    
    public func isDirectGraviteCall() -> Bool{
        return isStarted && directGraviteCall;
    }
    
    public func isGraviteStarted() -> Bool{
        return isStarted
    }
    
    /**
     Sets custom targeting parameters for Gravite ads.
     
     - Parameter targets: A dictionary where each key is a target parameter,
                          and each value is an array of strings representing possible values.
     */
    public func setCustomTargets(targets: [String: [String]]) {
        graviteWrapperInstance?.setCustomTargeting(targets: targets)
    }
    
    /**
     Returns the version string of the Gravite SDK, or "Unknown" if unavailable.
     
     - Returns: A `String` representing the Gravite SDK version.
     */
    public func getVersion() -> String {
        return graviteWrapperInstance?.getVersion() ?? "Unknown"
    }
    
    /**
     Builds an `AdSourceInfo` object containing information about the Gravite ad source.
     
     - Returns: An `AdSourceInfo` object with the ad source type set to `.Gravite` and its version.
     */
    public func getAdSource() -> AdSourceInfo {
        if isStarted == true, let graviteWrapperInstance = graviteWrapperInstance {
            return graviteWrapperInstance.getAdsourceInfo()
        }
        else
        {
            return AdSourceInfo.getUnknowAdSource()
        }
    }
    
    public func getDebugInfo() -> IDebugInfo? {
        if ConfigurationManager.isInspectionMode() {
            return graviteWrapperInstance?.getDebugInfo()
        }
        return nil
    }
    
    public func enableInspectionMode(){
        graviteWrapperInstance?.enableInspectionMode()
    }
    
    private func loadGraviteWrapper() -> NSObject.Type? {
        SLogger.i("Getting GraviteWrapper")
        // Try the plugin module first, keep legacy as fallback
        for name in ["YieldloveAdIntegration_Gravite.GraviteWrapper",
                     "YieldloveAdIntegration.GraviteWrapper"] {
            SLogger.i("Checking for GraviteWrapper in module: \(name)")
            if let t = NSClassFromString(name) as? NSObject.Type { return t }
        }
        return nil
    }
}
