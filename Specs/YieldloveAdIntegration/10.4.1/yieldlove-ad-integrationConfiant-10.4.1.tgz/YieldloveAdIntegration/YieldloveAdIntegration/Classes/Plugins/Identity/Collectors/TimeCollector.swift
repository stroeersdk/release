//
//  TimeCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class TimeCollector : IIdentityCollector{
    private let timeFormat = "yyyy-MM-dd'T'HH:mm:ssXXX"
    
    func retrieveData() async -> String? {
        let now = Date()

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = timeFormat
        dateFormatter.timeZone = TimeZone.current

        let formattedDateTime = dateFormatter.string(from: now)
        return formattedDateTime
    }
}
