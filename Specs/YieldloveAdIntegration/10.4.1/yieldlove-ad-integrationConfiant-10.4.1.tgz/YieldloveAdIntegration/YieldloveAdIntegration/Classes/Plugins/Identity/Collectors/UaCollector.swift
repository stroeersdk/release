//
//  UaCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation
import WebKit

/// Collects the default User-Agent string.
class UaCollector: IIdentityCollector {
    func retrieveData() async -> String {
        return await MainActor.run{
            let userAgent = WKWebView().value(forKey: "userAgent")
            if(userAgent == nil){
                return "Unknown User-Agent"
            }
            return userAgent as! String
        }
    }
}
