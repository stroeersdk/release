//
//  IIdentityManager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

import Foundation

protocol IIdentityManager {
    func initialize()
    func loadConsentStringFromHttp(retry: Bool) async
    func loadConsentStringFromStorage()
    func getIdentityData() -> IdentityCache?
    func isUpdated() -> Bool
    func setUserIdToPrebid()
    func setCustomInfo(customInfo: IdentityCustomInfo?)
}
