//
//  MaidCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation
import AdSupport
import AppTrackingTransparency


/// Collects the mobile advertising ID (IDFA) on iOS.
class MaidCollector: IIdentityCollector {
    func retrieveData() async -> String? {
        let idfa = ASIdentifierManager.shared().advertisingIdentifier.uuidString
        if idfa == "00000000-0000-0000-0000-000000000000" {
            return nil
        }

        return idfa
    }
}
