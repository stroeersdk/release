//
//  IIdentityCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 05/03/2025.
//

import Foundation

protocol IIdentityCollector {
    associatedtype T
    func retrieveData() async -> T
}
