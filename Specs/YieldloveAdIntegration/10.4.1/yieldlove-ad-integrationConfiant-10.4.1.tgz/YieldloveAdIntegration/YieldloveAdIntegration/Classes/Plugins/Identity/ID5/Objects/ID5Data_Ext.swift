//
//  ID5Data_Ext.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class ID5DataExt: Codable {
    var linkType: Int?
}
