//
//  IdentityCustomeInfo.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

@objcMembers
public class IdentityCustomInfo: NSObject{
    public var email: String?
    public var phone: String?
    public var puid: String?
    public var regionCode: String?
    public var cityCode: String?
    
    override public init(){
        super.init()
    }
}
