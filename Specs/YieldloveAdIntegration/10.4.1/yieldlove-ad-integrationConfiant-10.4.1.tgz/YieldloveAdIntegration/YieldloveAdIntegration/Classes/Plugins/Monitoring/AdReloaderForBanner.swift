//
//  AdReloaderForBanner.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 30/10/2024.
//

import Foundation
import UIKit

/// Extension of `YLBanner` to conform to the `IAdReloader` protocol.
/// Provides methods to manage ad views, retrieve ad slot information, and reload ads.
extension YLBanner: IAdReloader {

    /// Retrieves the current view associated with the banner.
    /// - Returns: The `UIView` that displays the banner ad. Returns an empty `UIView` if no view is available.
    func getView() -> UIView {
        if let view = currentView {
            return view as UIView
        } else {
            SLogger.e("[Monitoring] Failed to get a banner view")
            return UIView()
        }
    }

    /// Retrieves the placement ID for the ad slot.
    /// - Returns: A `String` representing the ad slot's placement ID.
    func getAdSlot() -> String {
        return self.publisherCallString!
    }

    /// Reloads a banner ad for the specified slot view and placement ID.
    /// - Parameters:
    ///   - slotView: The `UIView` associated with the ad slot.
    ///   - placementId: A `String` identifying the placement ID for the ad.
    func reloadAd(slotView: UIView, placementId: String) {
            // Attempt to load the ad with the provided placement ID and ad unit data.
        load(adSlotId: placementId, graviteHandler: graviteHandler)
    }
}
