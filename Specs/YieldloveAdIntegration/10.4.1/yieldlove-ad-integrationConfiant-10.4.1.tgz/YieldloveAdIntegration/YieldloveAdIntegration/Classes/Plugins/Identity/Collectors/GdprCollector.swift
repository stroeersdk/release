//
//  GdprCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class GdprCollector: IIdentityCollector {
    func retrieveData() async -> Int? {
        let consentString = await GdprConsentCollector().retrieveData()
        return (consentString?.isEmpty == false) ? 1 : nil
    }
}
