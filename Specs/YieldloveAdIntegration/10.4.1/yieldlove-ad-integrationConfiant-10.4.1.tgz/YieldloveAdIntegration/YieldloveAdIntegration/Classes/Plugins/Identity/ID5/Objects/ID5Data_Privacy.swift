//
//  ID5Data_Privacy.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class ID5DataPrivacy: Codable {
    var jurisdiction: String?
    var id5_consent: Bool?
}
