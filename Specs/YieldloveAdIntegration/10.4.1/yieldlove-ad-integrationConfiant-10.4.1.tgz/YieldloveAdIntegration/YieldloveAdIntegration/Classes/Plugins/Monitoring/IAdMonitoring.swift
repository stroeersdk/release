//
//  IAdMonitoring.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 10/10/2024.
//

import Foundation
import SwiftUI

/// Protocol defining the interface for ad monitoring functionalities.
/// Classes conforming to this protocol are responsible for managing ad monitoring,
/// including initialization, test mode, reload mode, and marking ads.
public protocol IAdMonitoring {

    /// Enables test mode for ad monitoring.
    /// Test mode allows for testing ads without actual production behavior.
    func enableTestMode()

    /// Enables reload functionality for ad monitoring.
    /// Allows monitored ads to be reloaded when necessary.
    func enableReload()

    /// Initializes the ad monitoring system.
    /// - Parameters:
    ///   - confiantPropertyId: A `String` representing the property ID used by the monitoring system.
    ///   - completetion: A closure called with a `Bool` indicating the success or failure of initialization.
    func initialize(confiantPropertyId: String, completetion: @escaping (Bool) -> Void)

    /// Marks a slot view for ad monitoring.
    /// - Parameters:
    ///   - slotView: A `UIView` representing the ad slot to be monitored.
    ///   - placementId: A `String` representing the placement ID of the ad.
    func mark(slotView: UIView, withPlacementId placementId: String)
}
