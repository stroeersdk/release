//
//  ID5RequestBodyBuilder.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 07/03/2025.
//

import Foundation
import CryptoKit
import WebKit

class ID5RequestBodyBuilder {
    static var shared : ID5RequestBodyBuilder = ID5RequestBodyBuilder()
    
    var requestBody = ID5RequestBody()
    var collectors: [String: any IIdentityCollector] = [:]
    
    init() {
        collectors["ip"] = IPv4Collector()
        collectors["ip6"] = IPv6Collector()
        collectors["bundle"] = BundleCollector()
        collectors["country"] = CountryCodeCollector()
        collectors["gdpr"] = GdprCollector()
        collectors["gdpr_consent"] = GdprConsentCollector()
        collectors["gpp_string"] = GppCollector()
        collectors["gppSid"] = GppSidCollector()
        collectors["language"] = LanguageCollector()
        collectors["maid"] = MaidCollector()
        collectors["maidType"] = MaidTypeCollector()
        collectors["name"] = NameCollector()
        collectors["ts"] = TimeCollector()
        collectors["partner"] = PartnerCollector()
        collectors["ver"] = VersionCollector()
        collectors["ua"] = UaCollector()
        collectors["signature"] = SignatureCollector()
        collectors["us_privacy"] = USPrivacyCollector()
        collectors["att"] = ATTCollector()
    }
    
    func setEmail(_ email: String) {
        requestBody.hem = hash(normalizeEmail(email))
    }
    
    func setPhone(_ phone: String) {
        requestBody.phone = hash(normalizePhoneNumber(phone))
    }
    
    func setPuid(_ puid: String) {
        requestBody.puid = puid
    }
    
    func setRegionCode(_ regionCode: String) {
        requestBody.region = regionCode
    }
    
    func setCityCode(_ cityCode: String) {
        requestBody.city = cityCode
    }
    
    func setSegments(_ segments: [ID5Segment]) {
        requestBody.segments = segments
    }
    
    func isUpdated() -> Bool {
        
        let dispatchGroup = DispatchGroup()
        let timeout: TimeInterval = 2.0 // Maximum wait time in seconds

        dispatchGroup.enter()
        Task {
            if let gdprConsentCollector = collectors["gdpr_consent"] {
                requestBody.gdpr_consent = await gdprConsentCollector.retrieveData() as? String
            }
            
            if let gppStringCollector = collectors["gpp_string"] {
                requestBody.gpp_string = await gppStringCollector.retrieveData() as? String
            }
            dispatchGroup.leave()
        }

        // This won't take long time. So, just run it
        let _ = dispatchGroup.wait(timeout: .now() + timeout)
        
        return requestBody.isUpdated
        
    }
    
    func getRequestBody() async -> ID5RequestBody {
        
        requestBody.resetUpdated()
        
        let updatedRequestBody = ID5RequestBody()
        var results: [String: Any] = [:]
        
        await withTaskGroup(of: (String, Any?).self) { group in
            for (key, collector) in collectors {
                group.addTask {
                    if let ipv6Collector = collector as? IPv6Collector {
                       return (key, await ipv6Collector.retrieveData())
                   } else {
                       return (key, await collector.retrieveData())
                   }
                }
            }
            
            for await (key, result) in group {
                results[key] = result
            }
        }
            
        updatedRequestBody.ip = results["ip"] as? String
        updatedRequestBody.ipv6 = results["ip6"] as? String
        updatedRequestBody.bundle = results["bundle"] as? String
        updatedRequestBody.appId = results["bundle"] as? String
        updatedRequestBody.country = results["country"] as? String
        updatedRequestBody.gdpr = results["gdpr"] as? Int
        updatedRequestBody.gdpr_consent = results["gdpr_consent"] as? String
        updatedRequestBody.gpp_string = results["gpp_string"] as? String
        updatedRequestBody.gpp_sid = results["gppSid"] as? String
        updatedRequestBody.accept_language = results["language"] as? String
        updatedRequestBody.maid = results["maid"] as? String
        updatedRequestBody.maid_type = results["maidType"] as? String
        updatedRequestBody.ts = results["ts"] as? String
        updatedRequestBody.partner = results["partner"] as? Int
        updatedRequestBody.ver = results["ver"] as? String
        updatedRequestBody.ua = results["ua"] as? String
        updatedRequestBody.signature = results["signature"] as? String
        updatedRequestBody.usPrivacy = results["us_privacy"] as? String
        updatedRequestBody.name = results["name"] as? String
        updatedRequestBody.att = results["att"] as? Int
        
        updatedRequestBody.hem = requestBody.hem
        updatedRequestBody.phone = requestBody.phone
        updatedRequestBody.puid = requestBody.puid
        updatedRequestBody.region = requestBody.region
        updatedRequestBody.city = requestBody.city
        
        updatedRequestBody.resetUpdated()
        requestBody = updatedRequestBody
        
        return requestBody
    }
    
    private func hash(_ source: String?) -> String? {
        guard let source = source else { return nil }
        let data = Data(source.utf8)
        let hashed = SHA256.hash(data: data)
        return hashed.compactMap { String(format: "%02x", $0) }.joined()
    }
    
    private func normalizeEmail(_ email: String) -> String? {
        guard !email.isEmpty else {
            SLogger.e("[ID5RequestBodyBuilder] Email is null or empty")
            return nil
        }
        
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard let atIndex = trimmedEmail.firstIndex(of: "@") else {
            SLogger.e("[ID5RequestBodyBuilder] Invalid email format: \(email)")
            return trimmedEmail
        }
        
        var username = String(trimmedEmail[..<atIndex])
        let domain = String(trimmedEmail[trimmedEmail.index(after: atIndex)...])
        
        if let plusIndex = username.firstIndex(of: "+") {
            username = String(username[..<plusIndex])
        }
        
        username = username.replacingOccurrences(of: ".", with: "")
        return "\(username)@\(domain)"
    }
    
    private func normalizePhoneNumber(_ phoneNumber: String) -> String? {
        let allowedCharacters = CharacterSet.decimalDigits.union(CharacterSet(charactersIn: "+"))
        let cleanedNumber = phoneNumber.unicodeScalars.filter { allowedCharacters.contains($0) }.map { String($0) }.joined()
        
        if cleanedNumber.hasPrefix("+") {
            return cleanedNumber
        } else {
            return "+" + cleanedNumber
        }
    }
}
