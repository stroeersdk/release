//
//  ID5HttpRequest.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 07/03/2025.
//

import Foundation

class ID5HttpRequest {

    /**
     Sends an ID5 request and returns the parsed response.
     
     - Parameter requestBody: ID5 request body.
     - Returns: `ID5Data?` if successful, `nil` otherwise.
     */
    func send(requestBody: ID5RequestBody) async -> ID5Data? {
        guard isValid(requestBody: requestBody) else {
            return nil
        }
        
        guard let json = await sendRequest(requestBody: requestBody) else {
            return nil
        }
        
        if let data = JsonUtils.fromJson(ID5Data.self, json) {
            return data
        }
        
        return nil
    }

    /**
     Constructs and sends the HTTP request.
     
     - Parameter requestBody: ID5 request body.
     - Returns: JSON response as a string, `nil` if the request fails.
     */
    private func sendRequest(requestBody: ID5RequestBody) async -> String? {
        guard let url = URL(string: ID5Constants.shared.baseUri) else {
            SLogger.e("[ID5HttpRequest] Invalid URL")
            return nil
        }
        
        SLogger.d("[ID5HttpRequest] Sending request to \(url) with body \n\(JsonUtils.toPrettyJson(requestBody))")
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = TimeInterval(ID5Constants.shared.timeoutInSecs)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        request.httpBody = JsonUtils.toJson(requestBody)?.data(using: .utf8)
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                SLogger.e("[ID5HttpRequest] Request failed with status: \((response as? HTTPURLResponse)?.statusCode ?? -1)")
                return nil
            }
            return String(data: data, encoding: .utf8)
        } catch {
            SLogger.e("[ID5HttpRequest] Network request failed: \(error)")
            return nil
        }
    }

    /**
     Validates the request body.
     
     - Parameter requestBody: ID5 request body.
     - Returns: `true` if valid, `false` otherwise.
     */
    private func isValid(requestBody: ID5RequestBody) -> Bool {
        if requestBody.ts == nil { return logInvalid("Timestamp is nil") }
        if requestBody.partner == nil { return logInvalid("Partner is nil") }
        if requestBody.bundle == nil { return logInvalid("Bundle is nil") }
        if requestBody.ver == nil { return logInvalid("Version is nil") }
        if requestBody.ip == nil { return logInvalid("IP is nil") }
        if requestBody.ua == nil { return logInvalid("User agent is nil") }
        return true
    }

    /**
     Logs validation failures.
     
     - Parameter message: Error message.
     - Returns: Always returns `false`.
     */
    private func logInvalid(_ message: String) -> Bool {
        SLogger.e("[ID5HttpRequest] \(message)")
        return false
    }
}
