//
//  SignatureCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation


class SignatureCollector: IIdentityCollector {
    func retrieveData() async -> String? {
        let signature = UserDefaults.standard.string(forKey: ID5Constants.shared.prefId5Signature)
        return signature?.isEmpty == true ? nil : signature
    }
}
