//
//  IdentityManager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 10/03/2025.
//

import Foundation

@objcMembers
public class IdentityManager : NSObject{
    public static var shared = IdentityManager()

    private var identityManager: IIdentityManager?
    private var customInfo: IdentityCustomInfo?
    private var isLoading = false

    override private init() { super.init()} // Private to enforce singleton pattern

    /// Configures the identity manager to use ID5 
    public func useID5() {
        identityManager = ID5Manager.shared
    }

    func initialize() {
        Task{
           await initializeAsync()
        }
    }
    
    func initializeAsync() async -> Bool{
        let _ = await ConfigurationManager.shared.getConfigAsync();
        if identityManager == nil {
            SLogger.i("[IdentityManager] Identity Manager is not set by user. Trying to find a default Identity Manager")

            if ConfigurationManager.shared.getConfig()?.modules?.id5.active == true {
                SLogger.i("[IdentityManager] ID5 is active. Using ID5 as default Identity Manager")
                useID5()
            }
        }
        
        guard let identityManager = identityManager else {
            SLogger.e("[IdentityManager] No identity manager set. Initialization is not finished.")
            return false;
        }

        identityManager.initialize()
        
        return await loadAsync()
    }
        

    /// Loads identity information from storage or triggers refresh if needed.
    func loadAsync() async ->Bool {
        
        if(isNotInitialized()){
            return false;
        }
        
        if(isLoading) {
            SLogger.d("[IdentityManager] Loading is already in progress. Skipping.")
            return false;
        }
        
        SLogger.i("[IdentityManager] Loading from local storage")
        identityManager!.loadConsentStringFromStorage()

        return await refreshAsync()
    }

    /// Loads identity data asynchronously.
    func load() {
        Task {
            await loadAsync()
        }
    }

    /// Refreshes identity data by checking cache and reloading if necessary.
    func refreshAsync() async -> Bool{
        
        if(isNotInitialized()){
            return false;
        }
        
        if(isLoading) {
            SLogger.d("[IdentityManager] Refresh is already in progress. Skipping.")
            return false;
        }
        
        isLoading = true

        var shouldRefresh = true
        var identityData = identityManager!.getIdentityData()

        if let identityData = identityData {
            if ConfigurationManager.isDebugMode() {
                identityData.refreshInterval = 300
                SLogger.d("[IdentityManager] Debug mode enabled, interval set to \(identityData.getRefreshInterval())")
            } else {
                identityData.setDefaultRefreshInterval()
                SLogger.d("[IdentityManager] Default refresh interval is set: \(identityData.getRefreshInterval())")
            }

            let cacheExpiryTime = identityData.cacheCreationDate.addingTimeInterval(Double(identityData.getRefreshInterval()))
            shouldRefresh = cacheExpiryTime < Date() || identityManager!.isUpdated()

            SLogger.d("[IdentityManager] Cache check: Cache date: \(identityData.cacheCreationDate), "
                      + "Current date: \(Date()), Interval: \(identityData.getRefreshInterval()), "
                      + "Is request updated: \(identityManager!.isUpdated()), Refresh needed: \(shouldRefresh)")
        }
        
        identityManager!.setCustomInfo(customInfo: customInfo)

        if identityData == nil || shouldRefresh {
            SLogger.d("[IdentityManager] Refreshing identity data from HTTP.")
            await identityManager!.loadConsentStringFromHttp(retry: false)
        }

        isLoading = false
        
        identityData = identityManager!.getIdentityData()
        if identityData == nil {
            SLogger.d("[IdentityManager] Failed to load identity, identity data is empty.")
            return false;
        } else {
            SLogger.i("[IdentityManager] Identity successfully loaded.")
            return true;
        }
    }

    func refresh() {
        Task {
            await refreshAsync()
        }
    }

    func setUserIdToPrebid() {
        if(isNotInitialized()){
            return
        }
        
        identityManager?.setUserIdToPrebid()
    }

    public func setCustomInfo(_ customInfo: IdentityCustomInfo) {
        self.customInfo = customInfo
    }
    
    func isNotInitialized() -> Bool {
        return identityManager == nil
    }
}
