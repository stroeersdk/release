//
//  MaidTypeCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class MaidTypeCollector: IIdentityCollector{
    func retrieveData() async -> String? {
        if let _ = await MaidCollector().retrieveData() {
            return "idfa"
        }
    
        return nil
    }
}
