import Foundation

class ID5RequestBody: Codable {
    var ts: String? { didSet { checkUpdated(oldValue, ts) } }
    var partner: Int? { didSet { checkUpdated(oldValue, partner) } }
    var appId: String? { didSet { checkUpdated(oldValue, appId) } }
    var bundle: String? { didSet { checkUpdated(oldValue, bundle) } }
    var ver: String? { didSet { checkUpdated(oldValue, ver) } }
    var ip: String? { didSet { checkUpdated(oldValue, ip) } }
    var ua: String? { didSet { checkUpdated(oldValue, ua) } }
    var signature: String? { didSet { checkUpdated(oldValue, signature) } }
    var gdpr: Int? { didSet { checkUpdated(oldValue, gdpr) } }
    var gdpr_consent: String? { didSet { checkUpdated(oldValue, gdpr_consent) } }
    var allowed_vendors: [String]? { didSet { checkUpdated(oldValue, allowed_vendors) } }
    var usPrivacy: String? { didSet { checkUpdated(oldValue, usPrivacy) } }
    var gpp_sid: String? { didSet { checkUpdated(oldValue, gpp_sid) } }
    var gpp_string: String? { didSet { checkUpdated(oldValue, gpp_string) } }
    var name: String? { didSet { checkUpdated(oldValue, name) } }
    var domain: String? { didSet { checkUpdated(oldValue, domain) } }
    var maid: String? { didSet { checkUpdated(oldValue, maid) } }
    var maid_type: String? { didSet { checkUpdated(oldValue, maid_type) } }
    var idfa: String? { didSet { checkUpdated(oldValue, idfa) } }
    var hem: String? { didSet { checkUpdated(oldValue, hem) } }
    var phone: String? { didSet { checkUpdated(oldValue, phone) } }
    var idfv: String? { didSet { checkUpdated(oldValue, idfv) } }
    var puid: String? { didSet { checkUpdated(oldValue, puid) } }
    var ipv6: String? { didSet { checkUpdated(oldValue, ipv6) } }
    var country: String? { didSet { checkUpdated(oldValue, country) } }
    var region: String? { didSet { checkUpdated(oldValue, region) } }
    var city: String? { didSet { checkUpdated(oldValue, city) } }
    var att: Int? { didSet { checkUpdated(oldValue, att) } }
    var accept_language: String? { didSet { checkUpdated(oldValue, accept_language) } }
    var segments: [ID5Segment]? { didSet { checkUpdated(oldValue, segments) } }
    
    var isUpdated = true

    /// Checks if the value has been updated
    private func checkUpdated<T: Equatable>(_ oldVal: T?, _ newVal: T?) {
        if oldVal != newVal {
            isUpdated = true
        }
    }

    /// Resets the update flag
    func resetUpdated() {
        isUpdated = false
    }
}

class ID5Segment: Codable, Equatable {
    var destination: String?
    var ids: [String]?

    init(destination: String?, ids: [String]?) {
        self.destination = destination
        self.ids = ids
    }

    static func == (lhs: ID5Segment, rhs: ID5Segment) -> Bool {
        return lhs.destination == rhs.destination && lhs.ids == rhs.ids
    }
}
