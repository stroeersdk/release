//
//  GdprConsentCollector.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 06/03/2025.
//

import Foundation

class GdprConsentCollector: IIdentityCollector {
    private let GDPR_CONSENT_KEY = "IABTCF_TCString"

    func retrieveData() async -> String? {
        UserDefaults.standard.synchronize()
        let consentString = UserDefaults.standard.string(forKey: GDPR_CONSENT_KEY)
        return consentString?.isEmpty == true ? nil : consentString
    }
}
