//
//  DebugLoggerView.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import SwiftUI

public struct DebugLoggerView: View {
    @ObservedObject var session: BannerDebugSession
    @ObservedObject var consoleStore: ConsoleLogStore

    @State private var selectedTab: Tab = .requestLogs
    @State private var prebidSearchText: String = ""
    @State private var consoleSearchText: String = ""

    var dismissAction: (() -> Void)? = nil

    enum Tab: String, CaseIterable {
        case requestLogs = "Request Logs"
        case prebid = "Prebid Logs"
        case log = "Console Logs"
    }

    public var body: some View {
        VStack(alignment: .leading) {
            topBar
            tabPicker
            selectedTabView
        }
        .background(Color(red: 0.0, green: 0.0, blue: 0.25).ignoresSafeArea())
        .interactiveDismissDisabled()
    }

    // MARK: - Top Bar
    var topBar: some View {
        HStack {
            Text(shortAdUnit(session.adUnit))
                .foregroundStyle(.white)
                .font(.headline)
            Spacer()
            Button {
                dismissAction?()
            } label: {
                Image(systemName: "xmark")
            }
        }
        .padding()
    }

    // MARK: - Tab Picker
    var tabPicker: some View {
        Picker("", selection: $selectedTab) {
            ForEach(Tab.allCases, id: \.self) { tab in
                Text(tab.rawValue).tag(tab)
            }
        }
        .pickerStyle(.segmented)
        .padding(.horizontal)
    }

    // MARK: - Tab Content
    @ViewBuilder
    var selectedTabView: some View {
        switch selectedTab {
        case .requestLogs:
            requestLogsView
        case .prebid:
            prebidView
        case .log:
            consoleView
        }
    }

    // MARK: - Request Logs (per banner)
    var requestLogsView: some View {
        // Latest first
        let ordered = session.requestRecords.sorted { $0.timestamp > $1.timestamp }

        return ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(ordered, id: \.id) { record in
                    RequestLogsCardView(record: record)
                        .textSelection(.enabled)
                }
            }
            .padding()
        }
    }

    // MARK: - Prebid View (per banner)
    var prebidView: some View {
        VStack(alignment: .leading) {
            TextField("Search in Prebid request/response…", text: $prebidSearchText)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .padding(.top, 8)

            let ordered = session.prebidRecords.sorted { $0.timestamp > $1.timestamp }

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 12) {
                    ForEach(ordered.indices, id: \.self) { index in
                        let rec = ordered[index]
                        let req = prettyPrint(rec.requestJSON)
                        let res = prettyPrint(rec.responseJSON)

                        // Combine for filtering
                        let combined = req + "\n" + res
                        let passes = combined.lowercased()
                            .contains(prebidSearchText.lowercased()) ||
                            prebidSearchText.isEmpty

                        if passes {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(rec.timestamp.formatted())
                                    .font(.caption)
                                    .foregroundStyle(.gray)

                                Text("Prebid Request")
                                    .font(.subheadline.bold())
                                    .foregroundStyle(.yellow)

                                highlightOccurrences(in: req, query: prebidSearchText)
                                    .font(.caption2)
                                    .foregroundStyle(.white)

                                Divider().background(Color.white.opacity(0.6))

                                Text("Prebid Response")
                                    .font(.subheadline.bold())
                                    .foregroundStyle(.green)

                                highlightOccurrences(in: res, query: prebidSearchText)
                                    .font(.caption2)
                                    .foregroundStyle(.white)
                            }
                            .padding(8)
                            .background(Color.black.opacity(0.3))
                            .cornerRadius(8)
                        }
                    }
                }
                .padding()
            }
        }
        .textSelection(.enabled)
    }

    // MARK: - Console View
    var consoleView: some View {
        VStack(alignment: .leading) {
            TextField("Search in console logs (AND: space, OR: |)…",
                      text: $consoleSearchText)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .padding(.top, 8)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)

            Text("Oldest logs at the TOP • Latest logs at the BOTTOM")
                .font(.caption2)
                .foregroundStyle(.white.opacity(0.7))
                .padding(.horizontal, 12)
                .padding(.top, 4)

            // Keep natural order: first appended = top, last appended = bottom
            let filtered = consoleStore.lines
                .filteredLogs(with: consoleSearchText)

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(filtered.indices, id: \.self) { i in
                            let line = filtered[i]
                            let bg = colorForLogLine(line)

                            HStack {
                                highlightOccurrences(
                                    in: line,
                                    query: consoleSearchText
                                )
                                .font(.system(size: 10, design: .monospaced))
                                .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .foregroundColor(.white) // default; red segments override
                            .padding(8)
                            .background(bg.opacity(0.9))
                            .cornerRadius(12)
                            .id(i) // important for scrolling
                        }
                    }
                    .padding()
                }
                // Scroll to bottom when the view first appears
                .onAppear {
                    let count = filtered.count
                    guard count > 0 else { return }
                    DispatchQueue.main.async {
                        proxy.scrollTo(count - 1, anchor: .bottom)
                    }
                }
                // Auto-scroll to bottom when new lines are added
                .onChange(of: filtered.count) { newCount in
                    guard newCount > 0 else { return }
                    DispatchQueue.main.async {
                        withAnimation {
                            proxy.scrollTo(newCount - 1, anchor: .bottom)
                        }
                    }
                }
            }
        }
    }

    // MARK: - Helpers
    private func prettyPrint(_ json: Any?) -> String {
        guard let json else { return "—" }
        if let data = try? JSONSerialization.data(
            withJSONObject: json,
            options: [.prettyPrinted]
        ),
        let string = String(data: data, encoding: .utf8) {
            return string
        }
        return String(describing: json)
    }

    private func shortAdUnit(_ full: String) -> String {
        full.split(separator: "/").last.map(String.init) ?? full
    }
}

// MARK: - Safe AND/OR Log Filtering
extension Collection where Element == String {
    func filteredLogs(with query: String) -> [String] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return Array(self) }

        // OR logic: “foo | bar”
        if trimmed.contains("|") {
            let terms = trimmed
                .split(separator: "|")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
                .filter { !$0.isEmpty }

            return self.filter { line in
                let lower = line.lowercased()
                return terms.contains(where: { lower.contains($0) })
            }
        }

        // AND logic: “foo bar”
        let terms = trimmed
            .split(separator: " ")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
            .filter { !$0.isEmpty }

        return self.filter { line in
            let lower = line.lowercased()
            return terms.allSatisfy { lower.contains($0) }
        }
    }
}

// MARK: - Safe Highlighting (NEVER CRASHES)
func highlightOccurrences(in text: String, query: String) -> Text {
    let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { return Text(text) }

    // Extract search terms
    let terms: [String]
    if trimmed.contains("|") {
        terms = trimmed.split(separator: "|")
            .map { $0.lowercased().trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    } else {
        terms = trimmed.split(separator: " ")
            .map { $0.lowercased().trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    guard !terms.isEmpty else { return Text(text) }

    let lower = text.lowercased()

    var result = Text("")
    var searchIndex = text.startIndex

    while searchIndex < text.endIndex {
        var foundRange: Range<String.Index>? = nil
        var foundTerm: String = ""

        // Find earliest match among terms
        for term in terms {
            if let r = lower.range(of: term, range: searchIndex..<lower.endIndex) {
                if foundRange == nil || r.lowerBound < foundRange!.lowerBound {
                    foundRange = r
                    foundTerm = String(text[r])
                }
            }
        }

        guard let match = foundRange else {
            result = result + Text(String(text[searchIndex..<text.endIndex]))
            break
        }

        // Add the text before the match
        if match.lowerBound > searchIndex {
            let before = text[searchIndex..<match.lowerBound]
            result = result + Text(String(before))
        }

        // Add highlighted match
        result = result + Text(foundTerm)
            .foregroundColor(.red)
            .bold()

        searchIndex = match.upperBound
    }

    return result
}

// MARK: - Console line coloring (matches your old LogView)
private func colorForLogLine(_ log: String) -> Color {
    if log.contains("🧨") || log.contains("[STRÖER-Fatal]") {
        return .red
    } else if log.contains("❗️") || log.contains("[STRÖER-Error]") {
        return .orange
    } else if log.contains("🔧") || log.contains("[STRÖER-Debug]") {
        return .blue
    } else if log.contains("📋") || log.contains("[STRÖER-Infos]") {
        return .gray
    }

    let keyword = log.lowercased()
    if keyword.contains("banner") {
        return .brown
    } else if keyword.contains("interstitial") {
        return .purple
    } else if keyword.contains("confiant") {
        return .yellow
    } else if keyword.contains("gravite") {
        return .mint
    } else if keyword.contains("consent") {
        return .pink
    }

    return .black
}
