//
//  DebugInfoGesture.swift
//  Pods
//
//  Created by Hyungon Kim on 26/06/2025.
//
import UIKit

class DebugInfoGesture {
    
    weak var parentViewController: UIViewController?
    
    func addDoubleTapRecognizer(view: UIView, parentViewController: UIViewController) {
        self.parentViewController = parentViewController
        let doubleTap = UILongPressGestureRecognizer(target: self, action: #selector(doubleTapFunction))
        doubleTap.numberOfTouchesRequired = 2
        view.addGestureRecognizer(doubleTap)
    }

    @objc private func doubleTapFunction(sender: UILongPressGestureRecognizer) {
        guard let _ = sender.view else { return } // the parent view already died
        
        if sender.state == .ended {
            ConfigurationManager.enableInspectionMode()
            GraviteLoader.shared.enableInspectionMode()
            
            if let viewController = parentViewController {
                let message = "Ad debugging mode has been switched on. Force close the app to switch it back off."
                ToastMessage.alert(viewController: viewController, title: "Debug Info", message: message)
            } else {
                SLogger.d("Warning: Could not find parent UIViewController from GAMBannerView")
            }
        }
    }
}
