//
//  KeyValueSection.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import SwiftUI

struct KeyValueSection: View {
    let data: [String: Any]

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            ForEach(data.sorted(by: { $0.key < $1.key }), id: \.key) { key, value in
                HStack(alignment: .top, spacing: 2) {
                    Text("\(key):")
                        .font(.callout)
                        .fontWeight(.bold)
                        .foregroundColor(.white.opacity(0.8))
                        .frame(minWidth: 90, alignment: .leading)

                    Text(String(describing: value))
                        .font(.callout)
                        .multilineTextAlignment(.trailing)
                        .foregroundColor(.white)
                }
            }
        }
        .padding(.top, 4)
    }
}
