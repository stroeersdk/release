import Foundation
import PrebidMobile

final class BannerTrafficDelegator: NSObject {

    static let shared = BannerTrafficDelegator()

    /// One session per adUnit (GAM adUnit / pbadslot)
    private var sessionsByAdUnit: [String: BannerDebugSession] = [:]

    private override init() {
        super.init()
    }

    func attachPrebidEventDelegate() {
        if !(Prebid.shared.eventDelegate === self) {
            Prebid.shared.eventDelegate = self
            SLogger.i("[TrafficDelegator] Attached as Prebid.shared.eventDelegate")
        }
    }

    /// Called by YLBannerLoader once it knows the adUnit (after config)
    /// and inspection mode is ON.
    func startSession(for adUnit: String) -> BannerDebugSession {
        let session = BannerDebugSession(adUnit: adUnit)
        sessionsByAdUnit[adUnit] = session
        SLogger.i("[TrafficDelegator] startSession for adUnit='\(adUnit)'")
        return session
    }

    func session(for adUnit: String) -> BannerDebugSession? {
        sessionsByAdUnit[adUnit]
    }

    func clearSession(for adUnit: String) {
        SLogger.i("[TrafficDelegator] clearSession for adUnit='\(adUnit)'")
        sessionsByAdUnit.removeValue(forKey: adUnit)
    }
}

// MARK: - PrebidEventDelegate
extension BannerTrafficDelegator: PrebidEventDelegate {

    public func prebidBidRequestDidFinish(requestData: Data?, responseData: Data?) {
        // figure out which adUnit (pbadslot) this belongs to
        var adUnitFromRequest: String = "unknown"
        var requestJSON: Any?
        var responseJSON: Any?

        if let requestData,
           let json = try? JSONSerialization.jsonObject(with: requestData) {

            requestJSON = json

            if let dict = json as? [String: Any],
               let imps = dict["imp"] as? [[String: Any]],
               let firstImp = imps.first,
               let ext = firstImp["ext"] as? [String: Any],
               let data = ext["data"] as? [String: Any],
               let pbadslot = data["pbadslot"] as? String {
                adUnitFromRequest = pbadslot
            }
        }

        if let responseData,
           let json = try? JSONSerialization.jsonObject(with: responseData) {
            responseJSON = sanitizePrebidResponse(json)
        }

        guard let session = sessionsByAdUnit[adUnitFromRequest] else {
            SLogger.i("[TrafficDelegator] No session for pbadslot='\(adUnitFromRequest)'. Ignoring Prebid event.")
            return
        }

        SLogger.i("[TrafficDelegator] Appending Prebid event to session for adUnit='\(session.adUnit)'")
        session.appendPrebidEvent(requestJSON: requestJSON,
                                  responseJSON: responseJSON)
    }

    private func sanitizePrebidResponse(_ value: Any) -> Any {
        if var dict = value as? [String: Any] {
            dict.removeValue(forKey: "adm")
            for (k, v) in dict {
                dict[k] = sanitizePrebidResponse(v)
            }
            return dict
        }

        if var array = value as? [Any] {
            for i in array.indices {
                array[i] = sanitizePrebidResponse(array[i])
            }
            return array
        }

        return value
    }
}
