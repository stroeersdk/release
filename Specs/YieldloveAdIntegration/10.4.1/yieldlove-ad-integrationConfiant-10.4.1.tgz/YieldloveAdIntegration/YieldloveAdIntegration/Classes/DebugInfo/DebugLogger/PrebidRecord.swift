//
//  PrebidRecord.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import Foundation

struct PrebidRecord: Identifiable {
    let id = UUID()
    let timestamp: Date
    let adUnit: String
    let requestJSON: Any?
    let responseJSON: Any?
}
