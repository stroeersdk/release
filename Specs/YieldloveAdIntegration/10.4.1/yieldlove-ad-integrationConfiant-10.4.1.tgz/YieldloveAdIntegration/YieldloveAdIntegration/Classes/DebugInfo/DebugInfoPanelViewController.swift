import UIKit
import SwiftUI
import PrebidMobile

class DebugInfoPanelViewController : UIViewController {
    
    private var debugInfo: IDebugInfo?
    private var viewPanel: DebugInfoPanelView?
    
    init(_ debugInfo: IDebugInfo?) {
        self.debugInfo = debugInfo
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addDebugInfoLabel()
        addCloseButton()
    }
    
    func addDebugInfoLabel() {
        let debugInfoViewPanel = DebugInfoPanelView()
        if let debugInfo = debugInfo {
            debugInfoViewPanel.attributedText = debugInfo.toString()
        }
        else {
            debugInfoViewPanel.attributedText = NSAttributedString(string: "No Debug Info")
        }
        
        self.view.addSubview(debugInfoViewPanel)
        layoutDebugInfoView(debugInfoViewPanel)
    }
    
    func layoutDebugInfoView(_ view: UIView) {
        let parentHeight = self.view.frame.height
        let parentWidth = self.view.frame.width
        let rect = CGRect(x: 0, y: parentHeight * 0.05, width: parentWidth, height: parentHeight*0.95)
        view.frame = rect
    }
    
    func addCloseButton() {
        let closeButton = UIButton(type: .system)
        closeButton.setTitle("Close", for: .normal)
        closeButton.setTitleColor(.white, for: .normal)
        closeButton.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        closeButton.layer.cornerRadius = 6
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.addTarget(self, action: #selector(dismissSelf), for: .touchUpInside)

        view.addSubview(closeButton)

        NSLayoutConstraint.activate([
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 3),
            closeButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -3),
            closeButton.widthAnchor.constraint(equalToConstant: 70),
            closeButton.heightAnchor.constraint(equalToConstant: 35)
        ])
    }

    @objc func dismissSelf() {
        self.dismiss(animated: true, completion: nil)
        viewPanel = nil
    }
}
