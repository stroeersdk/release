//
//  ConsoleLogStore.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 28/11/2025.
//

import Foundation
import SwiftUI

/// Global console capture, but only started explicitly (when inspection is on).
final class ConsoleLogStore: NSObject, ObservableObject {

    static let shared = ConsoleLogStore()

    @Published private(set) var lines: [String] = []

    private let pipe = Pipe()
    private var isCapturing = false

    /// Formatter for `[HH:mm:ss]` prefix in console lines.
    private let timeFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f
    }()

    private override init() {
        super.init()
        // NOTE: capture is started explicitly via startIfNeeded()
    }

    /// Call this when inspection is on and a banner is being loaded.
    func startIfNeeded() {
        guard !isCapturing else { return }
        isCapturing = true
        
        // Redirect stdout & stderr into our pipe
        dup2(pipe.fileHandleForWriting.fileDescriptor, fileno(stdout))
        dup2(pipe.fileHandleForWriting.fileDescriptor, fileno(stderr))
        
        pipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            guard let self = self else { return }
            
            let data = handle.availableData
            guard
                !data.isEmpty,
                let output = String(data: data, encoding: .utf8),
                !output.isEmpty
            else { return }
            
            let stampedLines: [String] = output
                .split(separator: "\n")
                .map { rawSub -> String in
                    // Remove OSLOG noise
                    let cleaned = rawSub.replacingOccurrences(
                        of: "OSLOG",
                        with: "",
                        options: .caseInsensitive
                    )
                    
                    guard !cleaned.isEmpty else { return "" }
                    
                    let ts = self.timeFormatter.string(from: Date())
                    return "[\(ts)] \(cleaned)"
                }
                .filter { !$0.isEmpty }
            
            guard !stampedLines.isEmpty else { return }
            
            DispatchQueue.main.async {
                self.lines.append(contentsOf: stampedLines)
            }
        }
    }
    
    func append(_ line: String) {
        DispatchQueue.main.async {
            self.lines.append(line)
        }
    }
}
