import Foundation
import UIKit

class DebugInfoForStroeer : IDebugInfo {
   
    var appName: String
    var adUnitData: YLAdUnitData
    var servedInTime: Double
    
    init(_ appName: String, _ adUnitData: YLAdUnitData,  _ servedInTime: Double = 0) {
        self.appName = appName
        self.adUnitData = adUnitData
        self.servedInTime = servedInTime
    }
    
    func toString() -> NSAttributedString {
        return getDebugInfoText()
    }
    
    func getAdSourceInfo() -> AdSourceInfo {
        return adUnitData.source
    }
    
    func getPublisherCallString() -> String {
        return adUnitData.publisherCallString ?? "No publisher call string"
    }
    
    func getServedInTime() -> Double {
        return servedInTime
    }
}

/// This extension is to format the DebugInfo
extension DebugInfoForStroeer {
    private func getDebugInfoText() -> NSAttributedString {
        let result = NSMutableAttributedString()
        result.append(getSectionLabel("Ad Slot Info"))
        result.append(getAdSlotInfo(self))
        result.append(getSectionLabel("General Info"))
        result.append(getGeneralInfo(self))
        return result
    }
    
    private func getSectionLabel(_ heading: String) -> NSAttributedString {
        let font = UIFont.boldSystemFont(ofSize: 24)
        let attributes = [NSAttributedString.Key.font: font]
        return NSAttributedString(string: heading, attributes: attributes)
    }
    
    private func getSectionText(_ text: String) -> NSAttributedString {
        let font = UIFont.systemFont(ofSize: 16)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineBreakMode = .byWordWrapping
        
        let paragraphAttributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .paragraphStyle: paragraphStyle
        ]
        return NSAttributedString(string: text, attributes: paragraphAttributes)
    }
    
    private func getAdSlotInfo(_ debugInfo: DebugInfoForStroeer) -> NSAttributedString {
        let adUnitData = debugInfo.adUnitData
        let adSlotInfo = """
        
        Ad Unit: \(adUnitData.adUnit)
        Ad Source: \(adUnitData.source)
        Sizes: \(YLAdSizeCollection(sizes: adUnitData.bannerSizes).description)
        Key-values: \(adUnitData.keyValueTargeting.description)
        Auto Refresh: \(adUnitData.autoRefreshTimeMs != nil)
        Gam Response Id: \(adUnitData.responseIdentifier ?? "unknown")
        GDPR String: \(adUnitData.TCString ?? "missing TC string")
        \n
        """
        return getSectionText(adSlotInfo)
    }
    
    private func getGeneralInfo(_ debugInfo: DebugInfoForStroeer) -> NSAttributedString {
        let adUnitData = debugInfo.adUnitData
        let generalInfo = """
        
        Prebid Active: \(!adUnitData.skipPrebid)
        YL AccountId: \(adUnitData.accountId ?? "unknown")
        YL ConfigId: \(adUnitData.configId)
        
        App Name: \(debugInfo.appName)
        Publisher Call String: \(adUnitData.publisherCallString ?? "unknown")
        """
        return getSectionText(generalInfo)
    }
}
