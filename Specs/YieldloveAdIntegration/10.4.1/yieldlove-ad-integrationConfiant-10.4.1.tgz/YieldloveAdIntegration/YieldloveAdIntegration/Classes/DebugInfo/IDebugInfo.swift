//
//  IDebugInfo.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 13/05/2025.
//

import Foundation

public protocol IDebugInfo {
    func toString() -> NSAttributedString
    func getAdSourceInfo() -> AdSourceInfo
    func getPublisherCallString() -> String
    func getServedInTime() -> Double
}
