//
//  TrafficDebugInfoViewController.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import SwiftUI

class DebugLoggerViewController: UIViewController {
    private let session: BannerDebugSession
    private let consoleStore: ConsoleLogStore

    init(session: BannerDebugSession, consoleStore: ConsoleLogStore) {
        self.session = session
        self.consoleStore = consoleStore
        super.init(nibName: nil, bundle: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let swiftUIView = DebugLoggerView(
            session: session,
            consoleStore: consoleStore,
            dismissAction: { [weak self] in
                self?.dismiss(animated: true, completion: nil)
            }
        )
        isModalInPresentation = true

        let hostingController = UIHostingController(rootView: swiftUIView)
        addChild(hostingController)
        view.addSubview(hostingController.view)

        hostingController.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            hostingController.view.topAnchor.constraint(equalTo: view.topAnchor),
            hostingController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            hostingController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hostingController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        hostingController.didMove(toParent: self)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

