//
//  TrafficRecord.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import SwiftUI

public struct RequestLogsRecord: Identifiable {
    public let id = UUID()
    public let timestamp: Date
    public let type: String                   // "banner" or "interstitial"
    public let recordType: RecordType        // stage of traffic
    public let targeting: [String: String]
    public let adUnit: String
    
    var adUnitLastPath: String {
        adUnit.split(separator: "/").last.map(String.init) ?? adUnit
    }

    public enum RecordType: String {
        case prebidSent = "Sent to Prebid"
        case prebidReceived = "Received from Prebid"
        case prebidSkipped = "Prebid Skipped"
        case gamSent = "Sent to GAM"
        case gamReceived = "Received from GAM"
        case prebidRendered = "Rendered by Prebid"
    }

    public init(
        timestamp: Date = Date(),
        type: String,
        recordType: RecordType,
        targeting: [String: String],
        adUnit: String
    ) {
        self.timestamp = timestamp
        self.type = type
        self.recordType = recordType
        self.targeting = targeting
        self.adUnit = adUnit
    }
}
