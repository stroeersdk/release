import UIKit
import UniformTypeIdentifiers

class DebugInfoPanelView: UIView {
    
    private let containerView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 12
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.2
        view.layer.shadowRadius = 8
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let scrollView: UIScrollView = {
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.backgroundColor = .clear
        return scroll
    }()
    
    let dynamicFontLabel: UILabel = {
        let label = UILabel()
        label.accessibilityIdentifier = "debugInfo"
        label.textColor = .black
        label.backgroundColor = UIColor.white
        label.numberOfLines = 0
        label.adjustsFontSizeToFitWidth = true
        label.translatesAutoresizingMaskIntoConstraints = false
        label.layer.masksToBounds = true
        label.layer.cornerRadius = 5
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        
        addSubview(containerView)
        containerView.addSubview(scrollView)
        scrollView.addSubview(dynamicFontLabel)
        
        NSLayoutConstraint.activate([
            containerView.topAnchor.constraint(equalTo:    topAnchor),
            containerView.bottomAnchor.constraint(equalTo: bottomAnchor),
            containerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo:trailingAnchor),
            
            scrollView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 16),
            scrollView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            scrollView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),
            scrollView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -16),

            dynamicFontLabel.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            dynamicFontLabel.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            dynamicFontLabel.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            dynamicFontLabel.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            dynamicFontLabel.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor)
        ])
        
        dynamicFontLabel.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(copyDebugInfoToClipboard))
        tap.numberOfTapsRequired = 2
        dynamicFontLabel.addGestureRecognizer(tap)
    }
    
    // As soon as this view is placed into a superview,
    // pin its edges so it fills the entire area.
    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        guard let parent = superview else { return }
        translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            topAnchor.constraint(equalTo: parent.topAnchor),
            bottomAnchor.constraint(equalTo: parent.bottomAnchor),
            leadingAnchor.constraint(equalTo: parent.leadingAnchor),
            trailingAnchor.constraint(equalTo: parent.trailingAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    var attributedText: NSAttributedString = NSAttributedString() {
        didSet {
            dynamicFontLabel.attributedText = attributedText
            self.setNeedsLayout()
        }
    }
    
    @objc private func copyDebugInfoToClipboard(sender: UITapGestureRecognizer) {
        UIPasteboard.general.set(attributedString: attributedText)
        ToastMessage.show(parentView: containerView, message: "Debug info copied to clipboard")
    }

}

public extension UIPasteboard {
    func set(attributedString: NSAttributedString) {
        do {
            let rtfData = try attributedString.data(
                from: NSMakeRange(0, attributedString.length),
                documentAttributes: [.documentType: NSAttributedString.DocumentType.rtf]
            )

            self.setItems([
                [
                    UTType.rtf.identifier: rtfData,
                    UTType.plainText.identifier: attributedString.string
                ]
            ])
        } catch {
            if ConfigurationManager.isDebugMode() {
                SLogger.e("Could not copy contents of debug info label")
            }
        }
    }
}
