//
//  BannerDebugSession.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 28/11/2025.
//

import Foundation
import SwiftUI

/// One instance per banner load. Holds only that banner's logs.
final class BannerDebugSession: NSObject, ObservableObject, BidTrackingListener {

    let adUnit: String

    // UI-observed state
    @Published private(set) var requestRecords: [RequestLogsRecord] = []
    @Published private(set) var prebidRecords: [PrebidRecord] = []

    init(adUnit: String) {
        self.adUnit = adUnit
        super.init()
    }

    // MARK: - BidTrackingListener (Prebid/GAM flow)

    func didSendToPrebid(targeting: [String: String], adType: String, adUnit: String) {
        let record = RequestLogsRecord(
            timestamp: Date(),
            type: adType,
            recordType: .prebidSent,
            targeting: targeting,
            adUnit: adUnit
        )
        appendRequest(record)
    }

    func didReceiveFromPrebid(targeting: [String: String], adUnit: String) {
        let record = RequestLogsRecord(
            timestamp: Date(),
            type: "banner",
            recordType: .prebidReceived,
            targeting: targeting,
            adUnit: adUnit
        )
        appendRequest(record)
    }

    func didSendToGAM(targeting: [String: String], adUnit: String) {
        let record = RequestLogsRecord(
            timestamp: Date(),
            type: "banner",
            recordType: .gamSent,
            targeting: targeting,
            adUnit: adUnit
        )
        appendRequest(record)
    }

    func didReceiveFromGAM(targeting: [String: String], adType: String, adUnit: String) {
        let record = RequestLogsRecord(
            timestamp: Date(),
            type: adType,
            recordType: .gamReceived,
            targeting: targeting,
            adUnit: adUnit
        )
        appendRequest(record)
    }
    
    func didRenderViaPrebid(targeting: [String : String], adType: String, adUnit: String) {
        let record = RequestLogsRecord(
            timestamp: Date(),
            type: adType,
            recordType: .prebidRendered,
            targeting: targeting,
            adUnit: adUnit
        )
        appendRequest(record)
    }

    func markPrebidSkipped(targeting: [String: String], adType: String, adUnit: String) {
        let record = RequestLogsRecord(
            timestamp: Date(),
            type: adType,
            recordType: .prebidSkipped,
            targeting: targeting,
            adUnit: adUnit
        )
        appendRequest(record)
    }

    func clear() {
        DispatchQueue.main.async {
            self.requestRecords.removeAll()
            self.prebidRecords.removeAll()
        }
    }

    // MARK: - Called from PrebidEvent routing (per banner)

    func appendPrebidEvent(requestJSON: Any?, responseJSON: Any?) {
        let rec = PrebidRecord(
            timestamp: Date(),
            adUnit: adUnit,
            requestJSON: requestJSON,
            responseJSON: responseJSON
        )
        DispatchQueue.main.async {
            self.prebidRecords.append(rec)
        }
    }

    // MARK: - Helpers

    private func appendRequest(_ record: RequestLogsRecord) {
        DispatchQueue.main.async {
            self.requestRecords.append(record)
        }
    }
}
