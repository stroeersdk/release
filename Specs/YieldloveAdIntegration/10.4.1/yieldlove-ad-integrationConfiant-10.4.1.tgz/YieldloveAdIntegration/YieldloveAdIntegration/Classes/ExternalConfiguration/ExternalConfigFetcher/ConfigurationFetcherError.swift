enum ConfigurationFetcherError: LocalizedError {
    case responseContainsNoData
    case unableToReadResponseData
    
    var errorDescription: String {
        switch self {
        case .responseContainsNoData:
            return "Response contains no data"
        case .unableToReadResponseData:
            return "Unable to read response data"
        }
    }
}
