//
//  IConfigFetcher.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 05/02/2025.
//

import Foundation

protocol IConfigFetcher {
    func fetch(appName: String) async throws -> String
}
