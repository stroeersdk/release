enum ConfigurationManagerError: LocalizedError {
    case unableToFetchConfig
    case askedToWriteNilConfig
    
    var errorDescription: String{
        switch self {
        case .unableToFetchConfig:
            return "Unable to fetch configuration"
        case .askedToWriteNilConfig:
            return "Asked to write nil configuration"
        }
    }
}
