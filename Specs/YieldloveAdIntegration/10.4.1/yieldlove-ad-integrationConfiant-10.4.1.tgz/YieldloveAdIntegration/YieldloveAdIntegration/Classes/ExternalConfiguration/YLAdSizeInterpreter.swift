import GoogleMobileAds

class YLAdSizeInterpreter {
    
    static let standardSizesDictionary = getStandardSizesAsDictionary()
    
    static func getAsGadSizes(_ cgSizes: [CGSize], _ gadSizes: [String]) -> [AdSize] {
        var sizes: [AdSize] = []
        sizes.append(contentsOf: getAsGadSizes(sizes: gadSizes))
        sizes.append(contentsOf: getAsGadSizes(sizes: cgSizes))
        return sizes
    }
    
    fileprivate static func getAsGadSizes(sizes: [CGSize]) -> [AdSize] {
        return sizes.map({ adSizeFor(cgSize: $0) })
    }
    
    fileprivate static func getAsGadSizes(sizes: [String]) -> [AdSize] {
        var gadSizes: [AdSize] = []
        for size in sizes {
            if let standardSize = standardSizesDictionary[size] {
                gadSizes.append(standardSize)
            }
        }
        return gadSizes
    }
    
    fileprivate static func getStandardSizesAsDictionary() -> [String: AdSize] {
        var sizesDictionary: [String: AdSize] = [:]
        for size in YLConstants.standardAdSizes {
            sizesDictionary[string(for: size)] = size
        }
        return sizesDictionary
    }
}
