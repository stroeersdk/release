//
//  HttpConfigFetcher.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 05/02/2025.
//

import Foundation

class HttpConfigFetcher: IConfigFetcher {
    private var requestSender: RequestSender
    
    var isFetching = false
    var configContent = ""
    private var configRequestUrl = ""
    
    init(requestSender: RequestSender) {
        self.requestSender = requestSender
    }
    
    func fetch(appName: String) async throws-> String {
        if (isFetching){
            return configContent
        }
        
        isFetching = true
        let request = HttpRequest();
        let response = try await request.get(url: getHttpConfigUrl(appName: appName))
        defer {
           isFetching = false
        }
        
        if(response.isSuccessfulHttpResponse()) {
             return try handleResponse(senderResponse: response)
        }
        
        return ""
    }
    
    private func handleResponse(senderResponse: HttpResponse) throws -> String {
        try self.assertResponseOk(response: senderResponse)
        
        if let url = senderResponse.response?.url {
            SLogger.d("[HttpConfigFetcher] Http config from \(url) was fetched")
        }

        guard let responseData = senderResponse.data else {
            SLogger.e("[HttpConfigFetcher] Http config is empty")
            throw ConfigurationFetcherError.responseContainsNoData
        }
        
        guard let json = String.init(data: responseData, encoding: .utf8) else {
            throw ConfigurationFetcherError.unableToReadResponseData
        }
        return json
    }
    
    private func assertResponseOk(response: HttpResponse) throws {
        if let httpResponse = response.response as? HTTPURLResponse {
            let code = httpResponse.statusCode
            if !response.isSuccessfulHttpResponse() {
                SLogger.e("[HttpConfigFetcher]Http config fetcher has not succeed with status code: \(String(code))")

                throw HttpExternalConfigFetcherError.notSuccessfulStatus(statusCode: String(code))
            } else {
                SLogger.i("[HttpConfigFetcher]Http config http response status validation successful")
            }
        }
    }
    
    func getHttpConfigUrl(appName: String) throws -> String {
        if configRequestUrl.isEmpty {
            self.configRequestUrl = ExternalConfigConstants.configJsonURL.replacingOccurrences(
                of: ExternalConfigConstants.appNamePlaceholder,
                with: appName)
        }
        
        return self.configRequestUrl
    }
}
