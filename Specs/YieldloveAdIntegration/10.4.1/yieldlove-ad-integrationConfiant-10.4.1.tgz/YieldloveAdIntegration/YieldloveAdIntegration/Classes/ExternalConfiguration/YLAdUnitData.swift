import GoogleMobileAds
import PrebidMobile

//circle reference
//public typealias AdSize = AdSize

public class YLAdUnitData: NSObject {
    
    public var adUnit: String
    var configId: String
    public var bannerSizes: [AdSize] = []
    var keyValueTargeting: [String: String] = [:]
    var prebidCacheId: String?
    var prebidAdSize: CGSize?
    var accountId: String?
    var adId: Int?
    var skipPrebid: Bool = false
    var frameworks: [Signals.Api]?
    var storeUrl: String?
    var itunesID: String?
    var autoRefreshTimeMs: Int?
    var publisherCallString: String?
    var responseIdentifier: String?
    
    var source: AdSourceInfo = AdSourceInfo.getDefaultAdSource()
    var TCString: String?
    var publichserCallString: String?
    var wasRefreshed: Bool = false
    
    
    init(adUnit: String, configId: String) {
        self.adUnit = adUnit
        self.configId = configId
    }
    
    init(adUnit: String, configId: String, sizes: [AdSize]) {
        self.adUnit = adUnit
        self.configId = configId
        self.bannerSizes.append(contentsOf: sizes)
    }
    
    func setAdSizes(sizes: [AdSize]) {
        self.bannerSizes.append(contentsOf: sizes)
    }
    
    func setAdSizes(sizes: [NSValue]) {
        var adSizes = [AdSize]()
        for size in sizes {
            let adSize = adSizeFor(nsValue: size)
            adSizes.append(adSize)
        }
        
        self.setAdSizes(sizes: adSizes)
    }
    
    func addCustomTargeting(key: String, value: String) {
        self.keyValueTargeting[key] = value
    }
    
    public func getAdSlotName() -> String {
        return String(self.adUnit.split(separator: "/").last ?? "")
    }
    
    public func getPlacementName() -> String {
        let adSlotName = getAdSlotName().trimmingCharacters(in: .whitespacesAndNewlines)

        guard !adSlotName.isEmpty else {
            SLogger.e("[YLAdUnitData] Failed to get PlacementName - adUnit: \(adUnit), adSlotName is empty")
            return adSlotName
        }

        let zoneAndPlacements = adSlotName.split(separator: "_")
        
        guard let placementName = zoneAndPlacements.last, !placementName.isEmpty else {
            SLogger.e("[YLAdUnitData] Failed to get PlacementName - adUnit: \(adUnit), invalid format")
            return adSlotName
        }

        return String(placementName)
    }
        
}
