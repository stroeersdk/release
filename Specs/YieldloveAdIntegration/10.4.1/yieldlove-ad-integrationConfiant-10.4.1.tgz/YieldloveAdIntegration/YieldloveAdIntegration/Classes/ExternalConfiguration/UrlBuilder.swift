class UrlBuilder: ConfigurationUrlBuilder {
    var externalConfigUrl: String = ""
    
    func getExternalConfigUrl() throws -> String {
        if let appName = ExternalConfigurationManagerBuilder.instance.appName {
            if self.externalConfigUrl.isEmpty || !doesUrlMatchAppName(urlString: self.externalConfigUrl, expectedAppName: appName) {
                self.externalConfigUrl = ExternalConfigConstants.configJsonURL.replacingOccurrences(
                    of: ExternalConfigConstants.appNamePlaceholder,
                    with: appName)
            }
            return self.externalConfigUrl
        } else {
            throw ConfigurationParsingError.undefinedAppName
        }
    }
    
    func doesUrlMatchAppName(urlString: String, expectedAppName: String) -> Bool {
        guard let url = URL(string: urlString) else { return false }
        let components = url.pathComponents

        // Extract app name after "live"
        if let liveIndex = components.firstIndex(of: "live"),
           components.count > liveIndex + 1 {
            let extractedAppName = components[liveIndex + 1]
            return extractedAppName == expectedAppName
        }

        return false
    }
}
