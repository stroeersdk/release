import PromiseKit

public protocol IConfigurationManager {

    func getAdUnitData(publisherAdSlot: String, adType: AdType) -> Promise<ConfigurableAdUnitData>

    func getConsentData(overrideProperties: String?) -> Promise<ConfigurableConsentData>
    
    func getMonitoringData() -> Promise<MonitoringData>

    func clearConfigurationCache() -> Void
}
