import UIKit
import GoogleMobileAds

@objcMembers
public final class YLBannerView: UIView {
    
    // MARK: - Public / external
    public var bannerInfo: YLAdUnitData
    public weak var publisherViewController: UIViewController?
    /*
     this is required so that we can listen to events such as click, impression
     and more for Custom Banner View
     they only fire if the banner exists.
     everything else gets deinited and only ylbannerview stays in memory
     is the reason its declared here
     */
    internal weak var publisherDelegate: YLBannerViewDelegate?
    
    internal var refreshController: YLRefreshableBanner?
    
    // MARK: - Internal views
    private var bannerView: UIView?
    var debugLabelView: UIView?
    
    // MARK: - Size tracking
    private var currentSize: CGSize = .zero {
        didSet {
            guard oldValue != currentSize else { return }
            updateHeightConstraint()
            invalidateIntrinsicContentSize()
            setNeedsLayout()
        }
    }
    
    // Wrapper constraint (HEIGHT only, required)
    private var heightConstraint: NSLayoutConstraint?
    
    // Child constraints (center + soft size)
    private var childCenterX: NSLayoutConstraint?
    private var childCenterY: NSLayoutConstraint?
    private var childWidth: NSLayoutConstraint?
    private var childHeight: NSLayoutConstraint?
    
    // KVO to detect size changes in the child (GAM can change after load/refresh)
    private var childBoundsObs: NSKeyValueObservation?
    private var childFrameObs: NSKeyValueObservation?
    
    // MARK: - Init
    
    public override init(frame: CGRect) {
        self.bannerInfo = YLAdUnitData(adUnit: "empty", configId: "empty")
        super.init(frame: frame)
        commonInit()
    }
    
    public init() {
        self.bannerInfo = YLAdUnitData(adUnit: "empty", configId: "empty")
        super.init(frame: .zero)
        commonInit()
    }
    
    public init(bannerInfo: YLAdUnitData) {
        self.bannerInfo = bannerInfo
        super.init(frame: .zero)
        commonInit()
    }
    
    public init(bannerView: UIView, bannerInfo: YLAdUnitData) {
        self.bannerInfo = bannerInfo
        super.init(frame: .zero)
        commonInit()
        setBannerView(bannerView: bannerView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func commonInit() {
        translatesAutoresizingMaskIntoConstraints = false
        clipsToBounds = false
        backgroundColor = .clear
        updateHeightConstraint() // starts at 0
    }
    
    // MARK: - Public API
    
    public func getSource() -> AdSourceInfo {
        bannerInfo.source
    }
    
    public func getBannerView() -> UIView? {
        bannerView
    }
    
    /// Kept for compatibility with your existing flow.
    /// This seeds the wrapper's size immediately (good for SwiftUI list rows),
    /// while KVO/intrinsic can still refine it later if GAM changes.
    public func updateSize(to size: CGSize) {
        let safe = size.nonNegativeOrZero()
        applySize(safe)
        
        // Also update the child "soft constraints" so it doesn't get stretched/cropped
        // when SwiftUI temporarily constrains the wrapper.
        childWidth?.constant = max(0, safe.width)
        childHeight?.constant = max(0, safe.height)
    }
    
    /// Prefer intrinsic/cached size over frame, because SwiftUI can temporarily
    /// force wrapper bounds (e.g. 320x100) while the real ad is 300x250.
    public func getBannerSize() -> CGSize {
        if currentSize != .zero { return currentSize }
        
        if let child = bannerView {
            let intrinsic = child.intrinsicContentSize.nonNegativeOrZero()
            if intrinsic.width > 0 || intrinsic.height > 0 { return intrinsic }
            let b = child.bounds.size.nonNegativeOrZero()
            if b.width > 0 || b.height > 0 { return b }
            let f = child.frame.size.nonNegativeOrZero()
            if f.width > 0 || f.height > 0 { return f }
        }
        
        return .zero
    }
    
    /// Main entry: SDK sets the child here once GAM returns it.
    public func setBannerView(bannerView: UIView) {
        detachChild()
        
        self.bannerView = bannerView
        bannerView.translatesAutoresizingMaskIntoConstraints = false
        bannerView.clipsToBounds = false
        
        addSubview(bannerView)
        
        // Center it (avoid edge-pin stretch/crop)
        childCenterX = bannerView.centerXAnchor.constraint(equalTo: centerXAnchor)
        childCenterY = bannerView.centerYAnchor.constraint(equalTo: centerYAnchor)
        
        // "Soft" size constraints (priority 999) so parent constraints can win if needed.
        let initial = bestSize(for: bannerView)
        childWidth = bannerView.widthAnchor.constraint(equalToConstant: max(0, initial.width))
        childHeight = bannerView.heightAnchor.constraint(equalToConstant: max(0, initial.height))
        childWidth?.priority = UILayoutPriority(999)
        childHeight?.priority = UILayoutPriority(999)
        
        NSLayoutConstraint.activate([
            childCenterX!,
            childCenterY!,
            childWidth!,
            childHeight!
        ])
        
        attachKVO(to: bannerView)
        
        // Update wrapper size from initial
        if initial != .zero {
            applySize(initial)
        }
    }
    
    // MARK: - Debug label overlay
    
    public func createDebugLabelView(debugView: UIView) {
        let tag = 123456789

        // We keep this guard: presenter is needed to show the panels reliably.
        guard publisherViewController != nil else {
            SLogger.e("[YLBannerView] Publisher view controller is not set. Cannot create debug label view.")
            return
        }

        debugLabelView?.removeFromSuperview()
        debugLabelView = nil
        self.viewWithTag(tag)?.removeFromSuperview()

        debugView.tag = tag
        debugView.frame = CGRect(x: 8, y: 8, width: 200, height: 40)

        self.addSubview(debugView)
        self.bringSubviewToFront(debugView)

        debugLabelView = debugView
    }
    
    // MARK: - Layout
    
    public override var intrinsicContentSize: CGSize {
        let size = currentSize
        if size == .zero {
            return CGSize(width: UIView.noIntrinsicMetric, height: 0)
        }
        return CGSize(
            width: size.width > 0 ? size.width : UIView.noIntrinsicMetric,
            height: size.height
        )
    }
    
    public override func layoutSubviews() {
        super.layoutSubviews()
        // DO NOT touch self.frame here.
        
        guard let child = bannerView else { return }
        let newSize = bestSize(for: child)
        if newSize != .zero && newSize != currentSize {
            applySize(newSize)
            childWidth?.constant = max(0, newSize.width)
            childHeight?.constant = max(0, newSize.height)
        }
    }
    
    // MARK: - Dispose
    
    deinit {
        dispose()
    }
    
    public func dispose() {
        refreshController = nil
        detachChild()

        debugLabelView?.removeFromSuperview()
        debugLabelView = nil
    }
    
    // MARK: - Internals
    
    private func detachChild() {
        childBoundsObs = nil
        childFrameObs = nil
        
        //important so we have no leaks on PrebidHtmlBannerView
        (bannerView as? PrebidHtmlBannerView)?.destroy()
        bannerView?.removeFromSuperview()
        bannerView = nil
        
        if let c = childCenterX { NSLayoutConstraint.deactivate([c]) }
        if let c = childCenterY { NSLayoutConstraint.deactivate([c]) }
        if let c = childWidth { NSLayoutConstraint.deactivate([c]) }
        if let c = childHeight { NSLayoutConstraint.deactivate([c]) }
        
        childCenterX = nil
        childCenterY = nil
        childWidth = nil
        childHeight = nil
    }
    
    private func attachKVO(to child: UIView) {
        childBoundsObs = child.observe(\.bounds, options: [.new]) { [weak self] view, _ in
            guard let self else { return }
            let newSize = self.bestSize(for: view)
            if newSize != .zero && newSize != self.currentSize {
                self.applySize(newSize)
                self.childWidth?.constant = max(0, newSize.width)
                self.childHeight?.constant = max(0, newSize.height)
            }
        }
        
        childFrameObs = child.observe(\.frame, options: [.new]) { [weak self] view, _ in
            guard let self else { return }
            let newSize = self.bestSize(for: view)
            if newSize != .zero && newSize != self.currentSize {
                self.applySize(newSize)
                self.childWidth?.constant = max(0, newSize.width)
                self.childHeight?.constant = max(0, newSize.height)
            }
        }
    }
    
    private func bestSize(for child: UIView) -> CGSize {
        let intrinsic = child.intrinsicContentSize.nonNegativeOrZero()
        if intrinsic.width > 0 || intrinsic.height > 0 { return intrinsic }
        
        let b = child.bounds.size.nonNegativeOrZero()
        if b.width > 0 || b.height > 0 { return b }
        
        let f = child.frame.size.nonNegativeOrZero()
        if f.width > 0 || f.height > 0 { return f }
        
        return .zero
    }
    
    private func applySize(_ size: CGSize) {
        let safe = size.nonNegativeOrZero()
        currentSize = safe
    }
    
    private func updateHeightConstraint() {
        if heightConstraint == nil {
            let c = heightAnchor.constraint(equalToConstant: max(0, currentSize.height))
            c.priority = .required
            c.isActive = true
            heightConstraint = c
        } else {
            heightConstraint?.constant = max(0, currentSize.height)
        }
    }
}

// MARK: - Debug gesture
extension YLBannerView {
    public func addDoubleTapRecognizer() {
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(doubleTapFunction))
        longPress.numberOfTouchesRequired = 2
        addGestureRecognizer(longPress)
    }

    @objc private func doubleTapFunction(sender: UILongPressGestureRecognizer) {
        guard sender.view != nil else { return }
        if sender.state == .ended {
            ConfigurationManager.enableInspectionMode()
            GraviteLoader.shared.enableInspectionMode()

            if let viewController = UIUtils.getRootViewController() {
                let message = "Ad debugging mode has been switched on. Force close the app to switch it back off."
                ToastMessage.alert(viewController: viewController, title: "Debug Info", message: message)
            } else {
                SLogger.d("Warning: Could not find root UIViewController to show debug message.")
            }
        }
    }
}

// MARK: - Helpers
private extension CGSize {
    func nonNegativeOrZero() -> CGSize {
        CGSize(
            width: max(0, width.isFinite ? width : 0),
            height: max(0, height.isFinite ? height : 0)
        )
    }
}

