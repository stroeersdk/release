//
//  YLInterstitialAdDelegate.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 13/01/2025.
//

import Foundation

@objc public protocol YLInterstitialAdDelegate{

    @objc optional func onAdLoaded(interstitial: YLInterstitialAd);

    @objc optional func onAdFailedToLoad(interstitial: YLInterstitialAd?, error: Error);
}

