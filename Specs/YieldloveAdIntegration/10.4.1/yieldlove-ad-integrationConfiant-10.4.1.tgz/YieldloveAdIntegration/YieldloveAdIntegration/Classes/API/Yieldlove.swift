import Foundation
import GoogleMobileAds
import PromiseKit
import PrebidMobile


public typealias GetAdSizesCompletion = (_ adSizes: NSArray, _ error: Error?) -> Void
public typealias RewardedAdCompletion = (_ ad: RewardedAd?, _ error: Error?) -> Void

@objc public class Yieldlove: NSObject {

    @objc public static let instance = Yieldlove()
    @objc public var adRequest = AdManagerRequest()

    private static var config: Config?

    private let configurationManager: IConfigurationManager
    public var bidTrackingListener: BidTrackingListener?

    @objc public class func setup(appName: String) {
        SLogger.i("Version - \(YLConstants.version)")
        Yieldlove.setupEnvironment(appName: appName)
    }

    
    class func setupEnvironment(appName: String, configProvider: Config.Type = YLConfig.self) {
        ExternalConfigurationManagerBuilder.instance.appName = appName
        if Yieldlove.config == nil {
            Yieldlove.config = configProvider.getProductionConfig(appName: appName)
        }
        ConfigurationManager.shared.initialize(appName: appName)
        IdentityManager.shared.initialize()
    }

    override private init() {
        guard let config = Yieldlove.config else {
            fatalError("Error - you must call setup before accessing Yieldlove.instance")
        }
        self.configurationManager = config.configurationManager
        super.init()
        MobileAds.shared.start()
    }

    func getConfig() -> Config {
        guard let config = Yieldlove.config else {
            fatalError("Error - you must call setup before accessing Yieldlove.instance")
        }
        return config
    }
    
    @objc public func clearConfigurationCache() {
        self.configurationManager.clearConfigurationCache()
    }

    @objc public static func enableDebugMode() {
        ConfigurationManager.enableDebugMode();
        SLogger.enableDebug = true
    }
    
    @objc public static func enableInspectionMode(){
        ConfigurationManager.enableInspectionMode()
    }

    @objc public func bannerAd(adSlotId: String, viewController: UIViewController, delegate: YLBannerViewDelegate) {
        let config = getConfig()
        let bannerConfiguration = YLBannerConfiguration(adSlotId, config, viewController, delegate)
        YLBannerLoader(bannerConfiguration: bannerConfiguration).loadBanner()
    }
    
    // GAMRequest is optional to get rid of a warning in Objective-C apps
    // which appears when nil is passed to methods that do not accept nil
    @objc public func interstitialAd(adSlotId: String, interstitialDelegate: YLInterstitialAdDelegate?, viewController: UIViewController, request: AdManagerRequest? = AdManagerRequest()) {
        
        let config = getConfig()
        YLInterstitial(config: config, interstitialDelegate: interstitialDelegate, request: request ?? AdManagerRequest())
                .load(adSlotId: adSlotId, viewController: viewController)
    }
    
    
    
    @objc public func rewardedAd(adSlotId: String, completion: @escaping RewardedAdCompletion, request: AdManagerRequest? = AdManagerRequest()) {
        let config = getConfig()
        YLRewardedAd(config: config, completion: completion, request: request ?? AdManagerRequest())
            .load(adSlotId: adSlotId)
    }

    @objc public func resizeBanner(banner: YLBannerView, handler: (() -> Void)? = {}) {
        YLAdResizer().resizeAd(banner: banner, completion: handler)
    }

    @objc public func getAdSizes(adSlotId: String, completion: @escaping GetAdSizesCompletion) {
        self.configurationManager
            .getAdUnitData(publisherAdSlot: adSlotId, adType: .bannerAd)
            .map(YLAdUnitDataTransformer.transformBannerAdUnitData)
            .map { adUnitData in
                completion(YLAdSizeCollection(sizes: adUnitData.bannerSizes).getSizes(), nil)
            }.catch { error in
                completion([] as NSArray, AdSlotConfigurationError(error))
            }
    }
    
    @objc public func setCustomTargets(targets: [String: String])
    {
        Yieldlove.instance.adRequest.customTargeting = targets
        var convertedTargets: [String: [String]] = [:]
        for (key, value) in targets{
            Targeting.shared.addAppKeyword(value)
            // Split the value by commas and remove any extra whitespace
            let valuesArray = value.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
            // Assign the array to the key in the new dictionary
            convertedTargets[key] = valuesArray.map { String($0) }
        }
        
        GraviteLoader.shared.setCustomTargets(targets: convertedTargets)
    }
}
