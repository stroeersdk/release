import GoogleMobileAds

@objc public protocol YLBannerViewDelegate {

    /// Tells the delegate that an ad request successfully received an ad.
    @objc optional func bannerViewDidReceiveAd(_ bannerView: YLBannerView)

    /// Tells the delegate that an ad request failed.
    @objc optional func bannerView(_ bannerView: YLBannerView, didFailToReceiveAdWithError error: Error)

    /// Tells the delegate that a full screen view will be presented in response to the user clicking on an ad.
    @objc optional func bannerViewWillPresentScreen(_ bannerView: YLBannerView)

    /// Tells the delegate that the full screen view will be dismissed.
    @objc optional func bannerViewWillDismissScreen(_ bannerView: YLBannerView)

    /// Tells the delegate that the full screen view has been dismissed.
    @objc optional func bannerViewDidDismissScreen(_ bannerView: YLBannerView)

    /// Optional: called when a load starts (useful for showing shimmer/spinner).
    @objc optional func bannerViewDidStartLoadingAd()

    /// Optional: allow publisher to provide a custom GAM request.
    @objc optional func getGAMRequest() -> AdManagerRequest

    /// Measurement callbacks.
    @objc optional func bannerViewDidRecordImpression(_ bannerView: YLBannerView)
    @objc optional func bannerViewDidRecordClick(_ bannerView: YLBannerView)
}
