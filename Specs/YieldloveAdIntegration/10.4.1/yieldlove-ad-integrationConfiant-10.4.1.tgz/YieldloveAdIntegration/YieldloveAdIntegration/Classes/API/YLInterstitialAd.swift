//
//  YLInterstitialView.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 13/01/2025.
//

import Foundation
import GoogleMobileAds

@objcMembers public class YLInterstitialAd: NSObject {
    
    var interstitialAd: InterstitialAd?
    var adSource: AdSourceInfo = AdSourceInfo.getUnknowAdSource()
    var ylAdUnitData: YLAdUnitData?
    
    public override init(){
        super.init()
    }
    
    public init(interstitialAd: InterstitialAd) {
        self.interstitialAd = interstitialAd
    }

    
    public func getInterstitialAd() -> InterstitialAd? {
        return interstitialAd
    }
    
    public func getAdSource() -> AdSourceInfo {
        return adSource
    }
    
    public func show(viewController : UIViewController){
        if(interstitialAd != nil)
        {
            interstitialAd!.present(from: viewController)
        }
        else if(ylAdUnitData != nil && GraviteLoader.shared.isGraviteStarted())
        {
            // Gravite
            GraviteLoader.shared.getInterstitialLoader()?.showInterstitial(ylAdUnitData: ylAdUnitData!)
        }
    }
}
