//
//  PrebidHtmlBannerView.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 05/02/2026.
//


import UIKit
import WebKit

@MainActor
public final class PrebidHtmlBannerView: UIView {
    /// IMPORTANT: must be STRONG, otherwise a temporary proxy gets deallocated immediately.
    public var listener: PrebidHtmlBannerViewListener?

    // MARK: - State

    private var webView: WKWebView?
    private var lastBaseUrl: URL = URL(string: "https://localhost/")!
    private var lastHtml: String?
    private var sizeWidth: CGFloat = 0
    private var sizeHeight: CGFloat = 0
    private let dbgId = UUID().uuidString.prefix(6)

    private var loadTimeoutSeconds: TimeInterval = 8
    private var watchdogTask: Task<Void, Never>?

    private var destroyed = false
    private var loadedSent = false
    private var failedSent = false
    private var impressionSent = false
    private var browserOpened = false

    private var loadGeneration: Int = 0
    private var didBecomeActiveObserver: NSObjectProtocol?

    /// IMPORTANT: bind the currently loading WKNavigation to a specific generation.
    /// This prevents late callbacks (from a previous load) from failing/finishing the newest load.
    private var currentNavigation: WKNavigation?
    private var currentNavigationGen: Int = 0

    /// tracking JS is injected after page finished (evaluateJavascript()).
    /// We keep a guard so we inject only once per generation.
    private var injectedTrackingGen: Int = 0

    // MARK: - Init

    public override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
    

    private func commonInit() {
        isUserInteractionEnabled = true
        clipsToBounds = false
        backgroundColor = .clear
        SLogger.i("[PrebidHtmlBannerView:\(dbgId)] init")
        ensureWebView()
        applySizeToSelf()
        applySizeToWebView()
    }

    // MARK: - Public API

    public func setLoadTimeout(seconds: TimeInterval) {
        loadTimeoutSeconds = max(1, seconds)
    }

    /// width/height in points (UIKit coords).
    public func setAdSize(width: CGFloat, height: CGFloat) {
        guard !destroyed else { return }
        sizeWidth = max(0, width)
        sizeHeight = max(0, height)
        applySizeToSelf()
        applySizeToWebView()
    }

    public func setHtml(_ html: String, baseUrl: String? = nil) {
        SLogger.i("[PrebidHtmlBannerView:\(dbgId)] setHtml gen->\(loadGeneration + 1) html_len=\(html.count) destroyed=\(destroyed)")
        guard !destroyed else { return }

        lastHtml = html
        if let baseUrl, let u = URL(string: baseUrl), !baseUrl.isEmpty {
            lastBaseUrl = u
        } else {
            lastBaseUrl = URL(string: "https://localhost/")!
        }

        loadGeneration += 1
        SLogger.i("[PrebidHtmlBannerView:\(dbgId)] setHtml START gen=\(loadGeneration)")
        stopCloseObserver()
        browserOpened = false
        loadedSent = false
        failedSent = false
        impressionSent = false
        injectedTrackingGen = 0

        ensureWebView()
        prepareForNewLoad(gen: loadGeneration)
        scheduleWatchdog(gen: loadGeneration)

        guard let wv = webView else {
            notifyFailedOnce(
                error: NSError(domain: "PrebidHtmlBannerView", code: 1, userInfo: [NSLocalizedDescriptionKey: "WKWebView missing"]),
                gen: loadGeneration
            )
            return
        }

        applySizeToSelf()
        applySizeToWebView()

        // keep wrapper minimal; inject tracking in didFinish.
        let wrapped = wrapHtml(inner: html)

        // Bind this navigation to the generation for race-safe callbacks.
        currentNavigationGen = loadGeneration
        currentNavigation = wv.loadHTMLString(wrapped, baseURL: lastBaseUrl)
    }

    public func onHostResumed() {
        if browserOpened {
            browserOpened = false
            stopCloseObserver()
            notifyClosed()
        }
    }

    public func onHostPaused() {
        // no-op; WKWebView pauses with app lifecycle
    }

    private func startCloseObserverIfNeeded() {
        guard didBecomeActiveObserver == nil else { return }

        didBecomeActiveObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.onHostResumed()
            }
        }
    }

    private func stopCloseObserver() {
        if let obs = didBecomeActiveObserver {
            NotificationCenter.default.removeObserver(obs)
            didBecomeActiveObserver = nil
        }
    }

    public func destroy() {
        guard !destroyed else { return }
        destroyed = true

        stopCloseObserver()
        cancelWatchdog()

        if let wv = webView {
            wv.configuration.userContentController.removeScriptMessageHandler(forName: "stroeer")
            wv.navigationDelegate = nil
            wv.uiDelegate = nil
            wv.scrollView.delegate = nil
            wv.stopLoading()
            wv.removeFromSuperview()
        }
        webView = nil

        currentNavigation = nil
        currentNavigationGen = 0
        injectedTrackingGen = 0

        listener = nil
    }

    public override func willMove(toWindow newWindow: UIWindow?) {
        super.willMove(toWindow: newWindow)
        if newWindow == nil {
            stopCloseObserver()
        }
    }

    // MARK: - WebView Setup

    private func ensureWebView() {
        if webView != nil { return }

        let contentController = WKUserContentController()
        contentController.add(self, name: "stroeer") // JS -> native messages

        // Inject console bridge (helps debug blank creatives)
        let consoleJS = """
        (function() {
          try {
            if (window.__stroeer_console_hooked) return;
            window.__stroeer_console_hooked = true;

            function send(type, args) {
              try {
                window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.stroeer &&
                  window.webkit.messageHandlers.stroeer.postMessage({ kind: "console", type: type, args: args });
              } catch (e) {}
            }

            var origLog = console.log;
            console.log = function() { try { send("log", Array.prototype.slice.call(arguments)); } catch(e) {} try { origLog.apply(console, arguments); } catch(e) {} };

            var origWarn = console.warn;
            console.warn = function() { try { send("warn", Array.prototype.slice.call(arguments)); } catch(e) {} try { origWarn.apply(console, arguments); } catch(e) {} };

            var origErr = console.error;
            console.error = function() { try { send("error", Array.prototype.slice.call(arguments)); } catch(e) {} try { origErr.apply(console, arguments); } catch(e) {} };
          } catch (e) {}
        })();
        """

        let consoleScript = WKUserScript(source: consoleJS, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        contentController.addUserScript(consoleScript)

        let config = WKWebViewConfiguration()
        config.userContentController = contentController
        config.preferences.javaScriptCanOpenWindowsAutomatically = true

        // iOS 14+: enable JS explicitly via WKWebpagePreferences
        if #available(iOS 14.0, *) {
            let prefs = WKWebpagePreferences()
            prefs.allowsContentJavaScript = true
            config.defaultWebpagePreferences = prefs
        }

        // Create webview
        let wv = WKWebView(frame: .zero, configuration: config)
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.isOpaque = false
        wv.backgroundColor = .clear
        wv.scrollView.isScrollEnabled = false
        wv.scrollView.bounces = false
        wv.scrollView.backgroundColor = .clear

        // IMPORTANT: constrain to fill self (fixes "blank but sized" due to 0 width/height)
        wv.translatesAutoresizingMaskIntoConstraints = false
        addSubview(wv)
        NSLayoutConstraint.activate([
            wv.leadingAnchor.constraint(equalTo: leadingAnchor),
            wv.trailingAnchor.constraint(equalTo: trailingAnchor),
            wv.topAnchor.constraint(equalTo: topAnchor),
            wv.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])

        webView = wv
        SLogger.i("[PrebidHtmlBannerView:\(dbgId)] ensureWebView CREATED wv")
    }

    private func applySizeToSelf() {
        invalidateIntrinsicContentSize()
        setNeedsLayout()
    }

    private func applySizeToWebView() {
        setNeedsLayout()
        layoutIfNeeded()
    }

    public override var intrinsicContentSize: CGSize {
        if sizeWidth > 0 || sizeHeight > 0 {
            return CGSize(
                width: sizeWidth > 0 ? sizeWidth : UIView.noIntrinsicMetric,
                height: sizeHeight
            )
        }
        return CGSize(width: UIView.noIntrinsicMetric, height: 0)
    }

    // MARK: - Load lifecycle

    private func prepareForNewLoad(gen: Int) {
        cancelWatchdog()

        // Important: clear navigation binding so late callbacks from old navigations are ignored.
        currentNavigation = nil
        currentNavigationGen = gen
        injectedTrackingGen = 0

        guard let wv = webView else { return }
        wv.stopLoading()

        loadedSent = false
        failedSent = false
        impressionSent = false

        // Clear previous content
        wv.loadHTMLString("<html><head></head><body></body></html>", baseURL: lastBaseUrl)
    }

    private func scheduleWatchdog(gen: Int) {
        cancelWatchdog()

        let timeout = loadTimeoutSeconds
        watchdogTask = Task { [weak self] in
            guard let self else { return }
            try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
            guard !Task.isCancelled else { return }
            guard !self.destroyed else { return }
            guard gen == self.loadGeneration else { return }
            if self.loadedSent || self.failedSent { return }

            self.notifyFailedOnce(
                error: NSError(
                    domain: "PrebidHtmlBannerView",
                    code: 2,
                    userInfo: [NSLocalizedDescriptionKey: "PrebidHtmlBannerView: load timeout \(Int(timeout))s"]
                ),
                gen: gen
            )
            
            SLogger.e("[PrebidHtmlBannerView:\(dbgId)] WATCHDOG timeout gen=\(gen) loadGeneration=\(self.loadGeneration) loadedSent=\(self.loadedSent) failedSent=\(self.failedSent)")
        }
    }

    private func cancelWatchdog() {
        watchdogTask?.cancel()
        watchdogTask = nil
    }

    // MARK: - Notifications (once)

    private func notifyLoadedOnce(gen: Int) {
        guard !destroyed else { return }
        guard gen == loadGeneration else { return }
        guard !failedSent else { return }
        guard !loadedSent else { return }

        loadedSent = true
        cancelWatchdog()
        listener?.onAdLoaded()
        SLogger.i("[PrebidHtmlBannerView:\(dbgId)] notifyLoadedOnce gen=\(gen)")
    }

    private func notifyFailedOnce(error: Error, gen: Int) {
        guard !destroyed else { return }
        guard gen == loadGeneration else { return }
        guard !loadedSent else { return }
        guard !failedSent else { return }

        failedSent = true
        cancelWatchdog()
        listener?.onAdFailedToLoad(error: error)
        SLogger.e("[PrebidHtmlBannerView:\(dbgId)] notifyFailedOnce gen=\(gen) err=\(error.localizedDescription)")
    }

    private func notifyClicked() {
        listener?.onAdClicked()
    }

    private func notifyImpression() {
        listener?.onAdImpression()
    }

    private func notifyOpened() {
        listener?.onAdOpened()
    }

    private func notifyClosed() {
        listener?.onAdClosed()
    }

    // MARK: - Click handling

    private func handleNavigation(url: URL, isMainFrame: Bool, userGesture: Bool) -> Bool {
        let lower = url.absoluteString.lowercased()

        // Allow internal / local navigation
        if lower.hasPrefix("about:") || lower.hasPrefix("data:") || lower.hasPrefix("javascript:") {
            return true
        }
        if isLocalhostNav(lower) {
            return true
        }

        // if it’s NOT a user gesture and NOT mainframe, block popups/noise.
        if !userGesture && !isMainFrame {
            return false
        }

        openExternal(url: url)
        return false
    }

    private func openExternal(url: URL) {
        guard !destroyed else { return }

        notifyClicked()

        UIApplication.shared.open(url, options: [:]) { [weak self] success in
            guard let self else { return }
            if success {
                self.browserOpened = true
                self.startCloseObserverIfNeeded()
                self.notifyOpened()
            } else {
                self.notifyFailedOnce(
                    error: NSError(
                        domain: "PrebidHtmlBannerView",
                        code: 3,
                        userInfo: [NSLocalizedDescriptionKey: "PrebidHtmlBannerView: failed to open url \(url.absoluteString)"]
                    ),
                    gen: self.loadGeneration
                )
            }
        }
    }

    private func isLocalhostNav(_ lower: String) -> Bool {
        return lower == "https://localhost/" ||
        lower == "http://localhost/" ||
        lower.hasPrefix("https://localhost/") ||
        lower.hasPrefix("http://localhost/")
    }

    private func wrapHtml(inner: String) -> String {
        """
        <!doctype html>
        <html>
          <head>
            <meta charset="utf-8"/>
            <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
            <style>
              html, body { margin:0; padding:0; background:transparent; overflow:hidden; }
              body { display:flex; justify-content:center; align-items:flex-start; }
              body > * { margin-left:auto; margin-right:auto; }
            </style>
          </head>
          <body>
            \(inner)
          </body>
        </html>
        """
    }

    private func injectImpressionAndClickTracking(gen: Int) {
        guard !destroyed else { return }
        guard gen == loadGeneration else { return }
        guard injectedTrackingGen != gen else { return } // only once per generation
        guard let wv = webView else { return }

        injectedTrackingGen = gen

        let js = """
        (function() {
          try {
            var gen = \(gen);

            function post(kind, payload) {
              try {
                if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.stroeer) {
                  var msg = Object.assign({ kind: kind, gen: gen }, payload || {});
                  window.webkit.messageHandlers.stroeer.postMessage(msg);
                }
              } catch (e) {}
            }

            function click(u) {
              post("click", { href: String(u || "") });
            }

            // Hook window.open
            try {
              if (!window.__stroeer_open_hooked) {
                window.__stroeer_open_hooked = true;
                var origOpen = window.open;
                window.open = function(u) { click(u); return null; };
                window.open.toString = function() { return String(origOpen); };
              }
            } catch (e) {}

            // Hook location.assign / replace
            try {
              if (window.location && window.location.assign && !window.__stroeer_assign_hooked) {
                window.__stroeer_assign_hooked = true;
                var origAssign = window.location.assign.bind(window.location);
                window.location.assign = function(u) { click(u); };
                window.location.assign.toString = function() { return String(origAssign); };
              }
            } catch (e) {}

            try {
              if (window.location && window.location.replace && !window.__stroeer_replace_hooked) {
                window.__stroeer_replace_hooked = true;
                var origReplace = window.location.replace.bind(window.location);
                window.location.replace = function(u) { click(u); };
                window.location.replace.toString = function() { return String(origReplace); };
              }
            } catch (e) {}

            // Capture anchor clicks (capture = true)
            try {
              if (!window.__stroeer_anchor_hooked) {
                window.__stroeer_anchor_hooked = true;
                window.addEventListener('click', function(ev) {
                  try {
                    var a = ev.target && ev.target.closest ? ev.target.closest('a') : null;
                    var href = a && a.href ? a.href : '';
                    if (href) { click(href); }
                  } catch (e) {}
                }, true);
              }
            } catch (e) {}

            // Impression (IntersectionObserver + fallbacks)
            try {
              if (!window.__stroeer_imp_hooked) {
                window.__stroeer_imp_hooked = true;
                var sent = false;

                function sendImpOnce() {
                  if (sent) return;
                  sent = true;
                  post("impression", {});
                }

                if ('IntersectionObserver' in window) {
                  var target = document.documentElement || document.body;
                  var obs = new IntersectionObserver(function(entries) {
                    if (sent) return;
                    for (var i=0;i<entries.length;i++) {
                      if (entries[i].isIntersecting && entries[i].intersectionRatio > 0) {
                        sendImpOnce();
                        try { obs.disconnect(); } catch (e) {}
                        break;
                      }
                    }
                  }, { threshold: [0.01] });

                  if (target) { obs.observe(target); }

                  // fallback if IO never triggers
                  setTimeout(sendImpOnce, 800);
                  setTimeout(sendImpOnce, 2000);
                } else {
                  setTimeout(sendImpOnce, 0);
                }

                window.addEventListener('touchstart', function(){ sendImpOnce(); }, { once:true, capture:true });
                window.addEventListener('mousedown', function(){ sendImpOnce(); }, { once:true, capture:true });
              }
            } catch (e) {}
          } catch (e) {}
        })();
        """

        wv.evaluateJavaScript(js) { _, error in
            if let error {
                SLogger.e("[PrebidHtmlBannerView] inject tracking JS failed: \(error.localizedDescription)")
            }
        }
    }
    
    deinit {
        SLogger.i("[PrebidHtmlBannerView:\(dbgId)] deinit")
    }
}

// MARK: - WKNavigationDelegate / WKUIDelegate / Script handler
extension PrebidHtmlBannerView: WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {

    // JS -> native messages
    public nonisolated func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            guard !self.destroyed else { return }
            guard message.name == "stroeer" else { return }

            guard let dict = message.body as? [String: Any],
                  let kind = dict["kind"] as? String else {
                return
            }

            let msgGen = (dict["gen"] as? Int) ?? self.loadGeneration
            if msgGen != self.loadGeneration { return }

            switch kind {
            case "ready":
                self.notifyLoadedOnce(gen: msgGen)

            case "impression":
                if !self.impressionSent {
                    self.impressionSent = true
                    self.notifyImpression()
                }

            case "click":
                let href = (dict["href"] as? String) ?? ""
                if let url = URL(string: href), !href.isEmpty {
                    self.openExternal(url: url)
                } else {
                    self.notifyClicked()
                }

            case "console":
                let type = dict["type"] as? String ?? "log"
                let args = dict["args"] as? [Any] ?? []
                SLogger.i("[PrebidHtmlBannerView][console.\(type)] \(args)")

            default:
                break
            }
        }
    }

    public nonisolated func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            SLogger.i("[PrebidHtmlBannerView:\(dbgId)] WK didFinish nav_is_current=\(navigation === self.currentNavigation) gen=\(self.currentNavigationGen)")
            guard navigation === self.currentNavigation else { return }

            self.injectImpressionAndClickTracking(gen: self.currentNavigationGen)
            self.notifyLoadedOnce(gen: self.currentNavigationGen)
        }
    }

    public func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        SLogger.e("[PrebidHtmlBannerView:\(dbgId)] didFail: \(error.localizedDescription)")
        guard navigation === currentNavigation else { return }
        notifyFailedOnce(error: error, gen: currentNavigationGen)
    }

    public func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        SLogger.e("[PrebidHtmlBannerView:\(dbgId)] didFailProvisionalNavigation: \(error.localizedDescription)")
        guard navigation === currentNavigation else { return }
        notifyFailedOnce(error: error, gen: currentNavigationGen)
    }

    public func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        SLogger.i("[PrebidHtmlBannerView:\(dbgId)] web content process terminated, recreating webview")
        let html = lastHtml
        let base = lastBaseUrl.absoluteString
        safeRecreateWebView()
        if let html, !html.isEmpty {
            setHtml(html, baseUrl: base)
        }
    }

    // Intercept navigation (clicks)
    public func webView(_ webView: WKWebView,
                        decidePolicyFor navigationAction: WKNavigationAction,
                        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {

        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }

        let isMainFrame = navigationAction.targetFrame?.isMainFrame ?? true
        let userGesture = navigationAction.navigationType == .linkActivated

        if handleNavigation(url: url, isMainFrame: isMainFrame, userGesture: userGesture) {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
        }
    }

    // Support window.open / target=_blank
    public func webView(_ webView: WKWebView,
                        createWebViewWith configuration: WKWebViewConfiguration,
                        for navigationAction: WKNavigationAction,
                        windowFeatures: WKWindowFeatures) -> WKWebView? {

        if let url = navigationAction.request.url {
            openExternal(url: url)
        }
        return nil
    }
}

private extension PrebidHtmlBannerView {

    func safeRecreateWebView() {
        guard !destroyed else { return }

        stopCloseObserver()
        cancelWatchdog()

        if let wv = webView {
            wv.configuration.userContentController.removeScriptMessageHandler(forName: "stroeer")
            wv.navigationDelegate = nil
            wv.uiDelegate = nil
            wv.stopLoading()
            wv.removeFromSuperview()
        }
        webView = nil

        currentNavigation = nil
        currentNavigationGen = 0
        injectedTrackingGen = 0

        ensureWebView()
        applySizeToSelf()
        applySizeToWebView()
    }
}

public protocol PrebidHtmlBannerViewListener: AnyObject {
    func onAdClosed()
    func onAdFailedToLoad(error: Error)
    func onAdOpened()
    func onAdLoaded()
    func onAdClicked()
    func onAdImpression()
}
