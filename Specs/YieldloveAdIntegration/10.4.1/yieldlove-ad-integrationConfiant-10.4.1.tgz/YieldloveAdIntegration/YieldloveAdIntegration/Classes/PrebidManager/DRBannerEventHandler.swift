//
//  DRBannerEventHandler.swift
//  Pods
//
//  Created by Shafee Rehman on 03/11/2025.
//

import UIKit
import PrebidMobile
import GoogleMobileAds

/// Decides DR vs GAM once the bid response is available.
final class DRBannerEventHandler: NSObject, BannerEventHandler {
    // MARK: BannerEventHandler conformance
    weak var loadingDelegate: BannerEventLoadingDelegate?
    weak var interactionDelegate: BannerEventInteractionDelegate?

    var adSizes: [CGSize]
    private let baseRequest: AdManagerRequest
    private let adUnitData: YLAdUnitData
    private weak var publisherVC: UIViewController?
    weak var publisherDelegate: YLBannerViewDelegate?
    private let debugSession: BannerDebugSession?
    private let dbgId = UUID().uuidString.prefix(6)

    /// Single wrapper reused forever for this handler instance.
    /// This is what keeps the DR child view alive.
    var currentView: YLBannerView?

    /// Called when Prebid has produced a BidResponse and we’ve decided DR or GAM.
    var onDecision: ((DRDecision) -> Void)?

    init(
        adSizes: [CGSize],
        baseRequest: AdManagerRequest,
        adUnitData: YLAdUnitData,
        publisherVC: UIViewController?,
        publisherDelegate: YLBannerViewDelegate?,
        reuseView: YLBannerView?,
        debugSession: BannerDebugSession?
    ) {
        self.adSizes = adSizes
        self.baseRequest = baseRequest
        self.adUnitData = adUnitData
        self.publisherVC = publisherVC
        self.publisherDelegate = publisherDelegate
        self.currentView = reuseView
        self.debugSession = debugSession
        super.init()
        SLogger.i("[DRBannerEventHandler:\(dbgId)] init adUnit=\(adUnitData.adUnit) reuseView=\(reuseView != nil))")
    }

    // Runs just after loading Prebid banner and just before the prebid delegate functions
    func requestAd(with bidResponse: PrebidMobile.BidResponse?) {
        SLogger.i("[DRBannerEventHandler:\(dbgId)] requestAd bidResponse_nil=\(bidResponse == nil)")
        // If there is no bid at all → straight to GAM (no hb_* targeting)
        guard let bidResponse = bidResponse else {
            let req = makeGAMRequest(pbidTargeting: [:], prebidWon: false)
            let data = GamRequestData(
                adUnitData: adUnitData,
                gamRequest: req,
                publisherViewController: publisherVC,
                publisherDelegate: publisherDelegate
            )
            onDecision?(.gam(requestData: data))
            return
        }

        let hasPrebidWin: Bool = {
            if let kv = bidResponse.targetingInfo, !kv.isEmpty { return true }
            return false
        }()

        if let drBid = bidResponse.allBids?.first(where: { $0.targetingInfo?["dr"] == "true" }),
           let adm = drBid.adm,
           let hbSizeString = drBid.targetingInfo?["hb_size"],
           let size = parseHxW(hbSizeString) {
            SLogger.i("[DRBannerEventHandler:\(dbgId)] DR detected hb_size=\(hbSizeString) wrapperReuse=\(self.currentView != nil)")
            Task { @MainActor [weak self] in
                guard let self else { return }

                // Create fresh webview per load/refresh (safe), wrapper stays same.
                SLogger.i("[DRBannerEventHandler:\(dbgId)] create PrebidHtmlBannerView size=\(size) webViewWrapperReuse=\(self.currentView != nil)")
                let customWebView = PrebidHtmlBannerView(frame: CGRect(origin: .zero, size: size))
                customWebView.setAdSize(width: size.width, height: size.height)
                customWebView.setLoadTimeout(seconds: 8)

                // Reuse single wrapper
                let wrapper: YLBannerView
                if let existing = self.currentView {
                    wrapper = existing
                } else {
                    wrapper = YLBannerView(bannerInfo: self.adUnitData)
                    self.currentView = wrapper
                }

                // Keep wrapper wired to publisher each time
                wrapper.publisherViewController = self.publisherVC
                wrapper.publisherDelegate = self.publisherDelegate

                // Attach the DR view to wrapper (ONLY ONCE)
                wrapper.setBannerView(bannerView: customWebView)
                wrapper.updateSize(to: size)

                // Listener talks to wrapper (publisher events)
                customWebView.listener = PrebidHtmlBannerLifecycleListener(
                    adUnit: self.adUnitData.getPlacementName(),
                    bannerEventHandler: self,
                    wrapper: wrapper
                )

                // start load
                customWebView.setHtml(adm)

                self.debugSession?.didReceiveFromPrebid(
                    targeting: drBid.targetingInfo ?? [:],
                    adUnit: self.adUnitData.adUnit
                )
            }

        } else {
            // GAM path
            let hbTargeting: [String: String] = bidResponse.targetingInfo ?? [:]
            SLogger.i("[DRBannerEventHandler:\(dbgId)] GAM path targetingCount=\(hbTargeting.count) prebidWon=\(hasPrebidWin)")
            let req = makeGAMRequest(pbidTargeting: hbTargeting, prebidWon: hasPrebidWin)
            recordPrebidCacheAndSize(from: req)

            let data = GamRequestData(
                adUnitData: adUnitData,
                gamRequest: req,
                publisherViewController: publisherVC,
                publisherDelegate: publisherDelegate
            )
            SLogger.i("[DRBannerEventHandler:\(dbgId)] onDecision GAM")
            onDecision?(.gam(requestData: data))
        }
    }

    // These two are invoked by the renderer to instruct PBM’s BannerView which path to follow.
    func signalPrebidWin() {
        loadingDelegate?.prebidDidWin()
    }

    func signalAdServerWin() {
        let baseSize = adSizes.first ?? .zero
        let placeholder = UIView(frame: CGRect(origin: .zero, size: baseSize))
        placeholder.backgroundColor = .clear
        loadingDelegate?.adServerDidWin(placeholder, adSize: baseSize)
    }

    func trackImpression() {}
    
    private func parseHxW(_ s: String) -> CGSize? {
        let trimmed = s.lowercased().replacingOccurrences(of: " ", with: "")
        let parts = trimmed.split(separator: "x")
        guard parts.count == 2,
              let w = Double(parts[0]),
              let h = Double(parts[1]),
              w > 0, h > 0 else { return nil }
        return CGSize(width: w, height: h)
    }
}

private extension DRBannerEventHandler {
    func makeGAMRequest(pbidTargeting: [String: String], prebidWon: Bool) -> AdManagerRequest {
        let req = AdManagerRequest()

        var merged: [String: String] = (baseRequest.customTargeting as? [String: String]) ?? [:]

        for (k, v) in pbidTargeting {
            if let ylKey = PrebidConstants.getTranslatedKey(
                key: PrebidConstants.KeyValueTargeting(rawValue: k) ?? .cache_id
            ) {
                merged[ylKey] = v
            } else {
                merged[k] = v
            }
        }

        merged[YLConstants.sdkVersionNumberKey] = YLConstants.version

        let tags: [String: String] = prebidWon
        ? getBidSuccessfulMetaTags(configId: adUnitData.configId)
        : getNoBidsMetaTags(configId: adUnitData.configId)

        let prebidAndMeta = combine(targ1: merged, targ2: tags)

        req.customTargeting = prebidAndMeta

        debugSession?.didReceiveFromPrebid(
            targeting: pbidTargeting.isEmpty ? ["targeting":"Empty"] : pbidTargeting,
            adUnit: adUnitData.adUnit
        )

        debugSession?.didSendToGAM(
            targeting: prebidAndMeta,
            adUnit: adUnitData.adUnit
        )

        if let url = baseRequest.contentURL, !url.isEmpty {
            req.contentURL = url
        }

        return req
    }

    func recordPrebidCacheAndSize(from req: AdManagerRequest) {
        if let cacheKey = PrebidConstants.getTranslatedKey(key: .cache_id),
           let cacheId = req.customTargeting?[cacheKey] as? String {
            self.adUnitData.prebidCacheId = cacheId
        }
        if let szKey = PrebidConstants.getTranslatedKey(key: .size),
           let sz = req.customTargeting?[szKey] as? String {
            self.adUnitData.prebidAdSize = YLCGSizeConverter.getCGSize(for: sz)
        }
    }

    func getBidSuccessfulMetaTags(configId: String) -> [String: String] {
        [
            PrebidConstants.MetaTag.bidSuccess.rawValue: "true",
            PrebidConstants.MetaTag.meta.rawValue: "pid:\(configId).sb:t.pr:t"
        ]
    }

    func getNoBidsMetaTags(configId: String) -> [String: String] {
        [
            PrebidConstants.MetaTag.bidSuccess.rawValue: "false",
            PrebidConstants.MetaTag.meta.rawValue: "pid:\(configId).sb:f"
        ]
    }

    func combine(targ1: [String: String], targ2: [String: String]) -> [String: String] {
        targ1.merging(targ2, uniquingKeysWith: { first, _ in first })
    }
}

enum DRDecision {
    case prebidDirect(view: YLBannerView?, error: Error? = nil)
    case gam(requestData: GamRequestData)
}

private final class PrebidHtmlBannerLifecycleListener: NSObject, PrebidHtmlBannerViewListener {

    let adUnit: String
    weak var bannerEventHandler: DRBannerEventHandler?
    weak var wrapper: YLBannerView?
    private var decisionSent = false

    init(adUnit: String, bannerEventHandler: DRBannerEventHandler, wrapper: YLBannerView) {
        self.adUnit = adUnit
        self.bannerEventHandler = bannerEventHandler
        self.wrapper = wrapper
    }

    func onAdClosed() {
        DispatchQueue.main.async { [weak self] in
            guard let self, let wrapper = self.wrapper else { return }
            wrapper.publisherDelegate?.bannerViewWillDismissScreen?(wrapper)
            wrapper.publisherDelegate?.bannerViewDidDismissScreen?(wrapper)
        }
    }

    func onAdFailedToLoad(error: any Error) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            guard !self.decisionSent else { return }
            self.decisionSent = true
            self.bannerEventHandler?.onDecision?(.prebidDirect(view: nil, error: error))
            SLogger.e("Failed to load HTML in PrebidHtmlBannerView - ad unit: \(adUnit) - error: \(error.localizedDescription)")
        }
    }

    func onAdOpened() {
        DispatchQueue.main.async { [weak self] in
            guard let self, let wrapper = self.wrapper else { return }
            wrapper.publisherDelegate?.bannerViewWillPresentScreen?(wrapper)
        }
    }

    func onAdLoaded() {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            guard !self.decisionSent else { return }
            self.decisionSent = true
            self.bannerEventHandler?.onDecision?(.prebidDirect(view: self.wrapper))
            SLogger.i("Rendering HTML in PrebidHtmlBannerView - ad unit: \(adUnit) onDecision: PREBID_DIRECT")
        }
    }

    func onAdClicked() {
        DispatchQueue.main.async { [weak self] in
            guard let self, let wrapper = self.wrapper else { return }
            wrapper.publisherDelegate?.bannerViewDidRecordClick?(wrapper)
            SLogger.i("PrebidHtmlBannerView - ad unit: \(adUnit) CLICKED")
        }
    }

    func onAdImpression() {
        DispatchQueue.main.async { [weak self] in
            guard let self, let wrapper = self.wrapper else { return }
            wrapper.publisherDelegate?.bannerViewDidRecordImpression?(wrapper)
            SLogger.i("PrebidHtmlBannerView - ad unit: \(adUnit) IMPRESSION")
        }
    }
}
