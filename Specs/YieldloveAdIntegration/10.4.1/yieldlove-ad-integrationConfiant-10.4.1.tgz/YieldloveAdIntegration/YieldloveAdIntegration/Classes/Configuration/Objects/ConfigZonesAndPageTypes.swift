//
//  ConfigZonesAndPageTypes.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

/**
  "zonesAndPageTypes": {
       "level1": {
           "homepage": {
               "keyValues": {
                   "test": "testValue"
               }
           }
       },
       "level2": {
           "sport": {
               "keyValues": {
                   "country": "de"
               }
           }
       },
       "pageType": {
           "rubrik": {
               "keyValues": {
                   "sport": "football"
               }
           }
       }
   },
 */

import Foundation

@objcMembers public class ConfigZonesAndPageTypes: NSObject, Codable {
    public var level1: [String: [String: [String: String]]]?
    public var level2: [String: [String: [String: String]]]?
    public var pageType: [String: [String: [String: String]]]?
    
    public override init() {
        super.init()
    }
}
 
