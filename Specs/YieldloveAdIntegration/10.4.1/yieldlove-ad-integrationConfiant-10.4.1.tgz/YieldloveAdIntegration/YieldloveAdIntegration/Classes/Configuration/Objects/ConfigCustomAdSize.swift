//
//  ConfigCustomAdSize.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 03/03/2025.
//

import Foundation

@objcMembers public class ConfigCustomAdSize : NSObject, Codable{
    public var w: Int?
    public var h: Int?
    
    public override init() {
        super.init()
    }
}
