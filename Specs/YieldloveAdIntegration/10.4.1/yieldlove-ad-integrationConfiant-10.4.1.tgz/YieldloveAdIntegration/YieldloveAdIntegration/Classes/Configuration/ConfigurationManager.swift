//
//  ConfigurationManager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

@objcMembers
public class ConfigurationManager: NSObject {
    public static let shared = ConfigurationManager()
    
    private override init() {} // Prevent instantiation
    
    private var appName: String?
    private var httpFetcher: IFetcher?
    private var usersDefaultFetcher: IFetcher?
    private var lastUpdated: Date?
    
    public var config: Configuration?
    private var isLoading = false
    
    private static var isDebug = false
    private static var isInsepctionMode = false

    public func initialize(appName: String) {
        self.appName = appName
        self.httpFetcher = ConfigHttpFetcher()
        self.usersDefaultFetcher = UserDefaultsFetcher()
        
        reload()
    }
    
    public func initializeAsync(appName:String) async {
        self.appName = appName
        self.httpFetcher = ConfigHttpFetcher()
        self.usersDefaultFetcher = UserDefaultsFetcher()
        
        await reloadAsync()
    }

    func initialize(appName: String, httpFetcher: IFetcher, usersDefaultFetcher: IFetcher) {
        SLogger.e("[ConfigurationManager] instance initialized with fetchers. This should not be called in Production")
        self.httpFetcher = httpFetcher
        self.usersDefaultFetcher = usersDefaultFetcher
        self.appName = appName
        
        reload()
    }

    public func getConfig() -> Configuration? {
        if isLoading {
            if(config == nil)
            {
                SLogger.e("[ConfigurationManager] getConfig is loading. You need to wait for complete")
                return nil
            }
            return config
        }

        reload()
        
        return config
    }
    
    public func getConfigAsync() async -> Configuration? {
        let timeout = UInt64(5_000_000_000) // 5 seconds in nanoseconds
        var elapsedTime: UInt64 = 0
        let interval: UInt64 = 100_000_000 // 100ms delay

        while isLoading && config == nil{
            if elapsedTime >= timeout {
                SLogger.e("[ConfigigurationManager] Timeout for getConfigAsync")
                return nil
            }
            do{
                try await Task.sleep(nanoseconds: interval)
                
            }catch{
                SLogger.e("[ConfigurationManager] getConfigAsync sleep error")
            }
            
            elapsedTime += interval
        }
        
        return config
    }
                
        

    public func reload() {
        isLoading = true
        Task.detached {
            await self.reloadAsync()
        }
    }
    
    public func reloadAsync() async {
        if shouldReloadConfig() {
            SLogger.i("[ConfigurationManager] configuration is loading")
            
            let json = await self.load()
            self.parse(json: json)
            
            if self.config == nil {
                SLogger.e("[ConfigurationManager] failed to load configuration")
            } else {
                SLogger.i("[ConfigurationManager] configuration loaded")
            }
        }
        self.isLoading = false
    }
    
    private func shouldReloadConfig() -> Bool {
        guard let lastUpdated = lastUpdated, let updateInterval = config?.common?.updateIntervalMs else {
            return true
        }
        return Date().timeIntervalSince(lastUpdated) > Double(updateInterval) / 1000.0
    }

    private func load() async -> String? {
        guard let appName = appName, let httpFetcher = httpFetcher else { return nil }
        
        if let json = await httpFetcher.load(appName: appName) {
            await usersDefaultFetcher?.store(json: json)
            lastUpdated = Date()
            return json
        }
        return nil
    }

    private func parse(json: String?) {
        if let json = json {
            config = Configuration.fromJson(json)
        } else {
            SLogger.e("[ConfigurationManager] failed to parse JSON, JSON is null")
        }
    }

    public func reset() {
        SLogger.i("[ConfigurationManager] reset")
        usersDefaultFetcher?.delete()
        config = nil
    }
    
    public func loadFromJson(json: String){
        SLogger.i("[Stroeer-ConfigurationManager] load from json")
        lastUpdated = Date()
        parse(json: json)
    }
    
    
    public static func enableDebugMode(){
        SLogger.d("[ConfigurationManager] debug mode enabled")
        isDebug = true
    }
    
    public static func isDebugMode() -> Bool {
        return isDebug
    }
    
    public class func enableInspectionMode() {
        SLogger.d("[ConfigurationManager] inspection mode enabled")
        isInsepctionMode = true
    }
    
    public class func isInspectionMode() -> Bool {
        return isInsepctionMode
    }

    public func isLoaded() -> Bool {
        return config != nil
    }

    public func isValid() throws {
        guard config != nil else {
            throw ConfigurationIsNotLoadedException()
        }
    }
    
    public func getAppName() -> String? {
        return appName
    }
}
