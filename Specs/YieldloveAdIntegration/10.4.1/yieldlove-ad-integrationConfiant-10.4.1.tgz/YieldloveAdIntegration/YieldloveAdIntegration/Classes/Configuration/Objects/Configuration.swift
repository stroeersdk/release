//
//  Configuration.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

@objcMembers public class Configuration: NSObject, Codable {
    public var common: ConfigCommon?
    public var formats: [String: ConfigFormat]?
    public var modules: ConfigModules?
    public var openRtb: ConfigOpenRtb?
    public var zonesAndPageTypes: ConfigZonesAndPageTypes?
    public var adSlots: [String: ConfigAdSlot]?

    public override init() {
        super.init()
    }
    
    public static func fromJson(_ json: String) -> Configuration? {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase // If JSON keys use snake_case
        
        do {
            let data = json.data(using: .utf8)!
            return try decoder.decode(Configuration.self, from: data)
        } catch {
            SLogger.e("[Configuration] Failed to parse the data", error)
            return nil
        }
    }
    
    public static func fromData(_ data: Data)-> Configuration?{
        let decoder = JSONDecoder()
        // decoder.keyDecodingStrategy = .convertFromSnakeCase // If JSON keys use snake_case
        
        do {
            return try decoder.decode(Configuration.self, from: data)
        } catch {
            SLogger.e("[Configuration] Failed to parse the data", error)
            return nil
        }
    }

    public func isValid() -> Bool {
        return common != nil
    }
}
