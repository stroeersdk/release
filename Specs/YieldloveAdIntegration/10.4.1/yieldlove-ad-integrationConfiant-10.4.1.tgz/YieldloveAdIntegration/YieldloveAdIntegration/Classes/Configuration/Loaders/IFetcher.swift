//
//  Fetcher.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

public protocol IFetcher {
    func load(appName: String) async -> String?
    func store(json: String ) async
    func delete()
}
