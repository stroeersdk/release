//
//  UserDefaultsFetcher.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

class UserDefaultsFetcher: IFetcher{
    private let userDefaults = UserDefaults.standard

    public func load(appName: String) -> String? {
        return userDefaults.string(forKey: ConfigConstants.shared.getPrefsConfig())
    }

    public func store(json: String) {
        userDefaults.set(json, forKey: ConfigConstants.shared.getPrefsConfig())
    }

    public func delete() {
        userDefaults.removeObject(forKey: ConfigConstants.shared.getPrefsConfig())
    }
}
