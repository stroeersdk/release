//
//  ConfigApis.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 03/03/2025.
//

import Foundation

@objcMembers public class ConfigOpenRtb: NSObject, Codable {
    public var apis: [ConfigApis]?

    public func getFramework() -> [Int]? {
        guard let apis = apis, !apis.isEmpty else {
            return nil
        }
        return apis.map { $0.framework }
    }
    
    public override init() {
        super.init()
    }
}

@objcMembers public class ConfigApis : NSObject, Codable {
    public var framework : Int
    public init(framework: Int) {
        self.framework = framework
        super.init()
    }
    
}
