//
//  ConfigurationIsNotLoadedException.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

public class ConfigurationIsNotLoadedException: Error {
    
}
