//
//  ConfigCommon.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

/**
 "common": {
 "dfpAppNetwork": "36930962",
 "dfpiOSAppName": "m.app.ios_sport1.de_sd",
 "dfpAndroidAppName": "m.app.droid_sport1.de_sd",
 "dfpAdRequestTimeoutMs": 7000,
 "updateIntervalMs": 60000,
 "androidStoreUrl": "https://play.google.com/store/apps/details?id=sport1.mobile.android.apps&hl=de&gl=US",
 "androidBundleId": "sport1.mobile.android.apps",
 "iOSStoreUrl": "https://apps.apple.com/de/app/sport1-sport-fussball-news/id300000385",
 "iOSITunesId": "300000385"
 "setAppMuted": true
 },

Android data will be ignored
 */

import Foundation


@objc public enum AdsSoundSettingStates : Int, Codable {
    case mute
    case unmute
    case respectUserSoundSetting
}

@objcMembers public class ConfigCommon: NSObject, Codable {
    public var dfpAppNetwork: String?
    public var dfpiOSAppName: String?
    public var dfpAdRequestTimeoutMs: Int?
    public var updateIntervalMs: Int?
    public var rtaAuction: Bool?
    public var iOSStoreUrl: String?
    public var iOSITunesId: String?
    public var inventoryStructure: String?
    public var setAppMuted: Bool?

    public override init() {
        super.init()
    }
    
    public func getSoundSetting() -> AdsSoundSettingStates {
        guard let isMuted = setAppMuted else {
            return .respectUserSoundSetting
        }
        return isMuted ? .mute : .unmute
    }
}
