//
//  ConfigModules.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

@objcMembers public class ConfigModule_ID5: NSObject, Codable {
    public var active : Bool = false
    public var refreshIntervalInSecs = 8 * 60 * 60;
    
    public override init() {
        super.init()
    }
}

@objcMembers public class ConfigModule_Prebid : NSObject, Codable {
    public var yieldloveAccountId : String?
    
    public override init() {
        super.init()
    }
}

@objcMembers public class ConfigModule_Confiant : NSObject, Codable {
    public var active: Bool = false
    public var confiantPropertyID : String? = nil
    
    public override init() {
        super.init()
    }
}

@objcMembers public class ConfigModule_SourcePoint : NSObject, Codable {
    public var sourcepointAccountId: Int?
    public var active: Bool?
    public var propertyId: Int?
    public var propertyName: String?
    public var privacyManagerId: String?
    public var overrides: [String: ConfigModule_SourcePoint]?
    
    public override init() {
        super.init()
    }
    
    public required init(from decoder: Decoder) throws {
        super.init()
        let container = try decoder.container(keyedBy: CodingKeys.self)

        if let stringValue = try container.decodeIfPresent(String.self, forKey: .sourcepointAccountId) {
            sourcepointAccountId = Int(stringValue) // Convert to Int
        }
        
        active = try container.decodeIfPresent(Bool.self, forKey: .active)
        
        if let stringValue = try container.decodeIfPresent(String.self, forKey: .propertyId) {
            propertyId = Int(stringValue) // Convert to Int
        }
        
        propertyName = try container.decodeIfPresent(String.self, forKey: .propertyName)
        privacyManagerId = try container.decodeIfPresent(String.self, forKey: .privacyManagerId)
        overrides = try container.decodeIfPresent([String: ConfigModule_SourcePoint].self, forKey: .overrides)
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(sourcepointAccountId, forKey: .sourcepointAccountId)
        try container.encodeIfPresent(active, forKey: .active)
        try container.encodeIfPresent(propertyId, forKey: .propertyId)
        try container.encodeIfPresent(propertyName, forKey: .propertyName)
        try container.encodeIfPresent(privacyManagerId, forKey: .privacyManagerId)
        try container.encodeIfPresent(overrides, forKey: .overrides)
    }

    private enum CodingKeys: String, CodingKey {
        case sourcepointAccountId, active, propertyId, propertyName, privacyManagerId, overrides
    }
}

@objcMembers public class ConfigModules: NSObject, Codable {
    public var prebid: ConfigModule_Prebid?
    public var sourcePoint: ConfigModule_SourcePoint?
    public var confiant: ConfigModule_Confiant?
    public var id5: ConfigModule_ID5 = ConfigModule_ID5()
    
    public override init() {
        super.init()
    }
    
    // Custom decoding to mimic the Java deserializer.
    public required init(from decoder: Decoder) throws {
        super.init()
        
        // Get the container for an array of module objects.
        var modulesContainer = try decoder.unkeyedContainer()
        
        while !modulesContainer.isAtEnd {
            // Each element is a nested container keyed by dynamic keys.
            let moduleContainer = try modulesContainer.nestedContainer(keyedBy: DynamicCodingKeys.self)
            
            // If the key "PREBID" exists, decode it.
            if let prebidKey = DynamicCodingKeys(stringValue: "PREBID"),
               let prebidValue = try moduleContainer.decodeIfPresent(ConfigModule_Prebid.self, forKey: prebidKey) {
                self.prebid = prebidValue
            }
                        
            // If the key "iOSSOURCEPOINT" exists, decode it.
            if let sourcePointKey = DynamicCodingKeys(stringValue: "iOSSOURCEPOINT"),
               let sourcePointValue = try moduleContainer.decodeIfPresent(ConfigModule_SourcePoint.self, forKey: sourcePointKey) {
                self.sourcePoint = sourcePointValue
            }
            
            // If the key "ID5" exists, decode it.
            if let id5Key = DynamicCodingKeys(stringValue: "ID5"),
               let id5Value = try moduleContainer.decodeIfPresent(ConfigModule_ID5.self, forKey: id5Key) {
                self.id5 = id5Value
            }
            
            // If the key "CONFIANT" exists
            if let confiantKey = DynamicCodingKeys(stringValue: "CONFIANT"),
               let confiantValue = try moduleContainer.decodeIfPresent(ConfigModule_Confiant.self, forKey: confiantKey) {
                self.confiant = confiantValue
            }
        }
    }
    
    // Optional: implement encoding if needed.
   public func encode(to encoder: Encoder) throws {
        // You can encode using a similar approach (for example, by creating an array of dictionaries).
        var container = encoder.unkeyedContainer()
        // Example: if you wish to encode each module as an object with its keys.
        if let prebid = prebid {
            var moduleContainer = container.nestedContainer(keyedBy: DynamicCodingKeys.self)
            let key = DynamicCodingKeys(stringValue: "PREBID")!
            try moduleContainer.encode(prebid, forKey: key)
        }
        if let sourcePoint = sourcePoint {
            var moduleContainer = container.nestedContainer(keyedBy: DynamicCodingKeys.self)
            let key = DynamicCodingKeys(stringValue: "SOURCEPOINT")!
            try moduleContainer.encode(sourcePoint, forKey: key)
        }
        
        if let confiant = confiant {
            var moduleContainer = container.nestedContainer(keyedBy: DynamicCodingKeys.self)
            let key = DynamicCodingKeys(stringValue: "CONFIANT")!
            try moduleContainer.encode(confiant, forKey: key)
        }
        
        // Encode id5 (even if it is default) if needed.
        var moduleContainer = container.nestedContainer(keyedBy: DynamicCodingKeys.self)
        let id5Key = DynamicCodingKeys(stringValue: "ID5")!
        try moduleContainer.encode(id5, forKey: id5Key)
    }
}

/// A helper struct that allows dynamic key lookups.
struct DynamicCodingKeys: CodingKey {
    var stringValue: String
    init?(stringValue: String) { self.stringValue = stringValue }
    
    var intValue: Int? { return nil }
    init?(intValue: Int) { return nil }
}


