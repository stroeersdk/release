//
//  ConfigConstants.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 03/03/2025.
//

import Foundation

class ConfigConstants {
    
    static public let shared = ConfigConstants()
    static private var _instance = ConfigConstants()
    
    private init() {}

    private static let PREFS_CONFIG = "STROEER_CONFIG"
    private static let CONFIG_URL = "https://cdn.stroeerdigitalgroup.de/sdk/live/{APPLICATION_NAME}/config.json"
    private static let APPLICATION_NAME_PLACEHOLDER = "{APPLICATION_NAME}"
    private static let CONFIG_TIMEOUT_SECONDS = 5

    let yieldloveDfpId = "53015287"
    let sourcepointIsStagingCampaign = false
    let externalConfigSharedPrefsFileKey = "EXTERNAL_CONFIG_FILE_KEY"
    let externalConfigContentKey = "EXTERNAL_CONFIG_CONTENT_KEY"
    let externalConfigLastFetchInMillisKey = "EXTERNAL_CONFIG_LAST_FETCH_IN_MILLIS_KEY"
    let prebidTimeOut = 3000
    let errorReporterUrl = "https://mobile-sdk.stroeer-labs.com/api/reporting"
    let monitoringReporterUrl = "https://mobile-sdk.stroeer-labs.com/api/event-sessions"
    let errorReporterApiKey = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T"
    let monitoringReporterApiKey = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T"
    let OmidPartnerName = "Google"
    let OmidPartnerVersion = "213502000.213502000"

    func getPrefsConfig() -> String {
        return ConfigConstants.PREFS_CONFIG
    }

    func getConfigUrl() -> String {
        return ConfigConstants.CONFIG_URL
    }

    func getApplicationNamePlaceholder() -> String {
        return ConfigConstants.APPLICATION_NAME_PLACEHOLDER
    }

    func getConfigTimeout() -> Int {
        return ConfigConstants.CONFIG_TIMEOUT_SECONDS
    }
}
