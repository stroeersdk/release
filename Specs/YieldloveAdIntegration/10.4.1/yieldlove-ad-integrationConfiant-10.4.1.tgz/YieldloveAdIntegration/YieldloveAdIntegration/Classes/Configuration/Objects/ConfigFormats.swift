//
//  ConfigFormat.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

import GoogleMobileAds

@objcMembers public class ConfigFormat: NSObject, Codable {
    public var active: Bool?
    public var availableOn: [String]?
    public var dfpSizes: ConfigFormatSizes?
    
    public override init() {
        super.init()
    }
}

@objcMembers public class ConfigFormatSizes: NSObject, Codable {
    public var androidAdSizes: [String]?
    public var customAdSizes: [ConfigCustomAdSize]?
    

    public override init() {
        super.init()
    }
    
    public static func getBannerSize(for gadSize: String) -> AdSize? {
        switch gadSize {
        case "GADAdSizeBanner":
            return AdSizeBanner
        case "GADAdSizeLargeBanner":
            return AdSizeLargeBanner
        case "GADAdSizeFullBanner":
            return AdSizeFullBanner
        case "GADAdSizeMediumRectangle":
            return AdSizeMediumRectangle
        case "GADAdSizeLeaderboard":
            return AdSizeLeaderboard
        case "GADAdSizeSkyscraper":
            return AdSizeSkyscraper
        case "GADAdSizeFluid":
            return AdSizeFluid
        case "GADAdSizeInvalid":
            return AdSizeInvalid
        default:
            return nil
        }
    }
}
