struct ContextualTargetingConstants {
    static let iabVendorConsentsKey = "IABTCF_VendorConsents"
    static let iabPurposeConsentsKey = "IABTCF_PurposeConsents"
    static let iabVendorLegitimateInterestKey = "IABTCF_VendorLegitimateInterests"
    static let iabPurposeLegitimateInterestKey = "IABTCF_PurposeLegitimateInterests"
    static let iabPublisherRestrictionsKeyPattern = "IABTCF_PublisherRestrictions{ID}"
    static let iabPublisherRestrictionsPlaceholder = "{ID}"
    static let symbolOfBinaryPermission: Character = "1"
    static let nonFlexiblePurpose1Id = 1
    static let iabTCStringKey = "IABTCF_TCString"
}
