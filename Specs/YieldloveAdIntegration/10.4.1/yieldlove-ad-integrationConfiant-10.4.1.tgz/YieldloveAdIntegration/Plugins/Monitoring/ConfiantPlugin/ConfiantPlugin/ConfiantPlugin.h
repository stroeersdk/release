//
//  ConfiantPlugin.h
//  ConfiantPlugin
//
//  Created by Hyungon Kim on 10/10/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for ConfiantPlugin.
FOUNDATION_EXPORT double ConfiantPluginVersionNumber;

//! Project version string for ConfiantPlugin.
FOUNDATION_EXPORT const unsigned char ConfiantPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConfiantPlugin/PublicHeader.h>


