//
//  YieldloveConsent.h
//  YieldloveConsent
//
//  Created by Gianpiero Bozza on 02.11.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for YieldloveConsent.
FOUNDATION_EXPORT double YieldloveConsentVersionNumber;

//! Project version string for YieldloveConsent.
FOUNDATION_EXPORT const unsigned char YieldloveConsentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YieldloveConsent/PublicHeader.h>


