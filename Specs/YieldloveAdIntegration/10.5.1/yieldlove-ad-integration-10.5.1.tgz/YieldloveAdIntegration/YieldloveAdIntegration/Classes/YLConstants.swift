// swiftlint:disable line_length

import GoogleMobileAds

struct YLConstants {
    static let sdkName = "StroeerSDK"
    static let version = "10.5.1"
    static let ylDfpAccountId = "53015287"
    static let standardAdSizes = [
        AdSizeBanner,
        AdSizeLargeBanner,
        AdSizeMediumRectangle,
        AdSizeFullBanner,
        AdSizeLeaderboard,
        AdSizeSkyscraper,
        AdSizeFluid,
        AdSizeInvalid
    ]
    static let adSlotConfigurationErrorMessage = "There was a problem with finding, parsing or applying external configuration for this ad slot (publisher call string)"
    static let sdkVersionNumberKey = "iosYlSdkVersion"
    static let omidPartnerName = "Google"
    static let omidPartnerVersion = "afma-sdk-i-v8.8.0"
}
