//
//  ConfigAdSlot.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 03/03/2025.
//

import Foundation

@objcMembers public class ConfigAdSlot : NSObject, Codable{
    public var iOSPrebidConfigId: String?
    public var rtaAuction: Bool?
    public var autoRefreshTimeMs: Int?
    public var keyValues: [String: [String]]?
    public var customAdSizes: [ConfigCustomAdSize]? = []
    
    public override init() {
        super.init()
    }
    
    public required init(from decoder: Decoder) throws {
            super.init()
            let container = try decoder.container(keyedBy: CodingKeys.self)

            do {
                iOSPrebidConfigId = try container.decodeIfPresent(String.self, forKey: .iOSPrebidConfigId)
            } catch {
                SLogger.e("[ConfigAdSlot] Failed to decode iOSPrebidConfigId", error)
            }

            do {
                rtaAuction = try container.decodeIfPresent(Bool.self, forKey: .rtaAuction)
            } catch {
                SLogger.e("[ConfigAdSlot] Failed to decode rtaAuction", error)
            }

            do {
                autoRefreshTimeMs = try container.decodeIfPresent(Int.self, forKey: .autoRefreshTimeMs)
            } catch {
                SLogger.e("[ConfigAdSlot] Failed to decode autoRefreshTimeMs", error)
            }

            do {
                customAdSizes = try container.decodeIfPresent([ConfigCustomAdSize].self, forKey: .customAdSizes)
            } catch {
                SLogger.e("[ConfigAdSlot] Failed to decode customAdSizes", error)
            }

            do {
                // Convert keyValues JSON structure into a Swift Dictionary
                if let keyValuesRaw = try container.decodeIfPresent([String: String].self, forKey: .keyValues) {
                    var formattedKeyValues: [String: [String]] = [:]
                    for (key, value) in keyValuesRaw {
                        formattedKeyValues[key] = value
                            .components(separatedBy: ",")
                            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                            .filter { !$0.isEmpty } // Split comma-separated values
                    }
                    keyValues = formattedKeyValues
                }
            } catch {
                SLogger.e("[ConfigAdSlot] Failed to decode keyValues", error)
            }
        }

        public func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)

            try container.encodeIfPresent(iOSPrebidConfigId, forKey: .iOSPrebidConfigId)
            try container.encodeIfPresent(rtaAuction, forKey: .rtaAuction)
            try container.encodeIfPresent(autoRefreshTimeMs, forKey: .autoRefreshTimeMs)
            try container.encodeIfPresent(customAdSizes, forKey: .customAdSizes)

            if let keyValues = keyValues {
                var stringKeyValues: [String: String] = [:]
                for (key, values) in keyValues {
                    stringKeyValues[key] = values.joined(separator: ",") // Convert back to comma-separated String
                }
                try container.encode(stringKeyValues, forKey: .keyValues)
            }
        }

        private enum CodingKeys: String, CodingKey {
            case iOSPrebidConfigId, rtaAuction, autoRefreshTimeMs, customAdSizes, keyValues
        }

    public func isInterstitial() -> Bool {
        return keyValues?.values.contains { $0.contains("interstitial") } ?? false
    }

    public func isBanner() -> Bool {
        return !isInterstitial()
    }
}


