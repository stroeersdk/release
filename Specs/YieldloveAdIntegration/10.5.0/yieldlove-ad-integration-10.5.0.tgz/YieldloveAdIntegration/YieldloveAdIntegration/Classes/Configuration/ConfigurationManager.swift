//
//  ConfigurationManager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

public typealias IConfigurationListener = any ISuccessFailListener<Any?>

@objcMembers
public class ConfigurationManager: NSObject {
    public static let shared = ConfigurationManager()

    private override init() {}

    // MARK: - State

    private var appName: String?
    private var httpFetcher: IFetcher?
    private var usersDefaultFetcher: IFetcher?

    public private(set) var config: Configuration?
    private var lastUpdated: Date?
    public private(set) var lastError: Error?

    private var backgroundRefreshTask: Task<Void, Never>?

    private static var _isDebug = false
    private static var _isInspectionMode = false
    public static var forcePrebidRendering = false

    /// Marks a cached config as stale so a refresh will be attempted soon.
    private static let staleCacheDate = Date(timeIntervalSince1970: 0)

    private let reloadLock = AsyncLock()
    private let networkReloadLock = AsyncLock()

    /// Cooldown to avoid hammering refresh attempts while offline.
    private let nextAllowedRefreshInterval: TimeInterval = 5.0
    private var prevNetworkRefreshTime: Date?

    private let maxRetries = 2

    public var requestTimeout: TimeInterval {
        let ms = config?.common?.dfpAdRequestTimeoutMs ?? (ConfigConstants.shared.getConfigTimeout() * 2 * 1000)
        return Double(ms) / 1000.0
    }

    private var updateIntervalMs: Int {
        if Self._isDebug { return 300_000 }
        return config?.common?.updateIntervalMs ?? 900_000
    }

    // MARK: - Initialization
    public func initialize(appName: String, listener: (any ISuccessFailListener<Any?>)? = nil) {
        if appName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            SLogger.e("[ConfigurationManager] appName empty")
            lastError = ConfigurationManagerError.appNameEmpty
            notifyFailed(listener)
            return
        }

        self.appName = appName
        self.httpFetcher = ConfigHttpFetcher()
        self.usersDefaultFetcher = UserDefaultsFetcher()

        Task { [weak self, weak listener] in
            guard let self else { return }
            let success = await self.reload()
            if success {
                self.displayConfiguration()
                self.notifySuccess(listener)
            } else {
                self.notifyFailed(listener)
            }
        }
    }

    func initialize(appName: String, httpFetcher: IFetcher, usersDefaultFetcher: IFetcher) {
        SLogger.e("[ConfigurationManager] instance initialized with fetchers. This should not be called in Production")
        self.httpFetcher = httpFetcher
        self.usersDefaultFetcher = usersDefaultFetcher
        self.appName = appName

        Task { [weak self] in
            _ = await self?.reload()
        }
    }

    // MARK: - Public API
    public func getConfig() -> Configuration? {
        maybeRefreshInBackground()
        return config
    }

    @discardableResult
    public func getConfigAsync(timeoutSeconds: TimeInterval = 10.0) async -> Configuration? {
        if config != nil {
            return config
        }

        return await withTimeout(seconds: timeoutSeconds) { [weak self] in
            guard let self else { return nil }
            
            _ = await self.reload()
            return self.config
        }
    }

    public func reset() {
        SLogger.i("[ConfigurationManager] reset")
        usersDefaultFetcher?.delete()
        backgroundRefreshTask?.cancel()
        backgroundRefreshTask = nil
        lastError = nil
        config = nil
        lastUpdated = nil
        prevNetworkRefreshTime = nil
    }

    public func isLoaded() -> Bool {
        return config != nil
    }

    public func ensureValid() throws {
        if config == nil && (appName?.isEmpty ?? true) {
            throw ConfigurationIsNotLoadedException()
        }
    }

    public func getAppName() -> String? {
        return appName
    }

    // Test Only. Should be use with @testable in unit tests or for manual testing.
    internal func loadFromJson(json: String) {
        SLogger.i("[Stroeer-ConfigurationManager] load from json")
        applyConfig(raw: json, timestamp: Date(), source: "manual json")
    }

    // MARK: - Debug / Inspection

    public static func enableDebugMode() {
        SLogger.d("[ConfigurationManager] debug mode enabled")
        _isDebug = true
    }

    public static func isDebugMode() -> Bool {
        return _isDebug
    }

    public class func enableInspectionMode() {
        SLogger.d("[ConfigurationManager] inspection mode enabled")
        _isInspectionMode = true
        enableDebugMode()
    }

    public class func isInspectionMode() -> Bool {
        return _isInspectionMode
    }

    // MARK: - Refresh scheduling

    private func maybeRefreshInBackground() {
        guard needsRefresh() else { return }
        reloadInBackground()
    }

    private func reloadInBackground() {
        if backgroundRefreshTask != nil { return }

        backgroundRefreshTask = Task { [weak self] in
            guard let self else { return }
            _ = await self.reload()
            self.backgroundRefreshTask = nil
        }
    }

    private func needsRefresh() -> Bool {
        guard config != nil, let lastUpdated = lastUpdated else { return true }
        if lastUpdated == Self.staleCacheDate { return true }
        return Date().timeIntervalSince(lastUpdated) > Double(updateIntervalMs) / 1000.0
    }

    // MARK: - Config loading
    @discardableResult
    private func applyConfig(raw: String, timestamp: Date, source: String) -> Bool {
        guard let parsed = Configuration.fromJson(raw), parsed.isValid() else {
            lastError = ConfigurationManagerError.parseFailed
            SLogger.e("[ConfigurationManager] failed to parse configuration from \(source)")
            return false
        }

        config = parsed
        lastUpdated = timestamp
        Task {
            await usersDefaultFetcher?.store(json: raw)
        }
        SLogger.i("[ConfigurationManager] loaded configuration from \(source)")
        return true
    }

    private func refreshFromNetwork() async -> String? {
        await networkReloadLock.withLock { [weak self] in
            guard let self else { return nil }
            
            // Recheck if refresh is still needed, another caller might have refreshed while waiting
            if !needsRefresh() { return nil }

            // Cooldown check
            if let prev = prevNetworkRefreshTime, Date().timeIntervalSince(prev) < nextAllowedRefreshInterval {
                lastError = ConfigurationManagerError.refreshCooldown
                SLogger.e("[ConfigurationManager] refreshFromNetwork called before cooldown - skipping")
                return nil
            }

            prevNetworkRefreshTime = Date()

            guard let appName = appName, let httpFetcher = httpFetcher else { return nil }

            for attempt in 0..<maxRetries {
                SLogger.i("[ConfigurationManager] \(appName), network refresh attempt \(attempt + 1)/\(maxRetries)")

                if let json = await httpFetcher.load(appName: appName) {
                    SLogger.d("[ConfigurationManager] \(appName), network refresh successful")
                    return json
                }

                let error = ConfigurationManagerError.unableToFetchConfig
                lastError = error
                SLogger.e("[ConfigurationManager] \(appName), network refresh failed (attempt \(attempt + 1)/\(maxRetries))")

                if attempt < maxRetries - 1 {
                    try? await Task.sleep(nanoseconds: UInt64(1_000_000_000 * (attempt + 1)))
                }
            }

            return nil
        }
    }

    /// Cache-first reload matching Android behavior:
    /// 1. Try cache -> use immediately, refresh network in background
    /// 2. If no cache -> load from network synchronously
    private func reload() async -> Bool {
        guard let appName = appName, !appName.isEmpty else {
            lastError = ConfigurationManagerError.appNameEmpty
            SLogger.e("[ConfigurationManager] appName is null or empty")
            return false
        }

        return await reloadLock.withLock { [weak self] in
            guard let self else { return false }
            
            // Recheck after acquiring lock, another caller might have reloaded while waiting
            if !needsRefresh() { return true }

            // 1. Try loading from cache first
            if let cachedRaw = await usersDefaultFetcher?.load(appName: appName), !cachedRaw.isEmpty {
                applyConfig(raw: cachedRaw, timestamp: Self.staleCacheDate, source: "cache")
                SLogger.i("[ConfigurationManager] loaded from cache")

                // Refresh from network in background
                Task { [weak self] in
                    guard let self else { return }
                    if let raw = await self.refreshFromNetwork() {
                        self.applyConfig(raw: raw, timestamp: Date(), source: "network (async)")
                    }
                }
                return true
            } else {
                SLogger.i("[ConfigurationManager] no cached configuration available - \(appName)")
            }

            // 2. No cache: load from network
            if let raw = await refreshFromNetwork() {
                return applyConfig(raw: raw, timestamp: Date(), source: "network")
            }

            return config != nil
        }
    }

    // MARK: - Listener notifications

    private func notifySuccess(_ listener: (any ISuccessFailListener<Any?>)?) {
        Task { @MainActor in listener?.onSuccess(data: nil) }
    }

    private func notifyFailed(_ listener: (any ISuccessFailListener<Any?>)?) {
        Task { @MainActor in listener?.onFailed() }
    }

    // MARK: - Display

    public func displayConfiguration() {
        SLogger.i("""
        [ConfigurationManager] Configuration Settings Loaded
        SDK Version : \(YLConstants.version)
        ApplicationName : \(appName ?? "")
        Ad Request Timeout(ms) : \(requestTimeout * 1000)
        Configuration Update Interval(ms) : \(updateIntervalMs)
        """)
    }
}
