//
//  Configuration.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

@objcMembers public class Configuration: NSObject, Codable {
    public var common: ConfigCommon?
    public var formats: [String: ConfigFormat]?
    public var modules: ConfigModules?
    public var openRtb: ConfigOpenRtb?
    public var zonesAndPageTypes: ConfigZonesAndPageTypes?
    public var adSlots: [String: ConfigAdSlot]?

    public override init() {
        super.init()
    }
    
    public static func fromJson(_ json: String) -> Configuration? {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase // If JSON keys use snake_case
        
        guard let data = json.data(using: .utf8) else {
            SLogger.e("[Configuration] Failed to encode json string")
            return nil
        }
        do {
            return try decoder.decode(Configuration.self, from: data)
        } catch {
            SLogger.e("[Configuration] Failed to parse the data", error)
            return nil
        }
    }
    
    public static func fromData(_ data: Data)-> Configuration?{
        let decoder = JSONDecoder()
        // decoder.keyDecodingStrategy = .convertFromSnakeCase // If JSON keys use snake_case
        
        do {
            return try decoder.decode(Configuration.self, from: data)
        } catch {
            SLogger.e("[Configuration] Failed to parse the data", error)
            return nil
        }
    }

    public func isValid() -> Bool {
        return common != nil
    }

    public func getAdSlot(publisherSlotName: String) -> ConfigAdSlot? {
        if let slot = adSlots?[publisherSlotName] { return slot }
        return adSlots?[getPlacementName(publisherSlotName)]
    }

    public func getPlacementName(_ publisherSlotName: String) -> String {
        return getSlotNameWithoutSdiPrefix(publisherSlotName)
    }

    public func getSlotNameWithoutSdiPrefix(_ publisherSlotName: String) -> String {
        guard common?.isSDI == true else { return publisherSlotName }
        return publisherSlotName.split(separator: "_").last.map(String.init) ?? publisherSlotName
    }

    public func getAdUnitId(publisherSlotName: String) -> String {
        guard let network = common?.dfpAppNetwork else { return "/\(publisherSlotName)" }
        let slotWithoutQuery = publisherSlotName.components(separatedBy: "?").first ?? publisherSlotName
        if common?.isSDI == true, let appName = common?.dfpiOSAppName {
            return "/\(network)/\(appName)/\(slotWithoutQuery)"
        }
        return "/\(network)/\(slotWithoutQuery)"
    }

    public func getBannerNames() -> [String] {
        return adSlots?.compactMap { (name, slot) in
            slot.isBanner() ? name : nil
        } ?? []
    }

    public func getInterstitialNames() -> [String] {
        return adSlots?.compactMap { (name, slot) in
            slot.isInterstitial() ? name : nil
        } ?? []
    }
}
