//
//  ConfigFormat.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

import GoogleMobileAds

@objcMembers public class ConfigFormat: NSObject, Codable {
    public var active: Bool?
    public var availableOn: [String]?
    public var dfpSizes: ConfigFormatSizes?
    
    public override init() {
        super.init()
    }
}

@objcMembers public class ConfigFormatSizes: NSObject, Codable {
    public var iosAdSizes: [String]?
    public var customAdSizes: [ConfigCustomAdSize]?
    

    public override init() {
        super.init()
    }
    
    public static func getBannerSize(for gadSize: String) -> AdSize? {
        switch gadSize {
        case "GADAdSizeBanner", "kGADAdSizeBanner":
            return AdSizeBanner
        case "GADAdSizeLargeBanner", "kGADAdSizeLargeBanner":
            return AdSizeLargeBanner
        case "GADAdSizeFullBanner", "kGADAdSizeFullBanner":
            return AdSizeFullBanner
        case "GADAdSizeMediumRectangle", "kGADAdSizeMediumRectangle":
            return AdSizeMediumRectangle
        case "GADAdSizeLeaderboard", "kGADAdSizeLeaderboard":
            return AdSizeLeaderboard
        case "GADAdSizeSkyscraper", "kGADAdSizeSkyscraper":
            return AdSizeSkyscraper
        case "GADAdSizeFluid", "kGADAdSizeFluid":
            return AdSizeFluid
        case "GADAdSizeInvalid", "kGADAdSizeInvalid":
            return AdSizeInvalid
        default:
            return nil
        }
    }
}
