//
//  ConfigHttpFetcher.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/03/2025.
//

import Foundation

class ConfigHttpFetcher : IFetcher {
    
    private var overwriteTimeout: Int = 0
    private let httpRequest: IHttpRequest
    
    init() {
        self.httpRequest = HttpRequest();
    }
    
    init(httpRequest: IHttpRequest) {
        SLogger.e("[Stroeer-ConfigHttpFetcher] This constructor is only for test. This should not be called in production")
        self.httpRequest = httpRequest
    }
    

    public func setTimeout(seconds: Int) {
        overwriteTimeout = seconds
    }
    
    public func load(appName: String) async -> String? {
        let appName = appName.trimmingCharacters(in: .whitespacesAndNewlines)
        if appName.isEmpty {
            SLogger.e("[Configuration-HttpFetcher] Invalid app name")
            return nil
        }

        let urlString = ConfigConstants.shared.getConfigUrl().replacingOccurrences(of: ConfigConstants.shared.getApplicationNamePlaceholder(), with: appName)

        let timeout = overwriteTimeout > 0 ? overwriteTimeout : ConfigConstants.shared.getConfigTimeout()
        return await sendGetJson(url: urlString, timeout: timeout)
    }

    private func sendGetJson(url: String, timeout: Int) async -> String? {
        httpRequest.setTimeoutInSec(timeoutInSec: timeout)
        
        let response = await httpRequest.get(url: url)
        
        if response.isSuccessfulHttpResponse(), let data = response.data {
            SLogger.i("[Configuration-HttpFetcher] Http config was fetched")
            return String(decoding: data, as: UTF8.self)
        } else {
            SLogger.e("[Configuration-HttpFetcher] Failed to fetch config")
            return nil
        }
    }
}
