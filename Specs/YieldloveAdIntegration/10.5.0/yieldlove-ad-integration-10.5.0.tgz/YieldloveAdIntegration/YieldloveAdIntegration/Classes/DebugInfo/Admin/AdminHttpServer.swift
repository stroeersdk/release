import Foundation

public class AdminHttpServer {

    private static let port: UInt = 9890
    private static var server: GCDWebServer?

    public static func launch() {
        guard server?.isRunning != true else { return }

        let webServer = GCDWebServer()
        registerRoutes(on: webServer)

        do {
            try webServer.start(options: [
                GCDWebServerOption_Port: port,
                GCDWebServerOption_BindToLocalhost: false,
                GCDWebServerOption_AutomaticallySuspendInBackground: false
            ])
            server = webServer
            SLogger.i("[AdminHttpServer] Admin server started on port \(port)")
        } catch {
            SLogger.e("[AdminHttpServer] Failed to start admin server: \(error.localizedDescription)")
        }
    }

    public static func shutdown() {
        server?.stop()
        server = nil
    }

    // MARK: - Route registration

    private static func registerRoutes(on webServer: GCDWebServer) {
        webServer.addHandler(forMethod: "GET", path: "/", request: GCDWebServerRequest.self) { _ in
            return dashboardResponse()
        }
        webServer.addHandler(forMethod: "GET", path: "/admin", request: GCDWebServerRequest.self) { _ in
            return dashboardResponse()
        }
        webServer.addHandler(forMethod: "GET", path: "/debugenable", request: GCDWebServerRequest.self) { _ in
            return enableInspectionResponse()
        }
        webServer.addHandler(forMethod: "GET", path: "/debuginfo", request: GCDWebServerRequest.self) { _ in
            return debugInfoPageResponse()
        }
        webServer.addHandler(forMethod: "GET", path: "/api/debuginfo", request: GCDWebServerRequest.self) { _ in
            return debugInfoJsonResponse()
        }
    }

    // MARK: - Handlers

    private static func dashboardResponse() -> GCDWebServerResponse {
        let inspectionEnabled = ConfigurationManager.isInspectionMode()
        guard var html = loadHtml("dashboard") else {
            return GCDWebServerResponse(statusCode: 500)
        }
        html = html
            .replacingOccurrences(of: "{{SDK_VERSION}}", with: YLConstants.version)
            .replacingOccurrences(of: "{{DEVICE_IP}}", with: deviceIPAddress())
            .replacingOccurrences(of: "{{INSPECTION_CLASS}}", with: inspectionEnabled ? "on" : "off")
            .replacingOccurrences(of: "{{INSPECTION_STATUS}}", with: inspectionEnabled ? "ON" : "OFF")
            .replacingOccurrences(of: "{{BUTTON_DISABLED}}", with: inspectionEnabled ? "disabled" : "")
            .replacingOccurrences(of: "{{TC_STRING}}", with: tcString())
        return GCDWebServerDataResponse(html: html)!
    }

    private static func enableInspectionResponse() -> GCDWebServerResponse {
        ConfigurationManager.enableInspectionMode()
        SLogger.i("[AdminHttpServer] Inspection mode enabled via admin server")
        return GCDWebServerDataResponse(
            data: #"{"status":"ok"}"#.data(using: .utf8)!,
            contentType: "application/json"
        )
    }

    private static func debugInfoPageResponse() -> GCDWebServerResponse {
        guard let html = loadHtml("debuginfo") else {
            return GCDWebServerResponse(statusCode: 500)
        }
        return GCDWebServerDataResponse(html: html)!
    }

    private static func debugInfoJsonResponse() -> GCDWebServerResponse {
        var jsonArray: [[String: Any]] = []

        if Thread.isMainThread {
            jsonArray = DebugSessionManager.shared.getAllSessions().map { serializeSession($0) }
        } else {
            let sema = DispatchSemaphore(value: 0)
            DispatchQueue.main.async {
                jsonArray = DebugSessionManager.shared.getAllSessions().map { serializeSession($0) }
                sema.signal()
            }
            sema.wait()
        }

        guard let data = try? JSONSerialization.data(withJSONObject: jsonArray) else {
            return GCDWebServerDataResponse(data: "[]".data(using: .utf8)!, contentType: "application/json")
        }
        return GCDWebServerDataResponse(data: data, contentType: "application/json")
    }

    private static func serializeSession(_ record: BannerDebugRecord) -> [String: Any] {
        let requestRecords = record.requestRecords
        let prebidRecords = record.prebidRecords

        let timestamps = requestRecords.map { $0.timestamp }
        let servedInTime: Int
        if let first = timestamps.min(), let last = timestamps.max() {
            servedInTime = Int(last.timeIntervalSince(first) * 1000)
        } else {
            servedInTime = 0
        }

        let prebidActive = requestRecords.contains {
            $0.recordType == .prebidSent || $0.recordType == .prebidReceived
        }

        let customTargeting: [String: String]
        if let latestGam = requestRecords.last(where: { $0.recordType == .gamSent || $0.recordType == .gamReceived }) {
            customTargeting = latestGam.targeting
        } else {
            customTargeting = [:]
        }

        var sdkDebugInfos: [[String: Any]] = requestRecords.map { r in
            let sdkType: String
            switch r.recordType {
            case .prebidSent, .prebidReceived, .prebidSkipped, .prebidRendered:
                sdkType = "Prebid"
            case .gamSent, .gamReceived:
                sdkType = "GAM"
            }
            return [
                "sdkType": sdkType,
                "description": r.recordType.rawValue,
                "createdDate": r.timestamp.timeIntervalSince1970 * 1000,
                "keyValues": r.targeting
            ]
        }

        for pr in prebidRecords {
            var step: [String: Any] = [
                "sdkType": "Prebid",
                "description": "Prebid Network Traffic",
                "createdDate": pr.timestamp.timeIntervalSince1970 * 1000
            ]
            if let req = pr.requestText { step["requestJson"] = req }
            if let resp = pr.responseText { step["responseJson"] = resp }
            sdkDebugInfos.append(step)
        }

        return [
            "adUnitId": record.adUnitId,
            "publisherSlotName": String(record.adUnitId.split(separator: "/").last ?? ""),
            "adSizes": "",
            "servedInTime": servedInTime,
            "autoRefreshEnabled": false,
            "prebidActive": prebidActive,
            "prebidConfigId": "",
            "customTargeting": customTargeting,
            "sdkDebugInfos": sdkDebugInfos
        ]
    }

    // MARK: - Bundle loading

    private static func loadHtml(_ name: String) -> String? {
        guard let url = resourceBundle.url(forResource: name, withExtension: "html") else {
            SLogger.e("[AdminHttpServer] Missing resource: \(name).html")
            return nil
        }
        return try? String(contentsOf: url, encoding: .utf8)
    }

    // When integrated via CocoaPods resource_bundles, HTML files live inside
    // YieldloveAdIntegration.bundle which is nested in the framework bundle.
    private static var resourceBundle: Bundle {
        let frameworkBundle = Bundle(for: AdminHttpServer.self)
        guard let bundleURL = frameworkBundle.url(forResource: "YieldloveAdIntegration", withExtension: "bundle"),
              let bundle = Bundle(url: bundleURL) else {
            return frameworkBundle
        }
        return bundle
    }

    // MARK: - Device info

    private static func deviceIPAddress() -> String {
        var address = "unknown"
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let firstAddr = ifaddr else { return address }
        defer { freeifaddrs(ifaddr) }

        var ptr = firstAddr
        while true {
            let flags = Int32(ptr.pointee.ifa_flags)
            let isUp = (flags & IFF_UP) != 0
            let isLoopback = (flags & IFF_LOOPBACK) != 0

            if isUp && !isLoopback,
               ptr.pointee.ifa_addr.pointee.sa_family == UInt8(AF_INET) {
                var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                if getnameinfo(ptr.pointee.ifa_addr, socklen_t(ptr.pointee.ifa_addr.pointee.sa_len),
                               &hostname, socklen_t(hostname.count),
                               nil, 0, NI_NUMERICHOST) == 0 {
                    address = String(cString: hostname)
                    break
                }
            }
            guard let next = ptr.pointee.ifa_next else { break }
            ptr = next
        }
        return address
    }

    private static func tcString() -> String {
        return UserDefaults.standard.string(forKey: ContextualTargetingConstants.iabTCStringKey) ?? "Not available"
    }
}
