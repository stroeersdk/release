//
//  PrebidRecord.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import Foundation

struct PrebidRecord: Identifiable {
    let id = UUID()
    let timestamp: Date = Date()
    let adUnit: String
    let requestText: String?
    let responseText: String?
}
