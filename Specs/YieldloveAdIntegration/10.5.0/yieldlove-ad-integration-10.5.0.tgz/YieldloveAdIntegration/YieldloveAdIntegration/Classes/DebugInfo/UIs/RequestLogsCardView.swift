//
//  TrafficCardView.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import SwiftUI

struct RequestLogsCardView: View {
    let record: DebugRecord
    let styleWithMilliseconds = Date.FormatStyle()
        .year().month().day()
        .hour(.twoDigits(amPM: .abbreviated))
        .minute(.twoDigits)
        .second(.twoDigits)
        .secondFraction(.fractional(3))

    var backgroundColor: Color {
        switch record.recordType {
        case .prebidSent: return .blue.opacity(0.3)
        case .prebidReceived: return .green.opacity(0.3)
        case .prebidSkipped: return .orange.opacity(0.3)
        case .gamSent: return .purple.opacity(0.3)
        case .gamReceived: return record.targeting["errorMessage"] != nil ? .red.opacity(0.35) : .teal.opacity(0.35)
        case .prebidRendered: return .black.opacity(0.3)
        }
    }

    var body: some View {
        VStack(alignment: .leading) {
            Text("🕓 \(record.timestamp.formatted(styleWithMilliseconds))")
                .font(.subheadline)
            
            Text("\(record.recordType.rawValue)")
                .font(.headline)
            
            KeyValueSection(data: record.targeting)
        }
        .foregroundStyle(.white)
        .padding()
        .background(backgroundColor)
        .cornerRadius(12)
    }
}
