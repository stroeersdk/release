//
//  TrafficRecord.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 23/07/2025.
//

import SwiftUI

public struct DebugRecord: Identifiable {
    public let id = UUID()
    public let timestamp: Date = Date()
    public let type: AdType                   // "banner" or "interstitial"
    public let recordType: RecordType        // stage of traffic
    public let targeting: [String: String]
    public let adUnitId: String
    
    var adUnitLastPath: String {
        adUnitId.split(separator: "/").last.map(String.init) ?? adUnitId
    }

    public enum RecordType: String {
        case prebidSent = "Sent to Prebid"
        case prebidReceived = "Received from Prebid"
        case prebidSkipped = "Prebid Skipped"
        case gamSent = "Sent to GAM"
        case gamReceived = "Received from GAM"
        case prebidRendered = "Rendered by Prebid"
    }

    public init(
        type: AdType,
        recordType: RecordType,
        targeting: [String: String],
        adUnitId: String
    ) {
        self.type = type
        self.recordType = recordType
        self.targeting = targeting
        self.adUnitId = adUnitId
    }
}
