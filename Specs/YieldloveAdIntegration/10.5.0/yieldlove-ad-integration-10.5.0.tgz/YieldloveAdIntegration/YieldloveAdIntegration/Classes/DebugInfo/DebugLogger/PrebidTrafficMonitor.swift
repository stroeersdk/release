import Foundation
import PrebidMobile

// MARK: - PrebidEventDelegate
final class PrebidTrafficMonitor: PrebidEventDelegate {
    
    // Because the instance must be alive all the time.
    static let shared = PrebidTrafficMonitor()
    
    func attachPrebidEventDelegate() {
        if !(Prebid.shared.eventDelegate === PrebidTrafficMonitor.shared) {
            Prebid.shared.eventDelegate = PrebidTrafficMonitor.shared
            SLogger.i("[PrebidTrafficMonitor] Enabled the Prebid Event Delegate to capture the network traffic.")
        }
    }
    
    public func prebidBidRequestDidFinish(requestData: Data?, responseData: Data?) {
        var adUnitId: String = "unknown"
        var requestText : String?
        var responseText: String?

        if let requestData,
           let json = try? JSONSerialization.jsonObject(with: requestData) as? [String: Any] {
            if let imps = json["imp"] as? [[String: Any]],
               let firstImp = imps.first,
               let ext = firstImp["ext"] as? [String: Any],
               let data = ext["data"] as? [String: Any] {
                
                adUnitId = data["pbadslot"] as? String ?? data["adslot"] as? String ?? "unknown"
            }
            requestText = JsonPrinter.print(json: json)
        }

        if let responseData,
           let json = try? JSONSerialization.jsonObject(with: responseData) as? [String: Any] {
            responseText = JsonPrinter.print(json: removeAdmInResponse(json) as? [String: Any] ?? [:])
        }

        if adUnitId == "unknown" {
            SLogger.i("[PrebidTrafficMonitor] No yl_debug_session_id for adUnit='\(adUnitId)'. Ignoring Prebid event.")
            return
        }

        guard let session = DebugSessionManager.shared.sessionsById[adUnitId] else {
            SLogger.i("[PrebidTrafficMonitor] No session for adUnit='\(adUnitId)'. Ignoring Prebid event.")
            return
        }

        SLogger.i("[PrebidTrafficMonitor] Appending Prebid event adUnit='\(session.adUnitId)'")
        let record = PrebidRecord(adUnit: adUnitId, requestText: requestText, responseText: responseText)
        
        session.appendPrebidEvent(record: record)
    }

    private func removeAdmInResponse(_ value: Any) -> Any {
        if var dict = value as? [String: Any] {
            dict.removeValue(forKey: "adm")
            for (k, v) in dict {
                dict[k] = removeAdmInResponse(v)
            }
            return dict
        }

        if var array = value as? [Any] {
            for i in array.indices {
                array[i] = removeAdmInResponse(array[i])
            }
            return array
        }

        return value
    }
}
