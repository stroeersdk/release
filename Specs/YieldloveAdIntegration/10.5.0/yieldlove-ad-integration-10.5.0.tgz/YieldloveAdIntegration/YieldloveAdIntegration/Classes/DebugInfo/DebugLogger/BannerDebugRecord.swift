//
//  BannerDebugSession.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 28/11/2025.
//

import Foundation
import SwiftUI

/// One instance per banner load. Holds only that banner's logs.
final class BannerDebugRecord: NSObject, ObservableObject, BidTrackingListener {

    let adUnitId: String

    // UI-observed state
    @Published private(set) var requestRecords: [DebugRecord] = []
    @Published private(set) var prebidRecords: [PrebidRecord] = []

    init(adUnitId: String) {
        self.adUnitId = adUnitId
        super.init()
    }

    // MARK: - BidTrackingListener (Prebid/GAM flow)

    func didSendToPrebid(targeting: [String: String], adType: AdType, adUnitId: String) {
        let record = DebugRecord(
            type: adType,
            recordType: .prebidSent,
            targeting: targeting,
            adUnitId: adUnitId
        )
        appendRequest(record)
    }

    func didReceiveFromPrebid(targeting: [String: String], adUnitId: String) {
        let record = DebugRecord(
            type: .banner,
            recordType: .prebidReceived,
            targeting: targeting,
            adUnitId: adUnitId
        )
        appendRequest(record)
    }

    func didSendToGAM(targeting: [String: String], adUnitId: String) {
        let record = DebugRecord(
            type: .banner,
            recordType: .gamSent,
            targeting: targeting,
            adUnitId: adUnitId
        )
        appendRequest(record)
    }

    func didReceiveFromGAM(targeting: [String: String], adType: AdType, adUnitId: String) {
        let record = DebugRecord(
            type: adType,
            recordType: .gamReceived,
            targeting: targeting,
            adUnitId: adUnitId
        )
        appendRequest(record)
    }
    
    func didRenderViaPrebid(targeting: [String : String], adType: AdType, adUnitId: String) {
        let record = DebugRecord(
            type: adType,
            recordType: .prebidRendered,
            targeting: targeting,
            adUnitId: adUnitId
        )
        appendRequest(record)
    }

    func markPrebidSkipped(targeting: [String: String], adType: AdType, adUnitId: String) {
        let record = DebugRecord(
            type: adType,
            recordType: .prebidSkipped,
            targeting: targeting,
            adUnitId: adUnitId
        )
        appendRequest(record)
    }

    func clear() {
        Task { @MainActor [weak self] in
            guard let self else { return }
            self.requestRecords.removeAll()
            self.prebidRecords.removeAll()
        }
    }

    // MARK: - Called from PrebidEvent routing (per banner)

    func appendPrebidEvent(record: PrebidRecord) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            self.prebidRecords.append(record)
        }
    }

    private func appendRequest(_ record: DebugRecord) {
        Task{ @MainActor  [weak self] in
            guard let self else { return }
            self.requestRecords.append(record)
        }
    }
}
