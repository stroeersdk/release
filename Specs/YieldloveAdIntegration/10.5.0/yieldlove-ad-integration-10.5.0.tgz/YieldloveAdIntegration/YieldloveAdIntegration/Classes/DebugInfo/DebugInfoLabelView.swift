//
//  StroeerDebugInfoViewManager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 19/05/2025.
//

import Foundation
import UIKit
import GoogleMobileAds

class DebugInfoLabelView : UILabel {
    
    private var onTap: (() -> Void)?
    
    override init(frame: CGRect = .zero) {
        super.init(frame: frame)
        isUserInteractionEnabled = true
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTap)))
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        isUserInteractionEnabled = true
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTap)))
    }
    
    func buildLabel(_ adSlotName: String?, _ adType: AdType, _ servedIn: TimeInterval, onTap: @escaping () -> Void){
        self.onTap = onTap
        accessibilityIdentifier = "Ad Debug Info"
        adjustsFontSizeToFitWidth = true
        textColor = UIColor.white
        numberOfLines = 2
        backgroundColor = UIColor(red: 8/255.0, green: 32/255.0, blue: 74/255.0, alpha: 0.6)
        text = getLabelText(adSlotName, adType, servedIn)
        isUserInteractionEnabled = true
    }
    
    @objc private func didTap() {
        onTap?()
    }
    
    private func getLabelText(_ adSlotName: String?, _ adType: AdType, _ servedIn: TimeInterval) -> String {
        let adTypeText = adType == .banner ? "Banner:" : "Instl:"
        return "\(adTypeText) \(adSlotName ?? "")\nServed in: \(String(format: "%.2f", servedIn)) s"
    }
}
