//
//  ConsoleLogStore.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 28/11/2025.
//

import Foundation
import SwiftUI

/// Global console capture, but only started explicitly (when inspection is on).
final class ConsoleLogStore: NSObject, ObservableObject {

    static let shared = ConsoleLogStore()

    private static let maxLines = 5_000

    @Published private(set) var lines: [String] = []

    private let pipe = Pipe()
    private var isCapturing = false

    // Saved originals so we can tee output back to Xcode
    private var originalStdout: Int32 = -1
    private var originalStderr: Int32 = -1

    private let timeFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f
    }()

    private override init() {
        super.init()
    }

    /// Call this when inspection is on and a banner is being loaded.
    func startIfNeeded() {
        guard !isCapturing else { return }
        isCapturing = true

        // Save original fds so we can tee output back to Xcode
        originalStdout = dup(fileno(stdout))
        originalStderr = dup(fileno(stderr))

        dup2(pipe.fileHandleForWriting.fileDescriptor, fileno(stdout))
        dup2(pipe.fileHandleForWriting.fileDescriptor, fileno(stderr))

        pipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            guard let self else { return }

            let data = handle.availableData
            guard !data.isEmpty else { return }

            // Tee: write back to original stdout so Xcode still shows logs
            if self.originalStdout != -1 {
                _ = data.withUnsafeBytes { Foundation.write(self.originalStdout, $0.baseAddress!, data.count) }
            }

            guard let output = String(data: data, encoding: .utf8), !output.isEmpty else { return }

            let stampedLines: [String] = output
                .split(separator: "\n", omittingEmptySubsequences: true)
                .compactMap { raw -> String? in
                    let cleaned = raw
                        .replacingOccurrences(of: "OSLOG", with: "", options: .caseInsensitive)
                        .trimmingCharacters(in: .whitespaces)
                    guard !cleaned.isEmpty else { return nil }
                    return "[\(self.timeFormatter.string(from: Date()))] \(cleaned)"
                }

            guard !stampedLines.isEmpty else { return }

            Task{ @MainActor [weak self] in
                guard let self else { return }
                self.lines.append(contentsOf: stampedLines)
                let overflow = self.lines.count - ConsoleLogStore.maxLines
                if overflow > 0 {
                    self.lines.removeFirst(overflow)
                }
            }
        }
    }

    func append(_ line: String) {
        Task{ @MainActor [weak self] in
            guard let self else { return }
            self.lines.append(line)
            if self.lines.count > ConsoleLogStore.maxLines {
                self.lines.removeFirst()
            }
        }
    }

    func clear() {
        Task{ @MainActor [weak self]  in
            self?.lines.removeAll()
        }
    }
}
