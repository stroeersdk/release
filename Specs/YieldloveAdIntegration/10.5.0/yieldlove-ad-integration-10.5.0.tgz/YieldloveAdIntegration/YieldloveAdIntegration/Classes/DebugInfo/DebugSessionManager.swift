//
//  DebugSessinoManager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 04/05/2026.
//

final class DebugSessionManager {
    
    static let shared = DebugSessionManager()
    
    /// One session per banner instance, keyed by unique debug session id.
    var sessionsById: [String: BannerDebugRecord] = [:]
    

    func startSession(for adUnitId: String) -> BannerDebugRecord {
        let session = sessionsById[adUnitId] ?? {
            let newSession = BannerDebugRecord(adUnitId: adUnitId)
            sessionsById[adUnitId] = newSession
            return newSession
        }()
        
        SLogger.i("[DebugSessionManager] startSession adUnit='\(adUnitId)'")
        return session
    }

    func session(for adUnitId: String) -> BannerDebugRecord? {
        sessionsById[adUnitId]
    }
    
    func getAllSessions() -> [BannerDebugRecord]{
        return Array(sessionsById.values)
    }

    func clearSession(for sessionId: String) {
        SLogger.i("[DebugSessionManager] clearSession sessionId='\(sessionId)'")
        sessionsById.removeValue(forKey: sessionId)
    }
}
