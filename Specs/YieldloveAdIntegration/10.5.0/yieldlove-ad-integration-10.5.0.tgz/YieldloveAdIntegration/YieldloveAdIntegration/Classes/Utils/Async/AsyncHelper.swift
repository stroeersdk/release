//
//  AsyncHelper.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 15/04/2026.
//


func withTimeout<T>(seconds: TimeInterval, operation: @escaping () async -> T?) async -> T? {
    return await withTaskGroup(of: T?.self) { group in
        group.addTask {
            return await operation()
        }
        group.addTask {
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            return nil
        }
        if let result = await group.next() {
            group.cancelAll()
            return result
        }
        return nil
    }
}

// AsyncSemaphore pattern
actor AsyncLock {
    private var isLocked = false
    private var waiters: [CheckedContinuation<Void, Never>] = []
    
    func lock() async {
        if !isLocked {
            isLocked = true
            return
        }
        
        await withCheckedContinuation { cont in
            waiters.append(cont)
        }
    }
    
    func unlock() {
        if waiters.isEmpty {
            isLocked = false
        } else {
            let next = waiters.removeFirst()
            next.resume()
        }
    }

    func withLock<T>(_ operation: @Sendable () async -> T) async -> T {
        await lock()
        let result = await operation()
        unlock()
        return result
    }
}

public extension Task where Success == Never, Failure == Never {

    static func delay(seconds: Double) async {

        let ns = UInt64(seconds * 1_000_000_000)

        try? await Task.sleep(nanoseconds: ns)

    }
}

