import CoreGraphics
import GoogleMobileAds

enum AdSizeConverter {

    // MARK: - GAM ↔ Prebid

    static func toPrebidSize(_ gamSize: AdSize) -> CGSize {
        gamSize.size
    }

    static func toPrebidSizes(_ gamSizes: [AdSize]) -> [CGSize] {
        gamSizes.map { $0.size }
    }

    static func toGamSize(_ prebidSize: CGSize) -> AdSize {
        adSizeFor(cgSize: prebidSize)
    }

    static func toGamSizes(_ prebidSizes: [CGSize]) -> [AdSize] {
        prebidSizes.map { adSizeFor(cgSize: $0) }
    }

    // MARK: - String ("WxH") → CGSize

    static func getCGSize(for wxh: String?) -> CGSize {
        guard let dimensions = wxh else { return .zero }
        let parts = dimensions.split(separator: "x")
        guard parts.count == 2,
              let width = Int(parts[0]),
              let height = Int(parts[1]) else { return .zero }
        return CGSize(width: width, height: height)
    }
}
