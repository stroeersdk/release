//
//  BidTrackingListener.swift
//  Pods
//
//  Created by Shafee Rehman on 04/07/2025.
//
import Foundation

public protocol BidTrackingListener {
    func didSendToPrebid(targeting: [String: String], adType: AdType, adUnitId: String)
    func didReceiveFromPrebid(targeting: [String: String], adUnitId: String)
    func didSendToGAM(targeting: [String: String], adUnitId: String)
    func didReceiveFromGAM(targeting: [String: String], adType: AdType, adUnitId: String)
    func didRenderViaPrebid(targeting: [String: String], adType: AdType, adUnitId: String)
    func markPrebidSkipped(targeting: ([String: String]), adType: AdType, adUnitId: String)
}
