//
//  HttpRequest.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 05/02/2025.
//

import Foundation

public struct HttpResponse {
    public let data: Data?
    public let response: URLResponse?
    public let error: Error?

    public init(data: Data?, response: URLResponse?, error: Error? = nil) {
        self.data = data
        self.response = response
        self.error = error
    }

    public func isSuccessfulHttpResponse() -> Bool {
        if let httpResponse = response as? HTTPURLResponse {
            return (200...299).contains(httpResponse.statusCode)
        }
            
        return false
    }
}

public enum HttpError: LocalizedError {
    case invalidRequestUrl(invalidUrl: String)

    public var errorDescription: String? {
        switch self {
        case .invalidRequestUrl(let invalidUrl):
            return "Request URL '\(invalidUrl)' is not valid"
        }
    }
}

public protocol IHttpRequest {
    func get(url:String) async -> HttpResponse
    func get(url: String, headers: [String: String]) async -> HttpResponse
    func post(url: String, body: Data?, headers: [String: String]) async -> HttpResponse
    func setTimeoutInSec(timeoutInSec: Int)
}

public class HttpRequest: IHttpRequest {

    public static let httpMethodGet = "GET"
    public static let httpMethodPost = "POST"

    private let urlSession: URLSession
    private var timeoutInSec = 5;

    public func setTimeoutInSec(timeoutInSec: Int) {
        self.timeoutInSec = timeoutInSec
    }

    public init(configuration: URLSessionConfiguration = .default) {
        self.urlSession = URLSession(configuration: configuration)
    }
    
    public func get(url: String) async -> HttpResponse {
        await get(url: url, headers:[:])
    }

    public func get(url: String, headers: [String: String] = [:]) async -> HttpResponse {
        do {
            let request = try self.createGetRequest(url: url, headers: headers)
            let (data, response) = try await self.urlSession.data(for: request)
            return HttpResponse(data: data, response: response)
        } catch {
            SLogger.e("Failed to get query: \(error.localizedDescription)")
            return HttpResponse(data: nil, response: nil, error: error)
        }
    }

    public func post(url: String, body: Data?, headers: [String: String] = [:]) async -> HttpResponse {
        do {
            let request = try self.createPostRequest(url: url, body: body, headers: headers)
            let (data, response) = try await self.urlSession.data(for: request)
            return HttpResponse(data: data, response: response)
        } catch {
            SLogger.e("Failed to post query: \(error.localizedDescription)")
            return HttpResponse(data: nil, response: nil, error: error)
        }
    }

    private func createPostRequest(url: String, body: Data?, headers: [String: String]) throws -> URLRequest {
        var request = try self.createBasicRequest(method: HttpRequest.httpMethodPost, url: url)
        if let safeBody = body {
            request.httpBody = safeBody
        }
        return setHeaders(request: request, headers: headers)
    }

    private func createGetRequest(url: String, headers: [String: String]) throws -> URLRequest {
        let request = try createBasicRequest(method: HttpRequest.httpMethodGet, url: url)
        return setHeaders(request: request, headers: headers)
    }

    private func createBasicRequest(method: String, url: String) throws -> URLRequest {
        guard let url = URL(string: url) else {
            throw HttpError.invalidRequestUrl(invalidUrl: url)
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = TimeInterval(self.timeoutInSec)
        return request
    }
    
    private func setHeaders(request: URLRequest, headers: [String: String]) -> URLRequest {
        var enrichedRequest = request
        for (key, value) in headers {
            enrichedRequest.addValue(value, forHTTPHeaderField: key)
        }
        return enrichedRequest
    }
}
