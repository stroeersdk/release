import Foundation

enum JsonPrinter {

    static func print(json: String) -> String {
        guard let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return json
        }
        var builder = ""
        printObject(obj, depth: 0, exclude: nil, into: &builder)
        return builder.trimmingCharacters(in: .newlines)
    }

    static func print(json: [String: Any]) -> String {
        var builder = ""
        printObject(json, depth: 0, exclude: nil, into: &builder)
        return builder.trimmingCharacters(in: .newlines)
    }

    static func print(json: [String: Any], exclude: String) -> String {
        var builder = ""
        printObject(json, depth: 0, exclude: exclude, into: &builder)
        return builder.trimmingCharacters(in: .newlines)
    }

    private static func printObject(_ obj: [String: Any], depth: Int, exclude: String?, into builder: inout String) {
        let indent = String(repeating: "  ", count: depth)
        for key in obj.keys.sorted() {
            let value = obj[key]!
            if let nested = value as? [String: Any] {
                if key != exclude {
                    builder += "\(indent)\(key) :\n"
                }
                printObject(nested, depth: depth + 1, exclude: exclude, into: &builder)
            } else if let array = value as? [Any] {
                if key != exclude {
                    builder += "\(indent)\(key) :\n"
                }
                printArray(array, depth: depth + 1, exclude: exclude, into: &builder)
            } else {
                if key != exclude {
                    builder += "\(indent)\(key) : \(value)\n"
                }
            }
        }
    }

    private static func printArray(_ array: [Any], depth: Int, exclude: String?, into builder: inout String) {
        let indent = String(repeating: "  ", count: depth)
        for value in array {
            if let nested = value as? [String: Any] {
                printObject(nested, depth: depth, exclude: exclude, into: &builder)
            } else if let nestedArray = value as? [Any] {
                printArray(nestedArray, depth: depth, exclude: exclude, into: &builder)
            } else {
                builder += "\(indent)- \(value)\n"
            }
        }
    }
}
