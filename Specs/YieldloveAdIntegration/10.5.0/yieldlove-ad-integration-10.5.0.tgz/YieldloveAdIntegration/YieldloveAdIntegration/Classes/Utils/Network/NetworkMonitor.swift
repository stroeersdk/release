//
//  NetworkMonitor.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 23/04/2026.
//
import Network

public enum Connection: String {

    case mobile = "MOBILE"

    case wifi = "WIFI"

    case other = "OTHER"

}

final class NetworkMonitor {

    static func getConnection() async -> Connection {

        await withCheckedContinuation { continuation in

            let monitor = NWPathMonitor()

            let queue = DispatchQueue(label: "NetworkMonitor.Async")

            monitor.pathUpdateHandler = { path in

                let connection: Connection

                if path.usesInterfaceType(.wifi) {

                    connection = .wifi

                } else if path.usesInterfaceType(.cellular) {

                    connection = .mobile

                } else {

                    connection = .other

                }

                monitor.cancel()

                continuation.resume(returning: connection)

            }

            monitor.start(queue: queue)

        }

    }

}
