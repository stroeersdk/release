//
//  IConfigurationListener.swift
//  YieldloveAdIntegration
//

import Foundation

public protocol ISuccessFailListener<T>: AnyObject {
    associatedtype T
    func onSuccess(data: T)
    func onFailed()
}
