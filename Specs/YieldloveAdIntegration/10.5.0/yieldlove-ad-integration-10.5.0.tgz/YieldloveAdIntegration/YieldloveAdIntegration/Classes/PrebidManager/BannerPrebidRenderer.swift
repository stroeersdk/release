//
//  BannerPrebidRenderer.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 01/04/2026.
//


import UIKit
import GoogleMobileAds
import PrebidMobile

typealias PBMBannerView         = PrebidMobile.BannerView
typealias PBMBannerViewDelegate = PrebidMobile.BannerViewDelegate

final class BannerPrebidRenderer: APrebidRenderer, PBMBannerViewDelegate {

    private let bannerConfiguration: BannerAdConfiguration
    private let dbgId = UUID().uuidString.prefix(6)

    private var didFinish = false
    private var directRenderEventHandler: BannerDirectRenderEventHandler?
    private var prebidBannerView: PBMBannerView?

    private var pendingDirectView: PrebidHtmlBannerView?
    private var pendingDirectListener: RendererDirectViewListener?

    private var onSuccess: ((UIView) -> Void)?
    private var onFailure: ((Error) -> Void)?

    private var requestAdUnitData: YLAdUnitData?

    private var timeEventRecorder: TimeEventRecorder {
        bannerConfiguration.timeEventRecorder
    }

    private var debugRecord: BannerDebugRecord? {
        bannerConfiguration.debugRecord
    }

    private var isRefreshable: Bool {
        bannerConfiguration.isRefreshable
    }

    init(
        bannerConfiguration: BannerAdConfiguration
    ) {
        self.bannerConfiguration = bannerConfiguration
        super.init()
    }

    @MainActor
    func load() async throws -> BannerPrebidRenderResult {
        guard let adUnitData = bannerConfiguration.adUnitData else {
            SLogger.e("[BannerPrebidRenderer:\(dbgId)] load failed because adUnitData is missing")
            throw YLError.adUnitDataWasNotSet
        }

        let publisherGamRequest = bannerConfiguration.publisherGamRequest()
        requestAdUnitData = adUnitData

        SLogger.i(
            "[BannerPrebidRenderer:\(dbgId)] load START adUnit=\(adUnitData.adUnit) configId=\(adUnitData.configId) skipPrebid=\(adUnitData.skipPrebid) isRefreshable=\(isRefreshable)"
        )

        if adUnitData.skipPrebid {
            debugRecord?.markPrebidSkipped(
                targeting: [
                    "adUnit": adUnitData.adUnit,
                    "configId": adUnitData.configId,
                    "sizes": adUnitData.bannerSizes
                        .map { "\($0.size.width)x\($0.size.height)" }
                        .joined(separator: ",")
                ],
                adType: .banner,
                adUnitId: adUnitData.adUnit
            )
            
            timeEventRecorder.recordBidderRespondedSuccessfully(
                bidAdapter: .Prebid,
                resultCode: .SKIPPED
            )

            let requestData = BannerGamRequestData(
                adUnitData: adUnitData,
                gamRequest: publisherGamRequest
            )

            SLogger.i("[BannerPrebidRenderer:\(dbgId)] skipPrebid => GAM")

            didFinish = true
            clearContinuations()
            return .gam(requestData: requestData)
        }

        PrebidCommonHelper.configureSharedPrebid(adUnitData: adUnitData)

        Prebid.shared.useCacheForReportingWithRenderingAPI = true
        PrebidTrafficMonitor.shared.attachPrebidEventDelegate()

        PrebidCommonHelper.applyCommonTargeting(using: adUnitData)

        return try await withCheckedThrowingContinuation { continuation in
            let bannerSizes = adUnitData.bannerSizes

            let directRenderEventHandler = BannerDirectRenderEventHandler(bannerConfiguration: bannerConfiguration)
            self.directRenderEventHandler = directRenderEventHandler

            SLogger.i(
                "[BannerPrebidRenderer:\(dbgId)] created BannerDirectRenderEventHandler bannerSizes=\(bannerSizes.map { "\($0.size.width)x\($0.size.height)" }.joined(separator: ","))"
            )

            onSuccess = { [weak self] view in
                guard let self else { return }
                guard !self.didFinish else { return }

                SLogger.i("[BannerPrebidRenderer:\(dbgId)] resume => PREBID")

                self.didFinish = true
                self.clearContinuations()
                continuation.resume(returning: .prebid(view: view))
                self.destroy()
            }

            onFailure = { [weak self] error in
                guard let self else { return }
                guard !self.didFinish else { return }

                SLogger.e(
                    "[BannerPrebidRenderer:\(dbgId)] resume => FAILURE error=\(error.localizedDescription)"
                )

                self.didFinish = true
                self.clearContinuations()
                continuation.resume(throwing: error)
                self.destroy()
            }

            directRenderEventHandler.onDecision = { [weak self] decision in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    guard !self.didFinish else { return }

                    switch decision {
                    case .prebidDirect(let payload):
                        SLogger.i(
                            "[BannerPrebidRenderer:\(dbgId)] decision => PREBID_DIRECT size=\(Int(payload.size.width))x\(Int(payload.size.height))"
                        )
                        self.createAndLoadDirectView(payload: payload)

                    case .gam(let requestData):
                        SLogger.i(
                            "[BannerPrebidRenderer:\(dbgId)] decision => GAM adUnit=\(requestData.adUnitData.adUnit)"
                        )
                        self.didFinish = true
                        self.clearContinuations()
                        continuation.resume(returning: .gam(requestData: requestData))
                        self.destroy()
                    }
                }
            }

            let firstSize = bannerSizes.first?.size ?? AdSizeBanner.size
            let prebidBannerView = PBMBannerView(
                frame: CGRect(origin: .zero, size: firstSize),
                configID: adUnitData.configId,
                adSize: firstSize,
                eventHandler: directRenderEventHandler
            )

            prebidBannerView.delegate = self
            if bannerSizes.count > 1 {
                prebidBannerView.additionalSizes = Array(bannerSizes.dropFirst().map(\.size))
            }

            self.prebidBannerView = prebidBannerView

            timeEventRecorder.recordRequestBids(bidAdapter: .Prebid)

            debugRecord?.didSendToPrebid(
                targeting: makePrebidSendInput(
                    adUnitData: adUnitData,
                    publisherGamRequest: publisherGamRequest,
                    isRefreshable: isRefreshable
                ),
                adType: .banner,
                adUnitId:adUnitData.adUnit
            )

            prebidBannerView.bannerParameters.api = adUnitData.frameworks
            prebidBannerView.adUnitConfig.setPbAdSlot(adUnitData.adUnit)
            
            // For a while, the custom targeting is empty
            prebidBannerView.setImpORTBConfig(getImpSetup(adUnitId: adUnitData.adUnit, customTargeting: ""))
            
            setGlobalOrtbConfig(contentURL: publisherGamRequest.contentURL)

            SLogger.i(
                "[BannerPrebidRenderer:\(dbgId)] loadAd configId=\(adUnitData.configId) firstSize=\(Int(firstSize.width))x\(Int(firstSize.height))"
            )
            prebidBannerView.loadAd()
        }
    }

    @MainActor
    func cancel() {
        guard !didFinish else { return }
        SLogger.i("[BannerPrebidRenderer:\(dbgId)] cancel")
        onFailure?(BannerRequestLifecycleError.cancelled)
    }

    @MainActor
    func destroy() {
        SLogger.i(
            "[BannerPrebidRenderer:\(dbgId)] destroy prebidBannerView_nil_before=\(prebidBannerView == nil) directRenderEventHandler_nil_before=\(directRenderEventHandler == nil) pendingDirectView_nil_before=\(pendingDirectView == nil)"
        )

        prebidBannerView?.delegate = nil
        prebidBannerView = nil

        destroyPendingDirectView()

        directRenderEventHandler?.onDecision = nil
        directRenderEventHandler = nil

        requestAdUnitData = nil
        clearContinuations()
    }

    func bannerViewPresentationController() -> UIViewController? {
        bannerConfiguration.viewController
    }

    @MainActor
    private func createAndLoadDirectView(payload: DirectRenderPayload) {
        guard !didFinish else { return }

        guard bannerConfiguration.wrapperView != nil else {
            SLogger.e("[BannerPrebidRenderer:\(dbgId)] createAndLoadDirectView failed because wrapperView is missing")
            onFailure?(BannerRequestLifecycleError.destroyed)
            return
        }

        destroyPendingDirectView()

        let directView = PrebidHtmlBannerView(frame: CGRect(origin: .zero, size: payload.size))
        directView.setAdSize(width: payload.size.width, height: payload.size.height)
        directView.setLoadTimeout(seconds: 8)

        let directViewListener = RendererDirectViewListener(
            renderer: self,
            bannerConfiguration: bannerConfiguration,
            directView: directView
        )

        pendingDirectView = directView
        pendingDirectListener = directViewListener
        directView.listener = directViewListener

        SLogger.i(
            "[BannerPrebidRenderer:\(dbgId)] createAndLoadDirectView size=\(Int(payload.size.width))x\(Int(payload.size.height))"
        )

        directView.setHtml(payload.adm)

        if let adUnitData = requestAdUnitData {
            debugRecord?.didReceiveFromPrebid(
                targeting: payload.targeting,
                adUnitId:adUnitData.adUnit
            )
        }
    }

    @MainActor
    func directViewDidLoad(_ view: PrebidHtmlBannerView) {
        guard !didFinish else { return }

        if pendingDirectView === view {
            pendingDirectView = nil
            pendingDirectListener = nil
        }

        SLogger.i("[BannerPrebidRenderer:\(dbgId)] directViewDidLoad")
        handleReceivedAdFromPrebid(view: view)
    }

    @MainActor
    func directViewDidFail(_ error: Error) {
        guard !didFinish else { return }
        SLogger.e(
            "[BannerPrebidRenderer:\(dbgId)] directViewDidFail error=\(error.localizedDescription)"
        )
        handleReceivedErrorFromPrebid(error: error)
    }

    private func handleReceivedAdFromPrebid(view: UIView) {
        guard !didFinish else { return }

        if let adUnitData = requestAdUnitData, debugRecord != nil {
            let size = view.intrinsicContentSize == .zero ? view.bounds.size : view.intrinsicContentSize
            let info: [String: String] = [
                "event": "Rendered Success",
                "adUnit": adUnitData.adUnit,
                "frameSize": "\(Int(size.width))x\(Int(size.height))"
            ]

            debugRecord?.didRenderViaPrebid(
                targeting: info,
                adType: .banner,
                adUnitId:adUnitData.adUnit
            )
        }

        SLogger.i("[BannerPrebidRenderer:\(dbgId)] handleReceivedAdFromPrebid SUCCESS")
        onSuccess?(view)
    }

    private func handleReceivedErrorFromPrebid(error: Error) {
        guard !didFinish else { return }

        if let adUnitData = requestAdUnitData, debugRecord != nil {
            let info: [String: String] = [
                "event": "Render Failed",
                "errorDescription": error.localizedDescription,
                "errorType": String(describing: type(of: error))
            ]

            debugRecord?.didRenderViaPrebid(
                targeting: info,
                adType: .banner,
                adUnitId:adUnitData.adUnit
            )
        }

        if ConfigurationManager.isInspectionMode() {
            let fallbackSize = requestAdUnitData?.bannerSizes.first?.size ?? CGSize(width: 150, height: 50)
            let placeholder = UIView(frame: CGRect(origin: .zero, size: fallbackSize))
            placeholder.backgroundColor = .clear
            SLogger.e("[BannerPrebidRenderer:\(dbgId)] inspection mode fallback after direct render failure")
            onSuccess?(placeholder)
        } else {
            SLogger.e(
                "[BannerPrebidRenderer:\(dbgId)] handleReceivedErrorFromPrebid FAILURE error=\(error.localizedDescription)"
            )
            onFailure?(error)
        }
    }

    private func setGlobalOrtbConfig(contentURL: String?) {
        guard let contentURL, !contentURL.isEmpty else {
            return
        }

        Targeting.shared.contentUrl = contentURL

        let globalOrtb = """
        {
          "app": {
            "content": {
              "url": "\(contentURL)"
            }
          }
        }
        """

        Targeting.shared.setGlobalORTBConfig(globalOrtb)
        SLogger.i("[BannerPrebidRenderer:\(dbgId)] setGlobalOrtbConfig contentURL_present=true")
    }

    private func clearContinuations() {
        onSuccess = nil
        onFailure = nil
    }

    @MainActor
    private func destroyPendingDirectView() {
        if pendingDirectView != nil {
            SLogger.i("[BannerPrebidRenderer:\(dbgId)] destroyPendingDirectView")
        }
        pendingDirectView?.destroy()
        pendingDirectView = nil
        pendingDirectListener = nil
    }

    private func makePrebidSendInput(
        adUnitData: YLAdUnitData,
        publisherGamRequest: AdManagerRequest,
        isRefreshable: Bool
    ) -> [String: String] {
        var input: [String: String] = [
            "adUnit": adUnitData.adUnit,
            "configId": adUnitData.configId,
            "sizes": adUnitData.bannerSizes
                .map { "\($0.size.width)x\($0.size.height)" }
                .joined(separator: ",")
        ]

        input["pbAdSlot"] = adUnitData.adUnit
        input["adType"] = "banner"
        input["refreshable"] = "\(isRefreshable)"
        input["SdkVersion"] = YLConstants.version
        input["contentUrl"] = publisherGamRequest.contentURL ?? ""

        let publisherTargeting = (publisherGamRequest.customTargeting as? [String: String]) ?? [:]
        input["publisherTargeting"] = publisherTargeting
            .map { "\($0.key)=\($0.value)" }
            .sorted()
            .joined(separator: ",")

        input["consent_present"] =
            UserDefaults.standard.string(forKey: "IABTCF_TCString") != nil ? "true" : "false"
        input["bundleId"] = Bundle.main.bundleIdentifier ?? ""
        input["appVersion"] =
            Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
        input["build"] =
            Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? ""
        input["os"] = "iOS"
        input["osVersion"] = UIDevice.current.systemVersion
        input["deviceModel"] = UIDevice.current.model

        return input
    }

    deinit {
        SLogger.i("[BannerPrebidRenderer:\(dbgId)] deinit")

        prebidBannerView?.delegate = nil
        prebidBannerView = nil

        directRenderEventHandler?.onDecision = nil
        directRenderEventHandler = nil

        pendingDirectView = nil
        pendingDirectListener = nil
        requestAdUnitData = nil

        clearContinuations()
    }
}
