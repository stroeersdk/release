//
//  BannerPrebidRenderResult.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 01/04/2026.
//


import UIKit

enum BannerPrebidRenderResult {
    case prebid(view: UIView)
    case gam(requestData: BannerGamRequestData)
}

enum BannerDRDecision {
    case prebidDirect(payload: DirectRenderPayload)
    case gam(requestData: BannerGamRequestData)
}

struct DirectRenderPayload {
    let adm: String
    let size: CGSize
    let targeting: [String: String]
}