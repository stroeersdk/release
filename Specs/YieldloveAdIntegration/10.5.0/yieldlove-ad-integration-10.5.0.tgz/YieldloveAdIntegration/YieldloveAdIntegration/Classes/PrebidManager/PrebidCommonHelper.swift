//
//  PrebidCommonHelper.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 21/04/2026.
//

import GoogleMobileAds
import PrebidMobile

enum PrebidCommonHelper {

    static func configureSharedPrebid(adUnitData: YLAdUnitData) {
        IdentityManager.shared.setUserIdToPrebid()

        if ConfigurationManager.isDebugMode() {
            Prebid.shared.logLevel = .severe
        }

        Prebid.shared.timeoutMillis = Int(ConfigurationManager.shared.requestTimeout * 1000)

        if let accountId = adUnitData.accountId, !accountId.isEmpty {
            Prebid.shared.prebidServerAccountId = accountId
        }

        setPrebidCustomHeaders()
    }

    static func applyCommonTargeting(using adUnitData: YLAdUnitData) {
        Targeting.shared.storeURL = adUnitData.storeUrl
        Targeting.shared.itunesID = adUnitData.itunesID
        Targeting.shared.addAppExtData(
            key: YLConstants.sdkVersionNumberKey,
            value: YLConstants.version
        )
        Targeting.shared.omidPartnerName = YLConstants.omidPartnerName
        Targeting.shared.omidPartnerVersion = YLConstants.omidPartnerVersion
    }

    static func translatedTargeting(
        from rawTargeting: [String: String],
        keepUntranslatedKeys: Bool = false
    ) -> [String: String] {
        var targetingDict = [String: String]()

        for (key, value) in rawTargeting {
            if let keyValue = PrebidConstants.KeyValueTargeting(rawValue: key),
               let translatedKey = PrebidConstants.getTranslatedKey(key: keyValue) {
                targetingDict[translatedKey] = value
            } else if keepUntranslatedKeys {
                targetingDict[key] = value
            }
        }

        return targetingDict
    }

    static func bidSuccessfulMetaTags(configId: String) -> [String: String] {
        [
            PrebidConstants.MetaTag.bidSuccess.rawValue: "true",
            PrebidConstants.MetaTag.meta.rawValue: "pid:\(configId).sb:t.pr:t"
        ]
    }

    static func noBidsMetaTags(
        configId: String,
        pbsResultCode: ResultCode? = nil
    ) -> [String: String] {
        var tags: [String: String] = [
            PrebidConstants.MetaTag.bidSuccess.rawValue: "false",
            PrebidConstants.MetaTag.meta.rawValue: "pid:\(configId).sb:f"
        ]

        if let pbsResultCode {
            tags[PrebidConstants.MetaTag.resultCode.rawValue] = "\(pbsResultCode.rawValue)"
        }

        return tags
    }

    static func merge(
        _ first: [String: String],
        _ second: [String: String]
    ) -> [String: String] {
        first.merging(second, uniquingKeysWith: { first, _ in first })
    }

    private static func setPrebidCustomHeaders() {
        Prebid.shared.addCustomHeader(
            name: "X-SDK-Version",
            value: YLConstants.version
        )

        if let bundleId = Bundle.main.bundleIdentifier {
            Prebid.shared.addCustomHeader(
                name: "X-Bundle",
                value: bundleId
            )
        }
    }
}
