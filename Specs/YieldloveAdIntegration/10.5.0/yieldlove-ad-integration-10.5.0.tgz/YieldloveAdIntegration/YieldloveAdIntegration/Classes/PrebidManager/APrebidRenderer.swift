//
//  APrebidRenderer.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 30/04/2026.
//

class APrebidRenderer : NSObject {
    
    func getImpSetup(adUnitId: String, customTargeting: String) -> String {
        return """
        {
          "displaymanager": "\(YLConstants.sdkName)",
          "displaymanagerver": "\(YLConstants.version)",
          "ext": {
            "data": {
              "adslot": "\(adUnitId)",
              "pbadslot": "\(adUnitId)"
              \(customTargeting)
            }
          }
        }
        """
    }
}
