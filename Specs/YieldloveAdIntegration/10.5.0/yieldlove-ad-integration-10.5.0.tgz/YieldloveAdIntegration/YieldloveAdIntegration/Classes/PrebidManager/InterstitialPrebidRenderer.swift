//
//  InterstitialPrebidRenderer.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 10/04/2026.
//

import Foundation
import GoogleMobileAds
import PrebidMobile

enum InterstitialPrebidRendererError: Error {
    case prebidFetchFailed(ResultCode)
}

final class InterstitialPrebidRenderer : APrebidRenderer {

    private let interstitialConfiguration: InterstitialAdConfiguration
    private let dbgId = UUID().uuidString.prefix(6)

    private var timeEventRecorder: TimeEventRecorder {
        interstitialConfiguration.timeEventRecorder
    }

    init(
        interstitialConfiguration: InterstitialAdConfiguration
    ) {
        self.interstitialConfiguration = interstitialConfiguration
    }

    @MainActor
    func load() async throws -> InterstitialGamRequestData {
        guard let adUnitData = interstitialConfiguration.adUnitData else {
            SLogger.i(
                "[InterstitialPrebidRenderer:\(dbgId)] load skipped because adUnitData is missing"
            )
            throw YLError.adUnitDataWasNotSet
        }

        let publisherGamRequest = interstitialConfiguration.getInitialGamRequest()

        SLogger.i(
            "[InterstitialPrebidRenderer:\(dbgId)] load START adUnit=\(adUnitData.adUnit) configId=\(adUnitData.configId) skipPrebid=\(adUnitData.skipPrebid)"
        )

        if adUnitData.skipPrebid {
            SLogger.i(
                "[InterstitialPrebidRenderer:\(dbgId)] load SKIPPED adUnit=\(adUnitData.adUnit)"
            )

            return InterstitialGamRequestData(
                adUnitData: adUnitData,
                gamRequest: publisherGamRequest
            )
        }
        
        PrebidCommonHelper.configureSharedPrebid(adUnitData: adUnitData)
        PrebidCommonHelper.applyCommonTargeting(using: adUnitData)

        let prebidAdUnit = makePrebidInterstitialAdUnit(adUnitData: adUnitData)
        applyContentURLIfNeeded(to: prebidAdUnit, request: publisherGamRequest)
        prebidAdUnit.setImpORTBConfig(getImpSetup(adUnitId: adUnitData.adUnit, customTargeting: ""))

        // Important: this same AdManagerRequest instance should later continue into GAM
        // after Prebid has enriched it with targeting.
        let enrichedRequest = try await fetchDemand(
            prebidAdUnit: prebidAdUnit,
            request: publisherGamRequest,
            adUnitData: adUnitData
        )

        SLogger.i(
            "[InterstitialPrebidRenderer:\(dbgId)] load SUCCESS adUnit=\(adUnitData.adUnit)"
        )

        return InterstitialGamRequestData(
            adUnitData: adUnitData,
            gamRequest: enrichedRequest
        )
    }
    // MARK: - Prebid demand

    private func fetchDemand(
        prebidAdUnit: InterstitialAdUnit,
        request: AdManagerRequest,
        adUnitData: YLAdUnitData
    ) async throws -> AdManagerRequest {
        try await withCheckedThrowingContinuation { continuation in
            timeEventRecorder.recordRequestBids(bidAdapter: .Prebid)

            prebidAdUnit.fetchDemand(adObject: request) { resultCode in
                SLogger.d(
                    "[InterstitialPrebidRenderer:\(self.dbgId)] fetchDemand resultCode: \(resultCode.name())"
                )

                let mappedResultCode = BidAdapterResultCode.fromPrebidResultCode(
                    code: resultCode
                )

                self.timeEventRecorder.recordBidderRespondedSuccessfully(
                    bidAdapter: .Prebid,
                    resultCode: mappedResultCode
                )

                switch resultCode {
                case .prebidDemandFetchSuccess:
                    let keyValues = self.getBidSuccessfulKeyValues(
                        configId: adUnitData.configId,
                        dfpRequest: request
                    )

                    request.customTargeting = keyValues

                    SLogger.i(
                        "[InterstitialPrebidRenderer:\(self.dbgId)] fetchDemand SUCCESS targeting=\(keyValues)"
                    )

                    continuation.resume(returning: request)

                case .prebidDemandNoBids:
                    let keyValues = self.getNoBidsKeyValues(
                        configId: adUnitData.configId,
                        pbsResultCode: resultCode
                    )

                    request.customTargeting = keyValues

                    SLogger.i(
                        "[InterstitialPrebidRenderer:\(self.dbgId)] fetchDemand NO_BIDS targeting=\(keyValues)"
                    )

                    continuation.resume(returning: request)

                default:
                    SLogger.i(
                        "[InterstitialPrebidRenderer:\(self.dbgId)] fetchDemand FAILED resultCode=\(resultCode.name())"
                    )

                    continuation.resume(
                        throwing: InterstitialPrebidRendererError.prebidFetchFailed(resultCode)
                    )
                }
            }
        }
    }

    // MARK: - Prebid ad unit setup

    private func makePrebidInterstitialAdUnit(
        adUnitData: YLAdUnitData
    ) -> InterstitialAdUnit {
        let adUnit = InterstitialAdUnit(
            configId: adUnitData.configId,
            minWidthPerc: 10,
            minHeightPerc: 10
        )

        let parameters = BannerParameters()
        parameters.api = adUnitData.frameworks
        adUnit.bannerParameters = parameters
        adUnit.pbAdSlot = adUnitData.adUnit

        return adUnit
    }

    private func applyContentURLIfNeeded(
        to prebidAdUnit: InterstitialAdUnit,
        request: AdManagerRequest
    ) {
        // TODO: This contentURL/app-content setup may also end up shared
        // with other Prebid renderers later.
        if let contentURL = request.contentURL, !contentURL.isEmpty {
            let appContent = ORTBAppContent()
            appContent.url = contentURL
            prebidAdUnit.setAppContent(appContent)
        }
    }

    // MARK: - Targeting mapping

    private func getBidSuccessfulKeyValues(
        configId: String,
        dfpRequest: AdManagerRequest
    ) -> [String: String] {
        let rawTargeting = (dfpRequest.customTargeting as? [String: String]) ?? [:]
        let prebidTargeting = PrebidCommonHelper.translatedTargeting(from: rawTargeting)
        let metaTags = PrebidCommonHelper.bidSuccessfulMetaTags(configId: configId)
        let prebidAndMeta = PrebidCommonHelper.merge(prebidTargeting, metaTags)

        return PrebidCommonHelper.merge(
            prebidAndMeta,
            interstitialConfiguration.publisherCustomTargeting
        )
    }
    
    private func getNoBidsKeyValues(
        configId: String,
        pbsResultCode: ResultCode
    ) -> [String: String] {
        let metaTags = PrebidCommonHelper.noBidsMetaTags(
            configId: configId,
            pbsResultCode: pbsResultCode
        )

        return PrebidCommonHelper.merge(
            metaTags,
            interstitialConfiguration.publisherCustomTargeting
        )
    }
}
