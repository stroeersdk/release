//
//  RendererDirectViewListener.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 01/04/2026.
//


import Foundation

final class RendererDirectViewListener: NSObject, PrebidHtmlBannerViewListener {

    weak var renderer: BannerPrebidRenderer?
    weak var bannerConfiguration: BannerAdConfiguration?
    weak var directView: PrebidHtmlBannerView?

    private var didFinish = false

    init(
        renderer: BannerPrebidRenderer,
        bannerConfiguration: BannerAdConfiguration,
        directView: PrebidHtmlBannerView
    ) {
        self.renderer = renderer
        self.bannerConfiguration = bannerConfiguration
        self.directView = directView
    }

    func onAdClosed() {
        Task { @MainActor [weak self] in
            guard let configuration = self?.bannerConfiguration,
                  let wrapperView = configuration.wrapperView else {
                return
            }

            configuration.publisherDelegate?.bannerViewWillDismissScreen?(wrapperView)
            configuration.publisherDelegate?.bannerViewDidDismissScreen?(wrapperView)
        }
    }

    func onAdFailedToLoad(error: Error) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            guard !didFinish else { return }
            didFinish = true
            renderer?.directViewDidFail(error)
        }
    }

    func onAdOpened() {
        Task { @MainActor [weak self] in
            guard let configuration = self?.bannerConfiguration,
                  let wrapperView = configuration.wrapperView else {
                return
            }

            configuration.publisherDelegate?.bannerViewWillPresentScreen?(wrapperView)
        }
    }

    func onAdLoaded() {
        Task { @MainActor [weak self] in
            guard let self else { return }
            guard !didFinish else { return }
            guard let directView else { return }
            didFinish = true
            renderer?.directViewDidLoad(directView)
        }
    }

    func onAdClicked() {
        Task { @MainActor [weak self] in
            guard let configuration = self?.bannerConfiguration,
                  let wrapperView = configuration.wrapperView else {
                return
            }

            configuration.publisherDelegate?.bannerViewDidRecordClick?(wrapperView)
        }
    }

    func onAdImpression() {
        Task { @MainActor [weak self] in
            guard let configuration = self?.bannerConfiguration,
                  let wrapperView = configuration.wrapperView else {
                return
            }

            configuration.publisherDelegate?.bannerViewDidRecordImpression?(wrapperView)
        }
    }
}
