//
//  BannerDirectRenderEventHandler.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 01/04/2026.
//


import UIKit
import PrebidMobile
import GoogleMobileAds

final class BannerDirectRenderEventHandler: NSObject, BannerEventHandler {

    weak var loadingDelegate: BannerEventLoadingDelegate?
    weak var interactionDelegate: BannerEventInteractionDelegate?

    private let bannerConfiguration: BannerAdConfiguration
    private let dbgId = UUID().uuidString.prefix(6)

    var onDecision: ((BannerDRDecision) -> Void)?

    private var timeEventRecorder: TimeEventRecorder {
        bannerConfiguration.timeEventRecorder
    }

    private var debugRecord: BannerDebugRecord? {
        bannerConfiguration.debugRecord
    }

    var adSizes: [CGSize] {
        bannerConfiguration.adUnitData?.bannerSizes.map(\.size) ?? []
    }

    init(bannerConfiguration: BannerAdConfiguration) {
        self.bannerConfiguration = bannerConfiguration
        super.init()

        SLogger.i(
            "[BannerDirectRenderEventHandler:\(dbgId)] init adUnit=\(bannerConfiguration.adUnitData?.adUnit ?? "") configId=\(bannerConfiguration.adUnitData?.configId ?? "")"
        )
    }

    func requestAd(with bidResponse: PrebidMobile.BidResponse?) {
        SLogger.i(
            "[BannerDirectRenderEventHandler:\(dbgId)] requestAd bidResponse_nil=\(bidResponse == nil)"
        )

        guard let adUnitData = bannerConfiguration.adUnitData else {
            SLogger.e("[BannerDirectRenderEventHandler:\(dbgId)] requestAd failed because adUnitData is nil")
            return
        }

        guard let bidResponse else {
            let request = makeGamRequest(adUnitData: adUnitData, pbidTargeting: [:], prebidWon: false)

            let requestData = BannerGamRequestData(
                adUnitData: adUnitData,
                gamRequest: request
            )

            SLogger.i("[BannerDirectRenderEventHandler:\(dbgId)] no bid => GAM")

            timeEventRecorder.recordBidderRespondedSuccessfully(
                bidAdapter: .Prebid,
                resultCode: .NO_BIDS
            )

            onDecision?(.gam(requestData: requestData))
            return
        }

        let hasPrebidWin = !(bidResponse.targetingInfo?.isEmpty ?? true)

        if let directRenderBid = bidResponse.allBids?.first(where: { $0.targetingInfo?["dr"] == "true" }),
           let adm = directRenderBid.adm,
           let hbSizeString = directRenderBid.targetingInfo?["hb_size"],
           let size = parseHxW(hbSizeString) {

            let payload = DirectRenderPayload(
                adm: adm,
                size: size,
                targeting: directRenderBid.targetingInfo ?? [:]
            )

            SLogger.i(
                "[BannerDirectRenderEventHandler:\(dbgId)] DR detected hb_size=\(hbSizeString)"
            )
            
            timeEventRecorder.recordBidderRespondedSuccessfully(
                bidAdapter: .Prebid,
                resultCode: .SUCCESS
            )

            onDecision?(.prebidDirect(payload: payload))
            return
        }

        let prebidTargeting: [String: String] = bidResponse.targetingInfo ?? [:]
        SLogger.i(
            "[BannerDirectRenderEventHandler:\(dbgId)] GAM path targetingCount=\(prebidTargeting.count) prebidWon=\(hasPrebidWin)"
        )
        
        timeEventRecorder.recordBidderRespondedSuccessfully(
            bidAdapter: .Prebid,
            resultCode: hasPrebidWin ? .SUCCESS : .NO_BIDS
        )

        let request = makeGamRequest(
            adUnitData: adUnitData,
            pbidTargeting: prebidTargeting,
            prebidWon: hasPrebidWin
        )

        recordPrebidCacheAndSize(
            from: request,
            adUnitData: adUnitData
        )

        let requestData = BannerGamRequestData(
            adUnitData: adUnitData,
            gamRequest: request
        )

        SLogger.i("[BannerDirectRenderEventHandler:\(dbgId)] onDecision => GAM")
        onDecision?(.gam(requestData: requestData))
    }

    func signalPrebidWin() {
        SLogger.i("[BannerDirectRenderEventHandler:\(dbgId)] signalPrebidWin")
        loadingDelegate?.prebidDidWin()
    }

    func signalAdServerWin() {
        let baseSize = adSizes.first ?? .zero
        let placeholder = UIView(frame: CGRect(origin: .zero, size: baseSize))
        placeholder.backgroundColor = .clear

        SLogger.i(
            "[BannerDirectRenderEventHandler:\(dbgId)] signalAdServerWin size=\(Int(baseSize.width))x\(Int(baseSize.height))"
        )

        loadingDelegate?.adServerDidWin(placeholder, adSize: baseSize)
    }

    func trackImpression() {}

    private func parseHxW(_ value: String) -> CGSize? {
        let trimmed = value.lowercased().replacingOccurrences(of: " ", with: "")
        let parts = trimmed.split(separator: "x")
        guard parts.count == 2,
              let width = Double(parts[0]),
              let height = Double(parts[1]),
              width > 0,
              height > 0 else {
            return nil
        }

        return CGSize(width: width, height: height)
    }
}

private extension BannerDirectRenderEventHandler {

    func makeGamRequest(
        adUnitData: YLAdUnitData,
        pbidTargeting: [String: String],
        prebidWon: Bool
    ) -> AdManagerRequest {
        let request = AdManagerRequest()
        let publisherGamRequest = bannerConfiguration.publisherGamRequest()

        let publisherTargeting = (publisherGamRequest.customTargeting as? [String: String]) ?? [:]

        let translatedPrebidTargeting = PrebidCommonHelper.translatedTargeting(
            from: pbidTargeting,
            keepUntranslatedKeys: true
        )

        var mergedTargeting = PrebidCommonHelper.merge(
            translatedPrebidTargeting,
            publisherTargeting
        )

        mergedTargeting[YLConstants.sdkVersionNumberKey] = YLConstants.version

        let metaTags = prebidWon
            ? PrebidCommonHelper.bidSuccessfulMetaTags(configId: adUnitData.configId)
            : PrebidCommonHelper.noBidsMetaTags(configId: adUnitData.configId)

        let finalTargeting = PrebidCommonHelper.merge(
            mergedTargeting,
            metaTags
        )
        request.customTargeting = finalTargeting

        debugRecord?.didReceiveFromPrebid(
            targeting: pbidTargeting.isEmpty ? ["targeting": "Empty"] : pbidTargeting,
            adUnitId: adUnitData.adUnit
        )

        debugRecord?.didSendToGAM(
            targeting: finalTargeting,
            adUnitId: adUnitData.adUnit
        )

        if let url = publisherGamRequest.contentURL, !url.isEmpty {
            request.contentURL = url
        }

        return request
    }

    func recordPrebidCacheAndSize(from request: AdManagerRequest, adUnitData: YLAdUnitData) {
        if let cacheKey = PrebidConstants.getTranslatedKey(key: .cache_id),
           let cacheId = request.customTargeting?[cacheKey] as? String {
            adUnitData.prebidCacheId = cacheId
        }

        if let sizeKey = PrebidConstants.getTranslatedKey(key: .size),
           let size = request.customTargeting?[sizeKey] as? String {
            adUnitData.prebidAdSize = AdSizeConverter.getCGSize(for: size)
        }
    }
}

struct BannerGamRequestData {
    let adUnitData: YLAdUnitData
    let gamRequest: AdManagerRequest
}
