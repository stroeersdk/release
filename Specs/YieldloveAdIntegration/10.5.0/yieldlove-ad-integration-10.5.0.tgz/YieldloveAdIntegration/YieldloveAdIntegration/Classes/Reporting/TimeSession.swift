import Foundation
import PrebidMobile

public class TimeSession {

    public var startingPoint: Date?

    var events: [TimeEvent] = []
    let sessionId: String
    let adType: AdType
    var connection: Connection?

    init(adType: AdType,
         uuidGenerator: @escaping () -> UUID = UUID.init) {
        self.adType = adType
        self.sessionId = uuidGenerator().uuidString
    }
    
    public func reset(){
        self.startingPoint = nil
        self.events.removeAll()
    }

    public func start() throws {
        if !events.isEmpty {
            throw ReportingError.multipleCallsToStartSession
        }
        
        Task { [weak self] in
            self?.connection = await NetworkMonitor.getConnection()
        }
        
        startingPoint = Date()
        self.events.append(MeasuringStarted())
    }

    public func stop() throws {
        if isSessionCompleted() {
            throw ReportingError.multipleCallsToStopSession
        }
        
        if let start = startingPoint {
            let stopEvent = MeasuringCompleted()
            stopEvent.diff(start)
            self.events.append(stopEvent)
        }
    }

    public func recordEvent(event: TimeEvent) throws {
        if events.count == 0 {
            throw ReportingError.sessionNotStarted
        }
        
        if isSessionCompleted() {
            throw ReportingError.addingEventToCompletedSessionNotAllowed
        }
        
        if let start = startingPoint {
            event.diff(start)
        }
        
        self.events.append(event)
    }

    public func getEvent(eventType: String) -> TimeEvent? {
        return events.first(where: { $0.typeName == eventType })
    }

    public func getServedInTime() -> TimeInterval {
        if let responseEvent = getEvent(eventType: "GamRespondedSuccessfully") {
            return TimeInterval(responseEvent.timeSinceMeasuringStarted) / 1000
        }
        return 0
    }

    private func isSessionCompleted() -> Bool {
        return events.last is MeasuringCompleted
    }
}

public enum BiddingAdapter: String {
    case Prebid
}

public enum BidAdapterResultCode: String {
    case SUCCESS
    case NO_BIDS
    case TIMEOUT
    case FAILED
    case NOT_AVAILABLE
    case SKIPPED

    public static func fromPrebidResultCode(code: ResultCode) -> BidAdapterResultCode {
        switch code {
        case .prebidDemandFetchSuccess: return .SUCCESS
        case .prebidDemandNoBids: return .NO_BIDS
        case .prebidDemandTimedOut: return .TIMEOUT
        default: return .FAILED
        }
    }
}

enum ReportingError: LocalizedError {
    case multipleCallsToStartSession
    case multipleCallsToStopSession
    case sessionNotStarted
    case addingEventToCompletedSessionNotAllowed

    var errorDescription: String? {
        switch self {
        case .multipleCallsToStartSession: return "Multiple calls to start session"
        case .multipleCallsToStopSession: return "Multiple calls to stop session"
        case .sessionNotStarted: return "Session not started"
        case .addingEventToCompletedSessionNotAllowed: return "Adding event to completed session is not allowed"
        }
    }
}
