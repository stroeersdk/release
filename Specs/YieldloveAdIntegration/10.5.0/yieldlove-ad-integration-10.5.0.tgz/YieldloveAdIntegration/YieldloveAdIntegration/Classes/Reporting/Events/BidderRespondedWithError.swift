import Foundation

struct BidderError {
    var message: String
    var type: StringLiteralType
    var stackTrace: String
}

class BidderRespondedWithError: TimeEvent {

    var error: BidderError
    var bidAdapter: BiddingAdapter

    init(adapter: BiddingAdapter, error: Error) {
        self.bidAdapter = adapter
        self.error = BidderError(message: error.localizedDescription, type: "BidderError", stackTrace: "")
        super.init()
    }
}
