import Foundation

class GamRespondedWithError: TimeEvent {

    var error: GamError

    init(error: Error) {
        self.error = GamError(message: error.localizedDescription, type: "GamRespondedWithError", stackTrace: "")
        super.init()
    }
}

struct GamError {
    var message: String
    var type: String
    var stackTrace: String
}
