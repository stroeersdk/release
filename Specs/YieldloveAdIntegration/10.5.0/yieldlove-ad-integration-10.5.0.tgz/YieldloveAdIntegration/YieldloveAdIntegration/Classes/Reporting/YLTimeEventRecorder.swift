
typealias EventProducer = () -> TimeEvent

protocol TimeEventRecorder {
    var session: TimeSession { get }
    func startSession()
    func stopSession()
    func recordAdUnitLoaded()
    func recordRequestBids(bidAdapter: BiddingAdapter)
    func recordBidderRespondedSuccessfully(bidAdapter: BiddingAdapter, resultCode: BidAdapterResultCode)
    func recordGamRequested()
    func recordGamRespondedSuccessfully()
    func recordGamRespondedWithError(error: Error)
    func recordAdAnalyzed(winner: String)
}

class YLTimeEventRecorder: TimeEventRecorder {

    let session: TimeSession

    init(adType: AdType) {
        self.session = TimeSession(adType: adType)
    }

    func startSession() {
        do {
            try session.start()
        } catch {
            debugPrint(error)
        }
    }

    func stopSession() {
        do {
            try session.stop()
        } catch {
            debugPrint(error)
        }
    }

    func recordAdUnitLoaded() {
        record(AdUnitLoaded())
    }

    func recordRequestBids(bidAdapter: BiddingAdapter) {
        record(BidRequested(bidAdapter: bidAdapter))
    }

    func recordBidderRespondedSuccessfully(bidAdapter: BiddingAdapter, resultCode: BidAdapterResultCode) {
        record(BidderRespondedSuccessfully(adapter: bidAdapter, result: resultCode))
    }

    func recordGamRequested() {
        record(GamRequested())
    }

    func recordGamRespondedSuccessfully() {
        record(GamRespondedSuccessfully())
    }

    func recordGamRespondedWithError(error: Error) {
        record(GamRespondedWithError(error: error))
    }

    func recordAdAnalyzed(winner: String) {
        record(AdAnalyzed(winner: winner))
    }
    
    func getServedTime() -> TimeInterval {
        return session.getServedInTime()
    }

    private func record(_ event: TimeEvent) {
        do {
            try session.recordEvent(event: event)
        } catch {
            debugPrint(error)
        }
    }

    private func debugPrint(_ error: Error) {
        if ConfigurationManager.isDebugMode() {
            SLogger.e("[EventRecorder] Error while recoding the event - \(error.localizedDescription)")
        }
    }
}
