import Foundation

class BidderRespondedSuccessfully: TimeEvent {
    var resultCode: BidAdapterResultCode
    var bidAdapter: BiddingAdapter

    init(adapter: BiddingAdapter, result: BidAdapterResultCode) {
        self.bidAdapter = adapter
        self.resultCode = result
        super.init()
    }
}
