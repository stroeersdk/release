import Foundation

class BidRequested: TimeEvent {

    var bidAdapter: BiddingAdapter

    init(bidAdapter: BiddingAdapter) {
        self.bidAdapter = bidAdapter
        super.init()
    }
}
