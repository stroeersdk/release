class MeasuringStarted: TimeEvent {}
