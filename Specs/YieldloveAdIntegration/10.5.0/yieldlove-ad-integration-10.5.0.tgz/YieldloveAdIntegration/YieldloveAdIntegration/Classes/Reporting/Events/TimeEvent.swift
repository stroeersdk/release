import Foundation

public class TimeEvent {

    public var typeName: String {
        let fullEventName = String(describing: self)
        if let index = fullEventName.firstIndex(of: ".") {
            let indexAfter = fullEventName.index(after: index)
            return String(fullEventName[indexAfter...])
        }
        return fullEventName
    }
    
    public var timeSinceMeasuringStarted = 0
    public let eventProduced = Date()

    func asString() -> String {
        return "\(typeName): \(timeSinceMeasuringStarted) ms"
    }

    func diff(_ startingPoint: Date){
        let interval = eventProduced.timeIntervalSince(startingPoint)
        let safeInterval = max(interval, 0)
        timeSinceMeasuringStarted = safeInterval.milliseconds
    }
}

extension TimeInterval {
    var milliseconds: Int {
        return Int(self * 1000)
    }
}
