import Foundation

class AdAnalyzed: TimeEvent {
    var winner: String

    init(winner: String) {
        self.winner = winner
        super.init()
    }
}
