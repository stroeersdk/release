import Foundation
import GoogleMobileAds
import PromiseKit
import PrebidMobile


public typealias GetAdSizesCompletion = (_ adSizes: NSArray, _ error: Error?) -> Void
public typealias RewardedAdCompletion = (_ ad: RewardedAd?, _ error: Error?) -> Void

@objc public class Yieldlove: NSObject {

    @objc public static let instance = Yieldlove()
    
    @available(*, deprecated, message: "Use GlobalGamManager.adRequest instead")
    @objc public var adRequest : AdManagerRequest{
        return GlobalGamManager.adRequest
    }

    private static var config: Config?

    private let configurationManager: IConfigurationManager
    public var bidTrackingListener: BidTrackingListener?

    @objc public class func setup(appName: String) {
        SLogger.i("Version - \(YLConstants.version)")
        Yieldlove.setupEnvironment(appName: appName)
    }

    
    class func setupEnvironment(appName: String, configProvider: Config.Type = YLConfig.self) {
        ExternalConfigurationManagerBuilder.instance.appName = appName
        if Yieldlove.config == nil {
            Yieldlove.config = configProvider.getProductionConfig(appName: appName)
        }
        ConfigurationManager.shared.initialize(appName: appName)
        IdentityManager.shared.initialize()
        AdminHttpServer.launch()
    }

    override private init() {
        guard let config = Yieldlove.config else {
            fatalError("Error - you must call setup before accessing Yieldlove.instance")
        }
        self.configurationManager = config.configurationManager
        super.init()
        MobileAds.shared.start()
    }

    func getConfig() -> Config {
        guard let config = Yieldlove.config else {
            fatalError("Error - you must call setup before accessing Yieldlove.instance")
        }
        return config
    }
    
    @objc public func clearConfigurationCache() {
        self.configurationManager.clearConfigurationCache()
    }

    @objc public static func enableDebugMode() {
        ConfigurationManager.enableDebugMode();
        SLogger.enableDebug = true
    }
    
    @objc public static func enableInspectionMode(){
        ConfigurationManager.enableInspectionMode()
    }
    
    @MainActor
    @objc public func bannerAd(
        adSlotId: String,
        viewController: UIViewController,
        delegate: YLBannerViewDelegate
    ) -> YLBannerView {
        let config = getConfig()

        let wrapperView = YLBannerView()

        let bannerConfiguration = BannerAdConfiguration(
            adSlotId: adSlotId,
            config: config,
            viewController: viewController,
            publisherDelegate: delegate,
            wrapperView: wrapperView
        )

        let controller = BannerController(bannerConfiguration: bannerConfiguration)

        wrapperView.attachController(controller)
        controller.start()
        
        return wrapperView
    }
    
    // GAMRequest is optional to get rid of a warning in Objective-C apps
    // which appears when nil is passed to methods that do not accept nil
    @MainActor
    @objc public func interstitialAd(adSlotId: String, interstitialDelegate: YLInterstitialAdDelegate?, viewController: UIViewController, request: AdManagerRequest? = AdManagerRequest()) {
        
        let config = getConfig()

        let interstitialConfiguration = InterstitialAdConfiguration(
            adSlotId: adSlotId,
            config: config,
            viewController: viewController,
            publisherDelegate: interstitialDelegate,
            request: request ?? AdManagerRequest()
        )

        let controller = InterstitialController(
            interstitialConfiguration: interstitialConfiguration
        )

        controller.start()
    }
    
    
    @MainActor
    @objc public func rewardedAd(
        adSlotId: String,
        completion: @escaping RewardedAdCompletion,
        request: AdManagerRequest? = AdManagerRequest()
    ) {
        let config = getConfig()

        let rewardedConfiguration = RewardedAdConfiguration(
            adSlotId: adSlotId,
            config: config,
            completion: completion,
            request: request ?? AdManagerRequest()
        )

        let controller = RewardedController(
            rewardedConfiguration: rewardedConfiguration
        )

        controller.start()
    }

    @objc public func getAdSizes(adSlotId: String, completion: @escaping GetAdSizesCompletion) {
        self.configurationManager
            .getAdUnitData(publisherAdSlot: adSlotId, adType: .banner)
            .map(YLAdUnitDataTransformer.transformBannerAdUnitData)
            .map { adUnitData in
                completion(YLAdSizeCollection(sizes: adUnitData.bannerSizes).getSizes(), nil)
            }.catch { error in
                completion([] as NSArray, AdSlotConfigurationError(error))
            }
    }
    
    @objc public func setCustomTargets(targets: [String: String])
    {
        GlobalGamManager.adRequest.customTargeting = targets
        var convertedTargets: [String: [String]] = [:]
        for (key, value) in targets{
            Targeting.shared.addAppKeyword(value)
            // Split the value by commas and remove any extra whitespace
            let valuesArray = value.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
            // Assign the array to the key in the new dictionary
            convertedTargets[key] = valuesArray.map { String($0) }
        }
        
        GraviteLoader.shared.setCustomTargets(targets: convertedTargets)
    }
}
