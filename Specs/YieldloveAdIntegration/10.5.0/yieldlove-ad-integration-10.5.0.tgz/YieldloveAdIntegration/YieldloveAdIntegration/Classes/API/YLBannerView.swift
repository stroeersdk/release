import UIKit

@objcMembers
public final class YLBannerView: UIView {
    
    // MARK: - Public / external
    public var bannerInfo: YLAdUnitData

    private var controller: BannerController?
    private var isDestroyed = false

    private var displayedAdView: UIView?
    var debugLabelView: UIView?

    private var currentSize: CGSize = .zero {
        didSet {
            guard oldValue != currentSize else { return }
            updateHeightConstraint()
            updateChildSizeConstraints()
            invalidateIntrinsicContentSize()
            setNeedsLayout()
        }
    }

    private var heightConstraint: NSLayoutConstraint?
    private var childCenterX: NSLayoutConstraint?
    private var childTop: NSLayoutConstraint?
    private var childWidth: NSLayoutConstraint?
    private var childHeight: NSLayoutConstraint?

    internal init() {
        self.bannerInfo = YLAdUnitData(adUnit: "empty", configId: "empty")
        super.init(frame: .zero)
        commonInit()
    }

    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func commonInit() {
        translatesAutoresizingMaskIntoConstraints = false
        clipsToBounds = false
        backgroundColor = .clear
        updateHeightConstraint()
    }

    internal func attachController(_ controller: BannerController) {
        self.controller = controller
    }

    public func refresh() {
        guard !isDestroyed else { return }
        controller?.refreshFromHost()
    }

    public func destroy() {
        guard !isDestroyed else { return }
        isDestroyed = true
        controller?.destroy()
        controller = nil
        cleanupViewState()
    }

    public func getSource() -> AdSourceInfo {
        bannerInfo.source
    }

    public func getBannerView() -> UIView? {
        displayedAdView
    }

    public func updateSize(to size: CGSize) {
        guard !isDestroyed else { return }
        currentSize = size.nonNegativeOrZero()
    }

    public func getBannerSize() -> CGSize {
        if currentSize != .zero {
            return currentSize
        }

        if let displayedAdView {
            let intrinsic = displayedAdView.intrinsicContentSize.nonNegativeOrZero()
            if intrinsic.width > 0 || intrinsic.height > 0 {
                return intrinsic
            }

            let bounds = displayedAdView.bounds.size.nonNegativeOrZero()
            if bounds.width > 0 || bounds.height > 0 {
                return bounds
            }

            let frame = displayedAdView.frame.size.nonNegativeOrZero()
            if frame.width > 0 || frame.height > 0 {
                return frame
            }
        }

        return .zero
    }

    public func setBannerView(bannerView: UIView) {
        guard !isDestroyed else { return }

        detachDisplayedAdView()

        displayedAdView = bannerView
        bannerView.translatesAutoresizingMaskIntoConstraints = false
        bannerView.clipsToBounds = false

        addSubview(bannerView)

        childCenterX = bannerView.centerXAnchor.constraint(equalTo: centerXAnchor)
        childTop = bannerView.topAnchor.constraint(equalTo: topAnchor)

        let initial = bestKnownSize(for: bannerView)
        childWidth = bannerView.widthAnchor.constraint(equalToConstant: max(0, initial.width))
        childHeight = bannerView.heightAnchor.constraint(equalToConstant: max(0, initial.height))

        NSLayoutConstraint.activate([
            childCenterX!,
            childTop!,
            childWidth!,
            childHeight!
        ])
    }

    public func createDebugLabelView(debugView: UIView) {
        guard !isDestroyed else { return }

        let tag = 123456789

        debugLabelView?.removeFromSuperview()
        debugLabelView = nil
        viewWithTag(tag)?.removeFromSuperview()

        debugView.tag = tag
        debugView.frame = CGRect(x: 8, y: 8, width: 200, height: 40)

        addSubview(debugView)
        bringSubviewToFront(debugView)

        debugLabelView = debugView
    }

    public override var intrinsicContentSize: CGSize {
        let size = currentSize
        if size == .zero {
            return CGSize(width: UIView.noIntrinsicMetric, height: 0)
        }

        return CGSize(
            width: size.width > 0 ? size.width : UIView.noIntrinsicMetric,
            height: size.height
        )
    }

    deinit {
        destroy()
    }

    private func cleanupViewState() {
        detachDisplayedAdView()

        debugLabelView?.removeFromSuperview()
        debugLabelView = nil

        currentSize = .zero
    }

    private func detachDisplayedAdView() {
        (displayedAdView as? PrebidHtmlBannerView)?.destroy()
        displayedAdView?.removeFromSuperview()
        displayedAdView = nil

        if let c = childCenterX { NSLayoutConstraint.deactivate([c]) }
        if let c = childTop { NSLayoutConstraint.deactivate([c]) }
        if let c = childWidth { NSLayoutConstraint.deactivate([c]) }
        if let c = childHeight { NSLayoutConstraint.deactivate([c]) }

        childCenterX = nil
        childTop = nil
        childWidth = nil
        childHeight = nil
    }

    private func updateChildSizeConstraints() {
        let size = currentSize.nonNegativeOrZero()
        childWidth?.constant = max(0, size.width)
        childHeight?.constant = max(0, size.height)
    }

    private func bestKnownSize(for child: UIView) -> CGSize {
        let current = currentSize.nonNegativeOrZero()
        if current.width > 0 || current.height > 0 {
            return current
        }

        let intrinsic = child.intrinsicContentSize.nonNegativeOrZero()
        if intrinsic.width > 0 || intrinsic.height > 0 {
            return intrinsic
        }

        let bounds = child.bounds.size.nonNegativeOrZero()
        if bounds.width > 0 || bounds.height > 0 {
            return bounds
        }

        let frame = child.frame.size.nonNegativeOrZero()
        if frame.width > 0 || frame.height > 0 {
            return frame
        }

        return .zero
    }

    private func updateHeightConstraint() {
        if heightConstraint == nil {
            let c = heightAnchor.constraint(equalToConstant: max(0, currentSize.height))
            c.priority = .required
            c.isActive = true
            heightConstraint = c
        } else {
            heightConstraint?.constant = max(0, currentSize.height)
        }
    }
}

extension YLBannerView {
    public func addInspectionGestureRecognizer() {
        let alreadyAdded = gestureRecognizers?.contains(where: {
            guard let longPress = $0 as? UILongPressGestureRecognizer else { return false }
            return longPress.numberOfTouchesRequired == 2
        }) ?? false

        guard !alreadyAdded else { return }

        let longPress = UILongPressGestureRecognizer(
            target: self,
            action: #selector(handleInspectionGesture(_:))
        )
        longPress.numberOfTouchesRequired = 2
        addGestureRecognizer(longPress)
    }

    @objc private func handleInspectionGesture(_ sender: UILongPressGestureRecognizer) {
        guard sender.view != nil else { return }

        if sender.state == .ended {
            ConfigurationManager.enableInspectionMode()
            GraviteLoader.shared.enableInspectionMode()

            if let viewController = UIUtils.getRootViewController() {
                let message = "Ad debugging mode has been switched on. Force close the app to switch it back off."
                ToastMessage.alert(viewController: viewController, title: "Debug Info", message: message)
            } else {
                SLogger.d("Warning: Could not find root UIViewController to show debug message.")
            }
        }
    }
}

private extension CGSize {
    func nonNegativeOrZero() -> CGSize {
        CGSize(
            width: max(0, width.isFinite ? width : 0),
            height: max(0, height.isFinite ? height : 0)
        )
    }
}
