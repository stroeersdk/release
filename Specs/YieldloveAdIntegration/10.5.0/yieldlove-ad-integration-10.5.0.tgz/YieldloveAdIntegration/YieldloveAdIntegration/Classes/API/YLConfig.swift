

protocol Config: AnyObject {
    var prebidAdUnitFactory: PrebidAdUnitFactory { get }
    var configurationManager: IConfigurationManager { get }
    var bidCollector: BidsCollector { get }
    var refreshTimerFactory: RefreshTimerFactory { get }
    var gamAdLoader: GamAdLoader { get }

    static func getProductionConfig(appName: String) -> Config
}

@objc public class YLConfig: NSObject, Config {

    var prebidAdUnitFactory: PrebidAdUnitFactory
    var configurationManager: IConfigurationManager
    var bidCollector: BidsCollector
    var refreshTimerFactory: RefreshTimerFactory
    var gamAdLoader: GamAdLoader

    init(
         prebidAdUnitFactory: PrebidAdUnitFactory,
         configurationManager: IConfigurationManager,
         bidCollector: BidsCollector,
         refreshTimerFactory: RefreshTimerFactory,
         gamAdLoader: GamAdLoader
    ) {
        self.prebidAdUnitFactory = prebidAdUnitFactory
        do {
            //TODO: this inits Prebid and must be addressed when refactoring config because prebidAdUnitFactory is legacy
            try self.prebidAdUnitFactory.setPrebidServerUrl()
        } catch {
            SLogger.e("[YLConfig] Could not set URL to production Prebid server")
        }
        self.configurationManager = configurationManager
        self.bidCollector = bidCollector
        self.refreshTimerFactory = refreshTimerFactory
        self.gamAdLoader = gamAdLoader
    }

    static func getProductionConfig(appName: String) -> Config {
        let configurationManager = ExternalConfigurationManagerBuilder.instance.externalConfigurationManager
        return YLConfig(
                prebidAdUnitFactory: YLPrebidAdUnitFactory(),
                configurationManager: configurationManager,
                bidCollector: YLBidsCollector(),
                refreshTimerFactory: YLRefreshTimerFactory(),
                gamAdLoader: YLGamAdLoader()
        )
    }

}
