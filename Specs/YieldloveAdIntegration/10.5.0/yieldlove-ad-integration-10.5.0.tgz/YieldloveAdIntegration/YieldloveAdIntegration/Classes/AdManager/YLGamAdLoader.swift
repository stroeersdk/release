import GoogleMobileAds
import PromiseKit

struct GamRequestData {
    var adUnitData: YLAdUnitData
    var gamRequest: AdManagerRequest
    var publisherViewController: UIViewController?
    var publisherDelegate: YLBannerViewDelegate?
}

typealias GamInstlRequestData = (adUnitData: YLAdUnitData,
                                 gamRequest: AdManagerRequest)

typealias RewardedRequestData = (adUnitData: YLAdUnitData,
                                 gamRequest: AdManagerRequest)

typealias RewardedCompletion = GADRewardedAdLoadCompletionHandler
typealias InstlCompletion = GAMInterstitialAdLoadCompletionHandler

protocol GamAdLoader {
    @discardableResult
    //func loadBanner(gamRequestData: GamRequestData, ylBanner: YLBanner) -> Promise<YLBannerView>
   // func loadRefreshableBanner(gamRequestData: GamRequestData, ylBanner: YLRefreshableBanner) -> Promise<YLBannerView>
   // func refreshBanner(gamRequestData: GamRequestData, ylBannerView: YLBannerView) -> Promise<YLBannerView>
    func loadInterstitial(gamRequestData: GamInstlRequestData, timeEventRecorder: TimeEventRecorder) -> Promise<AdManagerInterstitialAd>
    @discardableResult
    func loadRewardedAd(gamRequestData: RewardedRequestData, timeEventRecorder: TimeEventRecorder) -> Promise<RewardedAd>
}

class YLGamAdLoader: GamAdLoader {

  //  private let bannerViewFactory: GamBannerViewFactory
    private let gamInterstitialProvider: AdManagerInterstitialAd.Type
    private let gamRewardedAdProvider: RewardedAd.Type

    init(//bannerViewFactory: GamBannerViewFactory,
         gamInterstitialProvider: AdManagerInterstitialAd.Type = AdManagerInterstitialAd.self,
         gamRewardedAdProvider: RewardedAd.Type = RewardedAd.self) {
   //     self.bannerViewFactory = bannerViewFactory
        self.gamInterstitialProvider = gamInterstitialProvider
        self.gamRewardedAdProvider = gamRewardedAdProvider
    }

//    func loadBanner(gamRequestData: GamRequestData, ylBanner: YLBanner) -> Promise<YLBannerView> {
//        
//        let adDelegate = YLAdDelegate(gamRequestData: gamRequestData, timeEventRecorder: ylBanner.timeEventRecorder, bannerConfiguration: ylBanner.bannerConfiguration, bidTrackingListener: Yieldlove.instance.bidTrackingListener)
//        
//        let bannerView = bannerViewFactory.makeGAMBannerView(adUnitData: gamRequestData.adUnitData, delegate: adDelegate)
//
//        ylBanner.markBannerView(ylBannerView: bannerView)
//        
//        let referenceHolder = YLReferenceHolder(bannerView: bannerView, delegate: adDelegate)
//        keepReference(referenceHolder, ylAd: ylBanner)
//        
//        recordGamRequest(timeEventRecorder: ylBanner.timeEventRecorder)
//        
//        bannerView.load(gamRequestData.gamRequest)
//        return adDelegate.promise
//    }
//    
//    func loadRefreshableBanner(gamRequestData: GamRequestData, ylBanner: YLRefreshableBanner) -> Promise<YLBannerView> {
//        let adDelegate = YLAdDelegate(gamRequestData: gamRequestData, timeEventRecorder: ylBanner.timeEventRecorder, bannerConfiguration: ylBanner.bannerConfiguration, bidTrackingListener: Yieldlove.instance.bidTrackingListener)
//        let bannerView = bannerViewFactory.makeGAMBannerView(adUnitData: gamRequestData.adUnitData, delegate: adDelegate)
//
//        ylBanner.markBannerView(ylBannerView: bannerView)
//        
//        let referenceHolder = YLReferenceHolder(bannerView: bannerView, delegate: adDelegate)
//        startRefreshTimer(gamRequestData: gamRequestData, ylBanner: ylBanner, referenceHolder: referenceHolder)
//        keepReference(referenceHolder, ylAd: ylBanner)
//        
//        recordGamRequest(timeEventRecorder: ylBanner.timeEventRecorder)
//        bannerView.load(gamRequestData.gamRequest)
//        return adDelegate.promise
//    }
//    
//    func refreshBanner(gamRequestData: GamRequestData, ylBannerView: YLBannerView) -> Promise<YLBannerView> {
//        if let bannerView = ylBannerView.getBannerView() as? BannerView {
//            //using the new AdPromiseDelegate instead of AdDelegate as now its any object
//            guard let ylAdDelegate = bannerView.delegate as? AdPromiseDelegate else {
//                return Promise(error: YLGamAdLoaderError.cannotCastToYLAdDelegate)
//            }
//            ylAdDelegate.replacePromise()
//            bannerView.load(gamRequestData.gamRequest)
//            return ylAdDelegate.promise
//        }
//        else{
//            return Promise(error: YLGamAdLoaderError.cannotCastToYLAdDelegate)
//        }
//    }

    func loadInterstitial(gamRequestData: GamInstlRequestData, timeEventRecorder: TimeEventRecorder) -> Promise<AdManagerInterstitialAd> {
        let (promise, resolver) = Promise<AdManagerInterstitialAd>.pending()
        recordGamRequest(timeEventRecorder: timeEventRecorder)
        let completionHandler = getInstlCompletion(requestData: gamRequestData,
                                                      recorder: timeEventRecorder,
                                                      resolver: resolver)
        gamInterstitialProvider.load(with: gamRequestData.adUnitData.adUnit,
                                     request: gamRequestData.gamRequest,
                                     completionHandler: completionHandler)
        return promise
    }
    
    func loadRewardedAd(gamRequestData: RewardedRequestData, timeEventRecorder: TimeEventRecorder) -> Promise<RewardedAd> {
        let (promise, resolver) = Promise<RewardedAd>.pending()
        recordGamRequest(timeEventRecorder: timeEventRecorder)
        let completionHandler = getRewardedCompletion(requestData: gamRequestData,
                                                                recorder: timeEventRecorder,
                                                                resolver: resolver)
        
        gamRewardedAdProvider.load(with: gamRequestData.adUnitData.adUnit,
                                   request: gamRequestData.gamRequest,
                                   completionHandler: completionHandler)
        
        return promise
    }

//    private func startRefreshTimer(gamRequestData: GamRequestData, ylBanner: YLRefreshableBanner, referenceHolder: YLReferenceHolder) {
//        let config = ylBanner.config
//        let adUnitData = gamRequestData.adUnitData
//        let timerFactory = config.refreshTimerFactory
//        if let autoRefreshTimeMs = adUnitData.autoRefreshTimeMs {
//            let refreshTimer = timerFactory.makeTimer(autoRefreshTimeMs: autoRefreshTimeMs,
//                                                      delegate: ylBanner,
//                                                      referenceHolder: referenceHolder)
//            YLRefreshTimerCollection.instance.setTimer(adUnit: adUnitData.adUnit, refreshTimer)
//            refreshTimer.start()
//        }
//    }

    /*
     * Why keep a reference to GAMBannerView and YieldloveAdDelegate?
     * If YieldloveAdDelegate is released from memory during ad request,
     * there will be no object on which to call bannerViewDidReceiveAd()
     * or bannerViewDidFailToReceiveAdWithError()
     * If GAMBannerView is released from memory during ad request,
     * none of the delegate methods will be called. Releasing this object
     * signals to the GAM that app has moved on and is not waiting for ad.
     */
//    private func keepReference(_ referenceHolder: YLReferenceHolder, ylAd: YLAd) {
//        let referenceManager = ylAd.config.referenceManager
//        referenceManager.add(referenceHolder: referenceHolder)
//    }

    private func getInstlCompletion(requestData: GamInstlRequestData, recorder: TimeEventRecorder, resolver: Resolver<AdManagerInterstitialAd>)
            -> InstlCompletion {
        return { ad, error in
            self.recordGamResponse(timeEventRecorder: recorder, error: error)
            resolver.resolve(ad, error)
        }
    }
    
    private func getRewardedCompletion(requestData: RewardedRequestData, recorder: TimeEventRecorder, resolver: Resolver<RewardedAd>)
            -> RewardedCompletion {
        return { ad, error in
            self.recordGamResponse(timeEventRecorder: recorder, error: error)
            resolver.resolve(ad, error)
        }
    }

    private func recordGamRequest(timeEventRecorder: TimeEventRecorder?) {
        timeEventRecorder?.recordGamRequested()
    }

    private func recordGamResponse(timeEventRecorder: TimeEventRecorder, error: Error?) {
        if let err = error {
            timeEventRecorder.recordGamRespondedWithError(error: err)
        } else {
            timeEventRecorder.recordGamRespondedSuccessfully()
        }
    }
}
