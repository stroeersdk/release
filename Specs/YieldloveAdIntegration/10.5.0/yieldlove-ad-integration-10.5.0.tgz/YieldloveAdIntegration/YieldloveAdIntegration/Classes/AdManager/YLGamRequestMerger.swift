import GoogleMobileAds

class YLGamRequestMerger {
    
    public static func merge(_ highPrioRequest: AdManagerRequest?, _ lowPrioRequest: AdManagerRequest?) -> AdManagerRequest {
        if let req1 = highPrioRequest, let req2 = lowPrioRequest {
            return mergeIntoNewRequest(req1, req2)
        } else if let req = highPrioRequest {
            return mergeIntoNewRequest(req)
        } else if let req = lowPrioRequest {
            return mergeIntoNewRequest(req)
        }
        return AdManagerRequest()
    }
    
    private static func mergeIntoNewRequest(_ req: AdManagerRequest) -> AdManagerRequest {
        let gamRequest = AdManagerRequest()
        gamRequest.publisherProvidedID = req.publisherProvidedID
        gamRequest.contentURL = req.contentURL
        gamRequest.requestAgent = req.requestAgent
        mergeCustomTargeting(gamRequest, nil, req)
        mergeCategoryExclusions(gamRequest, nil, req)
        mergeKeywords(gamRequest, nil, req)
        return gamRequest
    }
    
    private static func mergeIntoNewRequest(_ req1: AdManagerRequest, _ req2: AdManagerRequest) -> AdManagerRequest {
        let gamRequest = AdManagerRequest()
        gamRequest.publisherProvidedID = req1.publisherProvidedID ?? req2.publisherProvidedID
        gamRequest.contentURL = req1.contentURL ?? req2.contentURL
        gamRequest.requestAgent = req1.requestAgent ?? req2.requestAgent
        mergeCustomTargeting(gamRequest, req2, req1)
        mergeCategoryExclusions(gamRequest, req2, req1)
        mergeKeywords(gamRequest, req2, req1)
        return gamRequest
    }

    private static func mergeKeywords(_ newRequest: AdManagerRequest, _ globalRequest: AdManagerRequest?, _ localRequest: AdManagerRequest) {
        newRequest.keywords = mergeStringArrays(
                globalRequest?.keywords,
                localRequest.keywords)
    }

    private static func mergeCategoryExclusions(_ newRequest: AdManagerRequest, _ globalRequest: AdManagerRequest?, _ localRequest: AdManagerRequest) {
        newRequest.categoryExclusions = mergeStringArrays(
                globalRequest?.categoryExclusions,
                localRequest.categoryExclusions)
    }
    
    private static func mergeStringArrays(_ globalArray: [String]?, _ localArray: [String]?) -> [String] {
        return (globalArray ?? []) + (localArray ?? [])
    }

    private static func mergeCustomTargeting(_ newRequest: AdManagerRequest, _ globalRequest: AdManagerRequest?, _ localRequest: AdManagerRequest) {
        newRequest.customTargeting = globalRequest?.customTargeting ?? [:]
        newRequest.customTargeting?.merge(localRequest.customTargeting ?? [:]) { (_, localValue) in
            localValue
        }
    }
    
    public static func mergeInto(request: AdManagerRequest, keyValues: [String: String], adUnit: String) -> AdManagerRequest {
        var requestKeyValues = request.customTargeting ?? [:]
        for (key, value) in keyValues {
            requestKeyValues[key] = value
        }
        // == Log GAM Values for traffic
        if let listener = Yieldlove.instance.bidTrackingListener {
            listener.didSendToGAM(targeting: requestKeyValues.compactMapValues { $0 as? String }, adUnitId: adUnit)
        }
         
        request.customTargeting = requestKeyValues
        return request
    }
}
