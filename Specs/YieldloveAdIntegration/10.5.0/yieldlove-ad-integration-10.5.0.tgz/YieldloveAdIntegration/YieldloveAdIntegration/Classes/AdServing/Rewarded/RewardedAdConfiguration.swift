//
//  RewardedAdConfiguration.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 20/04/2026.
//

import Foundation
import UIKit
import GoogleMobileAds

final class RewardedAdConfiguration: AdConfiguration {

    let completion: RewardedAdCompletion
    let timeEventRecorder: TimeEventRecorder
    let initialRequest: AdManagerRequest

    var gamRewardedAd: RewardedAd?

    private(set) var isDestroyed = false
    private let dbgId = UUID().uuidString.prefix(6)

    init(
        adSlotId: String,
        config: Config,
        completion: @escaping RewardedAdCompletion,
        request: AdManagerRequest,
        timeEventRecorder: TimeEventRecorder? = nil
    ) {
        self.completion = completion
        self.initialRequest = request
        self.timeEventRecorder = timeEventRecorder ?? YLTimeEventRecorder(
            adType: .rewarded
        )

        super.init(
            adSlotId: adSlotId,
            config: config,
            adType: .rewarded,
            viewController: nil
        )

        SLogger.i("[RewardedAdConfiguration:\(dbgId)] init adSlotId=\(adSlotId)")
    }

    // MARK: - Initialization

    @MainActor
    func initialize() async throws {
        guard adUnitData == nil else {
            SLogger.i(
                "[RewardedAdConfiguration:\(dbgId)] initialize skipped because adUnitData already exists"
            )
            return
        }

        SLogger.i(
            "[RewardedAdConfiguration:\(dbgId)] initialize START adSlotId=\(adSlotId)"
        )

        let configurableAdUnitData: ConfigurableAdUnitData = try await withCheckedThrowingContinuation { continuation in
            config.configurationManager
                .getAdUnitData(publisherAdSlot: adSlotId, adType: .rewarded)
                .done { value in
                    continuation.resume(returning: value)
                }
                .catch { error in
                    continuation.resume(throwing: error)
                }
        }

        let transformed = transformAdUnitData(
            configurableAdUnitData: configurableAdUnitData
        )

        transformed.TCString = YLConsentReader().getTCString()
        transformed.publisherCallString = adSlotId
        adUnitData = transformed

        SLogger.i(
            "[RewardedAdConfiguration:\(dbgId)] initialize SUCCESS adUnit=\(transformed.adUnit) configId=\(transformed.configId)"
        )
    }

    // MARK: - Runtime helpers

    @MainActor
    func getInitialGamRequest() -> AdManagerRequest {
        initialRequest
    }

    @MainActor
    func makeLoadedGamRewardedAd() -> RewardedAd? {
        guard let adUnitData else {
            SLogger.i(
                "[RewardedAdConfiguration:\(dbgId)] makeLoadedGamRewardedAd skipped because adUnitData is nil"
            )
            return nil
        }

        guard let gamRewardedAd else {
            SLogger.i(
                "[RewardedAdConfiguration:\(dbgId)] makeLoadedGamRewardedAd skipped because gamRewardedAd is nil"
            )
            return nil
        }

        SLogger.i(
            "[RewardedAdConfiguration:\(dbgId)] makeLoadedGamRewardedAd SUCCESS adUnit=\(adUnitData.adUnit)"
        )

        return gamRewardedAd
    }

    private func transformAdUnitData(
        configurableAdUnitData: ConfigurableAdUnitData
    ) -> YLAdUnitData {
        YLAdUnitDataTransformer.transformRewardedAdUnitData(
            configurableAdUnitData: configurableAdUnitData
        )
    }

    // MARK: - Cleanup

    @MainActor
    override func destroy() {
        guard !isDestroyed else {
            SLogger.i(
                "[RewardedAdConfiguration:\(dbgId)] destroy skipped because already destroyed"
            )
            return
        }

        SLogger.i("[RewardedAdConfiguration:\(dbgId)] destroy START")

        isDestroyed = true
        gamRewardedAd = nil

        super.destroy()

        SLogger.i("[RewardedAdConfiguration:\(dbgId)] destroy SUCCESS")
    }
}
