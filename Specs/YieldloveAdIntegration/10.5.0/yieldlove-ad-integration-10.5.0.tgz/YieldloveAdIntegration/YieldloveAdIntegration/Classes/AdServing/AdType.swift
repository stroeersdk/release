public enum AdType {
    case banner
    case interstitial
    case rewarded
    
    public var isBannerAd: Bool {
        return self == .banner
    }
}
