//
//  InterstitialController.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 13/04/2026.
//

import Foundation

@MainActor
final class InterstitialController {

    private let interstitialConfiguration: InterstitialAdConfiguration
    private let gamManager: InterstitialGamManager
    private let dbgId = UUID().uuidString.prefix(6)

    init(
        interstitialConfiguration: InterstitialAdConfiguration,
        gamManager: InterstitialGamManager = InterstitialGamManager()
    ) {
        self.interstitialConfiguration = interstitialConfiguration
        self.gamManager = gamManager

        SLogger.i("[InterstitialController:\(dbgId)] init adSlotId=\(interstitialConfiguration.adSlotId)")
    }

    deinit {
        SLogger.i("[InterstitialController:\(dbgId)] deinit adSlotId=\(interstitialConfiguration.adSlotId)")
    }

    func start() {
        IdentityManager.shared.refresh()
        interstitialConfiguration.timeEventRecorder.startSession()

        Task {
            do {
                if interstitialConfiguration.adUnitData == nil {
                    try await interstitialConfiguration.initialize()
                }

                guard let adUnitData = interstitialConfiguration.adUnitData else {
                    throw YLError.adUnitDataWasNotSet
                }

                preloadGravite(adUnitData: adUnitData)
                interstitialConfiguration.timeEventRecorder.recordAdUnitLoaded()

                if GraviteLoader.shared.isDirectGraviteCall() {
                    throw BackFillError.directCallToGravite
                }

                let requestData = try await InterstitialPrebidRenderer(
                    interstitialConfiguration: interstitialConfiguration
                ).load()

                _ = try await gamManager.loadInterstitial(
                    requestData: requestData,
                    interstitialConfiguration: interstitialConfiguration
                )

                if GraviteLoader.shared.isForceToExcute() {
                    throw BackFillError.forceToExecute
                }

                guard let interstitial = interstitialConfiguration.makeLoadedGamInterstitialAd() else {
                    throw InterstitialAdConfigurationError.gamInterstitialAdWasNotSet
                }

                stopSession()
                interstitialConfiguration.publisherDelegate?.onAdLoaded?(
                    interstitial: interstitial
                )
            } catch {
                if let interstitial = getGraviteIfAvailable(for: error) {
                    stopSession()
                    interstitialConfiguration.publisherDelegate?.onAdLoaded?(
                        interstitial: interstitial
                    )
                    return
                }

                stopSession()
                interstitialConfiguration.publisherDelegate?.onAdFailedToLoad?(
                    interstitial: nil,
                    error: error
                )
            }
        }
    }

    private func preloadGravite(adUnitData: YLAdUnitData) {
        guard GraviteLoader.shared.isGraviteStarted() else {
            return
        }

        let graviteConfig = GraviteInterstitialConfig()
        graviteConfig.ylAdUnitData = adUnitData
        graviteConfig.interstitialDelegate = interstitialConfiguration.publisherDelegate
        graviteConfig.viewController = interstitialConfiguration.presenterViewController

        GraviteLoader.shared.getInterstitialLoader()?.loadInterstitial(config: graviteConfig)

        SLogger.i("[InterstitialController:\(dbgId)] preload gravite adUnit=\(adUnitData.adUnit)")
    }

    private func getGraviteIfAvailable(for error: Error) -> YLInterstitialAd? {
        guard error is BackFillError || GraviteLoader.shared.isGraviteStarted() else {
            return nil
        }

        SLogger.i("[Interstitial] Calling backfill : reason - \(error)")

        guard let adUnitData = interstitialConfiguration.adUnitData else {
            return nil
        }

        guard let loader = GraviteLoader.shared.getInterstitialLoader() else {
            SLogger.i("[Interstitial] Interstitial loader is not available")
            return nil
        }

        guard loader.isInterstitialAvailable(ylAdUnitData: adUnitData) else {
            SLogger.i("[Interstitial] Interstitial is not available")
            return nil
        }

        return interstitialConfiguration.makeGraviteInterstitialAd()
    }

    private func stopSession() {
        interstitialConfiguration.timeEventRecorder.stopSession()
    }
}

enum InterstitialAdConfigurationError: Error {
    case gamInterstitialAdWasNotSet
}
