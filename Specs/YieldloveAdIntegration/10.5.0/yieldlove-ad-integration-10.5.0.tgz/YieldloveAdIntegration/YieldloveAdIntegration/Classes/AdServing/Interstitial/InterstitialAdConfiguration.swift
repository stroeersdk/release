//
//  InterstitialAdConfiguration.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 10/04/2026.
//

import Foundation
import UIKit
import GoogleMobileAds

final class InterstitialAdConfiguration: AdConfiguration {

    weak var publisherDelegate: YLInterstitialAdDelegate?

    let timeEventRecorder: TimeEventRecorder
    let initialRequest: AdManagerRequest
    let publisherCustomTargeting: [String: String]

    var gamInterstitialAd: AdManagerInterstitialAd?

    private(set) var isDestroyed = false
    private let dbgId = UUID().uuidString.prefix(6)

    init(
        adSlotId: String,
        config: Config,
        viewController: UIViewController,
        publisherDelegate: YLInterstitialAdDelegate?,
        request: AdManagerRequest,
        timeEventRecorder: TimeEventRecorder? = nil
    ) {
        self.publisherDelegate = publisherDelegate
        self.initialRequest = request
        self.publisherCustomTargeting = request.customTargeting?.compactMapValues { $0 as? String } ?? [:]
        self.timeEventRecorder = timeEventRecorder ?? YLTimeEventRecorder(
            adType: .interstitial
        )

        super.init(
            adSlotId: adSlotId,
            config: config,
            adType: .interstitial,
            viewController: viewController
        )

        SLogger.i("[InterstitialAdConfiguration:\(dbgId)] init adSlotId=\(adSlotId)")
    }

    // MARK: - Initialization

    @MainActor
    func initialize() async throws {
        guard adUnitData == nil else {
            SLogger.i(
                "[InterstitialAdConfiguration:\(dbgId)] initialize skipped because adUnitData already exists"
            )
            return
        }

        SLogger.i(
            "[InterstitialAdConfiguration:\(dbgId)] initialize START adSlotId=\(adSlotId)"
        )

        let configurableAdUnitData: ConfigurableAdUnitData = try await withCheckedThrowingContinuation { continuation in
            config.configurationManager
                .getAdUnitData(publisherAdSlot: adSlotId, adType: .interstitial)
                .done { value in
                    continuation.resume(returning: value)
                }
                .catch { error in
                    continuation.resume(throwing: error)
                }
        }

        let transformed = transformAdUnitData(
            configurableAdUnitData: configurableAdUnitData
        )

        transformed.TCString = YLConsentReader().getTCString()
        transformed.publisherCallString = adSlotId
        adUnitData = transformed

        SLogger.i(
            "[InterstitialAdConfiguration:\(dbgId)] initialize SUCCESS adUnit=\(transformed.adUnit) configId=\(transformed.configId)"
        )
    }

    // MARK: - Runtime helpers

    @MainActor
    func getInitialGamRequest() -> AdManagerRequest {
        initialRequest
    }

    @MainActor
    var presenterViewController: UIViewController? {
        guard !isDestroyed else { return nil }
        return viewController
    }

    @MainActor
    func makeLoadedGamInterstitialAd() -> YLInterstitialAd? {
        guard let adUnitData else {
            SLogger.i(
                "[InterstitialAdConfiguration:\(dbgId)] makeLoadedGamInterstitialAd skipped because adUnitData is nil"
            )
            return nil
        }

        guard let gamInterstitialAd else {
            SLogger.i(
                "[InterstitialAdConfiguration:\(dbgId)] makeLoadedGamInterstitialAd skipped because gamInterstitialAd is nil"
            )
            return nil
        }

        return makeLoadedInterstitialAd(
            adUnitData: adUnitData,
            interstitialAd: gamInterstitialAd
        )
    }

    @MainActor
    func makeGraviteInterstitialAd() -> YLInterstitialAd? {
        guard let adUnitData else {
            SLogger.i(
                "[InterstitialAdConfiguration:\(dbgId)] makeGraviteInterstitialAd skipped because adUnitData is nil"
            )
            return nil
        }

        adUnitData.source = GraviteLoader.shared.getAdSource()

        return makeLoadedInterstitialAd(adUnitData: adUnitData)
    }

    @MainActor
    private func makeLoadedInterstitialAd(
        adUnitData: YLAdUnitData,
        interstitialAd: InterstitialAd? = nil
    ) -> YLInterstitialAd {
        let interstitial: YLInterstitialAd

        if let interstitialAd {
            interstitial = YLInterstitialAd(interstitialAd: interstitialAd)
        } else {
            interstitial = YLInterstitialAd()
        }

        interstitial.adSource = adUnitData.source
        interstitial.ylAdUnitData = adUnitData

        SLogger.i(
            "[InterstitialAdConfiguration:\(dbgId)] makeLoadedInterstitialAd SUCCESS adUnit=\(adUnitData.adUnit)"
        )

        return interstitial
    }

    private func transformAdUnitData(
        configurableAdUnitData: ConfigurableAdUnitData
    ) -> YLAdUnitData {
        YLAdUnitDataTransformer.transformInterstitialAdUnitData(
            configurableAdUnitData: configurableAdUnitData
        )
    }

    // MARK: - Cleanup

    @MainActor
    override func destroy() {
        guard !isDestroyed else {
            SLogger.i(
                "[InterstitialAdConfiguration:\(dbgId)] destroy skipped because already destroyed"
            )
            return
        }

        SLogger.i("[InterstitialAdConfiguration:\(dbgId)] destroy START")

        isDestroyed = true

        gamInterstitialAd = nil
        publisherDelegate = nil

        super.destroy()

        SLogger.i("[InterstitialAdConfiguration:\(dbgId)] destroy SUCCESS")
    }
}
