//
//  BannerController.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 02/04/2026.
//

import Foundation
import UIKit
import GoogleMobileAds
import PrebidMobile

final class BannerController: RefreshTimerDelegate {

    let bannerConfiguration: BannerAdConfiguration
    private let graviteHelper = BannerGraviteHelper()
    private let gamManager: BannerGamManager

    private weak var currentView: UIView?
    private var cancelCurrentLoad: (() -> Void)?
    private var requestTask: Task<Void, Never>?
    private var isDestroyed = false
    private var isLoading = false
    private var skipRecordingMonitoringEvents = false

    private let dbgId = UUID().uuidString.prefix(6)

    @MainActor
    init(
        bannerConfiguration: BannerAdConfiguration,
        gamManager: BannerGamManager = BannerGamManager()
    ) {
        self.bannerConfiguration = bannerConfiguration
        self.gamManager = gamManager

        SLogger.i(
            "[BannerController:\(dbgId)] init adSlotId=\(bannerConfiguration.adSlotId)"
        )
    }

    // MARK: - Public

    @MainActor
    func start() {
        IdentityManager.shared.refresh()
        bannerConfiguration.timeEventRecorder.startSession()
        beginLoad(isRefresh: false)
    }

    @MainActor
    func refresh() {
        beginLoad(isRefresh: true)
    }

    @MainActor
    func refreshFromHost() {
        refresh()
    }

    @MainActor
    func reloadCurrentAd() {
        beginLoad(isRefresh: false)
    }

    @MainActor
    func setCurrentLoadCancellation(_ cancel: (() -> Void)?) {
        cancelCurrentLoad = cancel
    }

    @MainActor
    func startDebugSessionIfNeeded() {
        if ConfigurationManager.isInspectionMode(), let adUnitId = bannerConfiguration.adUnitData?.adUnit {
            if(bannerConfiguration.debugRecord == nil){
                bannerConfiguration.debugRecord = DebugSessionManager.shared.startSession(for: adUnitId)
            }
            ConsoleLogStore.shared.startIfNeeded()
        }
    }

    func markDisplayedBannerView(_ view: UIView) {
        currentView = view
        ConfiantLoader.shared.mark(adReloader: self)
    }

    @MainActor
    func destroy() {
        guard !isDestroyed else { return }
        isDestroyed = true
        cancelManagedWork()
        if let adUnitId = bannerConfiguration.adUnitData?.adUnit {
            DebugSessionManager.shared.clearSession(for: adUnitId)
        }
        bannerConfiguration.destroy()
        SLogger.i(
            "[BannerController:\(dbgId)] destroy SUCCESS, adSlotId=\(bannerConfiguration.adSlotId)"
        )
    }

    deinit {
        SLogger.i("[BannerController:\(dbgId)] deinit adSlot=\(bannerConfiguration.adSlotId)")
    }

    // MARK: - Managed task control

    @MainActor
    private func beginLoad(isRefresh: Bool) {
        guard !isDestroyed else { return }

        guard !isLoading else {
            SLogger.e(
                "[BannerController:\(dbgId)] \(isRefresh ? "Refresh" : "Load") ignored, because request is already loading. adSlot=\(bannerConfiguration.adSlotId)"
            )
            return
        }

        bannerConfiguration.publisherDelegate?.bannerViewDidStartLoadingAd?()

        startManagedFlow(
            needsInitialization: bannerConfiguration.adUnitData == nil,
            isRefresh: isRefresh
        )
    }

    @MainActor
    private func startManagedFlow(
        needsInitialization: Bool,
        isRefresh: Bool
    ) {
        cancelManagedWork()
        isLoading = true

        requestTask = Task { @MainActor [weak self] in
            guard let self else { return }

            defer {
                self.isLoading = false
                self.requestTask = nil
            }

            do {
                if needsInitialization {
                    try await self.bannerConfiguration.initialize()
                }

                guard !Task.isCancelled else { return }
                guard !self.isDestroyed else { return }

                self.startDebugSessionIfNeeded()
                try await self.performRequest(isRefresh: isRefresh)
            } catch {
                self.handleError(error: error, wasRefreshed: isRefresh)
            }
        }
    }

    @MainActor
    private func cancelManagedWork() {
        requestTask?.cancel()
        requestTask = nil

        cancelCurrentLoad?()
        cancelCurrentLoad = nil

        isLoading = false
    }

    // MARK: - Request flow

    @MainActor
    private func performRequest(isRefresh: Bool) async throws {
        guard !isDestroyed else { return }
        guard !Task.isCancelled else { return }

        skipRecordingMonitoringEvents = isRefresh

        graviteHelper.preloadIfNeeded(
            bannerConfiguration: bannerConfiguration,
            firstBannerLoaded: self
        )

        recordAdUnitLoaded()

        if GraviteLoader.shared.isDirectGraviteCall() {
            throw BackFillError.directCallToGravite
        }

        let prebidRenderer = BannerPrebidRenderer(
            bannerConfiguration: bannerConfiguration
        )

        setCurrentLoadCancellation { [weak prebidRenderer] in
            prebidRenderer?.cancel()
        }

        let renderResult = try await prebidRenderer.load()
        setCurrentLoadCancellation(nil)

        guard !Task.isCancelled else { return }
        guard !isDestroyed else { return }

        switch renderResult {
        case .prebid(let view):
            try bannerConfiguration.installPrebidDirect(
                view,
                wasRefreshed: isRefresh
            )

            let wrapperView = try bannerConfiguration.currentWrapperViewOrThrow()
            try finalizeInstalledBanner(wrapperView)

        case .gam(let requestData):
            let currentWrapperView = try bannerConfiguration.currentWrapperViewOrThrow()
            let loadedGamBanner: BannerLoadedGamBanner

            if isRefresh,
               currentWrapperView.getBannerView() is AdManagerBannerView {
                loadedGamBanner = try await gamManager.refreshBanner(
                    requestData: requestData,
                    controller: self,
                    wrapperView: currentWrapperView,
                    existingDelegate: bannerConfiguration.gamBannerDelegate
                )
            } else {
                loadedGamBanner = try await gamManager.loadBanner(
                    requestData: requestData,
                    controller: self
                )
            }

            setCurrentLoadCancellation(nil)

            guard !Task.isCancelled else { return }
            guard !isDestroyed else { return }

            try bannerConfiguration.installGam(
                loadedGamBanner,
                wasRefreshed: isRefresh
            )

            let installedWrapperView = try bannerConfiguration.currentWrapperViewOrThrow()
            try await finalizeInstalledGamBanner(installedWrapperView)
        }
    }

    private func recordAdUnitLoaded() {
        if !skipRecordingMonitoringEvents {
            bannerConfiguration.timeEventRecorder.recordAdUnitLoaded()
        }
    }

    // MARK: - Success finalization

    @MainActor
    private func finalizeInstalledBanner(_ wrapperView: YLBannerView) throws {
        decorateWrapperAfterInstall(wrapperView)
        passBannerToPublisher(wrapperView)
        startRefreshTimerIfNeeded(wrapper: wrapperView)
    }

    @MainActor
    private func finalizeInstalledGamBanner(_ wrapperView: YLBannerView) async throws {
        await finalizeBannerBeforePublisherCallback(wrapperView)
        try finalizeInstalledBanner(wrapperView)
    }

    // MARK: - Publisher callbacks

    @MainActor
    private func passBannerToPublisher(_ wrapperView: YLBannerView) {
        bannerConfiguration.publisherDelegate?.bannerViewDidReceiveAd?(wrapperView)
    }

    @MainActor
    private func handleError(
        error: Error,
        wasRefreshed: Bool
    ) {
        if isCancellationLifecycleError(error) {
            return
        }

        if graviteHelper.requestFallback(
            error: error,
            bannerConfiguration: bannerConfiguration,
            wasRefreshed: wasRefreshed
        ) {
            if let wrapper = bannerConfiguration.wrapperView {
                startRefreshTimerIfNeeded(wrapper: wrapper)
            }
            return
        }

        if let wrapper = bannerConfiguration.wrapperView {
            bannerConfiguration.publisherDelegate?.bannerView?(
                wrapper,
                didFailToReceiveAdWithError: error
            )
        }

    }

    private func isCancellationLifecycleError(_ error: Error) -> Bool {
        if case BannerRequestLifecycleError.cancelled = error {
            return true
        }
        if case BannerRequestLifecycleError.destroyed = error {
            return true
        }
        if error is CancellationError {
            return true
        }
        return false
    }

    private func isErrorPartOfNormalOperation(_ error: Error) -> Bool {
        if case YLError.errorWasReportedByDelegate = error {
            return true
        }
        if isCancellationLifecycleError(error) {
            return true
        }
        return false
    }

    // MARK: - Debug decoration

    @MainActor
    private func decorateWrapperAfterInstall(_ wrapperView: YLBannerView) {
        guard let adUnitData = bannerConfiguration.adUnitData else { return }

        if ConfigurationManager.isInspectionMode() {
            let servedInTime = bannerConfiguration.timeEventRecorder.session.getServedInTime()

            let debugInfo = DebugInfoForStroeer(
                ConfigurationManager.shared.getAppName() ?? "unknown",
                adUnitData,
                servedInTime
            )

            let sessionToPresent = bannerConfiguration.debugRecord
            let consoleStore = ConsoleLogStore.shared

            let label = DebugInfoLabelView()
            label.buildLabel(adUnitData.publisherCallString, .banner, servedInTime) {
                DispatchQueue.main.async {
                    let presenter = self.bannerConfiguration.presenterViewController
                    guard let presenter else {
                        SLogger.e("[DebugLabel] No presenter VC available to show debug panel.")
                        return
                    }

                    if let sessionToPresent {
                        let panel = DebugLoggerViewController(
                            session: sessionToPresent,
                            consoleStore: consoleStore
                        )
                        presenter.present(panel, animated: true)
                    } else {
                        let panel = DebugInfoPanelViewController(debugInfo)
                        presenter.present(panel, animated: true)
                    }
                }
            }

            wrapperView.createDebugLabelView(debugView: label)
        } else {
            wrapperView.addInspectionGestureRecognizer()
        }
    }

    // MARK: - Refresh timer

    @MainActor
    private func startRefreshTimerIfNeeded(wrapper: YLBannerView) {
        guard !bannerConfiguration.didStartRefreshTimer else { return }

        guard let autoRefreshTimeMs = bannerConfiguration.refreshTimeMs else {
            return
        }

        bannerConfiguration.didStartRefreshTimer = true

        let timer = bannerConfiguration.config.refreshTimerFactory.makeTimer(
            autoRefreshTimeMs: autoRefreshTimeMs,
            delegate: self,
            wrapperView: wrapper
        )

        bannerConfiguration.refreshTimer = timer
        timer.start()
    }

    // MARK: - GAM resize finalize

    @MainActor
    private func finalizeBannerBeforePublisherCallback(_ wrapperView: YLBannerView) async {
        guard let bannerAd = wrapperView.getBannerView() as? AdManagerBannerView else {
            return
        }

        do {
            let winner = try await withCheckedThrowingContinuation { continuation in
                AdWinnerAnalyzer.instance.getWinner(ylBannerView: wrapperView)
                    .done { continuation.resume(returning: $0) }
                    .catch { continuation.resume(throwing: $0) }
            }

            if !skipRecordingMonitoringEvents {
                bannerConfiguration.timeEventRecorder.recordAdAnalyzed(
                    winner: winner.rawValue
                )
            }

            guard !isDestroyed else { return }
            guard !Task.isCancelled else { return }

            if winner == .Prebid,
               wrapperView.getSource().adSubSource == AdSource.STROEER,
               let prebidSize = wrapperView.bannerInfo.prebidAdSize,
               prebidSize != .zero {
                let newAdSize = adSizeFor(cgSize: prebidSize)
                bannerAd.resize(newAdSize)
                bannerAd.adSize = newAdSize
                wrapperView.updateSize(to: prebidSize)
                wrapperView.layoutIfNeeded()
                wrapperView.superview?.setNeedsLayout()
                wrapperView.superview?.layoutIfNeeded()
            }
        } catch {
            // ignore resize analysis failure
        }
    }
}

extension BannerController: IAdReloader {

    func getView() -> UIView {
        currentView ?? UIView()
    }

    func getAdSlot() -> String {
        bannerConfiguration.adSlotId
    }

    func reloadAd(slotView: UIView, placementId: String) {
        Task { @MainActor in
            self.reloadCurrentAd()
        }
    }
}

extension BannerController: IFirstBannerLoaded {
    func onFirstBannerLoaded() {
        Task { @MainActor [weak self] in
            guard let self else { return }
            guard !self.isDestroyed else { return }
            guard let wrapperView = self.bannerConfiguration.wrapperView else { return }

            guard wrapperView.getBannerView() == nil else { return }

            let rendered = self.graviteHelper.renderIfAvailable(
                bannerConfiguration: self.bannerConfiguration,
                wasRefreshed: false
            )

            if rendered {
                self.startRefreshTimerIfNeeded(wrapper: wrapperView)
            }
        }
    }
}
