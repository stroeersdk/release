//
//  BannerAdConfiguration.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 01/04/2026.
//


import Foundation
import UIKit
import GoogleMobileAds

final class BannerAdConfiguration: AdConfiguration {

    weak var publisherDelegate: YLBannerViewDelegate?
    weak var wrapperView: YLBannerView?
    var debugSessionId: String?

    let timeEventRecorder: TimeEventRecorder

    // MARK: - Live displayed runtime only
    var gamBannerView: AdManagerBannerView?
    var gamBannerDelegate: BannerGamDelegate?

    var prebidDirectView: UIView?
    var graviteView: UIView?

    // MARK: - Refresh runtime
    var refreshTimer: RefreshTimer?
    var refreshTimeMs: Int?
    var didStartRefreshTimer = false

    var isRefreshable: Bool {
        refreshTimeMs != nil
    }

    // MARK: - Lifecycle
    private(set) var isDestroyed = false
    private let dbgId = UUID().uuidString.prefix(6)

    init(
        adSlotId: String,
        config: Config,
        viewController: UIViewController,
        publisherDelegate: YLBannerViewDelegate,
        wrapperView: YLBannerView,
        timeEventRecorder: TimeEventRecorder? = nil
    ) {
        self.publisherDelegate = publisherDelegate
        self.wrapperView = wrapperView
        self.timeEventRecorder = timeEventRecorder ?? YLTimeEventRecorder(adType: .banner)

        super.init(
            adSlotId: adSlotId,
            config: config,
            adType: .banner,
            viewController: viewController
        )

        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] init, adSlotId=\(adSlotId)"
        )
    }

    // MARK: - Initialization
    @MainActor
    func initialize() async throws {
        guard adUnitData == nil else {
            SLogger.i("[BannerAdConfiguration:\(dbgId)] initialize skipped because adUnitData already exists")
            return
        }

        SLogger.i("[BannerAdConfiguration:\(dbgId)] initialize START adSlotId=\(adSlotId)")

        let configurableAdUnitData: ConfigurableAdUnitData = try await withCheckedThrowingContinuation { continuation in
            config.configurationManager
                .getAdUnitData(publisherAdSlot: adSlotId, adType: .banner)
                .done { value in
                    continuation.resume(returning: value)
                }
                .catch { error in
                    continuation.resume(throwing: error)
                }
        }

        let transformed = try transformAdUnitData(
            configurableAdUnitData: configurableAdUnitData
        )

        transformed.TCString = YLConsentReader().getTCString()
        transformed.publisherCallString = adSlotId
        adUnitData = transformed
        refreshTimeMs = transformed.autoRefreshTimeMs

        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] initialize SUCCESS, adUnit=\(transformed.adUnit) configId=\(transformed.configId) refreshTimeMs=\(String(describing: refreshTimeMs))"
        )
    }

    // MARK: - Runtime access helpers
    func publisherGamRequest() -> AdManagerRequest {
        SLogger.i("[BannerAdConfiguration:\(dbgId)] publisherGamRequest")
        return publisherDelegate?.getGAMRequest?() ?? AdManagerRequest()
    }

    @MainActor
    func currentWrapperViewOrThrow() throws -> YLBannerView {
        guard !isDestroyed, let wrapperView = wrapperView else {
            SLogger.e(
                "[BannerAdConfiguration:\(dbgId)] currentWrapperViewOrThrow FAILED, isDestroyed=\(isDestroyed) wrapperView_nil=\(wrapperView == nil)"
            )
            throw BannerRequestLifecycleError.destroyed
        }
        return wrapperView
    }

    @MainActor
    var presenterViewController: UIViewController? {
        guard !isDestroyed else { return nil }
        return viewController
    }

    // MARK: - WrapperView sync
    @MainActor
    func applyBannerInfoToWrapperView(wasRefreshed: Bool = false) throws {
        let wrapperView = try currentWrapperViewOrThrow()

        if let adUnitData {
            adUnitData.wasRefreshed = wasRefreshed
            wrapperView.bannerInfo = adUnitData

            SLogger.i(
                "[BannerAdConfiguration:\(dbgId)] applyBannerInfoToWrapperView, adUnit=\(adUnitData.adUnit) configId=\(adUnitData.configId) wasRefreshed=\(wasRefreshed)"
            )
        } else {
            SLogger.i("[BannerAdConfiguration:\(dbgId)] applyBannerInfoToWrapperView skipped because adUnitData is nil")
        }
    }

    // MARK: - Install display
    @MainActor
    func installPrebidDirect(
        _ view: UIView,
        wasRefreshed: Bool
    ) throws {
        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] installPrebidDirect START, wasRefreshed=\(wasRefreshed)"
        )

        try validateInstallRequest()
        try applyBannerInfoToWrapperView(wasRefreshed: wasRefreshed)

        let wrapperView = try currentWrapperViewOrThrow()

        clearGamDisplayState()
        clearGraviteDisplayState()

        if let currentPrebidView = prebidDirectView,
           currentPrebidView !== view {
            clearPrebidDisplayState()
        }

        if wrapperView.getBannerView() !== view {
            wrapperView.setBannerView(bannerView: view)
        }

        let resolvedSize = resolvedViewSize(for: view)
        wrapperView.updateSize(to: resolvedSize)
        prebidDirectView = view

        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] installPrebidDirect SUCCESS, size=\(Int(resolvedSize.width))x\(Int(resolvedSize.height))"
        )
    }

    @MainActor
    func installGam(
        _ loadedBanner: BannerLoadedGamBanner,
        wasRefreshed: Bool
    ) throws {
        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] installGam managed START, wasRefreshed=\(wasRefreshed)"
        )

        try validateInstallRequest()
        try applyBannerInfoToWrapperView(wasRefreshed: wasRefreshed)

        let wrapperView = try currentWrapperViewOrThrow()

        clearPrebidDisplayState()
        clearGraviteDisplayState()

        if let currentLiveGam = gamBannerView,
           currentLiveGam !== loadedBanner.bannerView {
            clearGamDisplayState()
        }

        if wrapperView.getBannerView() !== loadedBanner.bannerView {
            wrapperView.setBannerView(bannerView: loadedBanner.bannerView)
        }

        loadedBanner.bannerDelegate.bannerConfiguration = self
        loadedBanner.bannerView.rootViewController = presenterViewController
        loadedBanner.bannerView.delegate = loadedBanner.bannerDelegate

        wrapperView.updateSize(to: loadedBanner.bannerView.adSize.size)

        gamBannerView = loadedBanner.bannerView
        gamBannerDelegate = loadedBanner.bannerDelegate

        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] installGam managed SUCCESS, size=\(Int(loadedBanner.bannerView.adSize.size.width))x\(Int(loadedBanner.bannerView.adSize.size.height))"
        )
    }

    @MainActor
    func installGravite(
        _ view: UIView,
        wasRefreshed: Bool
    ) throws {
        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] installGravite START, wasRefreshed=\(wasRefreshed)"
        )

        try validateInstallRequest()
        try applyBannerInfoToWrapperView(wasRefreshed: wasRefreshed)

        let wrapperView = try currentWrapperViewOrThrow()

        clearGamDisplayState()
        clearPrebidDisplayState()

        if let currentGraviteView = graviteView,
           currentGraviteView !== view {
            clearGraviteDisplayState()
        }

        if wrapperView.getBannerView() !== view {
            wrapperView.setBannerView(bannerView: view)
        }

        let resolvedSize = resolvedViewSize(for: view)
        wrapperView.updateSize(to: resolvedSize)
        graviteView = view

        SLogger.i(
            "[BannerAdConfiguration:\(dbgId)] installGravite SUCCESS, size=\(Int(resolvedSize.width))x\(Int(resolvedSize.height))"
        )
    }

    @MainActor
    private func validateInstallRequest() throws {
        guard !isDestroyed else {
            SLogger.e("[BannerAdConfiguration:\(dbgId)] validateInstallRequest FAILED because configuration is destroyed")
            throw BannerRequestLifecycleError.destroyed
        }

        guard wrapperView != nil else {
            SLogger.e("[BannerAdConfiguration:\(dbgId)] validateInstallRequest FAILED because wrapperView is nil")
            throw BannerRequestLifecycleError.destroyed
        }
    }

    // MARK: - Cleanup

    @MainActor
    private func clearGamDisplayState() {
        if gamBannerView != nil || gamBannerDelegate != nil {
            SLogger.i("[BannerAdConfiguration:\(dbgId)] clearGamDisplayState")
        }

        gamBannerDelegate?.cancelInFlightRequest()
        gamBannerDelegate?.bannerConfiguration = nil

        if let bannerView = gamBannerView {
            bannerView.delegate = nil
            bannerView.rootViewController = nil
        }

        gamBannerDelegate = nil
        gamBannerView = nil
    }

    @MainActor
    private func clearPrebidDisplayState() {
        if prebidDirectView != nil {
            SLogger.i("[BannerAdConfiguration:\(dbgId)] clearPrebidDisplayState")
        }
        prebidDirectView = nil
    }

    @MainActor
    private func clearGraviteDisplayState() {
        if graviteView != nil {
            SLogger.i("[BannerAdConfiguration:\(dbgId)] clearGraviteDisplayState")
        }
        graviteView = nil
    }

    @MainActor
    private func clearAllDisplayState() {
        SLogger.i("[BannerAdConfiguration:\(dbgId)] clearAllDisplayState")
        clearPrebidDisplayState()
        clearGamDisplayState()
        clearGraviteDisplayState()
    }

    private func transformAdUnitData(
        configurableAdUnitData: ConfigurableAdUnitData
    ) throws -> YLAdUnitData {
        try YLAdUnitDataTransformer.transformBannerAdUnitData(
            configurableAdUnitData: configurableAdUnitData
        )
    }

    private func resolvedViewSize(for view: UIView) -> CGSize {
        let intrinsic = sanitize(view.intrinsicContentSize)
        if intrinsic.width > 0 || intrinsic.height > 0 {
            return intrinsic
        }

        let bounds = sanitize(view.bounds.size)
        if bounds.width > 0 || bounds.height > 0 {
            return bounds
        }

        let frame = sanitize(view.frame.size)
        if frame.width > 0 || frame.height > 0 {
            return frame
        }

        return .zero
    }

    private func sanitize(_ size: CGSize) -> CGSize {
        CGSize(
            width: max(0, size.width.isFinite ? size.width : 0),
            height: max(0, size.height.isFinite ? size.height : 0)
        )
    }

    @MainActor
    override func destroy() {
        guard !isDestroyed else {
            SLogger.i("[BannerAdConfiguration:\(dbgId)] destroy skipped because already destroyed")
            return
        }

        SLogger.i("[BannerAdConfiguration:\(dbgId)] destroy START")

        isDestroyed = true
        
        timeEventRecorder.stopSession()
        refreshTimer?.stop()
        refreshTimer = nil
        refreshTimeMs = nil
        didStartRefreshTimer = false

        clearAllDisplayState()

        publisherDelegate = nil
        wrapperView = nil
        debugSessionId = nil

        super.destroy()

        SLogger.i("[BannerAdConfiguration:\(dbgId)] destroy SUCCESS")
    }
}
