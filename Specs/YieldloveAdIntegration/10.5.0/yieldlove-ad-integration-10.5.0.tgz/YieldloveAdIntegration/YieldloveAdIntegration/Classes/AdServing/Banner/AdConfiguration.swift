//
//  AAdConfiguration.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 01/04/2026.
//

import Foundation
import UIKit

class AdConfiguration {

    let adSlotId: String
    let config: Config
    let adType: AdType

    weak var viewController: UIViewController?
    var adUnitData: YLAdUnitData?
    var debugRecord: BannerDebugRecord?

    init(
        adSlotId: String,
        config: Config,
        adType: AdType,
        viewController: UIViewController?
    ) {
        self.adSlotId = adSlotId
        self.config = config
        self.adType = adType
        self.viewController = viewController
    }

    @MainActor
    func destroy() {
        debugRecord = nil
        adUnitData = nil
        viewController = nil
    }
}
