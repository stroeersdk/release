import Foundation
import GoogleMobileAds
import PrebidMobile
import PromiseKit


class YLAd {
    
    let config: Config
    let adType: AdType
    let timeEventRecorder: TimeEventRecorder
    let bidAdapterFactory: BidAdapterFactory
    let gamAdLoader: GamAdLoader
    var publisherCallString: String?
    
    private(set) var mergedGamRequest: AdManagerRequest
    var ylAdUnitData: YLAdUnitData?
    var adSource : AdSourceInfo = AdSourceInfo.getDefaultAdSource()

    init(config: Config, adType: AdType, gamRequest: AdManagerRequest, timeEventRecorder: TimeEventRecorder?) {
        self.config = config
        self.adType = adType
        self.timeEventRecorder = timeEventRecorder ?? YLTimeEventRecorder(adType: adType)
        self.mergedGamRequest = YLGamRequestMerger.merge(gamRequest, GlobalGamManager.adRequest)
        self.gamAdLoader = config.gamAdLoader
        self.bidAdapterFactory = YLBidAdapterFactory(prebidAdUnitFactory: config.prebidAdUnitFactory)
        self.timeEventRecorder.startSession()
        
        IdentityManager.shared.refresh()
    }

    func stopSession() {
        timeEventRecorder.stopSession()
    }

    func getConfigurableAdUnitData(publisherAdSlot: String) -> Promise<ConfigurableAdUnitData> {
        return config.configurationManager.getAdUnitData(publisherAdSlot: publisherAdSlot, adType: adType)
    }

    func getAdUnitData() throws -> YLAdUnitData {
        if let ylAdUnitData = self.ylAdUnitData {
            return ylAdUnitData
        } else {
            throw YLError.adUnitDataWasNotSet
        }
    }

    func setAdUnitData(adUnitData: YLAdUnitData) {
        self.ylAdUnitData = adUnitData
        self.ylAdUnitData?.publisherCallString = publisherCallString
    }

    func collectBids() throws -> Promise<Void> {
        if GraviteLoader.shared.isDirectGraviteCall() {
            throw BackFillError.directCallToGravite
        }
        
        let ylAdUnitData = try getAdUnitData()
        let bidsTuple = (mergedGamRequest, ylAdUnitData) as BidTuple
        let adapters = bidAdapterFactory.makeBidAdapters(bidTuple: bidsTuple)
        config.bidCollector.connectBidAdapters(adapters: adapters)
        return requestBids(bidsTuple: bidsTuple)
                .done { bidsResult in
                    self.ylAdUnitData = bidsResult.adUnitData
                    self.mergedGamRequest = bidsResult.request
                }
    }
    
    func applyTargeting() throws {
        try applyPrebidTargeting()
        try applyAdManagerTargeting()
    }
    
    private func requestBids(bidsTuple: BidTuple) -> Promise<BidTuple> {
        IdentityManager.shared.setUserIdToPrebid()
        
        // Not used
//        if skipRecordingMonitoringEvents {
//            return config.bidCollector.collectBids(bidTuple: bidsTuple, adType: adType, timeEventRecorder: nil)
//        }
        return config.bidCollector.collectBids(bidTuple: bidsTuple, adType: adType, timeEventRecorder: timeEventRecorder)
    }

    func applyAdManagerTargeting() throws {
        let ylAdUnitData = try getAdUnitData()
        let finalRequest = YLGamRequestMerger.mergeInto(request: mergedGamRequest, keyValues: ylAdUnitData.keyValueTargeting, adUnit: ylAdUnitData.adUnit)
        finalRequest.customTargeting?[YLConstants.sdkVersionNumberKey] = YLConstants.version
        mergedGamRequest = finalRequest
    }
    
    private func applyPrebidTargeting() throws {
        let ylAdUnitData = try getAdUnitData()
        Targeting.shared.storeURL = ylAdUnitData.storeUrl
        Targeting.shared.itunesID = ylAdUnitData.itunesID
        Targeting.shared.addAppExtData(key: YLConstants.sdkVersionNumberKey, value: YLConstants.version)
        Targeting.shared.omidPartnerName = YLConstants.omidPartnerName
        Targeting.shared.omidPartnerVersion = YLConstants.omidPartnerVersion
    }
    
    public func getAdSource() -> AdSourceInfo {
        return adSource;
    }    
}

