//
//  RewardedController.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 21/04/2026.
//

import GoogleMobileAds

@MainActor
final class RewardedController {

    private let rewardedConfiguration: RewardedAdConfiguration
    private let gamManager: RewardedGamManager
    private let dbgId = UUID().uuidString.prefix(6)

    init(
        rewardedConfiguration: RewardedAdConfiguration,
        gamManager: RewardedGamManager = RewardedGamManager()
    ) {
        self.rewardedConfiguration = rewardedConfiguration
        self.gamManager = gamManager

        SLogger.i("[RewardedController:\(dbgId)] init adSlotId=\(rewardedConfiguration.adSlotId)")
    }

    deinit {
        SLogger.i("[RewardedController:\(dbgId)] deinit adSlotId=\(rewardedConfiguration.adSlotId)")
    }

    func start() {
        IdentityManager.shared.refresh()
        rewardedConfiguration.timeEventRecorder.startSession()

        Task {
            let result: Result<RewardedAd, Error>

            do {
                if rewardedConfiguration.adUnitData == nil {
                    try await rewardedConfiguration.initialize()
                }

                guard let adUnitData = rewardedConfiguration.adUnitData else {
                    throw YLError.adUnitDataWasNotSet
                }

                rewardedConfiguration.timeEventRecorder.recordAdUnitLoaded()

                let requestData = RewardedGamRequestData(
                    adUnitData: adUnitData,
                    gamRequest: rewardedConfiguration.getInitialGamRequest()
                )

                _ = try await gamManager.loadRewarded(
                    requestData: requestData,
                    rewardedConfiguration: rewardedConfiguration
                )

                guard let rewardedAd = rewardedConfiguration.makeLoadedGamRewardedAd() else {
                    throw RewardedAdConfigurationError.gamRewardedAdWasNotSet
                }

                result = .success(rewardedAd)
            } catch {
                result = .failure(error)
            }

            stopSession()

            switch result {
            case .success(let rewardedAd):
                rewardedConfiguration.completion(rewardedAd, nil)

            case .failure(let error):
                rewardedConfiguration.completion(nil, error)
            }
        }
    }

    private func stopSession() {
        rewardedConfiguration.timeEventRecorder.stopSession()
    }
}

enum RewardedAdConfigurationError: Error {
    case gamRewardedAdWasNotSet
}
