//
//  BannerGraviteHelper.swift
//  Pods
//
//  Created by Shafee Rehman on 18/03/2026.
//


import Foundation
import UIKit

final class BannerGraviteHelper {

    func preloadIfNeeded(
        bannerConfiguration: BannerAdConfiguration,
        firstBannerLoaded: IFirstBannerLoaded?
    ) {
        guard let adUnitData = bannerConfiguration.adUnitData else {
            return
        }

        let config = GraviteBannerConfig()
        config.loaded = firstBannerLoaded
        config.viewController = bannerConfiguration.viewController
        config.ylAdUnitData = adUnitData

        GraviteLoader.shared.getBannerLoader()?.loadBanner(config: config)
    }

    @MainActor
    func requestFallback(
        error: Error,
        bannerConfiguration: BannerAdConfiguration,
        wasRefreshed: Bool
    ) -> Bool {
        guard error is BackFillError || GraviteLoader.shared.isGraviteStarted() else {
            return false
        }

        return renderIfAvailable(
            bannerConfiguration: bannerConfiguration,
            wasRefreshed: wasRefreshed
        )
    }

    @MainActor
    @discardableResult
    func renderIfAvailable(
        bannerConfiguration: BannerAdConfiguration,
        wasRefreshed: Bool
    ) -> Bool {
        guard let adUnitData = bannerConfiguration.adUnitData,
              let adView = GraviteLoader.shared
                .getBannerLoader()?
                .getBanner(
                    ylAdUnitData: adUnitData,
                    adContainerView: bannerConfiguration.viewController?.view ?? UIView()
                ) else {
            return false
        }

        adUnitData.source = GraviteLoader.shared.getAdSource()

        do {
            try bannerConfiguration.installGravite(
                adView,
                wasRefreshed: wasRefreshed
            )

            guard let wrapper = bannerConfiguration.wrapperView else {
                return false
            }

            decorateDisplayedWrapper(
                wrapper,
                bannerConfiguration: bannerConfiguration
            )

            bannerConfiguration.publisherDelegate?.bannerViewDidReceiveAd?(wrapper)
            return true

        } catch {
            return false
        }
    }

    @MainActor
    func decorateDisplayedWrapper(
        _ wrapperView: YLBannerView,
        bannerConfiguration: BannerAdConfiguration
    ) {
        guard let adUnitData = bannerConfiguration.adUnitData else { return }

        if ConfigurationManager.isInspectionMode() {
            let label = DebugInfoLabelView()
            label.buildLabel(
                adUnitData.publisherCallString,
                .banner,
                GraviteLoader.shared.getDebugInfo()?.getServedInTime() ?? 0
            ) { 
                DispatchQueue.main.async {
                    let presenter = bannerConfiguration.presenterViewController
                    guard let presenter else {
                        SLogger.e("[DebugLabel] No presenter VC available to show debug panel.")
                        return
                    }

                    guard let info = GraviteLoader.shared.getDebugInfo() else {
                        SLogger.e("[DebugLabel] Gravite debug info missing.")
                        return
                    }

                    let panel = DebugInfoPanelViewController(info)
                    presenter.present(panel, animated: true)
                }
            }

            wrapperView.createDebugLabelView(debugView: label)
        } else {
            wrapperView.addInspectionGestureRecognizer()
        }
    }
}
