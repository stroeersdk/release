//
//  BannerRequestLifecycleError.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 01/04/2026.
//


import Foundation

enum BannerRequestLifecycleError: Error {
    case cancelled
    case destroyed
}
