enum ConfigurationManagerError: LocalizedError {
    case unableToFetchConfig
    case askedToWriteNilConfig
    case appNameEmpty
    case parseFailed
    case refreshCooldown

    var errorDescription: String{
        switch self {
        case .unableToFetchConfig:
            return "Unable to fetch configuration"
        case .askedToWriteNilConfig:
            return "Asked to write nil configuration"
        case .appNameEmpty:
            return "appName cannot be empty"
        case .parseFailed:
            return "Failed to parse configuration"
        case .refreshCooldown:
            return "Refresh called before cooldown"
        }
    }
}
