import PromiseKit

class ConfigurationUpdater {
    
    let fetcher: ConfigFetcher
    let configDao: ConfigDao
    let timestampDao: ConfigTimestampDao

    init(fetcher: ConfigFetcher,
         configDao: ConfigDao,
         timestampDao: ConfigTimestampDao) {
        self.fetcher = fetcher
        self.configDao = configDao
        self.timestampDao = timestampDao
    }
    
    public func updateConfig() -> Promise<String> {
        firstly {
            getConfigUrl()
        }.then { (url: String) in
            self.fetcher.fetch(url: url)
        }.then { (fetchedConfig: String?) in
            self.writeConfig(configJSON: fetchedConfig)
        }
    }
    
    private func getConfigUrl() -> Promise<String> {
        return Promise { seal in
            if let appName = ExternalConfigurationManagerBuilder.instance.appName {
                let url = ConfigConstants.shared.getConfigUrl().replacingOccurrences(
                    of: ConfigConstants.shared.getApplicationNamePlaceholder(),
                    with: appName)
                seal.fulfill(url)
            } else {
                seal.reject(ConfigurationParsingError.undefinedAppName)
            }
        }
    }
    
    private func writeConfig(configJSON: String?) -> Promise<String> {
        return Promise { seal in
            if let safeConfigJSON = configJSON {
                self.configDao.write(configJSON: safeConfigJSON)
                self.timestampDao.write(timestamp: self.getNowTime())
                seal.fulfill(safeConfigJSON)
            } else {
                seal.reject(ConfigurationManagerError.askedToWriteNilConfig)
            }
        }
    }
    
    private func getNowTime() -> Int {
        Int(Date().timeIntervalSince1970 * 1000)
    }
    
}
