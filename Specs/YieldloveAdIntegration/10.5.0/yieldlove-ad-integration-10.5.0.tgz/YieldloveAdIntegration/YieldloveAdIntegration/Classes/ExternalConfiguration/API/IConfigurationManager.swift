import PromiseKit

public protocol IConfigurationManager {

    func getAdUnitData(publisherAdSlot: String, adType: AdType) -> Promise<ConfigurableAdUnitData>

    func getConsentData(overrideProperties: String?) -> Promise<ConfigurableConsentData>
    
    func clearConfigurationCache() -> Void
}
