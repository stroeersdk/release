

protocol RefreshTimerFactory {
    func makeTimer(autoRefreshTimeMs: Int, delegate: RefreshTimerDelegate, wrapperView: YLBannerView) -> RefreshTimer
}

class YLRefreshTimerFactory: RefreshTimerFactory {
    
    func makeTimer(autoRefreshTimeMs: Int, delegate: RefreshTimerDelegate, wrapperView: YLBannerView) -> RefreshTimer {
        let config = YLRefreshTimerConfig(refreshTimeMs: autoRefreshTimeMs, delegate: delegate, wrapper: wrapperView)
        return YLRefreshTimer(config: config)
    }

}
