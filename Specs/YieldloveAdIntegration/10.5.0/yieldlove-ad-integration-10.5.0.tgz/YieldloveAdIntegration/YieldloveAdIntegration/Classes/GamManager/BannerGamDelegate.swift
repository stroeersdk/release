//
//  BannerGamBannerDelegate.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 02/04/2026.
//

import Foundation
import GoogleMobileAds

final class BannerGamDelegate: NSObject, BannerViewDelegate {

    weak var bannerConfiguration: BannerAdConfiguration?

    private var completion: ((Result<Void, Error>) -> Void)?
    private let dbgId = UUID().uuidString.prefix(6)

    init(
        bannerConfiguration: BannerAdConfiguration
    ) {
        self.bannerConfiguration = bannerConfiguration
        super.init()

        SLogger.i(
            "[BannerGamBannerDelegate:\(dbgId)] init, adSlotId=\(bannerConfiguration.adSlotId)"
        )
    }

    private var hasActiveRequest: Bool {
        completion != nil
    }

    private var wrapperView: YLBannerView? {
        bannerConfiguration?.wrapperView
    }

    private var publisherDelegate: YLBannerViewDelegate? {
        bannerConfiguration?.publisherDelegate
    }

    private var adUnitData: YLAdUnitData? {
        bannerConfiguration?.adUnitData
    }

    private var timeEventRecorder: TimeEventRecorder? {
        bannerConfiguration?.timeEventRecorder
    }

    private var debugSession: BannerDebugRecord? {
        bannerConfiguration?.debugRecord
    }

    func beginRequest(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        cancelInFlightRequest()
        self.completion = completion

        SLogger.i("[BannerGamBannerDelegate:\(dbgId)] beginRequest")
    }

    func cancelInFlightRequest() {
        guard hasActiveRequest else { return }

        SLogger.i("[BannerGamBannerDelegate:\(dbgId)] cancelInFlightRequest")
        finishRequest(.failure(BannerRequestLifecycleError.cancelled))
    }

    func failInFlightRequest(_ error: Error) {
        guard hasActiveRequest else { return }

        SLogger.e(
            "[BannerGamBannerDelegate:\(dbgId)] failInFlightRequest, error=\(error.localizedDescription)"
        )
        finishRequest(.failure(error))
    }

    private func finishRequest(_ result: Result<Void, Error>) {
        guard hasActiveRequest else { return }

        let completion = self.completion
        self.completion = nil
        completion?(result)
    }

    func bannerViewDidReceiveAd(_ bannerView: BannerView) {
        guard hasActiveRequest else { return }

        SLogger.i("[BannerGamBannerDelegate:\(dbgId)] didReceiveAd")

        recordGamResponse(error: nil)
        adUnitData?.responseIdentifier = bannerView.responseInfo?.responseIdentifier

        let currentAdUnit = adUnitData?.adUnit ?? ""
        var targeting: [String: String] = [
            "ad unit": bannerView.adUnitID ?? "",
            "banner size": "\(bannerView.adSize)"
        ]
        targeting.merge(responseInfoTargeting(bannerView.responseInfo)) { _, new in new }

        debugSession?.didReceiveFromGAM(
            targeting: targeting,
            adType: .banner,
            adUnitId: currentAdUnit
        )

        finishRequest(.success(()))
    }

    func bannerView(_ bannerView: BannerView, didFailToReceiveAdWithError error: Error) {
        guard hasActiveRequest else { return }

        SLogger.e(
            "[BannerGamBannerDelegate:\(dbgId)] didFail, error=\(error.localizedDescription)"
        )

        recordGamResponse(error: error)

        let responseInfo = (error as NSError).userInfo[GADErrorUserInfoKeyResponseInfo] as? ResponseInfo
        adUnitData?.responseIdentifier = responseInfo?.responseIdentifier

        let currentAdUnit = adUnitData?.adUnit ?? ""
        var targeting: [String: String] = [
            "ad unit": bannerView.adUnitID ?? "",
            "banner size": "\(bannerView.adSize)",
            "errorMessage": error.localizedDescription
        ]
        targeting.merge(responseInfoTargeting(responseInfo)) { _, new in new }

        debugSession?.didReceiveFromGAM(
            targeting: targeting,
            adType: .banner,
            adUnitId: currentAdUnit
        )

        if ConfigurationManager.isInspectionMode() {
            finishRequest(.success(()))
        } else {
            finishRequest(.failure(error))
        }
    }

    func bannerViewWillPresentScreen(_ bannerView: BannerView) {
        guard let wrapperView else { return }
        publisherDelegate?.bannerViewWillPresentScreen?(wrapperView)
    }

    func bannerViewWillDismissScreen(_ bannerView: BannerView) {
        guard let wrapperView else { return }
        publisherDelegate?.bannerViewWillDismissScreen?(wrapperView)
    }

    func bannerViewDidDismissScreen(_ bannerView: BannerView) {
        guard let wrapperView else { return }
        publisherDelegate?.bannerViewDidDismissScreen?(wrapperView)
    }

    func bannerViewDidRecordClick(_ bannerView: BannerView) {
        guard let wrapperView else { return }

        SLogger.i("[BannerGamBannerDelegate:\(dbgId)] click")
        publisherDelegate?.bannerViewDidRecordClick?(wrapperView)
    }

    func bannerViewDidRecordImpression(_ bannerView: BannerView) {
        guard let wrapperView else { return }

        SLogger.i("[BannerGamBannerDelegate:\(dbgId)] impression")
        publisherDelegate?.bannerViewDidRecordImpression?(wrapperView)
    }

    private func responseInfoTargeting(_ info: ResponseInfo?) -> [String: String] {
        guard let info else { return [:] }
        var result: [String: String] = [:]
        if let id = info.responseIdentifier { result["responseId"] = id }
        if let loaded = info.loadedAdNetworkResponseInfo {
            if let name = loaded.adSourceName { result["adSourceName"] = name }
            if let id = loaded.adSourceID { result["adSourceID"] = id }
            if let name = loaded.adSourceInstanceName { result["adSourceInstanceName"] = name }
            if let id = loaded.adSourceInstanceID { result["adSourceInstanceID"] = id }
            result["latency"] = String(format: "%.0f ms", loaded.latency * 1000)
            for (key, value) in loaded.adUnitMapping {
                result["mapping_\(key)"] = String(describing: value)
            }
        }
        for (key, value) in info.extras {
            result["extra_\(key)"] = String(describing: value)
        }
        return result
    }

    private func recordGamResponse(error: Error?) {
        if let err = error {
            timeEventRecorder?.recordGamRespondedWithError(error: err)
        } else {
            timeEventRecorder?.recordGamRespondedSuccessfully()
        }
    }

    deinit {
        SLogger.i(
            "[BannerGamBannerDelegate:\(dbgId)] deinit, completion_nil=\(completion == nil)"
        )
    }
}
