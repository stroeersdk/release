//
//  GlobalGamManager.swift
//  YieldloveAdIntegration
//
//  Created by Hyungon Kim on 30/04/2026.
//

import GoogleMobileAds

@objcMembers final class GlobalGamManager {
    static var adRequest = AdManagerRequest()
}
