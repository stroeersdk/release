//
//  BannerGamManager.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 02/04/2026.
//

import Foundation
import GoogleMobileAds

struct BannerLoadedGamBanner {
    let bannerView: AdManagerBannerView
    let bannerDelegate: BannerGamDelegate
}

final class BannerGamManager {

    private let dbgId = UUID().uuidString.prefix(6)

    init() {}

    @MainActor
    func loadBanner(
        requestData: BannerGamRequestData,
        controller: BannerController
    ) async throws -> BannerLoadedGamBanner {
        SLogger.i(
            "[BannerGamManager:\(dbgId)] loadBanner START, adUnit=\(requestData.adUnitData.adUnit)"
        )

        let delegateWrapper = BannerGamDelegate(
            bannerConfiguration: controller.bannerConfiguration
        )

        let gamBanner = AdManagerBannerView(adSize: requestData.adUnitData.bannerSizes[0])
        gamBanner.validAdSizes = requestData.adUnitData.bannerSizes.map { nsValue(for: $0) }
        gamBanner.adUnitID = requestData.adUnitData.adUnit

        return try await awaitBannerLoad(
            gamBanner: gamBanner,
            delegateWrapper: delegateWrapper,
            requestData: requestData,
            controller: controller,
            failureCleanup: { [weak gamBanner] in
                guard let gamBanner else { return }
                gamBanner.delegate = nil
                gamBanner.rootViewController = nil
                gamBanner.removeFromSuperview()
            }
        )
    }

    @MainActor
    func refreshBanner(
        requestData: BannerGamRequestData,
        controller: BannerController,
        wrapperView: YLBannerView,
        existingDelegate: BannerGamDelegate?
    ) async throws -> BannerLoadedGamBanner {
        SLogger.i(
            "[BannerGamManager:\(dbgId)] refreshBanner START, adUnit=\(requestData.adUnitData.adUnit)"
        )

        guard let gamBanner = wrapperView.getBannerView() as? AdManagerBannerView else {
            throw YLError.adUnitDataWasNotSet
        }

        let delegateWrapper = existingDelegate ?? BannerGamDelegate(
            bannerConfiguration: controller.bannerConfiguration
        )

        gamBanner.validAdSizes = requestData.adUnitData.bannerSizes.map { nsValue(for: $0) }
        gamBanner.adUnitID = requestData.adUnitData.adUnit

        return try await awaitBannerLoad(
            gamBanner: gamBanner,
            delegateWrapper: delegateWrapper,
            requestData: requestData,
            controller: controller,
            failureCleanup: { }
        )
    }

    @MainActor
    private func awaitBannerLoad(
        gamBanner: AdManagerBannerView,
        delegateWrapper: BannerGamDelegate,
        requestData: BannerGamRequestData,
        controller: BannerController,
        failureCleanup: @escaping () -> Void
    ) async throws -> BannerLoadedGamBanner {
        let finalRequest = getRequestWithAdManagerTargeting(using: requestData)

        return try await withCheckedThrowingContinuation { continuation in
            var didResume = false
            var timeoutTask: Task<Void, Never>?

            let finish: (Result<BannerLoadedGamBanner, Error>) -> Void = { result in
                guard !didResume else { return }
                didResume = true
                timeoutTask?.cancel()
                controller.setCurrentLoadCancellation(nil)

                switch result {
                case .success(let loadedBanner):
                    continuation.resume(returning: loadedBanner)

                case .failure(let error):
                    continuation.resume(throwing: error)
                }
            }

            delegateWrapper.beginRequest { result in
                switch result {
                case .success:
                    SLogger.i("[BannerGamManager:\(self.dbgId)] completion SUCCESS")
                    finish(
                        .success(
                            BannerLoadedGamBanner(
                                bannerView: gamBanner,
                                bannerDelegate: delegateWrapper
                            )
                        )
                    )

                case .failure(let error):
                    SLogger.e(
                        "[BannerGamManager:\(self.dbgId)] completion FAIL, err=\(error.localizedDescription)"
                    )
                    failureCleanup()
                    finish(.failure(error))
                }
            }

            controller.setCurrentLoadCancellation { [weak delegateWrapper] in
                timeoutTask?.cancel()
                delegateWrapper?.cancelInFlightRequest()
            }

            timeoutTask = Task { @MainActor [weak delegateWrapper] in
                do {
                    try await Task.sleep(nanoseconds: 10_000_000_000)
                } catch {
                    return
                }

                guard !didResume else { return }
                delegateWrapper?.failInFlightRequest(YLError.timeout)
            }

            gamBanner.rootViewController = controller.bannerConfiguration.presenterViewController
            gamBanner.delegate = delegateWrapper

            controller.markDisplayedBannerView(gamBanner)
            controller.bannerConfiguration.timeEventRecorder.recordGamRequested()

            SLogger.i(
                "[BannerGamManager:\(dbgId)] gamBanner.load, adUnit=\(requestData.adUnitData.adUnit)"
            )
            gamBanner.load(finalRequest)
        }
    }

    private func getRequestWithAdManagerTargeting(
        using requestData: BannerGamRequestData
    ) -> AdManagerRequest {
        let mergedRequest = YLGamRequestMerger.merge(
            requestData.gamRequest,
            GlobalGamManager.adRequest
        )

        let finalRequest = YLGamRequestMerger.mergeInto(
            request: mergedRequest,
            keyValues: requestData.adUnitData.keyValueTargeting,
            adUnit: requestData.adUnitData.adUnit
        )

        finalRequest.customTargeting?[YLConstants.sdkVersionNumberKey] = YLConstants.version
        return finalRequest
    }
}
