//
//  InterstitialGamManager.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 10/04/2026.
//

import Foundation
import GoogleMobileAds

struct InterstitialGamRequestData {
    let adUnitData: YLAdUnitData
    let gamRequest: AdManagerRequest
}

final class InterstitialGamManager {

    init() {}

    @MainActor
    func loadInterstitial(
        requestData: InterstitialGamRequestData,
        interstitialConfiguration: InterstitialAdConfiguration
    ) async throws -> AdManagerInterstitialAd {
        SLogger.i("[InterstitialGamManager] loadInterstitial START adUnit=\(requestData.adUnitData.adUnit)")

        interstitialConfiguration.timeEventRecorder.recordGamRequested()

        let finalRequest = getRequestWithAdManagerTargeting(using: requestData)

        do {
            let ad = try await AdManagerInterstitialAd.load(
                with: requestData.adUnitData.adUnit,
                request: finalRequest
            )

            requestData.adUnitData.responseIdentifier = ad.responseInfo.responseIdentifier
            interstitialConfiguration.gamInterstitialAd = ad
            interstitialConfiguration.timeEventRecorder.recordGamRespondedSuccessfully()

            SLogger.i(
                "[InterstitialGamManager] loadInterstitial SUCCESS adUnit=\(requestData.adUnitData.adUnit) responseId=\(ad.responseInfo.responseIdentifier ?? "")"
            )

            return ad
        } catch {
            interstitialConfiguration.timeEventRecorder.recordGamRespondedWithError(error: error)

            SLogger.e(
                "[InterstitialGamManager] loadInterstitial FAIL adUnit=\(requestData.adUnitData.adUnit)",
                error
            )

            throw error
        }
    }
    
    private func getRequestWithAdManagerTargeting(using requestData: InterstitialGamRequestData) -> AdManagerRequest {
        let mergedRequest = YLGamRequestMerger.merge(
            requestData.gamRequest,
            GlobalGamManager.adRequest
        )

        let finalRequest = YLGamRequestMerger.mergeInto(
            request: mergedRequest,
            keyValues: requestData.adUnitData.keyValueTargeting,
            adUnit: requestData.adUnitData.adUnit
        )

        finalRequest.customTargeting?[YLConstants.sdkVersionNumberKey] = YLConstants.version
        return finalRequest
    }
}
