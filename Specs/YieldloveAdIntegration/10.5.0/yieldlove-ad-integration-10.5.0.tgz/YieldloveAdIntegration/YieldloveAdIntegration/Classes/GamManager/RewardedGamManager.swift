//
//  RewardedGamManager.swift
//  YieldloveAdIntegration
//
//  Created by Shafee Rehman on 20/04/2026.
//

import GoogleMobileAds

struct RewardedGamRequestData {
    let adUnitData: YLAdUnitData
    let gamRequest: AdManagerRequest
}

final class RewardedGamManager {

    init() {}

    @MainActor
    func loadRewarded(
        requestData: RewardedGamRequestData,
        rewardedConfiguration: RewardedAdConfiguration
    ) async throws -> RewardedAd {
        SLogger.i(
            "[RewardedGamManager] loadRewarded START adUnit=\(requestData.adUnitData.adUnit)"
        )

        rewardedConfiguration.timeEventRecorder.recordGamRequested()

        let finalRequest = getRequestWithAdManagerTargeting(using: requestData)

        do {
            let ad = try await RewardedAd.load(
                with: requestData.adUnitData.adUnit,
                request: finalRequest
            )

            requestData.adUnitData.responseIdentifier = ad.responseInfo.responseIdentifier
            rewardedConfiguration.gamRewardedAd = ad
            rewardedConfiguration.timeEventRecorder.recordGamRespondedSuccessfully()

            SLogger.i(
                "[RewardedGamManager] loadRewarded SUCCESS adUnit=\(requestData.adUnitData.adUnit) responseId=\(ad.responseInfo.responseIdentifier ?? "")"
            )

            return ad
        } catch {
            rewardedConfiguration.timeEventRecorder.recordGamRespondedWithError(error: error)

            SLogger.e(
                "[RewardedGamManager] loadRewarded FAIL adUnit=\(requestData.adUnitData.adUnit)",
                error
            )

            throw error
        }
    }

    private func getRequestWithAdManagerTargeting(
        using requestData: RewardedGamRequestData
    ) -> AdManagerRequest {
        let mergedRequest = YLGamRequestMerger.merge(
            requestData.gamRequest,
            GlobalGamManager.adRequest
        )

        let finalRequest = YLGamRequestMerger.mergeInto(
            request: mergedRequest,
            keyValues: requestData.adUnitData.keyValueTargeting,
            adUnit: requestData.adUnitData.adUnit
        )

        finalRequest.customTargeting?[YLConstants.sdkVersionNumberKey] = YLConstants.version
        return finalRequest
    }
}
