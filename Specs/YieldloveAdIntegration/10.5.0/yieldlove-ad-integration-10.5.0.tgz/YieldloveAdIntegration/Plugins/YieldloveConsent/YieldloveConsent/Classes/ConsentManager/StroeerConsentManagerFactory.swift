import ConsentViewController
import YieldloveAdIntegration

public class StroeerConsentManagerFactory {

    var shouldUseStagingConfiguration: Bool {
        return ProcessInfo.processInfo.environment["STAGINGCONFIGURATION"] == "1"
    }

    var campaignEnv: SPCampaignEnv {
        return self.shouldUseStagingConfiguration ? .Stage : .Public
    }

    var campaigns: SPCampaigns {
        return SPCampaigns(
            gdpr: SPCampaign(),
            environment: campaignEnv
        )
    }

    func make(delegate: StroeerConsentDelegate,
              variant: String? = nil) throws -> StroeerConsentManager {
        let sp = try getSourcePoint(variant: variant)
        return try buildSPConsentManager(sp, delegate)
    }

    private func getSourcePoint(variant: String? = nil) throws -> ConfigModule_SourcePoint {
        guard let sourcePoint = ConfigurationManager.shared.config?.modules?.sourcePoint else {
            throw StroeerConsentManagerFactoryError.consentConfigurationIncorrect
        }

        if let variant = variant, let override = sourcePoint.overrides?[variant] {
            return override
        }
        return sourcePoint
    }

    private func buildSPConsentManager(_ sp: ConfigModule_SourcePoint, _ delegate: SPDelegate) throws -> StroeerConsentManager {
        guard sp.active == true else {
            throw StroeerConsentManagerFactoryError.consentExternalConfigurationIsNotActive
        }
        guard let accountId = sp.sourcepointAccountId else {
            throw StroeerConsentManagerFactoryError.consentConfigurationIncorrect
        }
        guard let propertyId = sp.propertyId else {
            throw StroeerConsentManagerFactoryError.consentConfigurationIncorrect
        }
        guard let propertyName = sp.propertyName else {
            throw StroeerConsentManagerFactoryError.consentConfigurationIncorrect
        }
        return SPConsentManager(
            accountId: accountId,
            propertyId: propertyId,
            propertyName: try SPPropertyName(propertyName),
            campaigns: campaigns,
            delegate: delegate
        )
    }

}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerConsentManagerFactory")
public typealias YLConsentManagerFactory = StroeerConsentManagerFactory
