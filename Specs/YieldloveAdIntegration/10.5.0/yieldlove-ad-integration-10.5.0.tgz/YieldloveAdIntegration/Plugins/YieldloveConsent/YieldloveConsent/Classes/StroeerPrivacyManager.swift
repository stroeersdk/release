import ConsentViewController
import YieldloveAdIntegration
import UIKit

class StroeerPrivacyManager {

    private let delegate: StroeerConsentDelegate
    private let consentManagerFactory: StroeerConsentManagerFactory

    private var consentManager: StroeerConsentManager?

    init(viewController: UIViewController, publisherDelegate: StroeerConsentPublisherDelegate, factory: StroeerConsentManagerFactory = StroeerConsentManagerFactory()) {
        self.delegate = StroeerConsentDelegate(publisherViewController: viewController, publisherDelegate: publisherDelegate)
        self.consentManagerFactory = factory
    }

    func show(options: StroeerConsentOptions?) {
        Task { @MainActor in
            do {
                await ConfigurationManager.shared.getConfigAsync()

                var manager = try consentManagerFactory.make(delegate: delegate, variant: options?.variant)
                if let lang = options?.language {
                    manager.messageLanguage = lang
                }
                self.consentManager = manager

                let privacyManagerId = try getPrivacyManagerId(variant: options?.variant)
                manager.loadGDPRPrivacyManager(
                    withId: privacyManagerId,
                    tab: .Default,
                    useGroupPmIfAvailable: false
                )
            } catch {
                handleError(error: error)
            }
        }
    }

    private func getPrivacyManagerId(variant: String?) throws -> String {
        guard let sourcePoint = ConfigurationManager.shared.config?.modules?.sourcePoint else {
            throw ConfigurationParsingError.unableToFindCommonSection
        }

        var sp = sourcePoint
        if let variant = variant, let override = sourcePoint.overrides?[variant] {
            sp = override
        }
        
        if sp.privacyManagerId == nil || sp.privacyManagerId?.isEmpty == true {
            throw StroeerConsentManagerFactoryError.consentExternalConfigurationIsNotActive
        }

        return sp.privacyManagerId ?? ""
    }

    private func handleError(error: Error) {
        switch error {
        case StroeerConsentManagerFactoryError.consentExternalConfigurationIsNotActive:
            SLogger.e("[StroeerPrivacyManager] Could not show privacy manager, because consent external configuration is not active: \(error.localizedDescription)")
        default:
            SLogger.e("[StroeerPrivacyManager] Could not show privacy manager: \(error)")
        }
    }

}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerPrivacyManager")
typealias YLPrivacyManager = StroeerPrivacyManager
