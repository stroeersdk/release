import ConsentViewController
import YieldloveAdIntegration

typealias CustomConsentCompletion = (SPGDPRConsent) -> Void

class StroeerCustomConsent {

    private let delegate: StroeerConsentDelegate
    private let consentManagerFactory: StroeerConsentManagerFactory

    private var consentManager: StroeerConsentManager?

    init(publisherDelegate: StroeerConsentPublisherDelegate, factory: StroeerConsentManagerFactory = StroeerConsentManagerFactory()) {
        self.delegate = StroeerConsentDelegate(publisherDelegate: publisherDelegate)
        self.consentManagerFactory = factory
    }

    func forward(consentData: StroeerCustomConsentData, completionHandler: @escaping CustomConsentCompletion) {
        do {
            let manager = try consentManagerFactory.make(delegate: delegate, variant: nil)
            self.consentManager = manager
            submitCustomConsent(manager, consentData, completionHandler)
        } catch {
            handleError(error: error)
        }
    }

    private func submitCustomConsent(_ consentManager: StroeerConsentManager,
                                     _ consentData: StroeerCustomConsentData,
                                     _ completionHandler: @escaping CustomConsentCompletion) {
        consentManager.customConsentGDPR(vendors: consentData.vendors,
                                         categories: consentData.categories,
                                         legIntCategories: consentData.legIntCategories,
                                         handler: completionHandler)
    }

    private func handleError(error: Error) {
        SLogger.e("[StroeerCustomConsent] Failed to submit custom consent to SourcePoint: \(error.localizedDescription)")
    }

}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerCustomConsent")
typealias YLCustomConsent = StroeerCustomConsent
