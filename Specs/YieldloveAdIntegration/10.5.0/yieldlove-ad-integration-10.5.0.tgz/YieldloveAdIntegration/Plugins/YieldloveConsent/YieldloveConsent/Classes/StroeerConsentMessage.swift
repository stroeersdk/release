import ConsentViewController
import YieldloveAdIntegration
import UIKit

class StroeerConsentMessage {

    private let delegate: StroeerConsentDelegate
    private let consentManagerFactory: StroeerConsentManagerFactory

    private var consentManager: StroeerConsentManager?

    init(viewController: UIViewController, publisherDelegate: StroeerConsentPublisherDelegate, factory: StroeerConsentManagerFactory = StroeerConsentManagerFactory()) {
        self.delegate = StroeerConsentDelegate(publisherViewController: viewController, publisherDelegate: publisherDelegate)
        self.consentManagerFactory = factory
    }

    func show(options: StroeerConsentOptions?) {
        do {
            var manager = try consentManagerFactory.make(delegate: delegate, variant: options?.variant)
            if let lang = options?.language {
                manager.messageLanguage = lang
            }
            self.consentManager = manager
            manager.loadMessage(forAuthId: options?.authId, publisherData: nil)
        } catch {
            handleError(error: error)
        }
    }

    private func handleError(error: Error) {
        switch error {
        case StroeerConsentManagerFactoryError.consentExternalConfigurationIsNotActive:
            SLogger.e("[StroeerConsentMessage] Could not show consent message, because consent not enabled in external configuration: \(error.localizedDescription)")
        default:
            SLogger.e("[StroeerConsentMessage] Could not show consent form due to: \(error.localizedDescription)")
        }
    }
}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerConsentMessage")
typealias YLConsentMessage = StroeerConsentMessage
