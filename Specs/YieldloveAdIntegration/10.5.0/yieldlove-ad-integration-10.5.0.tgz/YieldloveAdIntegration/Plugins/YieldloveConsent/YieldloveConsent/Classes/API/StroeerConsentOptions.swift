import ConsentViewController

@objcMembers public class StroeerConsentOptions: NSObject {

    public var authId: String?
    public var variant: String?
    public var language: SPMessageLanguage = .BrowserDefault

}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerConsentOptions")
public typealias ConsentOptions = StroeerConsentOptions
