import ConsentViewController
import YieldloveAdIntegration
import UIKit

@objc public class StroeerConsent: NSObject, ObservableObject {

    @available(iOS, obsoleted: 1.0, message: "Create a new StroeerConsent() instance instead. This used to cause the memory leak issue")
    @objc public static let instance = StroeerConsent()

    public override init() {
        super.init()
    }

    var consentMessage: StroeerConsentMessage?
    var privacyManager: StroeerPrivacyManager?
    var customConsent: StroeerCustomConsent?

    @objc public func setAppName(appName: String) {
        ExternalConfigurationManagerBuilder.instance.appName = appName
    }

    @available(iOS, obsoleted: 1.0, message: "This method is no longer needed as the debug mode is now determined by the app's build configuration. Please Yieldlove.enableDebugMode() ")
    @objc public func enableDebug(isEnabled: Bool) {
    }

    @objc public func collect(viewController: UIViewController, delegate: StroeerConsentPublisherDelegate, options: StroeerConsentOptions? = StroeerConsentOptions()) {
        consentMessage = StroeerConsentMessage(viewController: viewController, publisherDelegate: delegate)
        consentMessage?.show(options: options)
    }

    @objc public func showPrivacyManager(viewController: UIViewController,
                                         delegate: StroeerConsentPublisherDelegate,
                                         options: StroeerConsentOptions? = StroeerConsentOptions()) {
        privacyManager = StroeerPrivacyManager(viewController: viewController, publisherDelegate: delegate)
        privacyManager?.show(options: options)
    }

    @objc public func customConsentTo(customConsentData: StroeerCustomConsentData,
                                      completionHandler: @escaping (SPGDPRConsent) -> Void,
                                      delegate: StroeerConsentPublisherDelegate) {
        customConsent = StroeerCustomConsent(publisherDelegate: delegate)
        customConsent?.forward(consentData: customConsentData, completionHandler: completionHandler)
    }

    @objc public func clearConsentData(delegate: StroeerConsentPublisherDelegate) {
        SPConsentManager.clearAllData()
    }

}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerConsent")
public typealias YLConsent = StroeerConsent
