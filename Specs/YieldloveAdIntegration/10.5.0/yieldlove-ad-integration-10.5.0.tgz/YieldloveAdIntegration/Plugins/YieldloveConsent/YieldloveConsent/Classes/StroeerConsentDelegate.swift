import ConsentViewController
import YieldloveAdIntegration
import UIKit

class StroeerConsentDelegate: SPDelegate {

    weak var publisherDelegate: StroeerConsentPublisherDelegate?
    weak var publisherViewController: UIViewController?

    init(publisherViewController: UIViewController?, publisherDelegate: StroeerConsentPublisherDelegate?) {
        self.publisherViewController = publisherViewController
        self.publisherDelegate = publisherDelegate
    }

    init(publisherDelegate: StroeerConsentPublisherDelegate?) {
        self.publisherDelegate = publisherDelegate
    }

    func onAction(_ action: SPAction, from controller: UIViewController) {
        publisherDelegate?.onAction?(action: action)
    }

    func onSPUIReady(_ controller: UIViewController) {
        if controller.isBeingPresented {
            return
        }
        controller.modalPresentationStyle = .overFullScreen
        publisherDelegate?.onSPUIReady?()
        publisherViewController?.present(controller, animated: true)
    }

    func onSPUIFinished(_ controller: UIViewController) {
        publisherViewController?.dismiss(animated: true)
        publisherDelegate?.onSPUIFinished?()
    }

    public func onConsentReady(userData: SPUserData) {
        publisherDelegate?.onConsentReady?(consents: userData)
    }

    func onSPFinished(userData: SPUserData) {
        publisherDelegate?.onSPFinished?(consents: userData)
    }

    func onError(error: SPError) {
        SLogger.e("[StroeerConsentDelegate] SourcePoint consent error: \(error)")
        let myError = StroeerConsentError.consentRequestFailed
        publisherDelegate?.onError?(error: myError)
    }
}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerConsentDelegate")
typealias YLConsentDelegate = StroeerConsentDelegate
