import Foundation

@objc public enum StroeerConsentError: Int, Error {
    case consentRequestFailed
}

extension StroeerConsentError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .consentRequestFailed:
            return NSLocalizedString("Consent request failed. Enable debug mode for more info.", comment: "consentRequestFailed")
        }
    }
}

// MARK: - Backward Compatibility
@available(*, deprecated, renamed: "StroeerConsentError")
public typealias YieldloveConsentError = StroeerConsentError
