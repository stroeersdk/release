package com.stroeer.ads.plugins.monitoring

import android.view.View

interface IAdReloader {
    fun getAdSlot(): String
    fun reloadAd(slotView: View?, placementId: String?)
    fun getAdView(): View?
}
