package com.stroeer.ads.utilities.http

/**
 * Timeouts for a single [HttpRequest].
 *
 * @param connectMillis max time to establish the TCP/TLS connection, per connection attempt.
 * @param readMillis max time to wait for the next byte once the request is sent, per connection
 *   attempt (this is `HttpURLConnection`'s "read timeout": it resets between reads, it is not a
 *   total-transfer budget).
 * @param callMillis a budget for the *entire* call - every redirect, the upload and the full body
 *   read - measured from when [HttpCall.execute] starts. It is checked at each phase boundary and
 *   between body chunks, but unlike OkHttp's `callTimeout` it cannot preempt a blocking operation
 *   already under way (`HttpURLConnection` exposes no hook for that, and DNS resolution is outside
 *   its connect timeout), so the real ceiling is this plus roughly one connect or read timeout.
 *   Wrap `HttpClient.send` in `withTimeout` where a hard bound is required.
 */
data class HttpTimeouts(
    val connectMillis: Int,
    val readMillis: Int,
    val callMillis: Long
) {
    companion object {
        private const val DEFAULT_SECONDS = 5

        /** The timeout the SDK falls back to when a caller does not specify one. */
        val DEFAULT = fromSeconds(DEFAULT_SECONDS)

        /**
         * Builds timeouts from a single [seconds] value, applied to connect, read and the whole
         * call alike.
         *
         * A non-positive value falls back to [DEFAULT_SECONDS]: `HttpURLConnection` treats a
         * timeout of `0` as *infinite*, so passing a caller-supplied `0` or negative value
         * straight through would silently turn "no timeout configured" into "never time out",
         * which is the opposite of safe. The millisecond value is also clamped into `Int` range,
         * since [java.net.HttpURLConnection.setConnectTimeout] and
         * [java.net.HttpURLConnection.setReadTimeout] both take an `Int`.
         */
        fun fromSeconds(seconds: Int): HttpTimeouts {
            val resolvedSeconds = if (seconds > 0) seconds else DEFAULT_SECONDS
            val millisLong = resolvedSeconds.toLong() * 1000L
            val millisInt = millisLong.coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()
            return HttpTimeouts(
                connectMillis = millisInt,
                readMillis = millisInt,
                callMillis = millisLong
            )
        }
    }
}
