package com.stroeer.ads.utilities.json

import org.json.JSONArray
import org.json.JSONObject

object JsonPrinter {

    fun print(json: String): String {
        val obj = JSONObject(json)
        val builder = StringBuilder()
        printObject(obj, 0, builder)
        return builder.toString().trimEnd()
    }

    fun print(json: JSONObject): String {
        val builder = StringBuilder()
        printObject(json, 0, builder)
        return builder.toString().trimEnd()
    }

    fun print(json : JSONObject, exclude: String) : String{
        val builder = StringBuilder()
        printObject(json, 0, exclude, builder)
        return builder.toString().trimEnd()
    }

    private fun printObject(obj: JSONObject, depth: Int, builder: StringBuilder) {
        printObject(obj, depth, null , builder)
    }

    private fun printObject(obj: JSONObject, depth: Int, exclude : String?, builder: StringBuilder) {
        val indent = "  ".repeat(depth)
        for (key in obj.keys()) {
            val value = obj.get(key)
            when (value) {
                is JSONObject -> {
                    if(!key.equals(exclude)) {
                        builder.appendLine("$indent$key :")
                    }
                    printObject(value, depth + 1,exclude, builder)
                }
                is JSONArray -> {
                    if(!key.equals(exclude)) {
                        builder.appendLine("$indent$key :")
                    }
                    printArray(value, depth + 1, exclude, builder)
                }
                else -> {
                    if(!key.equals(exclude)) {
                        builder.appendLine("$indent$key : $value")
                    }
                }
            }
        }
    }

    private fun printArray(array: JSONArray, depth: Int, exclude: String?, builder: StringBuilder) {
        val indent = "  ".repeat(depth)
        for (i in 0 until array.length()) {
            val value = array.get(i)
            when (value) {
                is JSONObject -> {
                    printObject(value, depth, exclude, builder)
                }
                is JSONArray -> {
                    printArray(value, depth, exclude, builder)
                }
                else -> builder.appendLine("$indent- $value")
            }
        }
    }
}