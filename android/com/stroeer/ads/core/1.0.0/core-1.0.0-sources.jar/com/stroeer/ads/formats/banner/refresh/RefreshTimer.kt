package com.stroeer.ads.formats.banner.refresh

import com.stroeer.ads.utilities.concurrent.ACoroutinable
import kotlinx.coroutines.*
import kotlin.time.Duration.Companion.milliseconds

class RefreshTimer(
    val listener: IRefreshListener
) : ACoroutinable(){
    private var refreshJob: Job? = null

    fun scheduleRefresh(timeInMs: Int) {
        if (timeInMs <= 0) return

        // Cancel any existing refresh task
        clearScheduledTasks()

        refreshJob = mainScope.launch {
            delay(timeInMs.toLong().milliseconds)
            listener.handleRefresh()
        }
    }

    fun clearScheduledTasks() {
        refreshJob?.cancel()
        refreshJob = null
    }

    override fun cancel(){
        clearScheduledTasks()
    }
}