/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.stroeer.ads;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.stroeer.ads";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final int VERSION_CODE = 188;
  // Field from default config.
  public static final String VERSION_NAME = "1.0.0";
}
