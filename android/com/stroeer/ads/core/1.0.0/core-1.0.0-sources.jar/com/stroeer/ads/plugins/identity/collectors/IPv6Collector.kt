package com.stroeer.ads.plugins.identity.collectors

import java.net.Inet6Address
import java.net.InetAddress

/**
 * Return IPv6 address
 */
class IPv6Collector : IPv4Collector() {
    override val checkURL: String = "https://api64.ipify.org"

    override fun getWifiIPAddress(): String? {
        return getNetworkIPAddress( true)
    }

    override val mobileIPAddress: String?
        get() = getNetworkIPAddress(true)

    override fun isValidFormat(ip: String): Boolean {
        // Must contain ':' (so a numeric IPv4 string is rejected) and parse as a literal IPv6
        // address. The contains(":") guard prevents InetAddress from doing a DNS lookup on a host.
        if (!ip.contains(":")) return false
        return try {
            InetAddress.getByName(ip) is Inet6Address
        } catch (_: Exception) {
            false
        }
    }
}
