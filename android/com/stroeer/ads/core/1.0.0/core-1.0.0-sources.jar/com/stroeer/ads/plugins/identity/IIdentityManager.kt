package com.stroeer.ads.plugins.identity

import android.content.Context
import com.stroeer.ads.plugins.identity.objects.IdentityCache
import com.stroeer.ads.plugins.identity.objects.IdentityCustomInfo

interface IIdentityManager {
    fun initialize(applicationContext: Context)
    suspend fun loadIdentityFromHttp(retry: Boolean)
    fun loadIdentityFromStorage()
    val identityData: IdentityCache
    suspend fun isUpdated() : Boolean
    fun setUserIdToPrebid()
    fun setCustomInfo(customInfo : IdentityCustomInfo)
}
