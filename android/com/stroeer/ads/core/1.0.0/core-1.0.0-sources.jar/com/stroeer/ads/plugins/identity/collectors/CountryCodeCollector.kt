package com.stroeer.ads.plugins.identity.collectors

import android.content.Context
import android.telephony.TelephonyManager
import com.stroeer.ads.plugins.identity.ACollectorWithContext
import java.util.Locale

/**
 * Return country code. Collect from SIM card, Network, or device's default locale.
 */
class CountryCodeCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        var countryCode: String?
        // Get the Telephony Manager
        val telephonyManager =
            applicationContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager?

        if (telephonyManager != null) {
            // 1. Try getting country from SIM card
            countryCode = telephonyManager.simCountryIso
            if (!countryCode.isNullOrEmpty()) {
                return countryCode.toIsoCountryCode() // Return uppercase ISO country code
            }

            // 2. Try getting country from Network
            countryCode = telephonyManager.networkCountryIso
            if (!countryCode.isNullOrEmpty()) {
                return countryCode.toIsoCountryCode()
            }
        }

        // 3. Fall back to the device's default locale, which carries no country at all for a
        // language-only locale such as "de". Report that as absent rather than as "".
        return Locale.getDefault().country.takeIf { it.isNotEmpty() }?.toIsoCountryCode()
    }

    // Locale.ROOT because ISO codes are locale-independent identifiers: the default locale
    // would uppercase "it" to "İT" on a Turkish device, corrupting every code containing 'i'.
    private fun String.toIsoCountryCode() = uppercase(Locale.ROOT)
}
