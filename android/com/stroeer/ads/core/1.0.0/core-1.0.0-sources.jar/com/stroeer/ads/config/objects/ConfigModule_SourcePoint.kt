package com.stroeer.ads.config.objects

import com.stroeer.ads.utilities.logging.Logger

/**
 * *         "SOURCEPOINT": {
 * *           "active": true,
 * *           "propertyId": "10629",
 * *           "propertyName": "android.app.herzrasen",
 * *           "privacyManagerId": "406840",
 * "overrides": {
 * "overrideTest": {
 * "privacyManagerId": "11111"
 * },
 * "overrideTest2": {
 * "privacyManagerId": "22222"
 * },
 * "overrideTest3": {
 * "privacyManagerId": "33333",
 * "propertyName": "test.android.name"
 * }
 * }
 * *         },
 */
class ConfigModule_SourcePoint {
    var sourcepointAccountId: Int = -1
    var active: Boolean = false
    var propertyId: Int = -1
    var propertyName: String = ""
    var privacyManagerId: String = ""
    var overrides: MutableMap<String, ConfigModule_SourcePoint>? = null

    fun getSourcePoint(overrideKey: String? = null) : ConfigModule_SourcePoint? {
        overrideKey?.let {
            overrides?.get(it)?.let { overrideConfig ->
                val configMod = ConfigModule_SourcePoint()
                configMod.active = overrideConfig.active ?: this.active
                configMod.propertyId = overrideConfig.propertyId ?: this.propertyId
                configMod.propertyName = overrideConfig.propertyName ?: this.propertyName
                configMod.privacyManagerId = overrideConfig.privacyManagerId ?: this.privacyManagerId
                configMod.sourcepointAccountId = overrideConfig.sourcepointAccountId ?: this.sourcepointAccountId
                return configMod
            }
        }

        // no override found, return base config
        overrideKey?.let{
            Logger.e("[ConfigModule_SourcePoint] no override found for key '$it', Use default config")
        }

        return this
    }
}
