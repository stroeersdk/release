package com.stroeer.ads.debugInfo.admin

import android.content.Context
import com.stroeer.ads.debugInfo.admin.pages.ABTestJsonPage
import com.stroeer.ads.debugInfo.admin.pages.AdminResponseFactory
import com.stroeer.ads.debugInfo.admin.pages.DashboardPage
import com.stroeer.ads.debugInfo.admin.pages.DebugInfoJsonPage
import com.stroeer.ads.debugInfo.admin.pages.DebugInfoPage
import com.stroeer.ads.utilities.logging.Logger
import fi.iki.elonen.NanoHTTPD

// Bind to loopback only: the admin server must be reachable from the device itself
// (e.g. via adb forward), never from other hosts on the network.
class AdminHttpServer private constructor(private val appContext: Context) : NanoHTTPD("127.0.0.1", PORT) {

    companion object {
        private const val PORT = 9890
        private const val TAG = "[AdminHttpServer]"

        @Volatile
        private var instance: AdminHttpServer? = null

        fun launch(context: Context) {
            if (instance?.isAlive == true) return
            try {
                val server = AdminHttpServer(context.applicationContext)
                server.start(SOCKET_READ_TIMEOUT, false)
                instance = server
                Logger.i("$TAG Admin server started on port $PORT")
            } catch (e: Exception) {
                Logger.e("$TAG Failed to start admin server", e)
            }
        }

        fun shutdown() {
            instance?.stop()
            instance = null
        }
    }

    private val responseFactory = AdminResponseFactory { status, mimeType, body ->
        newFixedLengthResponse(status, mimeType, body)
    }

    private val dashboardPage = DashboardPage(appContext, responseFactory)
    private val debugInfoPage = DebugInfoPage(appContext, responseFactory)
    private val debugInfoJsonPage = DebugInfoJsonPage(responseFactory)
    private val abTestJsonPage = ABTestJsonPage(responseFactory)

    override fun serve(session: IHTTPSession): Response {
        return when (session.uri) {
            "/", "/admin" -> dashboardPage.serve()
            "/debugenable" -> dashboardPage.enableInspection()
            "/debuginfo" -> debugInfoPage.serve()
            "/api/debuginfo" -> debugInfoJsonPage.serve()
            "/api/abtest" -> abTestJsonPage.serve()
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not Found")
        }
    }
}
