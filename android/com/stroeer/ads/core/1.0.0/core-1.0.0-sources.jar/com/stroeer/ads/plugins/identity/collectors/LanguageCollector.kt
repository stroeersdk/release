package com.stroeer.ads.plugins.identity.collectors

import com.stroeer.ads.plugins.identity.ACollectorWithContext
import java.util.Locale

/**
 * Return language
 */
class LanguageCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        val locales = applicationContext.resources.configuration.locales
        val acceptLanguage = StringBuilder()

        for (i in 0 until locales.size()) {
            val locale = locales[i]
            acceptLanguage.append(locale.toLanguageTag())

            if (i == 0) {
                acceptLanguage.append(",")
            } else {
                // Locale.ROOT keeps the '.' decimal separator; the default locale would emit
                // "0,9" on e.g. German devices, which is an invalid Accept-Language q-value.
                acceptLanguage.append(";q=").append(String.format(Locale.ROOT, "%.1f", 1.0 - (i * 0.1)))
                if (i < locales.size() - 1) {
                    acceptLanguage.append(",")
                }
            }
        }
        return acceptLanguage.toString()
    }
}
