package com.stroeer.ads.config

import com.stroeer.ads.BuildConfig
import com.stroeer.ads.utilities.logging.Logger

internal object ConfigConstants {

    const val PREBID_URL: String = "https://s2s.yieldlove-ad-serving.net/openrtb2/auction"
    const val CONFIG_URL: String = "https://cdn.stroeerdigitalgroup.de/sdk/live/{APPLICATION_NAME}/config.json"

    const val EXTERNAL_CONFIG_SHARED_PREFS_FILE_KEY: String = "EXTERNAL_CONFIG_FILE_KEY"
    const val EXTERNAL_CONFIG_CONTENT_KEY: String = "EXTERNAL_CONFIG_CONTENT_KEY"
    const val EXTERNAL_CONFIG_LAST_FETCH_IN_MILLIS_KEY: String = "EXTERNAL_CONFIG_LAST_FETCH_IN_MILLIS_KEY"

    // Not using anymore
    // val errorReporterUrl: String = "https://mobile-sdk.stroeer-labs.com/api/reporting"
    // val monitoringReporterUrl: String = "https://mobile-sdk.stroeer-labs.com/api/event-sessions"
    // val errorReporterApiKey: String = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T"
    // val monitoringReporterApiKey: String = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T"
    const val OMID_PARTNER_NAME: String = "Google"
    const val OMID_PARTNER_VERSION: String = "213502000.213502000"

    const val ANDROID_REQUEST_VERSION_KEY : String = "androidYlSdkVersion"

    const val PREFS_CONFIG: String = "STROEER_CONFIG"
    const val PREFS_AB_SESSION_PREFIX: String = "AB_SESSION_"

    const val APPLICATION_NAME_PLACEHOLDER: String = "{APPLICATION_NAME}"
    const val CONFIG_TIMEOUT: Int = 10
    const val CONFIG_TIMEOUT_MS : Long = CONFIG_TIMEOUT * 1000L
    const val DEFAULT_REQUEST_TIMEOUT_MS: Int = 5000

    private var _version : String = ""
    val VERSION_NAME: String
        get(){
            if (_version.isEmpty()){
                try {
                    val versions = BuildConfig.VERSION_NAME.split(".")
                    val majorV = versions[0].toInt() + 20 // New Versioning scheme, add 10 to major version to avoid conflicts with old versioning scheme
                    val minorV = versions[1].toInt()
                    val patchV = versions[2].toInt()
                    _version = "$majorV.$minorV.$patchV"
                }catch(e: Exception){
                    Logger.e("[StroeerSDK] Failed to parse version number", e)
                    _version = BuildConfig.VERSION_NAME
                }
            }

            return _version
        }
}
