package com.stroeer.ads.debugInfo.admin.pages

import android.content.Context
import fi.iki.elonen.NanoHTTPD

internal class DebugInfoPage(
    private val appContext: Context,
    private val responseFactory: AdminResponseFactory
) {

    fun serve(): NanoHTTPD.Response {
        val html = AdminPageUtils.loadHtmlTemplate(appContext, "admin/debuginfo.html")
        return responseFactory.create(NanoHTTPD.Response.Status.OK, "text/html", html)
    }
}
