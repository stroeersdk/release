package com.stroeer.ads.utilities.http

import java.io.OutputStream
import java.nio.charset.Charset

/**
 * An immutable request body.
 *
 * The bytes are copied on construction and never handed back out - callers only get the
 * [contentLength] and the ability to [writeTo] a stream - so a body built once cannot be
 * mutated afterwards by anyone holding a reference to the original array or to this object.
 */
class HttpBody private constructor(
    private val bytes: ByteArray,
    val contentType: String?
) {
    /** Size in bytes, used for `Content-Length` / `setFixedLengthStreamingMode`. */
    val contentLength: Int get() = bytes.size

    /** Writes the body to [out]. Does not close the stream; the caller owns its lifecycle. */
    internal fun writeTo(out: OutputStream) {
        out.write(bytes)
    }

    companion object {
        /** Builds a body from [text] encoded as UTF-8, tagged with [contentType]. */
        fun utf8(text: String, contentType: String): HttpBody {
            return HttpBody(text.toByteArray(Charset.forName("UTF-8")), contentType)
        }

        /**
         * Builds a JSON body from [text], tagged with the charset-qualified JSON content type
         * that every JSON endpoint in the SDK expects.
         */
        fun json(text: String): HttpBody {
            return utf8(text, "application/json; charset=utf-8")
        }
    }
}
