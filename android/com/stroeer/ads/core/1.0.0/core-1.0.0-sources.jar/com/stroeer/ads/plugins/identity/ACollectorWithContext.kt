package com.stroeer.ads.plugins.identity

import com.stroeer.ads.utilities.concurrent.ACoroutinable
import android.content.Context

abstract class ACollectorWithContext<T> : IIdentityCollector<T?>, ACoroutinable(){
    abstract override suspend fun retrieveData(): T?

    companion object {
        lateinit var applicationContext: Context
            internal set
    }
}
