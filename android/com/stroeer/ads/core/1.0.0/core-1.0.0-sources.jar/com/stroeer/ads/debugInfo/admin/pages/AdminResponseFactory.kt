package com.stroeer.ads.debugInfo.admin.pages

import fi.iki.elonen.NanoHTTPD

fun interface AdminResponseFactory {
    fun create(status: NanoHTTPD.Response.Status, mimeType: String, body: String): NanoHTTPD.Response
}
