package com.stroeer.ads.debugInfo.admin.pages

import fi.iki.elonen.NanoHTTPD

// Internal for the same reason as AdminHttpServer: NanoHTTPD is an `implementation` dependency,
// so NanoHTTPD.Response must not appear in a type publishers can see.
internal fun interface AdminResponseFactory {
    fun create(status: NanoHTTPD.Response.Status, mimeType: String, body: String): NanoHTTPD.Response
}
