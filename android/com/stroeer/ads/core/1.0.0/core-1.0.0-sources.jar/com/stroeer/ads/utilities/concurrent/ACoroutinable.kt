package com.stroeer.ads.utilities.concurrent

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.jetbrains.annotations.TestOnly
import kotlin.time.Duration.Companion.milliseconds

@Suppress("SpellCheckingInspection")
abstract class ACoroutinable {

    protected open var mainDispatcher: CoroutineDispatcher = Dispatchers.Main
    protected open var ioDispatcher: CoroutineDispatcher = Dispatchers.IO
    protected var mainScope = CoroutineScope(SupervisorJob() + mainDispatcher)

    protected val mutex = Mutex()

    @TestOnly
    fun setTestDispatcher(dispatcher: CoroutineDispatcher) {
        cancel()

        mainDispatcher = dispatcher
        ioDispatcher = dispatcher

        mainScope = CoroutineScope(SupervisorJob() + mainDispatcher)
    }

    open fun cancel() {
        mainScope.cancel()
    }

    suspend fun delay(delayMillis: Long, condition: (suspend () -> Boolean)? = null, timeoutMs: Long = 5000) : Boolean{
        return withTimeoutOrNull(timeoutMs.milliseconds) {
            while (condition?.invoke() == true) {
                delay(delayMillis)
            }
            true
        } ?: false
    }
}