package com.stroeer.ads.utilities.json

import com.stroeer.ads.utilities.concurrent.ACoroutinable
import com.stroeer.ads.utilities.http.HttpBody
import com.stroeer.ads.utilities.http.HttpClient
import com.stroeer.ads.utilities.http.HttpHeaders
import com.stroeer.ads.utilities.http.HttpMethod
import com.stroeer.ads.utilities.http.HttpRequest
import com.stroeer.ads.utilities.http.HttpResponse
import com.stroeer.ads.utilities.http.HttpTimeouts
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.CancellationException
import java.net.URI

/**
 * Sends JSON/text requests and returns the body as a String, or null on any failure.
 *
 * The "log it and return null" policy lives here rather than in the transport: [HttpClient] and
 * [com.stroeer.ads.utilities.http.HttpCall] throw, and this is the layer that decides a failed
 * fetch is not worth propagating to an ad-loading pipeline that can only carry on regardless.
 */
class HttpJsonRequest : ACoroutinable() {

    /**
     * @return the response body, or null if the request failed or answered with a non-2xx status.
     */
    suspend fun sendGetJson(
        url: String,
        headers: Map<String, String>?,
        timeoutInSecs: Int,
        senderClass: Class<*>
    ): String? {
        val response = sendGetForResponse(url, headers, timeoutInSecs, senderClass) ?: return null
        return if (response.isSuccessful) response.bodyText() else null
    }

    suspend fun sendPostJson(
        url: String,
        headers: Map<String, String>?,
        body: String,
        timeoutInSecs: Int,
        senderClass: Class<*>,
        contentType: String = CONTENT_TYPE_JSON
    ): String? {
        val request = HttpRequest(
            url = url,
            method = HttpMethod.POST,
            headers = HttpHeaders.of(headers),
            body = HttpBody.utf8(body, contentType),
            timeouts = HttpTimeouts.fromSeconds(timeoutInSecs)
        )

        val response = send(request, senderClass) ?: return null
        return if (response.isSuccessful) response.bodyText() else null
    }

    /**
     * A GET that hands back the whole [HttpResponse] instead of just a body.
     *
     * Callers doing conditional requests need the status code and headers - a `304` carries no
     * body at all, and its validators have to be read back off the response - which the
     * String-returning methods above deliberately hide. See
     * [com.stroeer.ads.config.loaders.ConfigHttpFetcher].
     */
    internal suspend fun sendGetForResponse(
        url: String,
        headers: Map<String, String>?,
        timeoutInSecs: Int,
        senderClass: Class<*>
    ): HttpResponse? {
        val request = HttpRequest.get(
            url = url,
            headers = HttpHeaders.of(headers),
            timeouts = HttpTimeouts.fromSeconds(timeoutInSecs)
        )

        return send(request, senderClass)
    }

    /**
     * Runs [request] and logs the outcome. Returns the response for any status the server
     * actually produced - including a non-2xx, which callers inspect - and null only when the
     * request could not be completed at all.
     */
    private suspend fun send(request: HttpRequest, senderClass: Class<*>): HttpResponse? {
        val senderClassName = senderClass.simpleName

        return try {
            val response = HttpClient.send(request, ioDispatcher)
            logOutcome(response, request, senderClassName)
            response
        } catch (e: CancellationException) {
            // A cancelled ad or config request is an expected part of the lifecycle, not a
            // failure: rethrown so the calling coroutine unwinds instead of being handed a null
            // that looks like a network error.
            throw e
        } catch (e: Exception) {
            Logger.e("[$senderClassName] Failed to fetch data - ${shorten(request.url)}", e)
            null
        }
    }

    private fun logOutcome(response: HttpResponse, request: HttpRequest, senderClassName: String) {
        val shortUrl = shorten(request.url)

        if (response.isSuccessful) {
            if (response.revalidated) {
                Logger.i("[$senderClassName] Not modified, served from cache: $shortUrl")
            } else {
                Logger.i("[$senderClassName] Fetched data successfully: $shortUrl")
            }
            return
        }

        Logger.e("[$senderClassName] Failed to fetch data - ${response.statusCode} ${response.message}")
        // The error body can echo back submitted identifiers or consent strings (ID5 does this
        // on 4xx), so it must not reach the persisted log file.
        Logger.dNotPersisted("[$senderClassName] Error response body: ${response.bodyText()}")
    }

    /**
     * The last two path segments, for a log line that identifies the resource without being a
     * full URL.
     *
     * Parsed as a URI and reduced to its *path*: a query string can carry identifiers or consent
     * data, and these log lines are persisted to stroeer.log.
     */
    private fun shorten(url: String): String {
        return try {
            val path = URI(url).path.orEmpty()
            path.split("/").filter { it.isNotEmpty() }.takeLast(2).joinToString("/")
                .ifEmpty { "/" }
        } catch (e: Exception) {
            Logger.e("Failed to shorten URL for logging", e)
            "unknown"
        }
    }

    private companion object {
        const val CONTENT_TYPE_JSON = "application/json; charset=utf-8"
    }
}
