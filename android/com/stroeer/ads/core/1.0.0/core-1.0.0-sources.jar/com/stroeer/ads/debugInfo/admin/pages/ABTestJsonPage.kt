package com.stroeer.ads.debugInfo.admin.pages

import com.stroeer.ads.config.ConfigurationManager
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject

internal class ABTestJsonPage(
    private val responseFactory: AdminResponseFactory
) {

    fun serve(): NanoHTTPD.Response {
        val config = ConfigurationManager.getInstance().getConfig()
        val obj = JSONObject()

        val abTest = config?.abTest
        obj.put("enabled", abTest?.active == true)
        obj.put("name", abTest?.name ?: "")

        val groups = JSONArray()
        abTest?.groups?.forEach { group ->
            val g = JSONObject()
            g.put("slots", JSONArray(group.slots))
            g.put("scope", group.scope)
            g.put("ratio", JSONObject().apply {
                put("main", group.ratio.main)
                put("test", group.ratio.test)
            })
            groups.put(g)
        }
        obj.put("groups", groups)

        val banners = JSONArray()
        config?.getBannerNames()?.forEach { name ->
            val slot = config.getAdSlot(name)
            banners.put(JSONObject().apply {
                put("name", name)
                put("active", slot?.active != false)
            })
        }
        obj.put("banners", banners)

        val interstitials = JSONArray()
        config?.getInterstitialNames()?.forEach { name ->
            val slot = config.getAdSlot(name)
            interstitials.put(JSONObject().apply {
                put("name", name)
                put("active", slot?.active != false)
            })
        }
        obj.put("interstitials", interstitials)

        return responseFactory.create(NanoHTTPD.Response.Status.OK, "application/json", obj.toString())
    }
}
