package com.stroeer.ads.plugins.identity.collectors

import android.webkit.WebSettings
import com.stroeer.ads.plugins.identity.ACollectorWithContext

/**
 * Return user agent
 */
class UaCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        return WebSettings.getDefaultUserAgent(applicationContext)
    }
}
