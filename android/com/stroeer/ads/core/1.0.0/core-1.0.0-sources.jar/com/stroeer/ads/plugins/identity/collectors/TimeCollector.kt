package com.stroeer.ads.plugins.identity.collectors

import com.stroeer.ads.plugins.identity.IIdentityCollector
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Return current date-time
 */
class TimeCollector : IIdentityCollector<String?> {
    private val timeFormat = "yyyy-MM-dd'T'HH:mm:ssXXX"

    override suspend fun retrieveData(): String? {
        val now = Date()
        val dateFormat = SimpleDateFormat(timeFormat, Locale.getDefault())
        dateFormat.timeZone = TimeZone.getDefault()
        return dateFormat.format(now)
    }
}
