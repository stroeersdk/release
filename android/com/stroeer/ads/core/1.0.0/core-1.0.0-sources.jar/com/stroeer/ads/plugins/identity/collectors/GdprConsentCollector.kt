package com.stroeer.ads.plugins.identity.collectors

import androidx.preference.PreferenceManager
import com.stroeer.ads.plugins.identity.ACollectorWithContext
import java.util.concurrent.CompletableFuture

/**
 * Return GDPR consent. Collect from IABTCF_TCString.
 */
class GdprConsentCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        val consentString = sharedPreferences.getString(GDPR_CONSENT_KEY, null)
        return if (consentString != null && consentString.isEmpty()) {
            null
        } else {
            consentString
        }
    }

    companion object {
        const val GDPR_CONSENT_KEY: String = "IABTCF_TCString"
    }
}
