package com.stroeer.ads.utilities.common

interface ISuccessListener<T> {
    fun onSuccess(data: T)
}
