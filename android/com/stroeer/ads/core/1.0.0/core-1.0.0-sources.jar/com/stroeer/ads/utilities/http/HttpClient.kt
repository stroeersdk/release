package com.stroeer.ads.utilities.http

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Entry point for the [HttpURLConnection]-based transport.
 *
 * A stateless object, unlike the shared-client singleton this replaced. `HttpURLConnection` pools
 * and reuses TCP connections process-wide underneath the SDK-visible API, so there is no
 * per-instance connection pool to configure, and building an `HttpURLConnection` is not expensive
 * the way building an `OkHttpClient` was. Nothing here is worth caching or sharing.
 */
object HttpClient {

    /** Creates a new, not-yet-started [HttpCall] for [request]. */
    fun newCall(request: HttpRequest): HttpCall = HttpCall(request)

    /** Blocking convenience for `newCall(request).execute()`. */
    fun execute(request: HttpRequest): HttpResponse = newCall(request).execute()

    /**
     * Suspending version of [execute]. Runs the blocking call on [dispatcher] and wires
     * coroutine cancellation to [HttpCall.cancel].
     *
     * `runInterruptible` alone would not be enough here: DNS resolution and socket I/O inside
     * `HttpURLConnection` do not reliably respond to thread interruption on Android, so a
     * cancelled coroutine could leave the underlying call running to completion regardless.
     * [HttpCall.cancel] is what actually aborts it, by disconnecting the live connection - see
     * its KDoc - so cancellation here explicitly invokes it via
     * [kotlinx.coroutines.suspendCancellableCoroutine]'s `invokeOnCancellation`, rather than
     * relying on interruption alone.
     */
    suspend fun send(request: HttpRequest, dispatcher: CoroutineDispatcher = Dispatchers.IO): HttpResponse {
        return withContext(dispatcher + CoroutineName("HttpClient.send")) {
            val call = newCall(request)
            suspendCancellableCoroutine { continuation ->
                continuation.invokeOnCancellation { call.cancel() }
                try {
                    val response = call.execute()
                    continuation.resume(response)
                } catch (e: Throwable) {
                    // A CancellationException here means invokeOnCancellation already fired (or
                    // is about to); resuming with it just propagates the cancellation instead of
                    // turning it into a value or an error the caller would log.
                    continuation.resumeWithException(e)
                }
            }
        }
    }
}
