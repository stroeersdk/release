package com.stroeer.ads.bidding.prebid

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.view.View
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.AdCategory
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.formats.banner.IBannerListenerRunner
import com.stroeer.ads.debugInfo.SdkDebugInfo
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.utilities.ui.SizeUtils
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.jetbrains.annotations.TestOnly
import org.prebid.mobile.ResultCode
import org.prebid.mobile.rendering.bidding.data.bid.Bid
import org.prebid.mobile.rendering.bidding.interfaces.BannerEventHandler
import org.prebid.mobile.rendering.bidding.listeners.BannerEventListener
import java.lang.ref.WeakReference
import kotlin.coroutines.resume

class BannerPrebidSdkAdapter(private val bannerConfig: BannerConfiguration, adUnitConverter: AdUnitConverter) : APrebidSdkAdapter(bannerConfig, adUnitConverter) {
    private var activityCallbacks: Application.ActivityLifecycleCallbacks? = null
    private var watchedActivityRef: WeakReference<Activity>? = null
    private var watchedAppRef: WeakReference<Application>? = null
    private var watchedViewRef: WeakReference<View>? = null
    private var detachListenerRef: WeakReference<View.OnAttachStateChangeListener>? = null


    override suspend fun getBid(): SdkResult {

        if (!isSdkInitialized()) {
            return SdkResult.FAILED
        }

        initPrebidAdUnit()
        updateContentUrl()
        updateDebugInfoForSend()

        var sdkResult = SdkResult.SKIPPED

        return withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->

                cont.invokeOnCancellation {
                    unregisterActivityWatcher()
                }

                if (bannerConfig.activityContext == null) {
                    cont.resume(SdkResult.FAILED)
                    return@suspendCancellableCoroutine
                }

                val weakConfig = WeakReference(bannerConfig)

                bannerConfig.prebidBannerView = PrebidBannerView(bannerConfig.activityContext!!, bannerConfig.configAdSlot!!.prebidConfigId!!, object : BannerEventHandler {

                    override fun getAdSizeArray(): Array<out org.prebid.mobile.AdSize?> {
                        val config = weakConfig.get() ?: return emptyArray()
                        return config.availableBannerSizes
                            .map { size -> org.prebid.mobile.AdSize(size.width, size.height) }
                            .toTypedArray()
                    }

                    override fun setBannerEventListener(bannerViewListener: BannerEventListener) {
                        weakConfig.get()?.prebidEventHandler = bannerViewListener
                    }

                    override fun requestAdWithBid(bid: Bid?) {
                        Logger.d("[BannerPrebidSdkAdapter] requestAdWithBid is called - ${weakConfig.get()?.adSlotId}")
                        weakConfig.get()?.let{
                            sdkResult = renderBidInPrebidHtmlBannerView(it, bid)
                        }
                        if(cont.isActive) {
                            cont.resume(sdkResult)
                        }
                    }

                    override fun trackImpression() {
                    }

                    override fun destroy() {
                        Logger.d("[BannerPrebidSdkAdapter] destroy is called - ${weakConfig.get()?.adSlotId}")
                        unregisterActivityWatcher()
                        if (cont.isActive) {
                            cont.resume(SdkResult.NOT_AVAILABLE)
                        }
                    }
                })

                bannerConfig.prebidBannerView?.pbAdSlot = bannerConfig.adUnitId


                // create custom targeting
                val customTargeting = bannerConfig.customTargeting
                    .takeIf { it.isNotEmpty() } // If not empty
                    ?.entries
                    ?.joinToString(", ") { (k, v) -> "\"$k\":\"$v\"" }
                    ?.let { ", $it" }
                    ?: ""

                // update imp json
                bannerConfig.prebidBannerView?.impOrtbConfig = getImpSetup(bannerConfig.adUnitId, customTargeting)

                Logger.d("[BannerPrebidSdkAdapter] Prebid loadAd is called - ${bannerConfig.adSlotId}")
                bannerConfig.prebidBannerView?.loadAd()
            }
        }
    }

    fun createAndLoadPrebidHtmlBannerView(bannerConfig: BannerConfiguration) {
        bannerConfig.prebidHtmlBannerView = PrebidHtmlBannerView(bannerConfig.activityContext!!)
        bannerConfig.prebidAdSize?.let { size ->
            bannerConfig.prebidHtmlBannerView?.setAdSize(
                size.width,
                size.height
            )
        }

        val weakConfig = WeakReference(bannerConfig)
        bannerConfig.prebidHtmlBannerView?.setListener(object : IBannerListenerRunner {
            override fun onAdClosed() {
                Logger.i("[BannerPrebidSdkAdapter] onAdClosed has been called - ${weakConfig.get()?.adSlotId}")
                weakConfig.get()?.publisherBannerListenerRunner?.onAdClosed()
            }

            override fun onAdFailedToLoad(error: StroeerException, description: String, beforeStart: (suspend () -> Unit)?, finish: Boolean) {
                Logger.e("[BannerPrebidSdkAdapter] onAdFailedToLoad has been called - ${weakConfig.get()?.adSlotId}, Error: ${error.message}")
                weakConfig.get()?.publisherBannerListenerRunner?.onAdFailedToLoad(error, description, {
                    updateDebugInfoForFail(weakConfig.get(), mutableMapOf<String, String?>().apply { put("Failed", error.message) })
                }, finish)
            }

            override fun onAdOpened() {
                Logger.i("[BannerPrebidSdkAdapter] onAdOpened has been called - ${weakConfig.get()?.adSlotId}")
                weakConfig.get()?.publisherBannerListenerRunner?.onAdOpened()
            }

            override fun onAdLoaded(beforeStart: (suspend () -> Boolean)?) {
                Logger.i("[BannerPrebidSdkAdapter] onAdLoaded has been called - ${weakConfig.get()?.adSlotId}")
                weakConfig.get()?.publisherBannerListenerRunner?.onAdLoaded()
            }

            override fun onAdClicked() {
                Logger.i("[BannerPrebidSdkAdapter] onAdClicked has been called - ${weakConfig.get()?.adSlotId}")
                weakConfig.get()?.publisherBannerListenerRunner?.onAdClicked()
            }

            override fun onAdImpression() {
                Logger.i("[BannerPrebidSdkAdapter] onAdImpression has been called - ${weakConfig.get()?.adSlotId}")
                weakConfig.get()?.publisherBannerListenerRunner?.onAdImpression()
            }
        })

        if(bannerConfig.prebidHtmlBannerView != null){
            bannerConfig.bannerView?.addBannerAdView(bannerConfig.prebidHtmlBannerView!!)
            registerActivityWatcher(bannerConfig.activityContext, bannerConfig.prebidHtmlBannerView)
        }else
        {
            Logger.e("[BannerPrebidSdkAdapter] Missing prebidHtmlBannerView - ${bannerConfig.adSlotId}")
        }
    }

    private fun renderBidInPrebidHtmlBannerView(bannerConfig: BannerConfiguration, bid: Bid?): SdkResult {

        val adSlotId = bannerConfig.adSlotId

        if (bid != null) {
            var resultCode = ResultCode.NO_BIDS

            bannerConfig.prebidBannerView?.price = bid.price
            bannerConfig.prebidBannerView?.targeting = bid.prebid.targeting
            bannerConfig.prebidAdSize = bid.prebid.targeting["hb_size"]?.let { SizeUtils.parseSize(it) }

            // somehow, gdrp_consent is null
            if (!bid.adm.isNullOrEmpty()) {
                bid.adm = bid.adm.replace("\${GDPR_CONSENT}", bannerConfig.tcString)
                resultCode = ResultCode.SUCCESS
            }

            val sdkResult = getSdkResult(resultCode, bid.prebid.targeting)

            if (resultCode == ResultCode.SUCCESS && !bid.adm.isNullOrEmpty()) {

                bannerConfig.prebidCacheIdentifier = getPrebidAdCacheIdFromTargeting(sdkResult.keyValues)

                savePrebidAdSize(bannerConfig , sdkResult.keyValues)
                updatedDebugInfoForResult(bid.prebid.targeting.toMutableMap(), bannerConfig.prebidBannerView?.bidResponse)

                if(ConfigurationManager.forcePrebidRendering || bannerConfig.prebidBannerView?.isDirectRenderingEnabled() == true) {
                    sdkResult.category = AdCategory.CAMPAIGN

                    Logger.d("[BannerPrebidSdkAdapter] Rendering HTML in PrebidHtmlBannerView - $adSlotId - cacheId=${bannerConfig.prebidCacheIdentifier}")
                    createAndLoadPrebidHtmlBannerView(bannerConfig)
                    bannerConfig.adSize = bannerConfig.prebidAdSize
                    bannerConfig.prebidHtmlBannerView?.setHtml(bid.adm)
                }
            } else {
                Logger.d("[BannerPrebidSdkAdapter] No bids / empty adm - $adSlotId")
                unregisterActivityWatcher()
            }

            return sdkResult
        } else {
            unregisterActivityWatcher()
            return getSdkResult(ResultCode.NO_BIDS, mutableMapOf())
        }
    }

    @TestOnly
    fun renderBidInPrebidHtmlBannerViewTest (bannerConfig: BannerConfiguration, bid: Bid?): SdkResult {
        return renderBidInPrebidHtmlBannerView(bannerConfig, bid)
    }

    private fun registerActivityWatcher(ctx: Context?, view: PrebidHtmlBannerView?) {
        unregisterActivityWatcher()

        val activity = ctx as? Activity ?: return
        val app = activity.application ?: return

        watchedActivityRef = WeakReference(activity)
        watchedAppRef = WeakReference(app)
        watchedViewRef = WeakReference(view)

        val viewRef = WeakReference(view)

        val detachListener = object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
            }
            override fun onViewDetachedFromWindow(v: View) {
                unregisterActivityWatcher()
            }
        }
        detachListenerRef = WeakReference(detachListener)
        view?.addOnAttachStateChangeListener(detachListener)

        activityCallbacks = object : Application.ActivityLifecycleCallbacks {

            override fun onActivityResumed(a: Activity) {
                val watched = watchedActivityRef?.get()
                if (watched != null && watched === a) {
                    viewRef.get()?.onHostResumed()
                }
            }

            override fun onActivityPaused(a: Activity) {
                val watched = watchedActivityRef?.get()
                if (watched != null && watched === a) {
                    viewRef.get()?.onHostPaused()
                }
            }

            override fun onActivityDestroyed(a: Activity) {
                val watched = watchedActivityRef?.get()
                if (watched != null && watched === a) {
                    unregisterActivityWatcher()
                }
            }

            override fun onActivityCreated(a: Activity, b: Bundle?) {
            }

            override fun onActivityStarted(a: Activity) {
            }

            override fun onActivityStopped(a: Activity) {
            }

            override fun onActivitySaveInstanceState(a: Activity, outState: Bundle) {
            }
        }

        app.registerActivityLifecycleCallbacks(activityCallbacks)
    }

    private fun unregisterActivityWatcher() {
        val cb = activityCallbacks
        activityCallbacks = null

        val app = watchedAppRef?.get()
        watchedAppRef = null

        val view = watchedViewRef?.get()
        watchedViewRef = null

        val detachListener = detachListenerRef?.get()
        detachListenerRef = null
        if (view != null && detachListener != null) {
            try {
                view.removeOnAttachStateChangeListener(detachListener)
            } catch (_: Throwable) {
            }
        }

        watchedActivityRef = null

        if (app != null && cb != null) {
            try {
                app.unregisterActivityLifecycleCallbacks(cb)
            } catch (_: Throwable) {
            }
        }
    }

    private fun updateDebugInfoForFail(bannerConfig: BannerConfiguration?, keyValues: MutableMap<String, String?>?) {
        if (ConfigurationManager.isInspectionMode) {
            bannerConfig?.debugInfo?.let {
                val prebidDebugInfo = SdkDebugInfo()
                prebidDebugInfo.adSlotId = bannerConfig.adSlotId
                prebidDebugInfo.description = "Failed from Prebid"
                prebidDebugInfo.keyValues = keyValues
                it.sdkDebugInfos.add(prebidDebugInfo)
            }
        }
    }

    private fun savePrebidAdSize(bannerConfig: BannerConfiguration, keyValuesFromPrebid: MutableMap<String, String>?) {
        keyValuesFromPrebid?.let {
            val size = keyValuesFromPrebid[PrebidToGAMKeyValueMapper.CustomTargetingMapping.size.ylKey]
            bannerConfig.prebidAdSize = SizeUtils.parseSize(size)
        }
    }
}