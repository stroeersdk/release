package com.stroeer.ads.config.abTest

import android.content.Context
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.stroeer.ads.config.ConfigConstants
import com.stroeer.ads.config.objects.ConfigABTestGroup
import com.stroeer.ads.utilities.logging.Logger

object ConfigurationRatioManager {

    private val ratioManagers = mutableMapOf<String, IRatioWindow>()

    // Signature of the currently applied groups. Used to avoid rebuilding (and thus resetting
    // the in-progress request windows and accumulated counters) when the config is unchanged.
    private var currentSignature: String? = null

    @Synchronized
    fun setGroups(groups: List<ConfigABTestGroup>?, context: Context?) {
        val signature = groups?.joinToString(";") { group ->
            "${group.slots.joinToString(",")}|${group.scope}|${group.ratio.main}:${group.ratio.test}"
        }

        // Only reset when the configuration actually changed.
        if (signature == currentSignature) return
        currentSignature = signature

        ratioManagers.clear()

        // Session windows that are still configured; everything else under the AB_SESSION_
        // prefix is orphaned (slot list changed) and should be pruned from SharedPreferences.
        val activeSessionKeys = mutableSetOf<String>()

        groups?.forEach { group ->
            val slotsName = group.slots.joinToString(",")
            when (group.scope) {
                "request" -> {
                    val sharedWindow = RatioWindow(slotsName, group.ratio.main, group.ratio.test)
                    group.slots.forEach { ratioManagers[it] = sharedWindow }
                }
                else -> {
                    val sharedWindow =
                        SessionRatioWindow(slotsName, group.ratio.main, group.ratio.test, context)
                    group.slots.forEach { ratioManagers[it] = sharedWindow }
                    activeSessionKeys.add(ConfigConstants.PREFS_AB_SESSION_PREFIX + slotsName)
                }
            }
        }

        pruneOrphanedSessionPrefs(context, activeSessionKeys)
    }

    /** Removes persisted AB_SESSION_ entries that are no longer backed by an active group. */
    private fun pruneOrphanedSessionPrefs(context: Context?, activeKeys: Set<String>) {
        val prefs = context?.let { PreferenceManager.getDefaultSharedPreferences(it) } ?: return
        val orphaned = prefs.all.keys.filter {
            it.startsWith(ConfigConstants.PREFS_AB_SESSION_PREFIX) && it !in activeKeys
        }
        if (orphaned.isEmpty()) return
        prefs.edit { orphaned.forEach { remove(it) } }
    }

    @Synchronized
    fun findSessionGroup(adSlotId: String): String? {
        return findRatioManager(adSlotId)?.getConfiguredRatio()
    }

    @Synchronized
    fun useMain(adSlotId: String): Boolean {
        val ret = findRatioManager(adSlotId)?.useMain() ?: true
        Logger.i("[ConfigurationRatioManager] $adSlotId use ${if (ret) "MAIN" else "TEST"}, ${getCurrentRunningRatio(adSlotId)}")
        return ret
    }

    @Synchronized
    fun getConfiguredRatio(adSlotId: String): String {
        return findRatioManager(adSlotId)?.getConfiguredRatio() ?: "1:0"
    }

    @Synchronized
    fun getCurrentRunningRatio(adSlotId: String): String {
        return findRatioManager(adSlotId)?.getCurrentRunningRatio()
            ?: "(conf-0:0, run-0:0, 100.0% Main in the group of $adSlotId)"
    }

    private fun findRatioManager(adSlotId: String): IRatioWindow? {
        ratioManagers[adSlotId]?.let { return it }

        return ratioManagers
            .filterKeys { key -> key != "*" && adSlotId.contains(key) }
            .maxByOrNull { it.key.length }
            ?.value
            ?: ratioManagers["*"]
    }

    @Synchronized
    override fun toString(): String {
        if (ratioManagers.isEmpty()) return "No AB test groups configured"

        return buildString {
            ratioManagers.forEach { (slot, manager) ->
                appendLine("  $slot -> ${manager.getConfiguredRatio()} in the group of ${manager.slotsName}")
            }
        }
    }
}