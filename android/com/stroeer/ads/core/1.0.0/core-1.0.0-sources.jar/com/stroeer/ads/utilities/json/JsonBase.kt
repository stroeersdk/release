package com.stroeer.ads.utilities.json

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.stroeer.ads.utilities.logging.Logger

open class JsonBase<T> {

    open fun toJson(): String? {
        return try {
            val json = getGson().toJson(this)
            if (json == "null") null else json
        } catch (e: Exception) {
            Logger.e("[${javaClass.name}] Failed to convert to json", e)
            null
        }
    }

    fun toPrettyJson(): String? {
        return try {
            val json = getPrettyGson().toJson(this)
            if (json == "null") null else json
        } catch (e: Exception) {
            Logger.e("[${javaClass.name}] Failed to convert to pretty json", e)
            null
        }
    }

    companion object {
        private val prettyGson: Gson = GsonBuilder()
            .setPrettyPrinting()
            .create()

        private val gson = Gson()

        protected fun getGson(): Gson {
            return gson
        }

        protected fun getPrettyGson(): Gson {
            return prettyGson
        }

        fun <T> fromJson(json: String?, clazz: Class<T>): T? {
            if (json.isNullOrBlank()) {
                return null
            }

            return try {
                getGson().fromJson(json, clazz)
            } catch (e: Exception) {
                Logger.e("[${clazz.name}] Failed to parse from json", e)
                null
            }
        }
    }
}