package com.stroeer.ads.reporting.events

import com.google.gson.JsonObject
// import com.stroeer.ads.bidding.ISdkAdapter
import com.stroeer.ads.utilities.logging.Logger
import com.stroeer.ads.formats.BidderRecognizer
import com.stroeer.ads.bidding.ISdkAdapter
import com.stroeer.ads.bidding.SdkResultCode

//class BidderRespondedSuccessfully(var adapter: ISdkAdapter) : TimeEvent() {
//    override fun toJsonObject(): JsonObject {
//        val jsonObject = super.toJsonObject()
//        try {
//            jsonObject.addProperty("bidder", adapter.name)
//        } catch (e: Exception) {
//            Logger.e("[BidderRespondedSuccessfully] Error while creating JSON object", e)
//        }
//
//        return jsonObject
//    }
//}

class BidderRespondedSuccessfully(var adapter: ISdkAdapter, val resultCode : SdkResultCode) : TimeEvent() {
    override fun toJsonObject(): JsonObject {
        val jsonObject = super.toJsonObject()
        try {
            jsonObject.addProperty("bidder", BidderRecognizer.getBidderName(this.adapter))
            jsonObject.addProperty("resultCode", resultCode.toString())
        } catch (e: Exception) {
            Logger.e("[BidderRespondedSuccessfully] Error while creating JSON object", e)
        }

        return jsonObject
    }
}