package com.stroeer.ads.debugInfo.admin.pages

import android.content.Context
import java.net.Inet4Address
import java.net.NetworkInterface

internal object AdminPageUtils {

    fun loadHtmlTemplate(context: Context, path: String): String {
        return context.assets.open(path)
            .bufferedReader()
            .use { it.readText() }
    }

    fun getDeviceIpAddress(): String {
        try {
            for (netInfo in NetworkInterface.getNetworkInterfaces()) {
                for (addr in netInfo.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {}
        return "unknown"
    }
}
