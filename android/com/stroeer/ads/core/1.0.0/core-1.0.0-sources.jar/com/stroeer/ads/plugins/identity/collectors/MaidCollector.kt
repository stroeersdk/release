package com.stroeer.ads.plugins.identity.collectors

import android.annotation.SuppressLint
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.stroeer.ads.plugins.identity.ACollectorWithContext
import com.stroeer.ads.utilities.logging.Logger

/**
 * Return Mobile Advertising ID
 */
class MaidCollector : ACollectorWithContext<String?>() {
    @SuppressLint("AdvertisingIdPolicy")
    override suspend fun retrieveData(): String? {
        return try {
            val adInfo = AdvertisingIdClient.getAdvertisingIdInfo(applicationContext)
            // Honour the OS-level "Delete/opt out of advertising ID" choice. Not every Android
            // version zeroes the ID itself, so the flag has to be checked explicitly.
            if (adInfo.isLimitAdTrackingEnabled) {
                Logger.d("[MaidCollector] Limit ad tracking is enabled. MAID is not collected.")
                null
            } else {
                adInfo.id
            }
        } catch (ex: Exception) {
            Logger.e("[MaidCollector] Failed to get MAID", ex)
            null
        }
    }
}
