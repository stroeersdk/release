package com.stroeer.ads.utilities.http

import java.io.IOException

/**
 * Signals a transport-level failure: a malformed URL, a disallowed scheme, too many redirects,
 * a redirect that would downgrade https to http, a cancelled call, or an exceeded deadline.
 *
 * Extends [IOException] so existing `catch (e: Exception)` / `catch (e: IOException)` call sites
 * (e.g. [com.stroeer.ads.utilities.json.HttpJsonRequest]) keep working unchanged when this
 * transport is swapped in underneath them.
 */
open class HttpTransportException(message: String, cause: Throwable? = null) : IOException(message, cause) {

    /** Raised specifically when the request's [HttpTimeouts.callMillis] deadline is exceeded. */
    class Timeout(message: String, cause: Throwable? = null) : HttpTransportException(message, cause)
}
