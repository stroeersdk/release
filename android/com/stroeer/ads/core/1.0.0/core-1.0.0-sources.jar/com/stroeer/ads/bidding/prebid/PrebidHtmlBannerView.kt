package com.stroeer.ads.bidding.prebid

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.util.AttributeSet
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.net.toUri
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.banner.IBannerListenerRunner
import com.stroeer.ads.utilities.logging.Logger
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.roundToInt

/**
 * Renders a Prebid HTML creative in a WebView.
 *
 * Threading: all mutable state in this class is confined to the main thread. The public entry
 * points hop there themselves, so they are safe to call from anywhere, and the JavaScript bridge
 * hops before touching anything. WebView client callbacks already arrive on the main thread.
 * The remaining atomics are kept for their once-only semantics, not for cross-thread access, except
 * [destroyed], which is also read off the main thread to reject work early.
 */
class PrebidHtmlBannerView : FrameLayout {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val listenerRef = AtomicReference<IBannerListenerRunner?>()

    private val destroyed = AtomicBoolean(false)
    private val loadedSent = AtomicBoolean(false)
    private val failedSent = AtomicBoolean(false)
    private val impressionSent = AtomicBoolean(false)
    private val pageFinished = AtomicBoolean(false)
    private val browserOpened = AtomicBoolean(false)

    private val loadGeneration = AtomicInteger(0)

    /**
     * Generation of the load that was last handed to the WebView. WebView callbacks are attributed
     * to this rather than to [loadGeneration], which setHtml() may already have moved on.
     */
    private var activeLoadGeneration: Int = 0

    private var scrollListener: ViewTreeObserver.OnScrollChangedListener? = null
    private var globalLayoutListener: ViewTreeObserver.OnGlobalLayoutListener? = null
    private var impressionObserver: ViewTreeObserver? = null
    private var preDrawListener: ViewTreeObserver.OnPreDrawListener? = null
    private var preDrawObserver: ViewTreeObserver? = null

    private var webView: WebView? = null
    private var popupWebView: WebView? = null
    private var lastHtml: String? = null

    private var sizeWidthPx: Int = 0
    private var sizeHeightPx: Int = 0

    private var loadTimeoutMs: Long = DEFAULT_LOAD_TIMEOUT_MS
    private var watchdogRunnable: Runnable? = null

    /**
     * Uptime of the last real touch on this view. External navigation is only honoured shortly
     * after one, so a creative cannot launch the browser on its own.
     */
    private var lastTouchUptimeMs: Long = 0L

    constructor(context: Context) : super(context) { initView() }
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) { initView() }
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) { initView() }

    fun setListener(listener: IBannerListenerRunner) {
        listenerRef.set(listener)
    }

    fun setLoadTimeoutMs(timeoutMs: Long) {
        runOnMain(Runnable {
            loadTimeoutMs = if (timeoutMs > 0L) timeoutMs else DEFAULT_LOAD_TIMEOUT_MS
        })
    }

    fun setAdSize(widthDp: Int, heightDp: Int) = runOnMain(Runnable {
        if (destroyed.get()) {
            return@Runnable
        }

        val metrics = resources.displayMetrics
        sizeWidthPx = dpToPx(widthDp, metrics)
        sizeHeightPx = dpToPx(heightDp, metrics)

        applySize()
    })

    fun setHtml(html: String) {
        if (destroyed.get()) {
            return
        }

        // Invalidate the previous load here rather than on the main thread, so that a callback
        // already queued for the old creative cannot be attributed to this one when the caller is
        // not on the main thread itself.
        val gen = loadGeneration.incrementAndGet()

        runOnMain(Runnable { startLoad(html, gen) })
    }

    private fun startLoad(html: String, gen: Int) {
        if (destroyed.get() || gen != loadGeneration.get()) {
            return
        }

        lastHtml = html

        loadedSent.set(false)
        failedSent.set(false)
        impressionSent.set(false)
        pageFinished.set(false)
        unregisterImpressionListeners()

        // A callback left pending by an earlier setHtml() would load this html a second time.
        unregisterPreDrawListener()

        val listener = object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                if (!isShown) return true

                // Once the webview is shown, then don't draw again.
                unregisterPreDrawListener()
                runOnMain(Runnable {
                    if (destroyed.get()) {
                        return@Runnable
                    }
                    val wv = ensureWebView()
                    applySize()
                    prepareForNewLoad(wv, gen)
                    scheduleWatchdog(gen)

                    try {
                        activeLoadGeneration = gen
                        // Use the html captured for this generation, not the lastHtml field, so a
                        // pending callback cannot render newer html under an older generation.
                        wv.loadDataWithBaseURL(LOCALHOST_BASE_URL, HTMLInjector.wrapHtml(html, gen, sizeWidthPx, sizeHeightPx), "text/html", StandardCharsets.UTF_8.name(), null)
                    } catch (t: Throwable) {
                        Logger.e("[PrebidHtmlBannerView] loadDataWithBaseURL failed", t)
                        notifyFailedOnce(StroeerException("PrebidHtmlBannerView: loadDataWithBaseURL failed - $t"), gen)
                    }
                })

                return true
            }
        }

        val observer = viewTreeObserver
        preDrawListener = listener
        preDrawObserver = observer
        observer.addOnPreDrawListener(listener)
    }

    private fun unregisterPreDrawListener() {
        val listener = preDrawListener ?: return
        val observer = preDrawObserver
        preDrawListener = null
        preDrawObserver = null
        tolerate("removeOnPreDrawListener") {
            // The observer captured at registration may already be dead after a detach, in which
            // case the current one is the live replacement.
            if (observer != null && observer.isAlive) {
                observer.removeOnPreDrawListener(listener)
            } else {
                viewTreeObserver.removeOnPreDrawListener(listener)
            }
        }
    }

    fun onHostResumed() {
        if (browserOpened.compareAndSet(true, false)) {
            runOnMain(Runnable { notifyClosed() })
        }
        runOnMain(Runnable {
            resumeWebView()
        })
    }

    fun onHostPaused() {
        runOnMain(Runnable {
            pauseWebView()
        })
    }

    fun destroy() {
        if (!destroyed.compareAndSet(false, true)) {
            return
        }
        runOnMain(Runnable {
            cancelWatchdog()
            unregisterImpressionListeners()
            unregisterPreDrawListener()
            popupWebView?.let { destroyPopupWebView(it) }
            val wv = webView
            webView = null
            removeAllViews()
            if (wv != null) {
                tolerate("stopLoading on destroy") { wv.stopLoading() }
                tolerate("clearing the WebViewClient") { wv.webViewClient = WebViewClient() }
                tolerate("clearing the WebChromeClient") { wv.webChromeClient = WebChromeClient() }
                tolerate("removing the WebView children") { wv.removeAllViews() }
                tolerate("destroying the WebView") { wv.destroy() }
            }

            // Leave no dead view behind in the publisher's banner container.
            tolerate("detaching from the banner container") {
                (parent as? ViewGroup)?.removeView(this@PrebidHtmlBannerView)
            }
            listenerRef.set(null)
            lastHtml = null
        })
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            onImpressionRecheck(loadGeneration.get())
        }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            onImpressionRecheck(loadGeneration.get())
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP -> lastTouchUptimeMs = SystemClock.uptimeMillis()
        }
        return super.dispatchTouchEvent(ev)
    }

    /**
     * @param reportedAtUptimeMs when the navigation was reported. It is passed in rather than read
     * here because a report arriving on the JavaScript bridge thread is evaluated on the main
     * thread, and a busy main thread must not turn a real click into a blocked one.
     */
    private fun hasRecentUserTouch(reportedAtUptimeMs: Long): Boolean {
        val last = lastTouchUptimeMs
        if (last <= 0L) {
            return false
        }
        val elapsed = reportedAtUptimeMs - last
        return elapsed in 0..USER_TOUCH_WINDOW_MS
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        // The observer these were registered on does not survive the detach.
        unregisterImpressionListeners()
        onHostPaused()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        runOnMain(Runnable {
            resumeWebView()
            // Re-arm an impression that is still outstanding, otherwise a banner detached before it
            // became visible would never report one.
            if (!destroyed.get() && !impressionSent.get() && pageFinished.get()) {
                checkAndNotifyImpression(loadGeneration.get())
            }
        })
    }

    private fun resumeWebView() {
        val wv = webView ?: return
        tolerate("WebView onResume") { wv.onResume() }
    }

    private fun pauseWebView() {
        val wv = webView ?: return
        tolerate("WebView onPause") { wv.onPause() }
    }

    private fun initView() {
        isClickable = true
        isFocusable = true
        runOnMain(Runnable { ensureWebView(); applySize() })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView(): WebView {
        val existing = webView
        if (existing != null) {
            return existing
        }

        val wv = WebView(context.applicationContext)
        wv.visibility = VISIBLE
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.overScrollMode = OVER_SCROLL_NEVER
        wv.setBackgroundColor(0x00000000)
        tolerate("enabling the hardware layer") { wv.setLayerType(LAYER_TYPE_HARDWARE, null) }

        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadsImagesAutomatically = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        tolerate("enabling offscreenPreRaster") { s.offscreenPreRaster = true }

        wv.addJavascriptInterface(BannerJsBridge(), "StroeerBridge")

        wv.webChromeClient = object : WebChromeClient() {

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val transport = resultMsg.obj as WebView.WebViewTransport
                val tmp = WebView(view.context)
                // A popup that never navigates and is never closed - window.open('') or a document
                // written by script - reaches neither cleanup path, so keep a handle on it.
                trackPopupWebView(tmp)
                tmp.settings.javaScriptEnabled = true
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        val u = request.url?.toString() ?: return true
                        openExternalFromWebView(u)
                        destroyPopupWebView(v)
                        return true
                    }

                    @Deprecated("Deprecated in Java")
                    override fun shouldOverrideUrlLoading(v: WebView, url: String): Boolean {
                        openExternalFromWebView(url)
                        destroyPopupWebView(v)
                        return true
                    }
                }
                transport.webView = tmp
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView) {
                destroyPopupWebView(window)
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageCommitVisible(view: WebView, url: String?) {
                super.onPageCommitVisible(view, url)

                // The first pixels of the creative have been painted, so the ad is on screen even
                // if a slow subresource keeps the page from ever finishing.
                if (isCreativeUrl(url)) {
                    notifyLoadedOnce(activeLoadGeneration)
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)

                // Ignore the "about:blank" load done in prepareForNewLoad(); it is not the creative
                // and must not mark the page ready or trigger an impression.
                if (!isCreativeUrl(url)) {
                    return
                }

                // Attribute the callback to the load that was actually handed to the WebView, not
                // to whatever generation setHtml() has reached in the meantime. Otherwise a
                // page-finish left over from the previous creative reports the new one as loaded.
                val gen = activeLoadGeneration

                // Report loaded only once the creative page has finished. Reporting it from
                // onPageStarted would fire for the about:blank load, cancel the watchdog before the
                // creative is fetched, and suppress any later main frame error.
                notifyLoadedOnce(gen)

                injectImpressionAndClickTracking(view, gen)

                // Native backstop: if the injected JS never calls StroeerBridge.onReady
                // (e.g. CSP blocks the script, or IntersectionObserver is unavailable),
                // still mark the page ready and evaluate the impression natively.
                // notifyImpressionOnce is idempotent, so this never double-fires with the JS path.
                runOnMain(Runnable {
                    if (destroyed.get() || gen != loadGeneration.get()) {
                        return@Runnable
                    }
                    pageFinished.set(true)
                    checkAndNotifyImpression(gen)
                })
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url?.toString()
                if (u.isNullOrBlank()) {
                    return false
                }
                return handleNavigation(u, request.isForMainFrame, request.hasGesture())
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleNavigation(url, true, false)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    notifyFailedOnce(StroeerException("PrebidHtmlBannerView: WebView error ${error.errorCode}: ${error.description}"), activeLoadGeneration)
                }
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                notifyFailedOnce(StroeerException("PrebidHtmlBannerView: render process gone"), activeLoadGeneration)

                // if somehow webview is broken, then hide it and prevent further issues
                val dead = view
                runOnMain{
                    if (webView === dead) {
                        webView = null
                    }
                    tolerate("detaching the dead WebView") { (dead.parent as? ViewGroup)?.removeView(dead) }
                    // The renderer is gone; the WebView is unusable and must be destroyed to
                    // release the resources still associated with it.
                    tolerate("destroying the dead WebView") { dead.destroy() }

                    visibility = GONE
                    layoutParams = layoutParams?.apply {
                        height = 0
                        width = 0
                    } ?: LayoutParams(0, 0)
                    requestLayout()
                }
                return true
            }
        }

        removeAllViews()
        addView(wv)
        webView = wv
        return wv
    }

    /**
     * Releases the throwaway WebView handed to the transport in onCreateWindow, which would
     * otherwise leak a WebView and its renderer for every window.open() a creative performs.
     * The destroy is posted because it is called from one of the WebView's own callbacks.
     */
    private fun trackPopupWebView(popup: WebView) {
        // Only one popup can be outstanding at a time; releasing the previous one bounds the number
        // of WebViews a creative can accumulate by calling window.open() repeatedly.
        val previous = popupWebView
        popupWebView = popup
        if (previous != null && previous !== popup) {
            destroyPopupWebView(previous)
        }
    }

    private fun destroyPopupWebView(popup: WebView) {
        if (popup === webView) {
            return
        }
        if (popupWebView === popup) {
            popupWebView = null
        }
        mainHandler.post {
            tolerate("stopLoading on the popup") { popup.stopLoading() }
            tolerate("clearing the popup WebViewClient") { popup.webViewClient = WebViewClient() }
            tolerate("detaching the popup") { (popup.parent as? ViewGroup)?.removeView(popup) }
            tolerate("destroying the popup") { popup.destroy() }
        }
    }

    private fun applySize(){
        if (destroyed.get()) {
            return
        }

        applySize(this, false)
        webView?.let{
            applySize(it, true)
        }
    }

    private fun applySize(target: View, allowWrapContentFallback: Boolean) {
        val width = if (sizeWidthPx > 0) sizeWidthPx else if (allowWrapContentFallback) LayoutParams.WRAP_CONTENT else return
        val height = if (sizeHeightPx > 0) sizeHeightPx else if (allowWrapContentFallback) LayoutParams.WRAP_CONTENT else return

        val params = (target.layoutParams as? LayoutParams)
            ?: LayoutParams(width, height)

        params.width = width
        params.height = height
        params.gravity = Gravity.CENTER_HORIZONTAL

        target.layoutParams = params
        target.requestLayout()
    }

    private fun prepareForNewLoad(wv: WebView, gen: Int) {
        cancelWatchdog()
        tolerate("stopLoading before a new load") { wv.stopLoading() }
        tolerate("clearing the WebView before a new load") { wv.loadUrl("about:blank") }
        // The per-load flags were already reset by setHtml() when this generation was created.
        if (gen == loadGeneration.get()) {
            wv.visibility = VISIBLE
        }
    }

    private fun scheduleWatchdog(gen: Int) {
        cancelWatchdog()
        val r = Runnable {
            if (destroyed.get()) {
                return@Runnable
            }
            if (gen != loadGeneration.get()) {
                return@Runnable
            }
            if (loadedSent.get() || failedSent.get()) {
                return@Runnable
            }
            notifyFailedOnce(StroeerException("PrebidHtmlBannerView: load timeout ${loadTimeoutMs}ms"), gen)
        }
        watchdogRunnable = r
        mainHandler.postDelayed(r, loadTimeoutMs)
    }

    private fun cancelWatchdog() {
        watchdogRunnable?.also { mainHandler.removeCallbacks(it) }
        watchdogRunnable = null
    }

    private fun handleNavigation(url: String, isMainFrame: Boolean, hasGesture: Boolean): Boolean {
        val lower = url.lowercase()

        if (lower.startsWith("about:") || lower.startsWith("data:") || lower.startsWith("javascript:")) {
            return false
        }

        if (isLocalhostNav(lower)) {
            return true
        }

        if (!hasGesture && !isMainFrame) {
            return true
        }

        openExternalFromWebView(url)
        return true
    }

    /**
     * True when a page callback belongs to the creative rather than to the "about:blank" load that
     * prepareForNewLoad() issues to clear the WebView.
     */
    private fun isCreativeUrl(url: String?): Boolean {
        return url != null && !url.startsWith("about:blank")
    }

    private fun isLocalhostNav(lower: String): Boolean {
        return lower.startsWith(LOCALHOST_BASE_URL) || lower.startsWith("http://localhost/")
    }

    private fun openExternalFromWebView(url: String, reportedAtUptimeMs: Long = SystemClock.uptimeMillis()) {
        if (destroyed.get()) {
            return
        }

        val lower = url.lowercase()
        if (lower.startsWith("about:") || lower.startsWith("data:") || lower.startsWith("javascript:")) {
            return
        }
        if (isLocalhostNav(lower)) {
            return
        }

        // Single gate for every path that can leave the app: shouldOverrideUrlLoading, the
        // JavaScript bridge and the window.open() popup. request.hasGesture() is not reliable for
        // JavaScript driven navigation, so a real touch on this view is required instead.
        if (!hasRecentUserTouch(reportedAtUptimeMs)) {
            Logger.d("[PrebidHtmlBannerView] Blocked external navigation without a recent user touch - url=$url")
            return
        }

        notifyClicked()
        val intent = Intent(Intent.ACTION_VIEW, safeUri(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
            browserOpened.set(true)
            notifyOpened()
        } catch (e: ActivityNotFoundException) {
            notifyFailedOnce(StroeerException("PrebidHtmlBannerView: no handler for url=$url - $e"), activeLoadGeneration)
        } catch (t: Throwable) {
            notifyFailedOnce(StroeerException("PrebidHtmlBannerView: failed to open browser for url=$url - $t"), activeLoadGeneration)
        }
    }

    @SuppressLint("UseKtx")
    private fun safeUri(url: String): Uri {
        return try {
            url.toUri()
        } catch (t: Throwable) {
            Logger.d("[PrebidHtmlBannerView] toUri failed, falling back to Uri.parse - url=$url - $t")
            Uri.parse(url)  // Just in case
        }
    }

    private fun injectImpressionAndClickTracking(view: WebView, gen: Int) {
        if (destroyed.get() || gen != loadGeneration.get()) {
            return
        }

        tolerate("injecting the impression and click tracking script") {
            view.evaluateJavascript(HTMLInjector.injectImpressionAndClickTracking(gen), null)
        }
    }

    /**
     * Runs a best-effort step - WebView teardown, listener removal - that must not bring the banner
     * down if it fails, but whose failure should not vanish either.
     */
    private inline fun tolerate(what: String, block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            Logger.d("[PrebidHtmlBannerView] $what failed - $t")
        }
    }

    private fun runOnMain(block: Runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block.run()
        } else {
            mainHandler.post(block)
        }
    }

    private fun notifyLoadedOnce(gen: Int) {
        if (destroyed.get()) {
            return
        }
        if (gen != loadGeneration.get()) {
            return
        }
        if (failedSent.get()) {
            return
        }
        if (!loadedSent.compareAndSet(false, true)) {
            return
        }
        cancelWatchdog()
        val l = listenerRef.get() ?: return
        runOnMain(Runnable { l.onAdLoaded() })
    }

    private fun notifyFailedOnce(error: StroeerException, gen: Int) {
        if (destroyed.get()) {
            return
        }
        if (gen != loadGeneration.get()) {
            return
        }
        if (loadedSent.get()) {
            return
        }
        if (!failedSent.compareAndSet(false, true)) {
            return
        }
        cancelWatchdog()
        val l = listenerRef.get() ?: return

        runOnMain { l.onAdFailedToLoad(error, "Failed to load the banner from Prebid", null, true) }
    }

    private fun notifyOpened() {
        val l = listenerRef.get() ?: return
        runOnMain{l.onAdOpened() }
    }

    private fun notifyClosed() {
        val l = listenerRef.get() ?: return
        runOnMain{ l.onAdClosed() }
    }

    private fun notifyClicked() {
        val l = listenerRef.get() ?: return
        runOnMain { l.onAdClicked() }
    }

    private fun isInViewport(): Boolean {
        if (!isShown) return false
        val rect = Rect()
        return getGlobalVisibleRect(rect) && rect.width() > 0 && rect.height() > 0
    }

    private fun checkAndNotifyImpression(gen: Int) {
        if (destroyed.get() || gen != loadGeneration.get()) return
        if (!pageFinished.get()) return
        if (isInViewport()) {
            notifyImpressionOnce(gen)
        } else {
            registerImpressionListeners(gen)
        }
    }

    /**
     * Re-evaluates the impression after something that can make the banner visible. Scrolling is
     * not the only way that happens: a layout pass, a tab switch, a dismissed dialog or the window
     * regaining focus can all reveal the banner without a single scroll event.
     */
    private fun onImpressionRecheck(gen: Int) {
        if (destroyed.get() || gen != loadGeneration.get() || impressionSent.get()) {
            unregisterImpressionListeners()
            return
        }
        if (!pageFinished.get()) return
        if (isInViewport()) {
            notifyImpressionOnce(gen)
        }
    }

    private fun registerImpressionListeners(gen: Int) {
        registerScrollListenerForImpression(gen)
        registerGlobalLayoutListenerForImpression(gen)
    }

    private fun unregisterImpressionListeners() {
        unregisterScrollListener()
        unregisterGlobalLayoutListener()
        impressionObserver = null
    }

    private fun registerScrollListenerForImpression(gen: Int) {
        if (scrollListener != null) return
        val listener = ViewTreeObserver.OnScrollChangedListener { onImpressionRecheck(gen) }
        val observer = viewTreeObserver
        scrollListener = listener
        impressionObserver = observer
        observer.addOnScrollChangedListener(listener)
    }

    private fun unregisterScrollListener() {
        val l = scrollListener ?: return
        scrollListener = null
        tolerate("removeOnScrollChangedListener") { impressionObserverFor().removeOnScrollChangedListener(l) }
    }

    private fun registerGlobalLayoutListenerForImpression(gen: Int) {
        if (globalLayoutListener != null) return
        val listener = ViewTreeObserver.OnGlobalLayoutListener { onImpressionRecheck(gen) }
        val observer = viewTreeObserver
        globalLayoutListener = listener
        impressionObserver = observer
        observer.addOnGlobalLayoutListener(listener)
    }

    private fun unregisterGlobalLayoutListener() {
        val l = globalLayoutListener ?: return
        globalLayoutListener = null
        tolerate("removeOnGlobalLayoutListener") { impressionObserverFor().removeOnGlobalLayoutListener(l) }
    }

    /**
     * The observer the impression listeners were registered on. Android replaces a view's
     * ViewTreeObserver across a detach, so removing from the current one would leave the
     * registration behind on the old observer.
     */
    private fun impressionObserverFor(): ViewTreeObserver {
        val observer = impressionObserver
        return if (observer != null && observer.isAlive) observer else viewTreeObserver
    }

    private fun notifyImpressionOnce(gen: Int) {
        if (destroyed.get() || gen != loadGeneration.get()) return
        if (!impressionSent.compareAndSet(false, true)) return
        unregisterImpressionListeners()
        val l = listenerRef.get() ?: return
        runOnMain { l.onAdImpression() }
    }

    /**
     * Bridge exposed to the creative. Every method is invoked on the WebView's JavaScript bridge
     * thread, so each one hops to the main thread before reading or writing any state.
     */
    private inner class BannerJsBridge {

        @JavascriptInterface
        fun onReady(gen: Int) {
            if (destroyed.get()) return
            runOnMain { markPageReady(gen) }
        }

        /**
         * The creative reported itself as visible inside the WebView. That only proves it is
         * visible within the WebView viewport, so the impression still has to pass the native
         * viewport check; otherwise a banner scrolled off screen would be counted.
         */
        @JavascriptInterface
        fun onImpression(gen: Int) {
            if (destroyed.get()) return
            runOnMain { markPageReady(gen) }
        }

        @JavascriptInterface
        fun onClick(href: String?) {
            if (destroyed.get()) return
            val u = href ?: ""
            // Stamp the report on arrival: the touch window is short, and a busy main thread must
            // not be what turns a real click into a blocked one.
            val reportedAt = SystemClock.uptimeMillis()
            runOnMain {
                if (destroyed.get()) {
                    return@runOnMain
                }
                if (u.isBlank()) {
                    if (!hasRecentUserTouch(reportedAt)) {
                        Logger.d("[PrebidHtmlBannerView] Blocked click report without a recent user touch")
                        return@runOnMain
                    }
                    notifyClicked()
                    return@runOnMain
                }
                openExternalFromWebView(u, reportedAt)
            }
        }
    }

    private fun markPageReady(gen: Int) {
        if (destroyed.get() || gen != loadGeneration.get()) {
            return
        }
        pageFinished.set(true)
        checkAndNotifyImpression(gen)
    }

    private fun dpToPx(dp: Int, metrics: DisplayMetrics): Int {
        return (dp.toFloat() * metrics.density).roundToInt()
    }

    private companion object {
        /** How long after a real touch an external navigation is still treated as user initiated. */
        const val USER_TOUCH_WINDOW_MS = 500L

        const val DEFAULT_LOAD_TIMEOUT_MS = 8000L

        /** Base url the creative is loaded under; navigation to it is the creative's own, not a click. */
        const val LOCALHOST_BASE_URL = "https://localhost/"
    }
}