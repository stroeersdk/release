package com.stroeer.ads.utilities.http

/**
 * The HTTP methods this transport supports.
 *
 * Kept deliberately small: the SDK only ever issues `GET` (config, ID5/IP lookups) and
 * `POST` (ID5) requests, so there is no reason to model the rest of the verb space.
 */
enum class HttpMethod {
    GET,
    POST
}
