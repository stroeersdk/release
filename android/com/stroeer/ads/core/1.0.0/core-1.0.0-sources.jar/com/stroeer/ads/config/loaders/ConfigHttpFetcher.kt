package com.stroeer.ads.config.loaders

import com.stroeer.ads.config.ConfigConstants
import com.stroeer.ads.utilities.json.HttpJsonRequest
import com.stroeer.ads.utilities.logging.Logger

class ConfigHttpFetcher : IFetcher {
    private var overwriteTimeout = 0

    fun setTimeout(seconds: Int) {
        overwriteTimeout = seconds
    }

    override suspend fun load(appName: String?): String? {
        val trimmedAppName = appName?.trim().orEmpty()
        if (trimmedAppName.isEmpty()) {
            Logger.e("[Configuration-HttpFetcher] Invalid app name")
            return null
        }

        val url = ConfigConstants.CONFIG_URL.replace(ConfigConstants.APPLICATION_NAME_PLACEHOLDER, trimmedAppName)
        val httpJsonRequest = HttpJsonRequest()
        val timeout = if (overwriteTimeout > 0) overwriteTimeout else ConfigConstants.CONFIG_TIMEOUT
        return httpJsonRequest.sendGetJson(url, null, timeout, this.javaClass)
    }

    override fun store(json: String?) {
        // Nothing to do here
    }

    override fun delete() {
        // Nothing to do here
    }
}
