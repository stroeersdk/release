package com.stroeer.ads.config.loaders

import android.content.Context
import com.stroeer.ads.config.ConfigConstants
import com.stroeer.ads.utilities.json.HttpJsonRequest
import com.stroeer.ads.utilities.logging.Logger
import java.io.File

/**
 * Fetches configuration JSON over HTTP.
 *
 * Responses are stored in a dedicated [ConfigResponseCache], which keeps each response's
 * validators (`ETag`, `Last-Modified`) alongside its body and replays them as `If-None-Match` /
 * `If-Modified-Since` on the next request. When the file on the CDN has not changed the server
 * answers `304` with no body and this class serves the stored copy itself, so the configuration
 * is only downloaded again once it actually changes.
 *
 * Each request asks for revalidation, so the stored copy is never served without checking with
 * the server first. Without that the CDN's `max-age=900` would let an intermediary answer from
 * its own cache with no request reaching the origin at all, and the SDK already decides for
 * itself when a refresh is due.
 *
 * The cache is keyed by URL, so one instance safely serves the main config and every A/B test
 * config, which resolve to different URLs through the same fetcher.
 */
class ConfigHttpFetcher internal constructor(
    private val configUrlTemplate: String,
    private val cache: ConfigResponseCache?
) : IFetcher {

    private var overwriteTimeout = 0

    /** Without a context there is nowhere to put the cache, so requests are unconditional. */
    constructor() : this(ConfigConstants.CONFIG_URL, null)

    constructor(applicationContext: Context) : this(
        ConfigConstants.CONFIG_URL,
        ConfigResponseCache(File(applicationContext.cacheDir, CACHE_DIR_NAME))
    )

    fun setTimeout(seconds: Int) {
        overwriteTimeout = seconds
    }

    override suspend fun load(appName: String?): String? {
        val trimmedAppName = appName?.trim().orEmpty()
        if (trimmedAppName.isEmpty()) {
            Logger.e("[Configuration-HttpFetcher] Invalid app name")
            return null
        }

        val url = configUrlTemplate.replace(ConfigConstants.APPLICATION_NAME_PLACEHOLDER, trimmedAppName)
        val timeout = if (overwriteTimeout > 0) overwriteTimeout else ConfigConstants.CONFIG_TIMEOUT

        val cachedEntry = cache?.read(url)
        val headers = conditionalHeaders(cachedEntry)

        val response = HttpJsonRequest().sendGetForResponse(url, headers, timeout, this.javaClass)
            ?: return null

        if (response.statusCode == HTTP_NOT_MODIFIED) {
            // The server confirmed the stored copy is still current; there is no fresher body to
            // store, so just hand back what was already on disk.
            return cachedEntry?.body
        }

        if (!response.isSuccessful) {
            // A failure must never be answered from the cache, so this deliberately falls through
            // without touching the stored entry.
            return null
        }

        val body = response.bodyText()
        cache?.write(url, response.headers.first("ETag"), response.headers.first("Last-Modified"), body)
        return body
    }

    private fun conditionalHeaders(cachedEntry: ConfigCacheEntry?): Map<String, String> {
        if (cache == null) return emptyMap()

        val headers = mutableMapOf(HEADER_CACHE_CONTROL to CACHE_CONTROL_REVALIDATE)
        cachedEntry?.eTag?.let { headers[HEADER_IF_NONE_MATCH] = it }
        cachedEntry?.lastModified?.let { headers[HEADER_IF_MODIFIED_SINCE] = it }
        return headers
    }

    override fun store(json: String?) {
        // Nothing to do here
    }

    override fun delete() {
        // Nothing to do here
    }

    private companion object {
        const val HEADER_CACHE_CONTROL = "Cache-Control"
        const val HEADER_IF_NONE_MATCH = "If-None-Match"
        const val HEADER_IF_MODIFIED_SINCE = "If-Modified-Since"
        const val HTTP_NOT_MODIFIED = 304

        /**
         * Marks the stored copy as immediately stale so the server is asked to revalidate on
         * every request, rather than an intermediary/CDN answering from its own cache.
         */
        const val CACHE_CONTROL_REVALIDATE = "max-age=0"

        const val CACHE_DIR_NAME = "stroeer-config-http-cache"
    }
}
