package com.stroeer.ads.bidding

import android.annotation.SuppressLint
import android.widget.FrameLayout
import com.stroeer.ads.formats.AdCategory

@SuppressLint("StaticFieldLeak")
class SdkResult(var resultCode: SdkResultCode, var keyValues: MutableMap<String, String>?){
    var category : AdCategory = AdCategory.REGULAR
    var errorMessage : String? = null

    companion object{
        val FAILED = SdkResult(SdkResultCode.FAILED, null)
        val SKIPPED = SdkResult(SdkResultCode.SKIPPED, null)
        val TIMEOUT = SdkResult(SdkResultCode.TIMEOUT, null)
        val NOT_AVAILABLE = SdkResult(SdkResultCode.NOT_AVAILABLE, null)
    }
}

