package com.stroeer.ads.plugins.identity.collectors

import com.stroeer.ads.plugins.identity.ACollectorWithContext

/**
 * Return 1 if GDPR consent is given, 0 otherwise
 */
class GdprCollector : ACollectorWithContext<Int?>() {
    override suspend fun retrieveData(): Int? {
        val consentString = GdprConsentCollector().retrieveData()
        return if (consentString.isNullOrEmpty()) null else 1
    }
}
