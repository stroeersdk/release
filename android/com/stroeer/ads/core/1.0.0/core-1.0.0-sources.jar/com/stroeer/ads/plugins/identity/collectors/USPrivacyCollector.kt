package com.stroeer.ads.plugins.identity.collectors

import androidx.preference.PreferenceManager
import com.stroeer.ads.plugins.identity.ACollectorWithContext

/**
 * Return US Privacy String
 */
class USPrivacyCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        return sharedPreferences.getString(US_PRIVACY_KEY, null)
    }

    companion object {
        private const val US_PRIVACY_KEY = "IABUSPrivacy_String"
    }
}
