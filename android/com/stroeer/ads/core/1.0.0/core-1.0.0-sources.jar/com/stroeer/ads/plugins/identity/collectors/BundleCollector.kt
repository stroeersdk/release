package com.stroeer.ads.plugins.identity.collectors

import com.stroeer.ads.plugins.identity.ACollectorWithContext
import java.util.concurrent.CompletableFuture


/**
 * Return package name
 */
class BundleCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        return applicationContext.packageName
    }
}
