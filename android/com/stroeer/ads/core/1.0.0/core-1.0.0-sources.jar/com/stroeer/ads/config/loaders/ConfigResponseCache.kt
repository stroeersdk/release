package com.stroeer.ads.config.loaders

import com.google.gson.Gson
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * A stored configuration response: its validators plus the body they describe.
 *
 * [body] is the configuration JSON exactly as the server sent it.
 */
internal data class ConfigCacheEntry(
    val eTag: String?,
    val lastModified: String?,
    val body: String
)

/**
 * Stores one configuration response per URL so the next request for it can be conditional.
 *
 * This is the part OkHttp's `Cache` used to provide. It is deliberately not a general HTTP cache:
 * it never decides on its own to serve a stored body, it only keeps a response's validators
 * (`ETag`, `Last-Modified`) next to that response's body so [ConfigHttpFetcher] can revalidate and
 * turn a `304` back into content. Freshness, `Vary`, `stale-if-error` and LRU eviction are all
 * out of scope - the SDK decides for itself when a refresh is due.
 *
 * Validators and body live in a *single* record, which is the whole point: a crash or a partial
 * write must never be able to leave an `ETag` paired with a body it does not describe, because
 * that would make the server answer `304` for content the SDK no longer has.
 */
internal class ConfigResponseCache(private val directory: File) {

    /**
     * The on-disk shape. [url] is stored and checked on read so a hash collision - or a file
     * copied between cache directories - can never hand back another resource's body.
     */
    private data class Record(
        val version: Int,
        val url: String,
        val eTag: String?,
        val lastModified: String?,
        val body: String
    )

    /**
     * One mutex per URL, so a refresh of the main configuration and of an A/B variant proceed
     * concurrently while two requests for the *same* URL cannot interleave their writes.
     */
    private val locks = ConcurrentHashMap<String, Mutex>()

    private fun lockFor(url: String): Mutex = locks.computeIfAbsent(url) { Mutex() }

    /** @return the stored response for [url], or null if there is none or it is unusable. */
    internal suspend fun read(url: String): ConfigCacheEntry? = withContext(Dispatchers.IO) {
        lockFor(url).withLock {
            val file = fileFor(url)
            if (!file.exists()) return@withLock null

            val record = try {
                gson.fromJson(file.readText(), Record::class.java)
            } catch (e: Exception) {
                Logger.e("$TAG Discarding an unreadable cache entry", e)
                null
            }

            // Anything unexpected is treated as a miss and removed rather than repaired: the
            // cost is one extra download, and a half-understood record is worse than none.
            if (record == null || record.version != FORMAT_VERSION || record.url != url) {
                delete(file)
                return@withLock null
            }

            if (record.eTag == null && record.lastModified == null) {
                // Nothing to revalidate with, so this entry can never save a download.
                delete(file)
                return@withLock null
            }

            ConfigCacheEntry(record.eTag, record.lastModified, record.body)
        }
    }

    /**
     * Stores [body] for [url] together with its validators.
     *
     * A response with no validator is not stored at all: without one the next request cannot be
     * conditional, so the stored copy could never be used. Any superseded entry is removed in
     * that case, and when the body is too large to keep, so the cache never holds a body that
     * disagrees with what the server last sent.
     */
    internal suspend fun write(url: String, eTag: String?, lastModified: String?, body: String) {
        withContext(Dispatchers.IO) {
            lockFor(url).withLock {
                val file = fileFor(url)

                if (eTag == null && lastModified == null) {
                    delete(file)
                    return@withLock
                }

                if (body.length > MAX_BODY_CHARS) {
                    Logger.i("$TAG Configuration too large to cache (${body.length} chars)")
                    delete(file)
                    return@withLock
                }

                val record = Record(FORMAT_VERSION, url, eTag, lastModified, body)

                // Write beside the target and rename: a rename is atomic enough that a reader
                // sees either the previous record or the new one, never a half-written file.
                val temp = File(file.parentFile, "${file.name}$TEMP_SUFFIX")
                try {
                    if (!directory.exists() && !directory.mkdirs()) {
                        Logger.e("$TAG Could not create the cache directory")
                        return@withLock
                    }

                    temp.writeText(gson.toJson(record))
                    if (!temp.renameTo(file)) {
                        // Some filesystems refuse to rename onto an existing file.
                        delete(file)
                        if (!temp.renameTo(file)) {
                            Logger.e("$TAG Could not commit the cache entry")
                        }
                    }
                } catch (e: Exception) {
                    // Caching is an optimisation; a failure here must never turn a successful
                    // configuration fetch into a failure for the caller.
                    Logger.e("$TAG Failed to store the configuration", e)
                } finally {
                    if (temp.exists()) delete(temp)
                }
            }
        }
    }

    private fun delete(file: File) {
        try {
            if (file.exists() && !file.delete()) {
                Logger.e("$TAG Could not delete ${file.name}")
            }
        } catch (e: Exception) {
            Logger.e("$TAG Could not delete ${file.name}", e)
        }
    }

    /** Named by the hash of the whole URL, query included: A/B variants differ only there. */
    private fun fileFor(url: String): File = File(directory, sha256(url))

    private fun sha256(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    private companion object {
        const val TAG = "[Configuration-ResponseCache]"
        const val FORMAT_VERSION = 1
        const val TEMP_SUFFIX = ".tmp"

        /** The configuration is a few KB; anything this size is not a configuration. */
        const val MAX_BODY_CHARS = 1024 * 1024

        val gson = Gson()
    }
}
