package com.stroeer.ads.reporting

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.stroeer.ads.exceptions.MultipleStartCalledException
import com.stroeer.ads.formats.AdType
import com.stroeer.ads.reporting.events.MeasuringCompleted
import com.stroeer.ads.reporting.events.MeasuringStarted
import com.stroeer.ads.reporting.events.RequestFinished
import com.stroeer.ads.reporting.events.TimeEvent
import com.stroeer.ads.utilities.logging.Logger
import org.jetbrains.annotations.TestOnly
import java.util.UUID
import kotlin.reflect.KClass

class TimeSession(private val adType: AdType, applicationContext: Context, val publisherAdSlot: String) : ISession {
    private var startTime: Long = 0
    var events: ArrayList<TimeEvent> = ArrayList()
    override val id: String = UUID.randomUUID().toString()
    private var connectionType = ConnectionType.UNKNOWN
    private var stopTime: Long

    init {
        this.stopTime = -1
        this.setConnectionType(applicationContext)
    }

    override fun reset(){
        stopTime = -1
        events.clear()
    }

    override fun start(): Long {
        if (!events.isEmpty()) {
            throw MultipleStartCalledException()
        }

        this.startTime = System.currentTimeMillis()
        val startEvent = MeasuringStarted()
        startEvent.startTime = this.startTime
        this.events.add(startEvent)

        return this.startTime
    }

    override fun stop(): Int {
        // Nothing to stop if start() was never called (events is empty), or it was
        // already stopped (last event is MeasuringCompleted).
        if (events.isEmpty() || events[events.size - 1] is MeasuringCompleted) {
            return this.stopTime.toInt()
        }
        this.stopTime = (System.currentTimeMillis() - this.startTime)
        val stopTime = this.stopTime.toInt()
        val completeEvent = MeasuringCompleted()
        completeEvent.timeSinceMeasuringStarted = stopTime

        this.events.add(completeEvent)

        this.makeLog()

        return stopTime
    }

    override fun recordEvent(event: TimeEvent): Int {
        if (stopTime >= 0) {
            return stopTime.toInt()
        }
        if (events.isEmpty()) {
            throw StartNotCalledException(event.javaClass.simpleName)
        }
        event.timeSinceMeasuringStarted = (System.currentTimeMillis() - this.startTime).toInt()
        this.events.add(event)
        return event.timeSinceMeasuringStarted
    }

    override fun toJsonString(): String {
        val jsonObject = JsonObject()
        try {
            jsonObject.addProperty("startTime", this.startTime)
            jsonObject.addProperty("adType", this.adType.toString())
            jsonObject.addProperty("sessionId", this.id)
            jsonObject.addProperty("connectionType", this.connectionType.toString())
            jsonObject.add("events", this.jsonSessions)
        } catch (e: Exception) {
            Logger.e("[TimeSession] Failed to convert json String", e)
        }
        return jsonObject.toString()
    }

    fun setConnectionType(context: Context) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        // Grab the currently active Network (may be null if offline)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)

        this.connectionType = when {
            caps == null ->
                ConnectionType.UNKNOWN

            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ->
                ConnectionType.WIFI

            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ->
                ConnectionType.MOBILE

            else ->
                ConnectionType.UNKNOWN
        }
    }

    val servedInMs: Int
        get() {
            val responseEvent =
                findRequestFinished() ?: return -1
            return responseEvent.timeSinceMeasuringStarted
        }

    private fun findRequestFinished(): TimeEvent? {
        return findEvent(RequestFinished::class)
    }

    fun findEvent(eventClass: KClass<out TimeEvent>): TimeEvent? {
        return events.firstOrNull { eventClass.isInstance(it) }
    }

    @TestOnly
    fun getStartTime() : Long {
        return startTime
    }



    private val jsonSessions: JsonArray
        get() {
            val jsonSessions = JsonArray()
            for (event in events) {
                jsonSessions.add(event.toJsonObject())
            }
            return jsonSessions
        }

    private fun makeLog() {
        val strBuilder = StringBuilder("-----TimeSession : $publisherAdSlot-----\n")
        strBuilder.append("Session: ").append(this.id).append("\n")
        for (event in this.events) {
            strBuilder.append(event.toString()).append("\n")
        }
        strBuilder.append("-------------------------")

        Logger.d(strBuilder.toString())
    }
}

