package com.stroeer.ads.utilities.logging

interface ILogger {
    fun d(tag: String, message: String)
    fun i(tag: String, message: String)
    fun w(tag: String, message: String)

    // Overloaded method without throwable
    fun e(tag: String, message: String)

    // Original method with throwable
    fun e(tag: String, message: String, throwable: Throwable?)

    fun dispose()
}