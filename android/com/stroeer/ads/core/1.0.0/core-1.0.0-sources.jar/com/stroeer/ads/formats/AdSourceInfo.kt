package com.stroeer.ads.formats

import com.stroeer.ads.BuildConfig

class AdSourceInfo {
    constructor() {
        this.adSource = AdSource.Stroeer
        this.adSubSource = AdSource.UNKNOWN
        this.version = BuildConfig.VERSION_NAME
    }

    var adSource: AdSource
    var adSubSource: String
    var version: String

    constructor(adSource: AdSource, version: String) {
        this.adSource = adSource
        this.adSubSource = AdSource.UNKNOWN
        this.version = version
    }

    fun setSubSource(adSubSource: String) {
        this.adSubSource = adSubSource
    }

    override fun toString(): String {
        return "AdSourceInfo{source='$adSource', subSource='${adSubSource}', version='$version'}"
    }

    companion object {
        @JvmStatic
        val defaultAdSource: AdSourceInfo
            get() = AdSourceInfo()
    }
}
