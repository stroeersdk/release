package com.stroeer.ads.utilities.common

typealias Action = () -> Unit
typealias ActionT<T> = (T) -> Unit