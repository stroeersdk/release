package com.stroeer.ads.utilities.logging.timber

import android.util.Log
import com.stroeer.ads.utilities.logging.ILogger
import timber.log.Timber

class TimberLogger(isDebugMode: Boolean) : ILogger {
    init {
        if (isDebugMode) {
            Timber.plant(DebugTree())
        } else {
            Timber.plant(ReleaseTree())
        }
    }

    override fun dispose(){
        Timber.uprootAll()
        Log.i("StroeerSDK", "[TimberLogger] Disposed")
    }

    override fun d(tag: String, message: String) {
        Timber.tag(tag).d(message)
    }

    override fun i(tag: String, message: String) {
        Timber.tag(tag).i(message)
    }

    override fun w(tag: String, message: String) {
        Timber.tag(tag).w(message)
    }

    override fun e(tag: String, message: String) {
        e(tag, message, null)
    }

    override fun e(tag: String, message: String, throwable: Throwable?) {
        if (throwable != null) {
            Timber.tag(tag).e(throwable, message)
        } else {
            Timber.tag(tag).e(message)
        }
    }
}

internal class DebugTree : Timber.Tree() {
    override fun isLoggable(tag: String?, priority: Int): Boolean {
        // Log DEBUG and above
        return priority >= Log.DEBUG
    }

    override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
        // Log to Logcat, appending the stack trace when a throwable is present
        val fullMessage = if (t != null) message + "\n" + Log.getStackTraceString(t) else message
        Log.println(priority, tag ?: "StroeerSDK", fullMessage)
    }
}

internal class ReleaseTree : Timber.Tree() {
    override fun isLoggable(tag: String?, priority: Int): Boolean {
        // Log INFO and above
        return priority >= Log.INFO
    }

    override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
        // Log to Logcat, appending the stack trace when a throwable is present
        val fullMessage = if (t != null) message + "\n" + Log.getStackTraceString(t) else message
        Log.println(priority, tag ?: "StroeerSDK", fullMessage)
    }
}