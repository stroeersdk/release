package com.stroeer.ads.plugins.identity.id5

import com.stroeer.ads.plugins.identity.IIdentityCollector
import com.stroeer.ads.plugins.identity.collectors.*
import com.stroeer.ads.plugins.identity.id5.collectors.*
import com.stroeer.ads.plugins.identity.id5.objects.ID5RequestBody
import com.stroeer.ads.utilities.concurrent.ACoroutinable
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.jetbrains.annotations.TestOnly
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

open class ID5RequestBodyBuilder : ACoroutinable() {

    var requestBody = ID5RequestBody()
        internal set

    protected var collectors: MutableMap<String, IIdentityCollector<*>> = mutableMapOf(
        "ip" to IPv4Collector(),
        "ip6" to IPv6Collector(),
        "bundle" to BundleCollector(),
        "country" to CountryCodeCollector(),
        "gdpr" to GdprCollector(),
        "gdprConsent" to GdprConsentCollector(),
        "gpp_string" to GppCollector(),
        "gppSid" to GppSidCollector(),
        "language" to LanguageCollector(),
        "maid" to MaidCollector(),
        "maidType" to MaidTypeCollector(),
        "name" to NameCollector(),
        "ts" to TimeCollector(),
        "partner" to PartnerCollector(),
        "ver" to VersionCollector(),
        "ua" to UaCollector(),
        "signature" to SignatureCollector(),
        "us_privacy" to USPrivacyCollector()
    )

    @TestOnly fun updateCollectors(collectors: MutableMap<String, IIdentityCollector<*>>){
        this.collectors = collectors
    }

    @TestOnly fun resetUpdated(){
        requestBody.resetUpdated()
    }

    fun setEmail(email: String?) {
        requestBody.hem = hash(normalizeEmail(email))
    }

    fun setPhone(phone: String?) {
        requestBody.phone = hash(normalizePhoneNumber(phone))
    }

    fun setPuid(puid: String?) {
        requestBody.puid = puid
    }

    fun setRegionCode(regionCode: String?) {
        requestBody.region = regionCode
    }

    fun setCityCode(cityCode: String?) {
        requestBody.city = cityCode
    }

    fun setSegments(segments: List<ID5RequestBody.Segment>?) {
        requestBody.segments = segments
    }

    suspend fun isUpdated(): Boolean {
        return withContext(ioDispatcher) {
            mutex.withLock {
                try {
                    requestBody.gdpr_consent = collectors["gdprConsent"]?.retrieveData() as? String
                    requestBody.gpp_string = collectors["gpp_string"]?.retrieveData() as? String
                } catch (ex: Exception) {
                    Logger.e("[ID5RequestBodyBuilder] Failed to get consent string", ex)
                }

                requestBody.isUpdated
            }
        }
    }

    suspend fun getRequestBody(): ID5RequestBody {
        requestBody.resetUpdated()

        return try {
            val updatedRequestBody = ID5RequestBody()

            val results: Map<String, Any?> = kotlinx.coroutines.supervisorScope {
                val deferredMap = collectors.mapValues { (_, collector) ->
                    async(ioDispatcher) {
                        collector.retrieveData()
                    }
                }

                deferredMap.mapValues { (key, deferred) ->
                    try {
                        deferred.await()
                    } catch (ex: Exception) {
                        Logger.e("[ID5RequestBodyBuilder] Failed to retrieve $key", ex)
                        null
                    }
                }
            }

            updatedRequestBody.ip = results["ip"] as? String
            updatedRequestBody.ipv6 = results["ip6"] as? String
            updatedRequestBody.bundle = results["bundle"] as? String
            updatedRequestBody.appId = results["bundle"] as? String  //appID is the same as bundle
            updatedRequestBody.country = results["country"] as? String
            updatedRequestBody.gdpr = results["gdpr"] as? Int
            updatedRequestBody.gdpr_consent = results["gdprConsent"] as? String
            updatedRequestBody.gpp_string = results["gpp_string"] as? String
            updatedRequestBody.gpp_sid = results["gppSid"] as? String
            updatedRequestBody.accept_language = results["language"] as? String
            updatedRequestBody.maid = results["maid"] as? String
            updatedRequestBody.maid_type = results["maidType"] as? String
            updatedRequestBody.ts = results["ts"] as? String
            updatedRequestBody.partner = results["partner"] as? Int
            updatedRequestBody.ver = results["ver"] as? String
            updatedRequestBody.ua = results["ua"] as? String
            updatedRequestBody.signature = results["signature"] as? String
            updatedRequestBody.us_privacy = results["us_privacy"] as? String
            updatedRequestBody.name = results["name"] as? String

            updatedRequestBody.hem = requestBody.hem
            updatedRequestBody.phone = requestBody.phone
            updatedRequestBody.puid = requestBody.puid
            updatedRequestBody.region = requestBody.region
            updatedRequestBody.city = requestBody.city

            updatedRequestBody.resetUpdated()
            requestBody = updatedRequestBody
            requestBody
        } catch (ex: Exception) {
            Logger.e("[ID5RequestBodyBuilder] Failed to get request body", ex)
            requestBody
        }
    }

    protected fun hash(source: String?): String? {
        if (source == null) return null
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(source.toByteArray(StandardCharsets.UTF_8))
            hash.joinToString("") { "%02x".format(it) }
        } catch (ex: NoSuchAlgorithmException) {
            Logger.e("[ID5RequestBodyBuilder] SHA-256 algorithm not found", ex)
            null
        }
    }

    internal fun normalizeEmail(email: String?): String? {
        if (email.isNullOrEmpty()) {
            Logger.e("[ID5RequestBodyBuilder] Email is null or empty")
            return null
        }

        val trimmed = email.trim().lowercase()
        val atIndex = trimmed.indexOf("@")
        if (atIndex == -1) {
            Logger.e("[ID5RequestBodyBuilder] Invalid email format: $trimmed")
            return trimmed
        }

        var username = trimmed.substring(0, atIndex)
        val domain = trimmed.substring(atIndex + 1)

        val plusIndex = username.indexOf("+")
        if (plusIndex != -1) {
            username = username.substring(0, plusIndex)
        }

        username = username.replace(".", "")

        return "$username@$domain"
    }

    internal fun normalizePhoneNumber(phoneNumber: String?): String? {
        if (phoneNumber.isNullOrEmpty()) return null

        var cleanedNumber = phoneNumber.replace("[^\\d+]".toRegex(), "")

        if (cleanedNumber.startsWith("+")) {
            cleanedNumber = cleanedNumber.substring(1)
        }

        cleanedNumber = cleanedNumber.replace("\\++".toRegex(), "+")
        cleanedNumber = cleanedNumber.replace("\\D".toRegex(), "")

        if (cleanedNumber.length > 15) {
            cleanedNumber = cleanedNumber.substring(0, 15)
        }

        return "+$cleanedNumber"
    }
}
