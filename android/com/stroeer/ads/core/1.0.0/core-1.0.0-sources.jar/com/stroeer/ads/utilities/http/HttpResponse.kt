package com.stroeer.ads.utilities.http

import java.nio.charset.Charset
import java.nio.charset.UnsupportedCharsetException

/**
 * The result of a completed [HttpCall].
 *
 * @param statusCode the *effective* status code the caller should act on.
 * @param message the HTTP reason phrase, if the server sent one.
 * @param headers the response headers of whichever connection actually produced this response.
 * @param bodyBytes the full response body, already buffered so the underlying connection can be
 *   released before the caller ever sees this object. Kept private; callers get a defensive copy
 *   through [bodyBytes] so nobody can mutate the buffer backing this response.
 * @param finalUrl the URL that actually produced this response, which can differ from the
 *   request's URL after redirects.
 * @param networkStatusCode the status code that literally came back over the wire for
 *   [finalUrl]. Equal to [statusCode] for a normal response. This exists purely so a caching
 *   layer can synthesize an effective `200` from a cached body while still reporting that the
 *   wire answer was a `304` - see [revalidated].
 */
class HttpResponse(
    val statusCode: Int,
    val message: String?,
    val headers: HttpHeaders,
    bodyBytes: ByteArray,
    val finalUrl: String,
    val networkStatusCode: Int = statusCode
) {
    private val bodyBytes: ByteArray = bodyBytes.copyOf()

    /** A defensive copy; the buffer backing this response is never exposed directly. */
    fun bodyBytes(): ByteArray = bodyBytes.copyOf()

    /** True for any `2xx` status. */
    val isSuccessful: Boolean get() = statusCode in 200..299

    /**
     * True when the wire response for [finalUrl] was `304 Not Modified`.
     *
     * This transport itself has no disk cache and simply returns a `304` with an empty body to
     * the caller. A caching layer built on top of it (mirroring what
     * [com.stroeer.ads.utilities.json.HttpJsonRequest] does today with OkHttp's
     * `networkResponse.code`) can revalidate, load the previously stored body, hand back an
     * [HttpResponse] whose [statusCode] is `200`, and still let [revalidated] answer truthfully
     * that the body did not travel over the wire this time.
     */
    val revalidated: Boolean get() = networkStatusCode == HTTP_NOT_MODIFIED

    /**
     * Decodes [bodyBytes] to text.
     *
     * A leading byte-order mark wins where there is one: it is stripped rather than decoded into
     * the string (callers, JSON parsers in particular, do not expect one) and it names the
     * encoding more reliably than a header can. Failing that, the charset named by a
     * `Content-Type` header (e.g. `application/json; charset=utf-8`) is used when supported, and
     * otherwise UTF-8, which is what every JSON/text endpoint this SDK talks to actually uses.
     * An empty body decodes to `""`.
     */
    fun bodyText(): String {
        if (bodyBytes.isEmpty()) return ""

        val charset = charsetFromContentType() ?: Charsets.UTF_8
        val (bytes, decodeCharset) = stripBom(bodyBytes, charset)
        return String(bytes, decodeCharset)
    }

    private fun charsetFromContentType(): Charset? {
        val contentType = headers.first("Content-Type") ?: return null
        val charsetParam = contentType
            .split(";")
            .map { it.trim() }
            .firstOrNull { it.startsWith("charset=", ignoreCase = true) }
            ?.substringAfter("=")
            ?.trim()
            ?.trim('"')
            ?: return null

        return try {
            Charset.forName(charsetParam)
        } catch (e: UnsupportedCharsetException) {
            null
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    /**
     * Longer byte-order marks are tested before their own prefixes: a UTF-32LE BOM starts with
     * the same two bytes as a UTF-16LE one, so checking UTF-16 first would decode a UTF-32
     * response as UTF-16 and pepper the result with NUL characters.
     */
    private fun stripBom(bytes: ByteArray, fallback: Charset): Pair<ByteArray, Charset> {
        val utf32BeBom = byteArrayOf(0x00, 0x00, 0xFE.toByte(), 0xFF.toByte())
        val utf32LeBom = byteArrayOf(0xFF.toByte(), 0xFE.toByte(), 0x00, 0x00)
        val utf8Bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
        val utf16BeBom = byteArrayOf(0xFE.toByte(), 0xFF.toByte())
        val utf16LeBom = byteArrayOf(0xFF.toByte(), 0xFE.toByte())

        return when {
            bytes.size >= 4 && bytes.copyOf(4).contentEquals(utf32BeBom) ->
                bytes.copyOfRange(4, bytes.size) to charsetOrFallback("UTF-32BE", fallback)
            bytes.size >= 4 && bytes.copyOf(4).contentEquals(utf32LeBom) ->
                bytes.copyOfRange(4, bytes.size) to charsetOrFallback("UTF-32LE", fallback)
            bytes.size >= 3 && bytes.copyOf(3).contentEquals(utf8Bom) ->
                bytes.copyOfRange(3, bytes.size) to Charsets.UTF_8
            bytes.size >= 2 && bytes.copyOf(2).contentEquals(utf16BeBom) ->
                bytes.copyOfRange(2, bytes.size) to Charsets.UTF_16BE
            bytes.size >= 2 && bytes.copyOf(2).contentEquals(utf16LeBom) ->
                bytes.copyOfRange(2, bytes.size) to Charsets.UTF_16LE
            else -> bytes to fallback
        }
    }

    /** UTF-32 is not one of the charsets Android guarantees, hence the fallback. */
    private fun charsetOrFallback(name: String, fallback: Charset): Charset {
        return try {
            Charset.forName(name)
        } catch (e: IllegalArgumentException) {
            fallback
        }
    }

    private companion object {
        const val HTTP_NOT_MODIFIED = 304
    }
}
