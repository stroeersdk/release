package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.utilities.logging.Logger
import com.stroeer.ads.config.ConfigConstants
import com.stroeer.ads.config.ConfigurationManager

class GamRequestBuilder(
    private val config: AAdConfiguration
) {
    private val keyValuesFromAdapter: MutableMap<String, String?> = HashMap()

    fun addKeyValuesFromSdks(keyValues: MutableMap<String, String>?): GamRequestBuilder {
        keyValues?.let{
            for (key in keyValues.keys) {
                this.keyValuesFromAdapter[key] = keyValues[key]
            }
        }
        return this
    }

    fun build(): AdManagerAdRequest {

        if(config.localBuilder == null){
            // Somehow, localBuilder is null, which means prepareRequestBuilder() was not called before build().
            // This is a critical error, so we log it and create a new AdManagerAdRequest.Builder to avoid crashing.
            Logger.e("[GamRequestBuilder] localBuilder is null - prepareRequestBuilder() must run before build().")
            config.localBuilder = AdManagerAdRequest.Builder()
        }

        val builderFromConfiguration = AdManagerAdRequest.Builder()
        // Key Values from Configuration
        this.config.configAdSlot?.keyValues?.let { kvs ->
            for ((key, value) in kvs) {
                if(value.isNotEmpty()) {
                    builderFromConfiguration.addCustomTargeting(key, value.joinToString(","))
                }
            }
        }

        // Add the global contenturl
        ConfigurationManager.getInstance().contentUrl?.let{
            builderFromConfiguration.setContentUrl(it)
        }

        // Add the local ContentUrl. Merger will resolve the final value, with the local one winning if set.
        config.contentUrl?.let{
            config.localBuilder!!.setContentUrl(it)
        }

        val globalBuilder = GamAdRequestBuilderMerger.merge(builderFromConfiguration, GlobalGamManager.adRequestBuilder)
        val builder = GamAdRequestBuilderMerger.merge(globalBuilder, config.localBuilder!!)

        // CustomTargeting
        for ((key, value) in this.config.customTargeting) {
            builder.addCustomTargeting(key, value)
        }

        // Adapter targeting values are nullable; skip nulls so a single missing
        // value can't NPE and abort the whole GAM request.
        for ((key, value) in this.keyValuesFromAdapter) {
            if (value != null) {
                builder.addCustomTargeting(key, value)
            }
        }

        // SetTimeout
        this.config.config?.gamRequestTimeout?.let { timeout->
            try {
                builder.setHttpTimeoutMillis(timeout.toInt())
            }catch(e: Exception){
                Logger.e("[GamRequestBuilder] Failed to set ad request timeout: $timeout ms - ${e.message}", e)
            }
        }

        // Adding Android SDK Version
        builder.addCustomTargeting(ConfigConstants.ANDROID_REQUEST_VERSION_KEY, listOf(ConfigConstants.VERSION_NAME))

        return builder.build()
    }
}

