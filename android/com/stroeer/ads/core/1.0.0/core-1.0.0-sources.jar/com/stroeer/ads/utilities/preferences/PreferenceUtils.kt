package com.stroeer.ads.utilities.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import org.jetbrains.annotations.TestOnly
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * A thin wrapper around a single SharedPreferences file.
 */
class PreferenceUtils private constructor(
    private val prefs: SharedPreferences
) {
    companion object {
        private var applicationContext: Context? = null

        fun setContext(context: Context) {
            this.applicationContext = context.applicationContext
        }

        /**
         * Create (or retrieve) the singleton for this name.
         *
         * Note: [mode] is only honoured the first time an instance is created for a given
         * [name]; subsequent calls with the same [name] but a different [mode] will still
         * return the originally created instance.
         *
         * @throws IllegalStateException if [setContext] has not been called yet.
         */
        fun getInstance(
            name: String,
            mode: Int = Context.MODE_PRIVATE
        ): PreferenceUtils = Holder.getOrCreate(name, mode)

        /**
         * Resets the process-global state (context + instance cache) to its
         * never-initialized condition. Tests only: this state is JVM-static and would
         * otherwise leak between test classes sharing a JVM.
         */
        @TestOnly
        internal fun resetForTest() {
            applicationContext = null
            Holder.clear()
        }

        fun clearAllSharedPreferences(context: Context) {
            val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
            if (!prefsDir.exists()) return

            prefsDir.listFiles()?.forEach { file ->
                if (file.isFile && file.name.endsWith(".xml")) {
                    val prefsName = file.name.removeSuffix(".xml")
                    context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)
                        .edit(commit = true) {
                            clear()
                        } // commit to be synchronous
                    file.delete() // optional, but ensures it's gone
                }
            }
        }
    }

    private object Holder {
        private val map = ConcurrentHashMap<String, PreferenceUtils>()
        fun getOrCreate(
            name: String,
            mode: Int
        ): PreferenceUtils {
            val context = applicationContext
                ?: throw IllegalStateException(
                    "PreferenceUtils.setContext() must be called before getInstance()"
                )
            return map.computeIfAbsent(name) {
                PreferenceUtils(context.getSharedPreferences(name, mode))
            }
        }

        fun clear() = map.clear()
    }

    // String
    fun putString(key: String, value: String?) = prefs.edit { putString(key, value) }
    fun getString(key: String, default: String? = null): String? =
        prefs.getString(key, default)

    // Boolean
    fun putBoolean(key: String, value: Boolean) = prefs.edit { putBoolean(key, value) }
    fun getBoolean(key: String, default: Boolean = false): Boolean =
        prefs.getBoolean(key, default)

    // Int
    fun putInt(key: String, value: Int) = prefs.edit { putInt(key, value) }
    fun getInt(key: String, default: Int = 0): Int =
        prefs.getInt(key, default)

    // Long
    fun putLong(key: String, value: Long) = prefs.edit { putLong(key, value) }
    fun getLong(key: String, default: Long = 0L): Long =
        prefs.getLong(key, default)

    // Float
    fun putFloat(key: String, value: Float) = prefs.edit { putFloat(key, value) }
    fun getFloat(key: String, default: Float = 0f): Float =
        prefs.getFloat(key, default)

    // String Set
    fun putStringSet(key: String, value: Set<String>) = prefs.edit { putStringSet(key, value) }
    fun getStringSet(key: String, default: Set<String>? = null): Set<String>? =  prefs.getStringSet(key, default)

    // Remove & clear
    fun remove(key: String) = prefs.edit { remove(key) }
    fun clear() = prefs.edit { clear() }

}