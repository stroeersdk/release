package com.stroeer.ads.utilities.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import java.io.File
import kotlin.jvm.Throws

/**
 * A thin wrapper around a single SharedPreferences file.
 */
class PreferenceUtils private constructor(
    private val prefs: SharedPreferences
) {
    companion object Companion {
        lateinit var applicationContext : Context

        fun setContext(applicationContext: Context) {
            this.applicationContext = applicationContext
        }

        /** Create (or retrieve) the singleton for this name */
        fun getInstance(
            name: String,
            mode: Int = Context.MODE_PRIVATE
        ): PreferenceUtils = Holder.getOrCreate(name, mode)

        fun clearAllSharedPreferences(context: Context) {
            val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
            if (!prefsDir.exists()) return

            prefsDir.listFiles()?.forEach { file ->
                if (file.isFile && file.name.endsWith(".xml")) {
                    val prefsName = file.name.removeSuffix(".xml")
                    context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)
                        .edit(commit = true) {
                            clear()
                        } // commit to be synchronous
                    file.delete() // optional, but ensures it's gone
                }
            }
        }
    }

    private object Holder {
        private val map = mutableMapOf<String, PreferenceUtils>()
        fun getOrCreate(
            name: String,
            mode: Int
        ): PreferenceUtils {
            return map.getOrPut(name) {
                PreferenceUtils(applicationContext.getSharedPreferences(name, mode))
            }
        }
    }

    // String
    fun putString(key: String, value: String?) = prefs.edit { putString(key, value) }
    fun getString(key: String, default: String? = null): String? =
        prefs.getString(key, default)

    // Boolean
    fun putBoolean(key: String, value: Boolean) = prefs.edit { putBoolean(key, value) }
    fun getBoolean(key: String, default: Boolean = false): Boolean =
        prefs.getBoolean(key, default)

    // Int
    fun putInt(key: String, value: Int) = prefs.edit { putInt(key, value) }
    fun getInt(key: String, default: Int = 0): Int =
        prefs.getInt(key, default)

    // Long
    fun putLong(key: String, value: Long) = prefs.edit { putLong(key, value) }
    fun getLong(key: String, default: Long = 0L): Long =
        prefs.getLong(key, default)

    // Float
    fun putFloat(key: String, value: Float) = prefs.edit { putFloat(key, value) }
    fun getFloat(key: String, default: Float = 0f): Float =
        prefs.getFloat(key, default)

    // String Set
    fun putStringSet(key: String, value: Set<String>) = prefs.edit { putStringSet(key, value) }
    fun getStringSet(key: String, default: Set<String>? = null): Set<String>? =  prefs.getStringSet(key, default)

    // Remove & clear
    fun remove(key: String) = prefs.edit { remove(key) }
    fun clear() = prefs.edit { clear() }

}