package com.stroeer.ads.utilities.http

/**
 * A single, immutable HTTP request description.
 *
 * This is pure data - building one performs no I/O. Executing it is the job of
 * [HttpClient.newCall] / [HttpCall.execute].
 */
data class HttpRequest(
    val url: String,
    val method: HttpMethod = HttpMethod.GET,
    val headers: HttpHeaders = HttpHeaders.EMPTY,
    val body: HttpBody? = null,
    val timeouts: HttpTimeouts = HttpTimeouts.DEFAULT
) {
    companion object {
        /** Convenience factory for a `GET` request. */
        fun get(
            url: String,
            headers: HttpHeaders = HttpHeaders.EMPTY,
            timeouts: HttpTimeouts = HttpTimeouts.DEFAULT
        ): HttpRequest = HttpRequest(url, HttpMethod.GET, headers, null, timeouts)

        /** Convenience factory for a `POST` request carrying [body]. */
        fun post(
            url: String,
            body: HttpBody,
            headers: HttpHeaders = HttpHeaders.EMPTY,
            timeouts: HttpTimeouts = HttpTimeouts.DEFAULT
        ): HttpRequest = HttpRequest(url, HttpMethod.POST, headers, body, timeouts)
    }
}
