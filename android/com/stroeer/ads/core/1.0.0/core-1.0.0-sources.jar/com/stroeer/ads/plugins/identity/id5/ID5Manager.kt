package com.stroeer.ads.plugins.identity.id5

import android.content.Context
import androidx.preference.PreferenceManager
import com.stroeer.ads.consent.ConsentManager.hasVendorConsent
import com.stroeer.ads.plugins.identity.ACollectorWithContext
import com.stroeer.ads.plugins.identity.IIdentityManager
import com.stroeer.ads.plugins.identity.id5.objects.ID5Data
import com.stroeer.ads.plugins.identity.id5.objects.ID5RequestBody
import com.stroeer.ads.plugins.identity.objects.IdentityCache
import com.stroeer.ads.plugins.identity.objects.IdentityCustomInfo
import com.stroeer.ads.utilities.json.JsonBase
import com.stroeer.ads.utilities.logging.Logger
import org.prebid.mobile.ExternalUserId
import org.prebid.mobile.TargetingParams
import java.util.Date
import androidx.core.content.edit
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.Configuration

class ID5Manager : IIdentityManager {
    lateinit var applicationContext: Context

    /**
     * Retrieves the identity data.
     * 
     * @return IdentityCache object or null if not available.
     */
    override var identityData: IdentityCache = IdentityCache()
        private set

    var requestBuilder : ID5RequestBodyBuilder = ID5RequestBodyBuilder()

    /**
     * Gets the current ID5 data.
     * 
     * @return ID5Data object.
     */
    var data: ID5Data? = null
        private set

    var prebidUserId: ExternalUserId = ExternalUserId(ID5Constants.source, ArrayList<ExternalUserId.UniqueId>())
        private set

    /**
     * Initializes the ID5Manager with application context and listener.
     * 
     * @param applicationContext Application context.
     */
    override fun initialize(applicationContext: Context) {
        this.applicationContext = applicationContext

        // Some collectors require the application context to be set
        // before the collectors are called
        ACollectorWithContext.applicationContext = applicationContext
    }


    /**
     * Loads the consent string from shared preferences cache.
     */
    override fun loadIdentityFromStorage() {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        val cacheString =
            sharedPreferences.getString(ID5Constants.prefId5Cache, null)
        val cacheDate =
            sharedPreferences.getLong(ID5Constants.prefId5CacheDate, 0)

        if (cacheString.isNullOrEmpty()) {
            Logger.i("[ID5Manager] loadConsentStringFromStorage: No cache found")
        } else {
            // Load from the cache in the local storage
            identityData.identityString = cacheString
            data = JsonBase.fromJson(cacheString, ID5Data::class.java)
            data?.let{
                identityData.cacheCreationDate = Date(cacheDate)

                if (ConfigurationManager.isDebugMode) {
                    Logger.d("[ID5Manager] loadConsentStringFromStorage: Cache found - " + it.toPrettyJson())
                } else {
                    Logger.i("[ID5Manager] loadConsentStringFromStorage: Cache found")
                }
            }
        }
    }

    /**
     * Fetches the consent string via an HTTP request.
     * 
     * @param retry Whether to retry on failure.
     */
    override suspend fun loadIdentityFromHttp(retry: Boolean) {
        try {
            if(!isUpdated()){
                return
            }

            val requestBody: ID5RequestBody = requestBuilder.getRequestBody() // RequestBody cannot be null
            if (requestBody.gdpr_consent != null || requestBody.gpp_string != null) {
                if (!hasVendorConsent(ID5Constants.vendorId)) {
                    Logger.d("[ID5Manager] ID5 is not allowed to use. Disabled by GDPR.")
                    clearIdentity()
                    return
                }

                Logger.i("[ID5Manager] Loading ID5 from HTTP.")

                val request = ID5HttpRequest()
                data = request.send(requestBody)
                if (data != null) {
                    identityData.cacheCreationDate = Date()
                    identityData.identityString = data!!.toJson()!!

                    storeIdentityData()
                } else {
                    Logger.d("[ID5Manager] Failed to load consent string from HTTP. gdpr : " + requestBody.gdpr_consent + ", gpp : " + requestBody.gpp_string)
                    // Still keep the previous ID5. but will not be used.
                }
            } else {
                Logger.d("[ID5Manager] No gdrp/gpp string found. Removing from request body.")
                clearIdentity()
            }
        } catch (e: Exception) {
            Logger.e("[ID5Manager] Failed to load consent string from HTTP.", e)
            clearIdentity()
        }
    }

    fun clearIdentity() {
        identityData = IdentityCache()
        data = null
        clearStoredIdentityData()
    }

    private fun clearStoredIdentityData() {
        if (!::applicationContext.isInitialized) return
        PreferenceManager.getDefaultSharedPreferences(applicationContext).edit {
            remove(ID5Constants.prefId5Cache)
            remove(ID5Constants.prefId5CacheDate)
            remove(ID5Constants.prefId5Signature)
        }
    }

    /**
     * Checks if the ID5 request body has been updated.
     * 
     * @return true if updated, false otherwise.
     */
    override suspend fun isUpdated(): Boolean {
        return requestBuilder.isUpdated()
    }

    /**
     * Sets the Prebid user ID based on ID5 data.
     */
    @Synchronized
    override fun setUserIdToPrebid() {
        if (data == null) {
            return
        }
        // Remove anyway
        val idList = TargetingParams.getExternalUserIds()
        for (id in idList) {
            if (ID5Constants.source == id.source) {
                idList.remove(id)
                break
            }
        }

        val ids = prebidUserId.uniqueIds
        if (!ids.isEmpty()) {
            ids.removeAt(0)
        }
        val id = ExternalUserId.UniqueId(data!!.universal_uid!!, 1)
        val ext = HashMap<String?, Any?>()
        ext["linkType"] = data!!.ext!!.linkType
        // ext.put("universal_uid", data.universal_uid);
        id.setExt(ext)
        ids.add(id)

        idList.add(prebidUserId)
        TargetingParams.setExternalUserIds(idList)
    }

    /**
     * Sets custom identity information from provided details.
     * 
     * @param customInfo IdentityCustomInfo containing user data.
     */
    override fun setCustomInfo(customInfo : IdentityCustomInfo){
        if (customInfo.email != null) requestBuilder.setEmail(customInfo.email)
        if (customInfo.phone != null) requestBuilder.setPhone(customInfo.phone)
        if (customInfo.puid != null) requestBuilder.setPuid(customInfo.puid)
        if (customInfo.regionCode != null) requestBuilder.setRegionCode(customInfo.regionCode)
        if (customInfo.cityCode != null) requestBuilder.setCityCode(customInfo.cityCode)
    }

    fun storeIdentityData() {
        if (identityData.identityString.isNotEmpty()) {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
            sharedPreferences.edit {
                putString(
                    ID5Constants.prefId5Cache,
                    identityData.identityString
                )
                putLong(
                    ID5Constants.prefId5CacheDate,
                    identityData.cacheCreationDate.time
                )
                putString(ID5Constants.prefId5Signature, data!!.signature)
            }
        }
    }
}
