package com.stroeer.ads.plugins.identity.id5

import android.content.Context
import android.os.SystemClock
import androidx.preference.PreferenceManager
import com.stroeer.ads.consent.ConsentManager.hasVendorConsent
import com.stroeer.ads.plugins.identity.ACollectorWithContext
import com.stroeer.ads.plugins.identity.IIdentityManager
import com.stroeer.ads.plugins.identity.id5.objects.ID5Data
import com.stroeer.ads.plugins.identity.id5.objects.ID5RequestBody
import com.stroeer.ads.plugins.identity.objects.IdentityCache
import com.stroeer.ads.plugins.identity.objects.IdentityCustomInfo
import com.stroeer.ads.utilities.json.JsonBase
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.CancellationException
import org.prebid.mobile.ExternalUserId
import org.prebid.mobile.TargetingParams
import java.util.Date
import androidx.core.content.edit
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.Configuration

class ID5Manager : IIdentityManager {
    lateinit var applicationContext: Context

    /**
     * Retrieves the identity data.
     * 
     * @return IdentityCache object or null if not available.
     */
    override var identityData: IdentityCache = IdentityCache()
        private set

    var requestBuilder : ID5RequestBodyBuilder = ID5RequestBodyBuilder()

    /**
     * Gets the current ID5 data.
     * 
     * @return ID5Data object.
     */
    var data: ID5Data? = null
        private set

    var prebidUserId: ExternalUserId = ExternalUserId(ID5Constants.source, ArrayList<ExternalUserId.UniqueId>())
        private set

    /** Timestamp of the last failed HTTP attempt, 0 when the last attempt succeeded. */
    @Volatile
    private var lastFailedAttemptMs: Long = 0

    /**
     * Initializes the ID5Manager with application context and listener.
     * 
     * @param applicationContext Application context.
     */
    override fun initialize(applicationContext: Context) {
        this.applicationContext = applicationContext

        // Some collectors require the application context to be set
        // before the collectors are called
        ACollectorWithContext.applicationContext = applicationContext
    }


    /**
     * Loads the consent string from shared preferences cache.
     */
    override fun loadIdentityFromStorage() {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        val cacheString =
            sharedPreferences.getString(ID5Constants.prefId5Cache, null)
        val cacheDate =
            sharedPreferences.getLong(ID5Constants.prefId5CacheDate, 0)

        if (cacheString.isNullOrEmpty()) {
            Logger.i("[ID5Manager] loadIdentityFromStorage: No cache found")
            return
        }

        val cached = JsonBase.fromJson(cacheString, ID5Data::class.java)

        // A cache entry that cannot be parsed, carries no UID, or records a withdrawn ID5
        // consent must not be exposed as a usable identity: IdentityManager only checks that
        // identityString is non-empty, so storing it unvalidated reports success for junk.
        if (!isUsable(cached)) {
            Logger.i("[ID5Manager] loadIdentityFromStorage: Cache found but unusable. Discarding.")
            clearIdentity()
            return
        }

        identityData.identityString = cacheString
        data = cached
        identityData.cacheCreationDate = Date(cacheDate)

        if (ConfigurationManager.isDebugMode) {
            // Contains the universal UID and signature - console only, never the log file.
            Logger.dNotPersisted("[ID5Manager] loadIdentityFromStorage: Cache found - " + cached?.toPrettyJson())
        }
        Logger.i("[ID5Manager] loadIdentityFromStorage: Cache found")
    }

    /**
     * Whether an [ID5Data] can be used as an identity.
     *
     * Every field on the wire model is nullable, so this is the single place that decides what
     * "usable" means before the value reaches Prebid or the cache. An explicitly withdrawn
     * `id5_consent` is rejected; an absent `privacy` block is tolerated so that a response
     * shape change on ID5's side cannot disable the integration outright.
     */
    private fun isUsable(candidate: ID5Data?): Boolean {
        if (candidate == null) return false
        if (candidate.universal_uid.isNullOrBlank()) return false
        if (candidate.privacy?.id5_consent == false) {
            Logger.i("[ID5Manager] ID5 reported id5_consent=false. Identity is not usable.")
            return false
        }
        return true
    }

    /**
     * Fetches the consent string via an HTTP request.
     * 
     * @param retry Whether to retry on failure.
     */
    override suspend fun loadIdentityFromHttp(retry: Boolean) {
        try {
            // Refresh the stored consent strings. This is the only read permitted before the
            // consent gate below: it touches SharedPreferences only - no advertising ID, no
            // network egress. Its boolean result is used purely to bypass the failure backoff
            // when consent has actually changed; freshness/expiry is IdentityManager's call.
            val inputChanged = requestBuilder.isUpdated()

            val gdprConsent = requestBuilder.requestBody.gdpr_consent
            val gppString = requestBuilder.requestBody.gpp_string

            if (gdprConsent == null && gppString == null) {
                Logger.d("[ID5Manager] No gdpr/gpp string found. Clearing identity.")
                clearIdentity()
                return
            }

            if (!hasVendorConsent(ID5Constants.vendorId, gdprConsent)) {
                Logger.d("[ID5Manager] ID5 is not allowed to use. Disabled by GDPR.")
                clearIdentity()
                return
            }

            // refreshAsync() runs on every ad load, so a persistently failing endpoint would
            // otherwise re-collect the MAID/IP and re-request once per ad. A changed consent
            // input always bypasses this, so revocation stays responsive.
            if (!inputChanged && !mayRetryAfterFailure()) {
                Logger.d("[ID5Manager] Skipping ID5 request, last attempt failed less than ${MIN_RETRY_INTERVAL_MS / 1000}s ago.")
                return
            }

            // Consent is granted - only now may identifiers be collected and sent.
            val requestBody: ID5RequestBody = requestBuilder.getRequestBody() // RequestBody cannot be null

            Logger.i("[ID5Manager] Loading ID5 from HTTP.")

            val request = ID5HttpRequest()
            val response = request.send(requestBody)

            // An explicit id5_consent=false is a revocation by ID5 itself, not a transient
            // failure. Keeping the cache here would let the old UID be republished on every
            // subsequent ad load for as long as ID5 keeps refusing.
            if (response?.privacy?.id5_consent == false) {
                Logger.i("[ID5Manager] ID5 reported id5_consent=false. Clearing identity.")
                clearIdentity()
                return
            }

            if (!isUsable(response)) {
                recordFailedAttempt()
                Logger.d("[ID5Manager] Failed to load a usable identity from HTTP. gdpr present: ${gdprConsent != null}, gpp present: ${gppString != null}")
                // Keep the previously cached ID5 rather than dropping a still-valid identity.
                return
            }

            val identityJson = response?.toJson()
            if (identityJson == null) {
                recordFailedAttempt()
                Logger.e("[ID5Manager] Failed to serialize the received ID5 identity.")
                return
            }

            // Storing happens under the same monitor as the in-memory update: otherwise a
            // concurrent clearIdentity() could wipe the preferences and then have this thread's
            // already-built editor write the revoked identity straight back.
            synchronized(this) {
                lastFailedAttemptMs = 0
                data = response
                identityData.cacheCreationDate = Date()
                identityData.identityString = identityJson
                storeIdentityData()
            }
        } catch (e: CancellationException) {
            // Timeout or lifecycle cancellation is not an identity failure - never clear on it.
            // It still counts as a failed attempt, otherwise a slow endpoint would re-collect
            // identifiers and retry on every single ad load.
            recordFailedAttempt()
            throw e
        } catch (e: Exception) {
            recordFailedAttempt()
            Logger.e("[ID5Manager] Failed to load the identity from HTTP.", e)
            clearIdentity()
        }
    }

    private fun recordFailedAttempt() {
        // elapsedRealtime, not wall clock: a backwards clock correction would otherwise
        // suppress every retry until wall time caught up again.
        lastFailedAttemptMs = SystemClock.elapsedRealtime()
    }

    /** Whether enough time has passed since the last failed HTTP attempt to try again. */
    private fun mayRetryAfterFailure(): Boolean {
        val lastFailure = lastFailedAttemptMs
        return lastFailure == 0L || (SystemClock.elapsedRealtime() - lastFailure) > MIN_RETRY_INTERVAL_MS
    }

    @Synchronized
    fun clearIdentity() {
        identityData = IdentityCache()
        data = null
        clearStoredIdentityData()
        // Withdraw the ID from Prebid as well, otherwise bids keep carrying it after revocation.
        removeUserIdFromPrebid()
    }

    private fun clearStoredIdentityData() {
        if (!::applicationContext.isInitialized) return
        PreferenceManager.getDefaultSharedPreferences(applicationContext).edit {
            remove(ID5Constants.prefId5Cache)
            remove(ID5Constants.prefId5CacheDate)
            remove(ID5Constants.prefId5Signature)
        }
    }

    /**
     * Checks if the ID5 request body has been updated.
     * 
     * @return true if updated, false otherwise.
     */
    override suspend fun isUpdated(): Boolean {
        return requestBuilder.isUpdated()
    }

    /**
     * Sets the Prebid user ID based on ID5 data.
     */
    @Synchronized
    override fun setUserIdToPrebid() {
        // Snapshot once: a concurrent refresh may null this out between the check and the use.
        val current = data

        // Covers a cleared identity, a UID-less response and a withdrawn id5_consent. In every
        // one of those cases any ID5 entry already published to Prebid must be withdrawn too,
        // otherwise revocation would leave the old UID on every subsequent bid.
        if (!isUsable(current)) {
            removeUserIdFromPrebid()
            return
        }

        val ids = prebidUserId.uniqueIds
        if (!ids.isEmpty()) {
            ids.removeAt(0)
        }

        val id = ExternalUserId.UniqueId(current!!.universal_uid!!, 1)
        // ext is optional in the ID5 response - omit the map rather than inventing a linkType.
        current.ext?.let { responseExt ->
            val ext = HashMap<String?, Any?>()
            ext["linkType"] = responseExt.linkType
            id.setExt(ext)
        }
        ids.add(id)

        // getExternalUserIds() hands back a defensive copy, so the list has to be given back to
        // setExternalUserIds() for any change to take effect.
        val idList = TargetingParams.getExternalUserIds()
            .filterNot { ID5Constants.source == it.source }
            .toMutableList()
        idList.add(prebidUserId)
        TargetingParams.setExternalUserIds(idList)
    }

    /**
     * Removes the ID5 entry from Prebid, leaving every other identity source untouched.
     *
     * TargetingParams is a process-global, unsynchronized map and its getter returns a copy, so
     * this read/modify/write cannot be made atomic against a publisher mutating the same list.
     * The window is kept as small as possible and the write is skipped when there is nothing to
     * remove, which matters because a denied-consent refresh runs on every ad load.
     */
    @Synchronized
    private fun removeUserIdFromPrebid() {
        val current = TargetingParams.getExternalUserIds()
        if (current.none { ID5Constants.source == it.source }) {
            return
        }
        TargetingParams.setExternalUserIds(current.filterNot { ID5Constants.source == it.source })
    }

    /**
     * Sets custom identity information from provided details.
     * 
     * @param customInfo IdentityCustomInfo containing user data.
     */
    override fun setCustomInfo(customInfo : IdentityCustomInfo){
        if (customInfo.email != null) requestBuilder.setEmail(customInfo.email)
        if (customInfo.phone != null) requestBuilder.setPhone(customInfo.phone)
        if (customInfo.puid != null) requestBuilder.setPuid(customInfo.puid)
        if (customInfo.regionCode != null) requestBuilder.setRegionCode(customInfo.regionCode)
        if (customInfo.cityCode != null) requestBuilder.setCityCode(customInfo.cityCode)
    }

    fun storeIdentityData() {
        if (identityData.identityString.isNotEmpty()) {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
            sharedPreferences.edit {
                putString(
                    ID5Constants.prefId5Cache,
                    identityData.identityString
                )
                putLong(
                    ID5Constants.prefId5CacheDate,
                    identityData.cacheCreationDate.time
                )
                putString(ID5Constants.prefId5Signature, data?.signature)
            }
        }
    }

    companion object {
        /** Minimum gap between HTTP attempts after a failure, unless the consent input changed. */
        private const val MIN_RETRY_INTERVAL_MS: Long = 60 * 1000
    }
}
