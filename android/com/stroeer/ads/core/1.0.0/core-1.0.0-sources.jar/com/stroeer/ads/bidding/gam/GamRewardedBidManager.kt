package com.stroeer.ads.bidding.gam

import android.app.Activity
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardItem
import com.stroeer.ads.formats.rewarded.RewardedConfiguration
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.exceptions.DfpRewardedLoadAdError
import com.stroeer.ads.formats.rewarded.IStroeerRewardedFullListener
import com.stroeer.ads.reporting.events.GamRespondedSuccessfully
import com.stroeer.ads.reporting.events.GamRespondedWithError
import com.stroeer.ads.utilities.logging.Logger
import java.lang.ref.WeakReference

class GamRewardedBidManager(rewardConfig: RewardedConfiguration) : AGamBidManager(rewardConfig){

    val rewardConfig : RewardedConfiguration
        get() {return adConfig as RewardedConfiguration}

    override fun createAdManagerAdView() {
        prepareRequestBuilder()
    }

    override fun callGam(results: Array<SdkResult>) {
        // results should not be used
        super.callGam(results)

        val builtRequest = request ?: return
        context?.let { context ->

            val weakConfig = WeakReference(rewardConfig)

                RewardedAd.load(
                    context,
                    rewardConfig.adUnitId,
                    builtRequest,
                    object : RewardedAdLoadCallback() {
                        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                            Logger.i("[GamRewardedBidManager] onAdFailedToLoad has been called - ${weakConfig.get()?.adSlotId}, ${loadAdError.message}")

                            weakConfig.get()?.session?.recordEvent(GamRespondedWithError(loadAdError))
                            weakConfig.get()?.sessionEnd()
                            try {
                                weakConfig.get()?.publisherListener?.onAdFailedToLoad(DfpRewardedLoadAdError(loadAdError))
                            }catch (e: Exception){
                                Logger.e("[GamRewardedBidManager] Exception happen in onAdFailedToLoad callback", e)
                            }
                        }

                        override fun onAdLoaded(rewaredAd: RewardedAd) {
                            weakConfig.get()?.let {config->
                                config.rewardedAd = rewaredAd
                                config.session?.recordEvent(GamRespondedSuccessfully())
                                config.setReady()

                                val weakFullListener = WeakReference(config.publisherListener as? IStroeerRewardedFullListener)
                                if(weakFullListener.get() != null){
                                    Logger.i("[GamRewardedBidManager] PublisherListener is also IStroeerRewardedFullListener, set FullScreenContentCallback - ${weakConfig.get()?.adSlotId}")

                                    config.rewardedAd?.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                                        override fun onAdDismissedFullScreenContent() {
                                            Logger.i("[GamRewardedBidManager] onAdDismissedFullScreenContent has been called - ${weakConfig.get()?.adSlotId}")
                                            try {
                                                weakFullListener.get()?.onAdDismissedFullScreenContent()
                                            }catch(e: Exception){
                                                Logger.e("[GamRewardedBidManager] Exception happen in onAdDismissedFullScreenContent callback", e)
                                            }
                                        }

                                        override fun onAdFailedToShowFullScreenContent(err: com.google.android.gms.ads.AdError) {
                                            Logger.i("[GamRewardedBidManager] onAdFailedToShowFullScreenContent has been called - ${weakConfig.get()?.adSlotId}")
                                            try{
                                                weakFullListener.get()?.onAdFailedToShowFullScreenContent(DfpRewardedLoadAdError(err))
                                            }catch(e: Exception){
                                                Logger.e("[GamRewardedBidManager] Exception happen in onAdFailedToShowFull ScreenContent callback", e)
                                            }
                                        }

                                        override fun onAdClicked() {
                                            Logger.i("[GamRewardedBidManager] onAdClicked has been called - ${weakConfig.get()?.adSlotId}")
                                            try {
                                                weakFullListener.get()?.onAdClicked()
                                            }catch (e: Exception){
                                                Logger.e("[GamRewardedBidManager] Exception happen in onAdClicked callback", e)
                                            }
                                        }

                                        override fun onAdImpression() {
                                            Logger.i("[GamRewardedBidManager] onAdImpression has been called - ${weakConfig.get()?.adSlotId}")
                                            try {
                                                weakFullListener.get()?.onAdImpression()
                                            }catch(e: Exception){
                                                Logger.e("[GamRewardedBidManager] Exception happen in onAdImpression callback", e)
                                            }
                                        }

                                        override fun onAdShowedFullScreenContent(){
                                            Logger.i("[GamRewardedBidManager] onAdShowedFullScreenContent has been called - ${weakConfig.get()?.adSlotId}")
                                            try {
                                                weakFullListener.get()?.onAdShowedFullScreenContent()
                                            }catch(e: Exception){
                                                Logger.e("[GamRewardedBidManager] Exception happen in onAdShowedFullScreenContent callback", e)
                                            }
                                        }
                                    }
                                }// end of full listener

                                Logger.i("[GamRewardedBidManager] onAdLoaded has been called - ${weakConfig.get()?.adSlotId}")

                                try {
                                    weakConfig.get()?.publisherListener?.onAdLoaded(weakConfig.get()?.rewardedAd)

                                    if (weakConfig.get()?.loadAfterReady == true) {
                                        show()
                                    }
                                } catch (exception: Exception) {
                                    Logger.e(
                                        "[StroeerRewardedView] Exception happen in onAdLoaded callback - ${exception.message}",
                                        exception
                                    )
                                }
                            }
                        }
                    })
            }
    }

    fun show(){
        rewardConfig.activityContext?.let{
            val weakConfig = WeakReference(rewardConfig)
            rewardConfig.rewardedAd?.show(it as Activity, object : OnUserEarnedRewardListener {
                override fun onUserEarnedReward(p0: RewardItem) {
                    Logger.i("[StroeerRewardedView] onUserEarnedReward has been called - ${weakConfig.get()?.adSlotId}")
                    weakConfig.get()?.publisherListener?.onUserEarnedReward(p0)
                }
            })
        }
    }

    override fun destroy(){
        rewardConfig.rewardedAd?.fullScreenContentCallback = null
        rewardConfig.rewardedAd = null
        super.destroy()   // also clears the built request
    }
}