package com.stroeer.ads.reporting.events

import com.google.gson.JsonObject
//import com.stroeer.ads.bidding.ISdkAdapter
import com.stroeer.ads.utilities.logging.Logger
import com.stroeer.ads.bidding.ISdkAdapter

//class BidRequested(var adapter: ISdkAdapter) : TimeEvent() {
//    override fun toJsonObject(): JsonObject {
//        val jsonObject = super.toJsonObject()
//        try {
//            jsonObject.addProperty("bidder", adapter.name)
//        } catch (e: Exception) {
//            Logger.e("[BidRequested] Error while creating JSON object", e)
//        }
//        return jsonObject
//    }
//}


class BidRequested(var adapter: ISdkAdapter) : TimeEvent() {
    override fun toJsonObject(): JsonObject {
        val jsonObject = super.toJsonObject()
        try {
            //jsonObject.addProperty("bidder", adapter.name)
        } catch (e: Exception) {
            Logger.e("[BidRequested] Error while creating JSON object", e)
        }
        return jsonObject
    }
}


