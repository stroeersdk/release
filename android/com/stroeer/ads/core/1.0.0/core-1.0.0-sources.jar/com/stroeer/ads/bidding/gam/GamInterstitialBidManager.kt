package com.stroeer.ads.bidding.gam

import android.app.Activity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.admanager.AdManagerInterstitialAd
import com.google.android.gms.ads.admanager.AdManagerInterstitialAdLoadCallback
import com.stroeer.ads.exceptions.DfpInterstitialLoadAdError
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.reporting.events.GamRespondedSuccessfully
import com.stroeer.ads.reporting.events.GamRespondedWithError
import com.stroeer.ads.utilities.logging.Logger
import java.lang.ref.WeakReference

class GamInterstitialBidManager(intConfig: InterstitialConfiguration) : AGamBidManager(intConfig){

    val intConfig : InterstitialConfiguration
        get() {return adConfig as InterstitialConfiguration}

    override fun createAdManagerAdView() {
        prepareRequestBuilder()
    }

    override fun callGam(results: Array<SdkResult>) {
        super.callGam(results)

        val builtRequest = request ?: return
        context?.let { context ->

            val weakConfig = WeakReference(intConfig)

            AdManagerInterstitialAd.load(
                context, intConfig.adUnitId, builtRequest,
                object : AdManagerInterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        val error = DfpInterstitialLoadAdError(loadAdError)
                        weakConfig.get()?.session?.recordEvent(GamRespondedWithError(error))
                        weakConfig.get()?.publisherInterstitialListenerRunner?.onAdFailedToLoad(error, loadAdError.message, null, true)
                    }

                    override fun onAdLoaded(adManagerInterstitialAd: AdManagerInterstitialAd) {
                        weakConfig.get()?.let {
                            it.adManagerInterstitialAd = adManagerInterstitialAd

                            if(it.publisherInterstitialListenerRunner?.isFullListener() == true){
                                adManagerInterstitialAd.fullScreenContentCallback =
                                    object : FullScreenContentCallback() {
                                        override fun onAdFailedToShowFullScreenContent(var1: AdError) {
                                            weakConfig.get()?.publisherInterstitialListenerRunner?.onAdFailedToShowFullScreenContent(DfpInterstitialLoadAdError(var1))
                                        }

                                        override fun onAdShowedFullScreenContent() {
                                            weakConfig.get()?.publisherInterstitialListenerRunner?.onAdShowedFullScreenContent()
                                        }

                                        override fun onAdDismissedFullScreenContent() {
                                            weakConfig.get()?.publisherInterstitialListenerRunner?.onAdDismissedFullScreenContent()
                                        }

                                        override fun onAdImpression() {
                                            weakConfig.get()?.publisherInterstitialListenerRunner?.onAdImpression()
                                        }

                                        override fun onAdClicked() {
                                            weakConfig.get()?.publisherInterstitialListenerRunner?.onAdClicked()
                                        }
                                    }
                            }

                            weakConfig.get()?.publisherInterstitialListenerRunner?.onAdLoaded(beforeStart = {
                                Logger.i("[StroeerInterstitialView] onAdLoaded has been called - ${weakConfig.get()?.adSlotId}")
                                weakConfig.get()?.session?.recordEvent(GamRespondedSuccessfully())
                                return@onAdLoaded true
                            })
                        }
                    }
                })
        }
    }

    fun show(){
        intConfig.activityContext?.let {
            intConfig.adManagerInterstitialAd?.show(it as Activity)
        }
    }
}