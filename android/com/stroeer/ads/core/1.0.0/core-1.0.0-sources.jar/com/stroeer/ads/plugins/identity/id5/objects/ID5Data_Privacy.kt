package com.stroeer.ads.plugins.identity.id5.objects

/**
 * "privacy": {
 * "jurisdiction": "other",
 * "id5_consent": true
 * 
 * },  */
@Suppress("PropertyName","ClassName")
class ID5Data_Privacy {
    var jurisdiction: String? = null

    // Nullable on purpose: a non-null Boolean would default to false, leaving Gson unable to
    // tell an absent field from an explicit "id5_consent": false. Only an explicit false is a
    // withdrawal of consent, so that distinction has to survive parsing.
    var id5_consent: Boolean? = null
}
