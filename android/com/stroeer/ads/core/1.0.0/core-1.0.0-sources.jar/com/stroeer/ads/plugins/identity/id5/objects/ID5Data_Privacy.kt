package com.stroeer.ads.plugins.identity.id5.objects

/**
 * "privacy": {
 * "jurisdiction": "other",
 * "id5_consent": true
 * 
 * },  */
@Suppress("PropertyName","ClassName")
class ID5Data_Privacy {
    var jurisdiction: String? = null
    var id5_consent: Boolean = false
}
