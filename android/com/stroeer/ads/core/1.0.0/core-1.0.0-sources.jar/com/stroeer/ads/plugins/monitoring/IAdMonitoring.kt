package com.stroeer.ads.plugins.monitoring

import android.view.View

interface IAdMonitoring {
    fun enableReload()
    fun enableTestMode()
    fun initialize(confiantPropertyId: String, callback: IAdMonitorCallback?)
    fun mark(view: View, placementId: String)
}
