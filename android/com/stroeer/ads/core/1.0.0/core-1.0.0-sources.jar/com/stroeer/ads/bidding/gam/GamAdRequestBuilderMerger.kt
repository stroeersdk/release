package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest

/**
 * Combines the process wide request settings with the ones the publisher set on this ad, into a
 * fresh builder so that neither input is mutated.
 *
 * Local values win; global values only fill in what the local builder left unset.
 *
 * GMA has no way to copy a builder, so everything has to be read back off a built request. Three
 * things cannot be read back at all - network extras bundles and custom event extras bundles are
 * only retrievable per adapter class, which cannot be enumerated, and category exclusions have no
 * getter - so a publisher who sets those on their own builder will not see them in the request.
 * Everything the GMA API does expose is copied here.
 */
internal object GamAdRequestBuilderMerger {

    fun merge(
        globalBuilder: AdManagerAdRequest.Builder,
        localBuilder: AdManagerAdRequest.Builder
    ): AdManagerAdRequest.Builder {
        val globalRequest = globalBuilder.build()
        val localRequest = localBuilder.build()

        val finalBuilder = AdManagerAdRequest.Builder()

        copyLocalValues(finalBuilder, localRequest)
        mergeGlobalOnlyValues(finalBuilder, globalRequest, localRequest)

        return finalBuilder
    }

    private fun copyLocalValues(
        builder: AdManagerAdRequest.Builder,
        localRequest: AdManagerAdRequest
    ) {
        copyCustomTargeting(builder, localRequest)

        @Suppress("UNNECESSARY_SAFE_CALL")  // GMA's API is nullable, but the docs say it should never be null.
        localRequest.contentUrl?.let { builder.setContentUrl(it) }

        localRequest.neighboringContentUrls
            .takeIf { it.isNotEmpty() }
            ?.let { builder.setNeighboringContentUrls(it) }

        for (keyword in localRequest.keywords) {
            builder.addKeyword(keyword)
        }

        @Suppress("UNNECESSARY_SAFE_CALL")  // GMA's API is nullable, but the docs say it should never be null.
        localRequest.requestAgent?.let { builder.setRequestAgent(it) }
        localRequest.adString?.let { builder.setAdString(it) }
        localRequest.placementId.takeIf { it != UNSET_PLACEMENT_ID }?.let { builder.setPlacementId(it) }
        @Suppress("UNNECESSARY_SAFE_CALL")  // GMA's API is nullable, but the docs say it should never be null.
        localRequest.publisherProvidedId?.let { builder.setPublisherProvidedId(it) }
    }

    private fun mergeGlobalOnlyValues(
        builder: AdManagerAdRequest.Builder,
        globalRequest: AdManagerAdRequest,
        localRequest: AdManagerAdRequest
    ) {
        val globalCustomTargeting = globalRequest.customTargeting
        val localCustomTargeting = localRequest.customTargeting
        for (key in globalCustomTargeting.keySet()) {
            if (!localCustomTargeting.containsKey(key)) {
                globalCustomTargeting.getString(key)?.let { builder.addCustomTargeting(key, it) }
            }
        }

        @Suppress("SENSELESS_COMPARISON", "UNNECESSARY_SAFE_CALL")  // GMA's API is nullable, but the docs say it should never be null.
        if (localRequest.contentUrl == null) {
            globalRequest.contentUrl?.let { builder.setContentUrl(it) }
        }

        if (localRequest.neighboringContentUrls.isEmpty()) {
            globalRequest.neighboringContentUrls
                .takeIf { it.isNotEmpty() }
                ?.let { builder.setNeighboringContentUrls(it) }
        }

        val localKeywords = localRequest.keywords
        for (keyword in globalRequest.keywords) {
            if (!localKeywords.contains(keyword)) {
                builder.addKeyword(keyword)
            }
        }

        @Suppress("SENSELESS_COMPARISON", "UNNECESSARY_SAFE_CALL")  // GMA's API is nullable, but the docs say it should never be null.
        if (localRequest.requestAgent == null) {
            globalRequest.requestAgent?.let { builder.setRequestAgent(it) }
        }

        if (localRequest.adString == null) {
            globalRequest.adString?.let { builder.setAdString(it) }
        }

        if (localRequest.placementId == UNSET_PLACEMENT_ID) {
            globalRequest.placementId.takeIf { it != UNSET_PLACEMENT_ID }?.let { builder.setPlacementId(it) }
        }

        // Guarded rather than passed straight through: with both sides unset this used to hand
        // GMA a null publisher provided id.
        @Suppress("SENSELESS_COMPARISON", "UNNECESSARY_SAFE_CALL")  // GMA's API is nullable, but the docs say it should never be null.
        if (localRequest.publisherProvidedId == null) {
            globalRequest.publisherProvidedId?.let { builder.setPublisherProvidedId(it) }
        }
    }

    /**
     * Custom targeting is read back out of a [android.os.Bundle]. A key GMA cannot return as a
     * string is skipped rather than asserted on, so one odd entry cannot take the whole request
     * down with it.
     */
    private fun copyCustomTargeting(
        builder: AdManagerAdRequest.Builder,
        localRequest: AdManagerAdRequest
    ) {
        val customTargeting = localRequest.customTargeting
        for (key in customTargeting.keySet()) {
            customTargeting.getString(key)?.let { builder.addCustomTargeting(key, it) }
        }
    }

    /** GMA's default for an unset placement id. */
    private const val UNSET_PLACEMENT_ID = 0L
}
