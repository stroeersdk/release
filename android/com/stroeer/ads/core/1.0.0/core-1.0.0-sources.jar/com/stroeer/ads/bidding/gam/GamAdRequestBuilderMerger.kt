package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest

internal object GamAdRequestBuilderMerger {

    fun merge(
        globalBuilder: AdManagerAdRequest.Builder,
        localBuilder: AdManagerAdRequest.Builder
    ): AdManagerAdRequest.Builder {
        val globalRequest = globalBuilder.build()
        val localRequest = localBuilder.build()

        val finalBuilder = AdManagerAdRequest.Builder()

        copyLocalValues(finalBuilder, localRequest)
        mergeGlobalOnlyValues(finalBuilder, globalRequest, localRequest)

        return finalBuilder
    }

    private fun copyLocalValues(
        builder: AdManagerAdRequest.Builder,
        localRequest: AdManagerAdRequest
    ) {
        for (key in localRequest.customTargeting.keySet()) {
            builder.addCustomTargeting(key, localRequest.customTargeting.getString(key)!!)
        }

        localRequest.contentUrl?.let { builder.setContentUrl(it) }

        for (keyword in localRequest.keywords) {
            builder.addKeyword(keyword)
        }

        @Suppress("SENSELESS_COMPARISON")
        if (localRequest.publisherProvidedId != null) {
            builder.setPublisherProvidedId(localRequest.publisherProvidedId)
        }
    }

    private fun mergeGlobalOnlyValues(
        builder: AdManagerAdRequest.Builder,
        globalRequest: AdManagerAdRequest,
        localRequest: AdManagerAdRequest
    ) {
        val globalCustomTargeting = globalRequest.customTargeting
        val localCustomTargeting = localRequest.customTargeting
        for (key in globalCustomTargeting.keySet()) {
            if (!localCustomTargeting.containsKey(key)) {
                builder.addCustomTargeting(key, globalCustomTargeting.getString(key)!!)
            }
        }

        @Suppress("SENSELESS_COMPARISON")
        if (localRequest.contentUrl == null && globalRequest.contentUrl != null) {
            builder.setContentUrl(globalRequest.contentUrl)
        }

        val localKeywords = localRequest.keywords
        for (keyword in globalRequest.keywords) {
            if (!localKeywords.contains(keyword)) {
                builder.addKeyword(keyword)
            }
        }

        @Suppress("SENSELESS_COMPARISON")
        if (localRequest.publisherProvidedId == null) {
            builder.setPublisherProvidedId(globalRequest.publisherProvidedId)
        }
    }
}