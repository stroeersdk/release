package com.stroeer.ads.plugins.identity

import android.content.Context
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.ConfigurationManager.Companion.isDebugMode
import com.stroeer.ads.plugins.identity.id5.ID5Manager
import com.stroeer.ads.plugins.identity.objects.IdentityCustomInfo
import com.stroeer.ads.utilities.common.ISuccessFailListener
import com.stroeer.ads.utilities.concurrent.ACoroutinable
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Date
import kotlinx.coroutines.sync.withLock
import kotlin.time.Duration.Companion.milliseconds

class IdentityManager : ACoroutinable(){
    @JvmField
    var identityManager: IIdentityManager? = null
    @JvmField
    var listener: ISuccessFailListener<Any>? = null
    var customInfo: IdentityCustomInfo? = null

    /**
     * Configures the identity manager to use ID5 as the default provider.
     */
    fun useID5() {
        if(identityManager !is ID5Manager){
            identityManager = ID5Manager()
        }
    }

    /**
     * Initializes the IdentityManager with application context and a listener.
     * 
     * @param applicationContext Application context.
     * @param listener Callback listener for success or failure events.
     */
    fun initialize(applicationContext: Context, listener: ISuccessFailListener<Any>?) {

        this.listener = listener

        mainScope.launch (ioDispatcher){

            ConfigurationManager.getInstance().getConfigAsync()

            if (!ConfigurationManager.getInstance().isLoaded) {
                Logger.e("[IdentityManager] Configuration not loaded. Initialization skipped.")
                listener?.onFailed()
                return@launch
            }

            if (identityManager == null) {
                Logger.i("[IdentityManager] Identity Manager is not set by user. Trying to find a default Identity Manager")

                if (ConfigurationManager.getInstance().getConfig()!!.modules.id5.active) {
                    Logger.i("[IdentityManager] ID5 is active. Using ID5 as default Identity Manager")
                    useID5()
                }
            }

            // Still no identity manager set
            if (identityManager == null) {
                Logger.e("[IdentityManager] No identity manager set. Identity Manager is disabled.")
                listener?.onFailed()
                return@launch
            }

            identityManager?.initialize(applicationContext)
            load()
        }
    }

    /**
     * Loads identity information from storage or triggers refresh if needed.
     */
    suspend fun load() {
        if (this.isNotInitialized) {
            return
        }

        identityManager?.loadIdentityFromStorage()

        refresh()
    }

    fun refreshAsync(){
        mainScope.launch (ioDispatcher){
            refresh()
        }
    }

    /**
     * Refreshes identity data by checking cache and reloading if necessary.
     */
    suspend fun refresh() {
        if (this.isNotInitialized) {
            return
        }

        identityManager?.let{ identityManager->
            val timeout = withTimeoutOrNull(10_000.milliseconds){
                mutex.withLock {
                    val now = Date()
                    var shouldRefresh = true
                    val identityData = identityManager.identityData

                    if (isDebugMode) {
                        identityData.refreshInterval = 300
                        Logger.d("[IdentityManager] As the debug mode is enabled, the interval is automatically changed to ${identityData.refreshInterval}s")
                    } else {
                        identityData.setDefaultRefreshInterval()
                    }

                    val cacheExpiryTime = identityData.cacheCreationDate.time + identityData.refreshInterval * 1000
                    shouldRefresh = cacheExpiryTime < now.time || identityManager.isUpdated()

                    Logger.d("[IdentityManager] Cache check: Cache date: ${identityData.cacheCreationDate}, Current date: ${now}, Interval: ${identityData.refreshInterval}, Is request updated: ${identityManager.isUpdated()}, Refresh needed: $shouldRefresh")

                    // Set Custom Information
                    customInfo?.let{
                        identityManager.setCustomInfo(it)
                    }

                    if (shouldRefresh) {
                        Logger.i("[IdentityManager] Refreshing identity data from HTTP.")
                        identityManager.loadIdentityFromHttp(false)
                    }

                    if (identityData.identityString.isEmpty()) {
                        Logger.i("[IdentityManager] Failed to load identity, identity data is empty.")
                        listener?.onFailed()
                    } else {
                        if (shouldRefresh) Logger.i("[IdentityManager] Identity successfully loaded.")
                        listener?.onSuccess(identityData)
                    }
                }
            }
            if(timeout == null){
                Logger.d("[IdentityManager] Refresh operation timed out.")
                return
            }
        }



    }

    fun setUserIdToPrebid() {
        if (this.isNotInitialized) {
            return
        }

        identityManager!!.setUserIdToPrebid()
    }

    private val isNotInitialized: Boolean
        /**
         * Checks if the identity manager is initialized.
         * 
         * @return false if initialized, true otherwise.
         */
        get() = identityManager == null


    companion object {
        private var _instance: IdentityManager = IdentityManager()

        @JvmStatic
        var instance: IdentityManager
            get() = _instance
            set(instance) {
                Logger.e("[IdentityManager] instance is set. This should not be called in Production")
                _instance = instance
            }
    }
}
