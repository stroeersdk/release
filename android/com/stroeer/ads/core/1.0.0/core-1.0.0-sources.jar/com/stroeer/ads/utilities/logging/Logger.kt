package com.stroeer.ads.utilities.logging

import android.annotation.SuppressLint
import android.content.Context
import android.os.Looper
import android.util.Log
import com.stroeer.ads.utilities.logging.timber.TimberLogger
import org.jetbrains.annotations.TestOnly
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.*

/**
 * Central logging utility for the SDK.
 *
 * Responsibilities:
 * - Route logs to the configured logger backend (e.g. Timber)
 * - Persist logs to a rotating file
 * - Flush logs periodically and on demand
 * - Capture uncaught exceptions without interfering with the host app
 *
 * Design goals:
 * - Never block the main thread
 * - Avoid re-entrancy inside the logger itself
 * - Be safe to initialize multiple times
 * - Be test-friendly and teardown-safe
 */
@SuppressLint("LogNotTimber")
class Logger private constructor() {

    companion object {
        private const val TAG = "StroeerSDK"
        private const val MAX_LOG_FILE_SIZE = 10 * 1024 * 1024L // 10 MB

        private val instance = Logger()

        private var isDebugMode = false
        private var appContext: Context? = null

        @TestOnly
        internal fun getInstance(): ILogger? = instance.loggerInstance

        @JvmStatic
        fun initialize() = initialize(null)

        /**
         * Initializes the logger.
         *
         * Safe to call multiple times.
         * File logging is enabled only when a Context is provided.
         */
        @JvmStatic
        fun initialize(context: Context?) {
            appContext = context

            if (instance.loggerInstance == null) {
                instance.loggerInstance = TimberLogger(isDebugMode)
            }

            context?.let{
                instance.initializeFileLogging(it)
            }

            instance.startUncaughtExceptionHandler()
            instance.startPeriodicFlush()

            i("Logger initialized (debug=$isDebugMode, fileLogging=${instance.bufferedWriter != null})")
        }

        /**
         * Test-only initialization that avoids Android logging dependencies.
         */
        @TestOnly
        @JvmStatic
        fun initializeForTest() {
            instance.loggerInstance = object : ILogger {
                override fun d(tag: String, message: String) = println("D/$tag: $message")
                override fun i(tag: String, message: String) = println("I/$tag: $message")
                override fun w(tag: String, message: String) = System.err.println("W/$tag: $message")
                override fun e(tag: String, message: String) = System.err.println("E/$tag: $message")
                override fun e(tag: String, message: String, throwable: Throwable?) {
                    System.err.println("E/$tag: $message")
                    throwable?.printStackTrace(System.err)
                }
                override fun dispose() {}
            }

            instance.startUncaughtExceptionHandler()
            instance.startPeriodicFlush()
        }

        /**
         * Enables verbose logging regardless of build type.
         * Intended for QA and diagnostics.
         */
        @JvmStatic
        fun enableDebugMode() {
            if (isDebugMode) return
            isDebugMode = true

            instance.loggerInstance?.dispose()
            instance.loggerInstance = TimberLogger(true)
        }

        /**
         * Provides the Context required for file logging.
         * Must be called after initialize().
         */
        @JvmStatic
        fun setContext(context: Context) {
            if (instance.loggerInstance != null) {
                instance.initializeFileLogging(context)
            } else {
                Log.wtf(TAG, "Logger not initialized. Call Logger.initialize() first.")
            }
        }

        private fun initializeIfNot() {
            if (instance.loggerInstance == null) {
                initialize(appContext)
            }
        }

        /**
         * Applies debug/release severity policy to console logging only.
         * File logging is intentionally NOT affected by this policy.
         */
        private fun logWithDebugPolicy(
            level: String,
            message: String,
            throwable: Throwable? = null
        ) {
            when (level) {
                "ERROR" -> {
                    val message = "[ERROR]$message"
                    if (!com.stroeer.ads.config.ConfigurationManager.disableErrorLog) instance.loggerInstance?.e(TAG, message, throwable)
                    else instance.loggerInstance?.i(TAG, message)
                }
                "WARN" -> {
                    instance.loggerInstance?.i(TAG, message)
                }
                "INFO" -> instance.loggerInstance?.i(TAG, message)
                "DEBUG" -> {
                    if (isDebugMode) instance.loggerInstance?.d(TAG, message)
                }
            }
        }

        // ---- Public logging API (all overloads preserved) ----

        @JvmStatic
        fun d(message: String) {
            initializeIfNot()
            logWithDebugPolicy("DEBUG", message)
            instance.writeLog("DEBUG", message, false)
        }

        @JvmStatic
        fun d(message: String, flush: Boolean = false) {
            initializeIfNot()
            logWithDebugPolicy("DEBUG", message)
            instance.writeLog("DEBUG", message, flush)
        }

        @JvmStatic
        fun d(message: String, throwable: Throwable? = null) {
            initializeIfNot()
            logWithDebugPolicy("DEBUG", message, throwable)
            instance.writeLog("DEBUG", message, false, throwable)
        }

        @JvmStatic
        fun d(message: String, throwable: Throwable? = null, flush: Boolean = false) {
            initializeIfNot()
            logWithDebugPolicy("DEBUG", message, throwable)
            instance.writeLog("DEBUG", message, flush, throwable)
        }

        @JvmStatic
        fun i(message: String) {
            initializeIfNot()
            logWithDebugPolicy("INFO", message)
            instance.writeLog("INFO", message, false)
        }

        @JvmStatic
        fun i(message: String, flush: Boolean = false) {
            initializeIfNot()
            logWithDebugPolicy("INFO", message)
            instance.writeLog("INFO", message, flush)
        }

        @JvmStatic
        fun w(message: String) {
            initializeIfNot()
            logWithDebugPolicy("WARN", message)
            instance.writeLog("WARN", message, false)
        }

        @JvmStatic
        fun w(message: String, flush: Boolean = false) {
            initializeIfNot()
            logWithDebugPolicy("WARN", message)
            instance.writeLog("WARN", message, flush)
        }

        @JvmStatic
        fun e(message: String) {
            initializeIfNot()
            logWithDebugPolicy("ERROR", message)
            instance.writeLog("ERROR", message, false)
        }

        @JvmStatic
        fun e(throwable: Throwable?) {
            initializeIfNot()
            val message = throwable?.message ?: "Unknown error"
            logWithDebugPolicy("ERROR", message, throwable)
            instance.writeLog("ERROR", message, false, throwable)
        }

        @JvmStatic
        fun e(message: String, throwable: Throwable? = null) {
            initializeIfNot()
            logWithDebugPolicy("ERROR", message, throwable)
            instance.writeLog("ERROR", message, false, throwable)
        }

        @JvmStatic
        fun e(message: String, throwable: Throwable? = null, flush: Boolean = false) {
            initializeIfNot()
            logWithDebugPolicy("ERROR", message, throwable)
            instance.writeLog("ERROR", message, flush, throwable)
        }

        /**
         * Flushes the log file synchronously.
         * Never blocks the main thread.
         */
        @JvmStatic
        fun flush() {
            if (instance.bufferedWriter == null) return
            instance.flushInternal(blocking = true)
        }

        /**
         * Flushes the log file asynchronously.
         */
        @JvmStatic
        fun flushAsync() {
            if (instance.bufferedWriter == null) return
            instance.flushInternal(blocking = false)
        }

        /**
         * Closes the logger.
         *
         * When shutdownExecutors is true, all background threads are terminated.
         * Intended for tests or controlled teardown scenarios.
         */
        @JvmStatic
        fun close(shutdownExecutors: Boolean = false) {
            if (instance.bufferedWriter == null) return

            instance.stopPeriodicFlush()
            instance.closeInternal()
            instance.bufferedWriter = null
            instance.loggerInstance = null

            if (shutdownExecutors) {
                instance.restoreUncaughtExceptionHandlerIfNeeded()
                instance.shutdownExecutors()
            }
        }

        @TestOnly
        @JvmStatic
        fun shutdownForTest() {
            close(shutdownExecutors = true)
        }
    }

    // ---- Internal state ----

    @Volatile private var loggerInstance: ILogger? = null
    @Volatile private var bufferedWriter: BufferedWriter? = null
    @Volatile private var logFile: File? = null

    /**
     * Guards against installing multiple uncaught exception handlers.
     */
    @Volatile private var handlerInstalled = false
    @Volatile private var previousUncaughtHandler: Thread.UncaughtExceptionHandler? = null

    /**
     * Dedicated single-thread executors to preserve log ordering.
     */
    private fun newIoExecutor(): ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor {
            Thread(it, "StroeerLogger-IO").apply { isDaemon = true }
        }

    private fun newSchedulerExecutor(): ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor {
            Thread(it, "StroeerLogger-Scheduler").apply { isDaemon = true }
        }

    @Volatile private var executor: ScheduledExecutorService? = null
    @Volatile private var scheduledExecutor: ScheduledExecutorService? = null

    private var periodicFlushTask: ScheduledFuture<*>? = null

    /**
     * Initializes file logging.
     * Must never call Logger.* to avoid re-entrancy.
     */
    @Synchronized
    private fun initializeFileLogging(context: Context) {
        if (bufferedWriter != null) return

        try {
            val logDir = File(context.filesDir, "logs")
            if (!logDir.exists()) logDir.mkdirs()

            logFile = File(logDir, "stroeer.log")
            bufferedWriter = BufferedWriter(FileWriter(logFile, true), 1024)

            writeNewSession()

            Log.i(TAG, "Log file initialized: $logFile")
        } catch (e: IOException) {
            Log.e(TAG, "Failed to initialize log file", e)
        }
    }

    /**
     * Writes a session delimiter to the log file.
     */
    private fun writeNewSession() {
        bufferedWriter?.apply {
            repeat(3) { newLine() }
            write("=============================================================")
            newLine()
            write("New session started")
            newLine()
            write("=============================================================")
            newLine()
        }
    }

    /**
     * Ensures executors are alive.
     * Recreates them if they were shut down.
     */
    @Synchronized
    private fun ensureExecutors() {
        val ex = executor
        if (ex == null || ex.isShutdown || ex.isTerminated) {
            executor = newIoExecutor()
        }
        val sched = scheduledExecutor
        if (sched == null || sched.isShutdown || sched.isTerminated) {
            scheduledExecutor = newSchedulerExecutor()
        }
    }

    /**
     * Writes a formatted log entry to the file.
     */
    private fun writeLog(
        level: String,
        message: String,
        flush: Boolean,
        throwable: Throwable? = null
    ) {
        val formatted = formatLogMessage(level, message)
        writeLogToFile(formatted, throwable)

        if (flush) {
            if (Looper.getMainLooper().thread === Thread.currentThread()) {
                Logger.flushAsync()
            } else {
                Logger.flush()
            }
        }
    }

    private val dateFormat = ThreadLocal.withInitial {
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
    }

    private fun formatLogMessage(level: String, message: String): String {
        val ts = dateFormat.get()!!.format(Date())
        return "$ts [$level] $TAG: $message"
    }

    private fun getLogFileSize(): Long = logFile?.length() ?: 0L

    /**
     * Performs actual file I/O on the background executor.
     */
    private fun writeLogToFile(message: String, throwable: Throwable?) {
        if (bufferedWriter == null) return
        ensureExecutors()

        val stack = throwable?.let { "\n" + Log.getStackTraceString(it) } ?: ""
        val entry = "$message$stack\n"

        executor!!.execute {
            try {
                bufferedWriter?.apply {
                    write(entry)
                    if (getLogFileSize() >= MAX_LOG_FILE_SIZE) {
                        rotateLogFile()
                    }
                }
            } catch (e: IOException) {
                Log.e(TAG, "Error writing log file", e)
                try { bufferedWriter?.close() } catch (_: IOException) {}
                bufferedWriter = null
            }
        }
    }

    /**
     * Rotates the log file when the size limit is reached.
     */
    @Synchronized
    private fun rotateLogFile() {
        if (bufferedWriter == null || logFile == null) return

        try {
            bufferedWriter?.flush()
            bufferedWriter?.close()

            val rotated = File(logFile!!.parent, "stroeer_old.log")
            if (rotated.exists()) rotated.delete()
            logFile!!.renameTo(rotated)

            logFile = File(logFile!!.parent, "stroeer.log")
            bufferedWriter = BufferedWriter(FileWriter(logFile, true), 1024)
        } catch (e: IOException) {
            Log.e(TAG, "Error rotating log file", e)
        }
    }

    /**
     * Installs a single uncaught exception handler.
     * Delegates to the previous handler after logging.
     */
    @Synchronized
    private fun startUncaughtExceptionHandler() {
        if (handlerInstalled) return

        previousUncaughtHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e(TAG, "Uncaught exception in thread ${thread.name}", throwable)
            flushAsync()
            previousUncaughtHandler?.uncaughtException(thread, throwable)
        }

        handlerInstalled = true
    }

    /**
     * Restores the original uncaught exception handler.
     */
    @Synchronized
    private fun restoreUncaughtExceptionHandlerIfNeeded() {
        if (!handlerInstalled) return

        previousUncaughtHandler?.let {
            Thread.setDefaultUncaughtExceptionHandler(it)
        }

        previousUncaughtHandler = null
        handlerInstalled = false
    }

    /**
     * Periodically flushes buffered logs to disk.
     */
    private fun startPeriodicFlush() {
        if (bufferedWriter == null) return
        ensureExecutors()

        periodicFlushTask?.cancel(false)
        periodicFlushTask = scheduledExecutor!!.scheduleWithFixedDelay(
            { Logger.flushAsync() },
            10, 10, TimeUnit.SECONDS
        )
    }

    private fun stopPeriodicFlush() {
        periodicFlushTask?.cancel(true)
        periodicFlushTask = null
    }

    /**
     * Flushes the writer, optionally blocking a background thread.
     */
    private fun flushInternal(blocking: Boolean) {
        ensureExecutors()

        val writer = bufferedWriter ?: return

        if (!blocking) {
            executor!!.execute {
                try {
                    writer.flush()
                } catch (e: IOException) {
                    Log.e(TAG, "Error flushing log file", e)
                }
            }
            return
        }

        val latch = CountDownLatch(1)
        executor!!.execute {
            try {
                writer.flush()
            } catch (e: IOException) {
                Log.e(TAG, "Error flushing log file", e)
            } finally {
                latch.countDown()
            }
        }

        if (Looper.getMainLooper().thread !== Thread.currentThread()) {
            latch.await(2, TimeUnit.SECONDS)
        }
    }

    /**
     * Closes the log file safely.
     */
    private fun closeInternal() {
        ensureExecutors()

        val writer = bufferedWriter ?: return
        val blocking = Looper.getMainLooper().thread !== Thread.currentThread()

        if (!blocking) {
            executor!!.execute {
                try {
                    writer.flush()
                    writer.close()
                } catch (e: IOException) {
                    Log.e(TAG, "Error closing log file", e)
                } finally {
                    bufferedWriter = null
                }
            }
            return
        }

        val latch = CountDownLatch(1)
        executor!!.execute {
            try {
                writer.flush()
                writer.close()
            } catch (e: IOException) {
                Log.e(TAG, "Error closing log file", e)
            } finally {
                bufferedWriter = null
                latch.countDown()
            }
        }

        latch.await(2, TimeUnit.SECONDS)
    }

    /**
     * Shuts down all background executors.
     * Intended for tests and controlled teardown.
     */
    @Synchronized
    private fun shutdownExecutors() {
        try { periodicFlushTask?.cancel(true) } catch (_: Throwable) {}
        periodicFlushTask = null

        try { scheduledExecutor?.shutdownNow() } catch (_: Throwable) {}
        try { executor?.shutdownNow() } catch (_: Throwable) {}
    }
}

fun Any.logPrefix(): String = "[${this::class.java.simpleName}] "

fun Any.d(message: String?) {
    Logger.d(logPrefix() + message)
}

fun Any.d(message: String?, flush: Boolean) {
    Logger.d(logPrefix() + message, flush)
}

fun Any.d(message: String?, throwable: Throwable?) {
    Logger.d(logPrefix() + message, throwable)
}

fun Any.d(message: String?, throwable: Throwable?, flush: Boolean) {
    Logger.d(logPrefix() + message, throwable, flush)
}

fun Any.i(message: String?) {
    Logger.i(logPrefix() + message)
}

fun Any.i(message: String?, flush: Boolean) {
    Logger.i(logPrefix() + message, flush)
}

fun Any.w(message: String?) {
    Logger.w(logPrefix() + message)
}

fun Any.w(message: String?, flush: Boolean) {
    Logger.w(logPrefix() + message, flush)
}

fun Any.e(message: String?) {
    Logger.e(logPrefix() + message)
}

fun Any.e(throwable: Throwable?) {
    Logger.e(throwable)
}

fun Any.e(message: String?, throwable: Throwable?) {
    Logger.e(logPrefix() + message, throwable)
}

fun Any.e(message: String?, throwable: Throwable?, flush: Boolean) {
    Logger.e(logPrefix() + message, throwable, flush)
}