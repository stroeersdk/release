package com.stroeer.ads.plugins.identity.collectors

import com.stroeer.ads.plugins.identity.IIdentityCollector

/**
 * Return maid type, Google is gaid. Constant value.
 */
class MaidTypeCollector : IIdentityCollector<String?> {
    override suspend fun retrieveData(): String? {
        return "gaid"
    }
}
