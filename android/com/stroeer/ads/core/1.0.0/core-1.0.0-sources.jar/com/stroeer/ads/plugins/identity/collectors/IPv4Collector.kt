package com.stroeer.ads.plugins.identity.collectors

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.stroeer.ads.plugins.identity.ACollectorWithContext
import com.stroeer.ads.utilities.http.HttpClient
import com.stroeer.ads.utilities.http.HttpRequest
import com.stroeer.ads.utilities.http.HttpResponse
import com.stroeer.ads.utilities.http.HttpTimeouts
import com.stroeer.ads.utilities.logging.d
import com.stroeer.ads.utilities.logging.e
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.withLock
import java.net.NetworkInterface
import java.util.Collections

/*
    * Return IPv4 address
 */
open class IPv4Collector : ACollectorWithContext<String?>() {

    protected val timeoutInSecs: Int = 3
    protected open val checkURL: String = "https://checkip.amazonaws.com/"

    // Cache is per-instance: IPv4Collector and IPv6Collector must NOT share it, otherwise the
    // collector that runs second returns the other protocol's cached address.
    protected var currentIP: String = EMPTY_IP
    protected var lastUpdate: Long = 0

    fun needToUpdate(now : Long) : Boolean{
        return currentIP == EMPTY_IP || (now - lastUpdate) > RECHECK_PERIOD
    }

    override suspend fun retrieveData(): String? {
        mutex.withLock {
            val now = System.currentTimeMillis()
            if (!needToUpdate(now)) {
                return currentIP
            }

            try {
                // Suspending variant so a cancelled collector actually aborts the in-flight call
                // (via HttpClient.send) instead of leaving a socket open until its own timeout.
                val publicIp = getPublicIPAddressSuspend(checkURL)
                val localIp = getIPAddress(applicationContext)

                if (!publicIp.isNullOrEmpty() && isValidFormat(publicIp)) {
                    lastUpdate = now
                    currentIP = publicIp
                } else if (!localIp.isNullOrEmpty() && isValidFormat(localIp)) {
                    lastUpdate = now
                    currentIP = localIp
                }
            } catch (ex: CancellationException) {
                throw ex
            } catch (ex: Exception) {
                d("Failed to get IP addresses", ex)
            }
            return currentIP
        }
    }

    fun getIPAddress(context: Context): String? {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = cm.activeNetwork

            if (activeNetwork != null) {
                val capabilities = cm.getNetworkCapabilities(activeNetwork)
                if (capabilities != null) {
                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        return mobileIPAddress
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        return getWifiIPAddress()
                    }
                }
            }
            null
        } catch (ex: Exception) {
            d("Failed to get IP address", ex)
            null
        }
    }

    protected open fun getWifiIPAddress(): String? {
        return getNetworkIPAddress(false)
    }

    protected open val mobileIPAddress: String?
        get() = getNetworkIPAddress(false)

    fun getNetworkIPAddress(ipv6: Boolean): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            for (networkInterface in Collections.list(interfaces)) {
                val addresses = networkInterface.inetAddresses
                for (address in Collections.list(addresses)) {
                    if (!address.isLoopbackAddress) {
                        if (!ipv6 && address?.hostAddress?.contains(".") == true) {
                            return address.hostAddress
                        } else if (ipv6 && address?.hostAddress?.contains(":") == true) {
                            return address.hostAddress
                        }
                    }
                }
            }
        } catch (ex: Exception) {
            e("Failed to get IP address", ex)
        }
        return null
    }

    /**
     * Blocking variant, kept public/non-suspend because [IPv6Collector] inherits it and existing
     * callers/tests rely on that shape. Delegates to [buildIpRequest]/[parseIpResponse] so there
     * is exactly one copy of the request-building and body-parsing logic shared with
     * [getPublicIPAddressSuspend].
     */
    fun getPublicIPAddress(url: String): String? {
        return try {
            parseIpResponse(HttpClient.execute(buildIpRequest(url)))
        } catch (ex: Exception) {
            d("Failed to fetch public IP", ex)
            null
        }
    }

    /**
     * Suspending counterpart of [getPublicIPAddress], used by [retrieveData] so that cancelling
     * the collector's coroutine actually aborts the in-flight call via [HttpClient.send] instead
     * of merely abandoning the result once the blocking call eventually times out on its own.
     */
    private suspend fun getPublicIPAddressSuspend(url: String): String? {
        return try {
            parseIpResponse(HttpClient.send(buildIpRequest(url), ioDispatcher))
        } catch (ex: CancellationException) {
            throw ex
        } catch (ex: Exception) {
            d("Failed to fetch public IP", ex)
            null
        }
    }

    private fun buildIpRequest(url: String): HttpRequest {
        return HttpRequest.get(url = url, timeouts = HttpTimeouts.fromSeconds(timeoutInSecs))
    }

    private fun parseIpResponse(response: HttpResponse): String? {
        return if (response.isSuccessful) {
            response.bodyText().trim { it <= ' ' }.replace("\n", "")
        } else {
            null
        }
    }

    open fun isValidFormat(ip: String): Boolean {
        return ip.matches("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b".toRegex())
    }

    companion object {
        const val EMPTY_IP: String = "0.0.0.0"
        const val RECHECK_PERIOD : Long = 10 * 60 * 1000 // 10 minutes
    }
}
