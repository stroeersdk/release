package com.stroeer.ads.formats.banner

import android.content.Context
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.admanager.AdManagerAdView
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.ConfigAdSlot
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.refresh.RefreshTimer
import com.stroeer.ads.bidding.prebid.PrebidBannerView
import com.stroeer.ads.bidding.prebid.PrebidHtmlBannerView
import com.stroeer.ads.utilities.logging.Logger
import org.prebid.mobile.rendering.bidding.listeners.BannerEventListener

/**
 * Holds configuration for a single banner ad instance.
 *
 * Extends [AAdConfiguration] to add banner-specific properties such as
 * refresh timers, listeners, and the underlying [AdManagerAdView].
 */
class BannerConfiguration(context: Context) : AAdConfiguration(context) {

    var availableBannerSizes: Array<AdSize> = arrayOf()

    /** Optional timer used for auto-refreshing the banner at a defined interval. */
    var timer: RefreshTimer? = null

    /** Refresh interval (in milliseconds) for auto-refreshing the banner. */
    var refreshTime: Int? = null

    /** The Main BannerView containing GAM / Prebid **/
    var bannerView: StroeerBannerView? = null

    /** The Google Ad Manager ad view associated with this configuration. */
    var adManagerAdView: AdManagerAdView? = null

    /** This is the final ad size **/
    var adSize : org.prebid.mobile.AdSize? = null

    /** The Prebid BannerView associated with this configuration. */
    // This PrebidBannerView is to call Prebid Request, the actual rendering of Prebid Banner can be done by PrebidHtmlBannerView
    var prebidBannerView: PrebidBannerView? = null
    var prebidEventHandler : BannerEventListener? = null
    var prebidHtmlBannerView : PrebidHtmlBannerView? = null

    /** Listener for banner ad lifecycle events (load, click, impression, etc.). */
    var publisherListener: IStroeerBannerListener? = null
        set (value) {
            field = value
            publisherBannerListenerRunner = if(field != null) {
                PublisherBannerListenerRunner(this)
            } else {
                null
            }
        }

    internal var publisherBannerListenerRunner : PublisherBannerListenerRunner? = null

    /**
     * Initializes the configuration with the given placement name.
     *
     * - Calls the parent [AAdConfiguration.initialize].
     * - Retrieves configuration data from [ConfigurationManager].
     * - Extracts the `autoRefreshTimeMs` for this specific ad slot, if available.
     *
     * @param adSlotId The publisher slot name identifying this banner placement.
     */
    override fun initialize(adSlotId: String) {
        super.initialize(adSlotId)
        refreshTime = configAdSlot?.autoRefreshTimeMs
        // availableBannerSizes = configAdSlot.
        configAdSlot?.let{
            populateAvailableBannerSizes(it)
        }
    }

    /**
     * Cleans up resources used by this banner configuration.
     *
     * - Calls the parent [AAdConfiguration.destroy].
     * - Cancels and clears any active [RefreshTimer].
     * - Releases the [publisherListener] reference to avoid memory leaks.
     */
    override fun destroy() {
        timer?.clearScheduledTasks()
        timer = null
        publisherListener = null
        publisherBannerListenerRunner = null

        destroyViews()
        super.destroy()
    }

    override fun reset(){
        super.reset()

        publisherBannerListenerRunner?.reset()
    }

    override fun destroyViews(){
        bannerView?.removeAllViews()
        publisherBannerListenerRunner?.cancel()

        adManagerAdView?.let{
            try {
                val parent = it.parent as View?
                if (parent is ViewGroup) {
                    parent.removeView(it)
                }
            } catch (e: Exception) {
                Logger.e("[BannerConfiguration] Failed to remove AdView from parent", e)
            }
            it.adListener = object : AdListener() {}
            it.destroy()
            adManagerAdView = null
            Logger.d("[BannerConfiguration] GAM Banner is destroyed - $adSlotId")
        }

        prebidBannerView?.let{
            it.setBannerListener(null)
            it.destroy()
            Logger.d("[BannerConfiguration] Prebid Banner is destroyed - $adSlotId")
            prebidBannerView = null
            prebidEventHandler = null
        }

        prebidHtmlBannerView?.let {obj->
            obj.destroy()
            prebidHtmlBannerView = null
            Logger.d("[BannerConfiguration] Prebid HTML Banner is destroyed - $adSlotId")
        }

        Logger.i("[BannerConfiguration] Banner is destroyed - $adSlotId")
    }

    private fun populateAvailableBannerSizes(configAd: ConfigAdSlot) {
        val list = mutableListOf<AdSize>()

        // Add custom sizes from configuration
        configAd.customAdSizes?.let { cusSizes ->
            for (size in cusSizes) {
                list.add(AdSize(size.w, size.h))
            }
        }

        // Add sizes from formats
        val formats = config?.formats
        formats?.let {
            formats.forEach{ (_, value)->
                if(value?.active == true){
                    if(value.availableOn?.contains(placementName) == true){

                        value.dfpSizes?.let{ dfpSizes->
                            // Add DFP sizes if available
                            list.addAll(dfpSizes.convertBannerSizesForDfp())

                            // Add custom sizes from DFP configuration if available
                            dfpSizes.customAdSizes?.let { cusSizes ->
                                for (size in cusSizes) {
                                    list.add(AdSize(size.w, size.h))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (list.isEmpty()) {
            list.add(AdSize(0, 0))
        }

        availableBannerSizes = list.toTypedArray()
    }
}