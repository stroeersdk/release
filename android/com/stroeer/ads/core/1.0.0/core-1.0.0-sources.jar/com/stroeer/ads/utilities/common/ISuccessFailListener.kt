package com.stroeer.ads.utilities.common

interface ISuccessFailListener<T> {
    fun onSuccess(data: T)
    fun onFailed()
}
