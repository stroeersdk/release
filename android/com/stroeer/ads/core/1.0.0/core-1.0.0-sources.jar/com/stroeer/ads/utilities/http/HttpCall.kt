package com.stroeer.ads.utilities.http

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.InterruptedIOException
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * A one-shot, cancellable HTTP call built from an [HttpRequest].
 *
 * Obtained via [HttpClient.newCall]. Call [execute] exactly once - a second call throws
 * [IllegalStateException], matching the "calls are one-shot" contract callers already know from
 * OkHttp. [cancel] may be called from any thread at any time, including before [execute] starts
 * or concurrently with it; see the fields below for how that race is made safe both ways.
 */
class HttpCall internal constructor(val request: HttpRequest) {

    private companion object {
        /** Redirects beyond this are treated as a runaway chain rather than followed forever. */
        const val MAX_REDIRECTS = 5

        val REDIRECT_STATUS_CODES = setOf(301, 302, 303, 307, 308)
        val BODYLESS_STATUS_CODES = setOf(204, 205, 304)
    }

    private val executed = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)

    /**
     * The connection currently in flight, if any.
     *
     * [cancel] disconnects whatever is published here, and [execute] re-checks [cancelled] after
     * publishing a connection and again at every phase boundary. Both halves are needed and
     * neither is sufficient alone: [HttpURLConnection.disconnect] is documented to do nothing
     * while the platform's internal HTTP engine has not been created yet, so a [cancel] arriving
     * before the first read or write leaves no trace on the connection and only the flag catches
     * it; conversely, once a thread is blocked inside a socket operation the flag is not observed
     * and only the disconnect aborts it.
     *
     * This narrows the window rather than eliminating it. A cancellation landing inside DNS
     * resolution cannot be made to take effect promptly - the platform exposes no way to abort a
     * resolver - so cancellation is prompt in every phase but that one.
     */
    private val liveConnection = AtomicReference<HttpURLConnection?>(null)

    /**
     * Cancels this call. Idempotent and safe to call from any thread, including one other than
     * the thread running [execute].
     *
     * Setting the flag alone would not stop a call that is already blocked inside a socket
     * read or connect - a plain boolean is not observed by that native call. Calling
     * [HttpURLConnection.disconnect] on the live connection is what actually aborts it, which is
     * why both are done here.
     */
    fun cancel() {
        cancelled.set(true)
        liveConnection.get()?.disconnect()
    }

    /**
     * Executes this call, blocking the calling thread until a response is available or the call
     * fails. Throws [IOException] (typically [HttpTransportException]) on any failure; never
     * returns a partial or null response.
     */
    fun execute(): HttpResponse {
        check(executed.compareAndSet(false, true)) {
            "HttpCall.execute() may only be called once per HttpCall instance."
        }

        // One budget for the ENTIRE call - every redirect hop, the upload and the body read -
        // computed once here from a monotonic clock. Recomputing it per connection attempt would
        // let a chain of individually-legal waits add up to an unbounded total, which is exactly
        // what a call-level timeout exists to prevent.
        //
        // It is checked at every phase boundary and between body chunks, but it cannot *preempt*
        // a blocking operation already in progress: HttpURLConnection offers no such hook, and
        // DNS resolution is not covered by its connect timeout either. So the worst case overruns
        // the budget by roughly one connect or read timeout. Callers needing a hard bound should
        // wrap `HttpClient.send` in `withTimeout`, whose cancellation reaches [cancel].
        val deadlineNanos = System.nanoTime() + toNanosSaturating(request.timeouts.callMillis)

        var currentUrl = parseUrl(request.url)
        var currentMethod = request.method
        var currentBody = request.body
        var currentHeaders = request.headers
        var redirectCount = 0

        while (true) {
            checkNotCancelled(currentUrl)

            if (remainingMillis(deadlineNanos) <= 0) {
                throw HttpTransportException.Timeout("Call deadline exceeded before requesting $currentUrl")
            }

            val attempt = performAttempt(currentUrl, currentMethod, currentHeaders, currentBody, deadlineNanos)

            if (attempt.statusCode !in REDIRECT_STATUS_CODES) {
                return HttpResponse(
                    statusCode = attempt.statusCode,
                    message = attempt.message,
                    headers = attempt.headers,
                    bodyBytes = attempt.bodyBytes,
                    finalUrl = currentUrl.toString()
                )
            }

            if (redirectCount >= MAX_REDIRECTS) {
                throw HttpTransportException("Too many redirects (> $MAX_REDIRECTS) starting from ${request.url}")
            }

            val location = attempt.headers.first("Location")
            if (location.isNullOrBlank()) {
                throw HttpTransportException(
                    "Redirect (${attempt.statusCode}) from $currentUrl carried no Location header"
                )
            }

            val redirectTarget = resolveRedirectTarget(currentUrl, location)
            val crossOrigin = !isSameOrigin(currentUrl, redirectTarget)

            // 301/302/303 historically meant "resource moved, re-fetch with GET" and browsers/
            // clients converting a POST to GET on those codes is long-standing, expected
            // behaviour; 307/308 exist specifically to say "same method, same body, just a
            // different URL", so those two preserve everything.
            val convertToGet = currentMethod == HttpMethod.POST && attempt.statusCode != 307 && attempt.statusCode != 308

            currentMethod = if (convertToGet) HttpMethod.GET else currentMethod
            currentBody = if (convertToGet) null else currentBody
            if (convertToGet) {
                // The body is gone, so any caller-supplied header still describing it has to go
                // too. Left in place, a Content-Length from the original POST would make the
                // follow-up GET advertise a body it never sends, and the server would either wait
                // for those bytes or reject the request outright.
                currentHeaders = currentHeaders.without("Content-Length", "Content-Type", "Transfer-Encoding")
            }
            if (crossOrigin) {
                currentHeaders = currentHeaders.without("Authorization", "Cookie")
            }
            currentUrl = redirectTarget
            redirectCount++
        }
    }

    // ---- one connection attempt (no redirect-following logic in here) ----

    private class Attempt(
        val statusCode: Int,
        val message: String?,
        val headers: HttpHeaders,
        val bodyBytes: ByteArray
    )

    private fun performAttempt(
        url: URL,
        method: HttpMethod,
        headers: HttpHeaders,
        body: HttpBody?,
        deadlineNanos: Long
    ): Attempt {
        validateHeaders(headers)
        body?.contentType?.let { validateHeaderValue("Content-Type", it) }

        val remainingMillis = remainingMillis(deadlineNanos)
        val connectMillis = clampToPositiveInt(minOf(request.timeouts.connectMillis.toLong(), remainingMillis))
        val readMillis = clampToPositiveInt(minOf(request.timeouts.readMillis.toLong(), remainingMillis))

        val connection = try {
            url.openConnection() as HttpURLConnection
        } catch (e: IOException) {
            throw HttpTransportException("Could not open a connection to $url: ${e.message}", e)
        }

        // Configure EVERYTHING before the implicit connect triggered by writing/reading below -
        // HttpURLConnection freezes most of this once the connection is established.
        connection.requestMethod = method.name
        // Redirects are handled manually (see execute()): the built-in follower refuses to
        // cross http<->https, which this SDK sometimes legitimately needs to (a plain-http
        // config URL upgrading to https, for instance), and it does not expose the target URL
        // for finalUrl/origin-change bookkeeping.
        connection.instanceFollowRedirects = false
        // A host app can install its own global java.net.ResponseCache. Without this, that cache
        // could sit underneath every request this SDK makes and serve stale ad/config data with
        // no way for us to detect or control it.
        connection.useCaches = false
        connection.connectTimeout = connectMillis
        connection.readTimeout = readMillis

        // Deliberately NOT setting Accept-Encoding: Android's HttpURLConnection requests gzip
        // and transparently decompresses the response only when this header is left untouched.
        // Setting it ourselves (even to "gzip") disables that transparent handling and would
        // leave a caller decoding a gzip stream it did not ask to see.
        for (name in headers.names) {
            if (body?.contentType != null && name.equals("Content-Type", ignoreCase = true)) {
                // The body's content type is authoritative; skip the caller-supplied header so
                // it is not sent twice (and never with conflicting values).
                continue
            }
            for (value in headers.values(name)) {
                validateHeaderValue(name, value)
                connection.addRequestProperty(name, value)
            }
        }
        body?.contentType?.let { connection.setRequestProperty("Content-Type", it) }

        if (method == HttpMethod.POST) {
            connection.doOutput = true
            connection.setFixedLengthStreamingMode(body?.contentLength ?: 0)
        }

        publishConnection(connection)

        // Set only once a response stream has been read to its end, which is the single case where
        // the connection is in a known-reusable state. See the `finally` block.
        var fullyRead = false

        return try {
            if (method == HttpMethod.POST) {
                // disconnect() is documented to do nothing while the platform's internal HTTP
                // engine does not exist yet, so a cancel() landing between publishConnection()'s
                // check and here would have had no effect on the connection. Re-checking the flag
                // at each phase boundary is what stops a cancelled call from still sending its
                // body or still waiting on a response.
                abortIfCancelled(url)
                connection.outputStream.use { out -> body?.writeTo(out) }
            }

            abortIfCancelled(url)
            checkDeadline(deadlineNanos, url, "before reading the response status")

            val statusCode = connection.responseCode
            val message = connection.responseMessage
            val responseHeaders = HttpHeaders.fromConnection(connection.headerFields)
            val bodyBytes = if (statusCode in BODYLESS_STATUS_CODES) {
                // These statuses carry no body by definition, but the platform may still have
                // built a response source from a Content-Length the server sent anyway (a 304
                // legitimately echoes the length of the *cached* representation). Reading it would
                // block for bytes that never arrive, so the stream is only closed - and
                // `fullyRead` deliberately stays false so the `finally` disconnects and nothing is
                // left allocated. Losing connection reuse on a 304 is a fair price for that.
                closeQuietly(connection)
                ByteArray(0)
            } else {
                val stream = if (statusCode >= 400) connection.errorStream else connection.inputStream
                val bytes = stream?.use { readWithinDeadline(it, url, deadlineNanos) } ?: ByteArray(0)
                fullyRead = true
                bytes
            }

            Attempt(statusCode, message, responseHeaders, bodyBytes)
        } catch (e: HttpTransportException) {
            // Already a transport-level failure with a useful message (a deadline overrun during
            // the body read, for instance); re-wrapping it would bury that.
            throw e
        } catch (e: IOException) {
            if (cancelled.get()) {
                throw InterruptedIOException("Call to $url was cancelled").apply { initCause(e) }
            }
            if (e is SocketTimeoutException) {
                throw HttpTransportException.Timeout("Timed out talking to $url", e)
            }
            throw HttpTransportException("Failed talking to $url: ${e.message}", e)
        } finally {
            // Reading a response stream to its end and closing it is what releases the platform's
            // stream allocation and lets the socket go back to the process-wide pool
            // HttpURLConnection maintains. Once that has happened disconnect() has nothing left to
            // close, so skipping it there is free; calling it on every response, on the other
            // hand, risks giving up the connection reuse OkHttp's ConnectionPool(5, 5 min) was
            // configured for. Every other path - a failure, a cancellation, a bodyless response
            // whose stream was closed unread - leaves the connection in an unknown state and is
            // disconnected explicitly.
            if (!fullyRead) {
                connection.disconnect()
            }
            liveConnection.compareAndSet(connection, null)
        }
    }

    /**
     * Reads [stream] to the end, giving up if the call deadline passes mid-transfer.
     *
     * `readTimeout` alone cannot bound this: it limits the wait for the *next* chunk and resets on
     * every chunk that arrives, so a server trickling bytes just inside that limit could hold a
     * call open indefinitely. Re-checking the deadline (and cancellation) between chunks bounds
     * that to one further read timeout instead; see [HttpTimeouts.callMillis] for why no tighter
     * guarantee is available here.
     */
    private fun readWithinDeadline(stream: InputStream, url: URL, deadlineNanos: Long): ByteArray {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        val collected = ByteArrayOutputStream()

        while (true) {
            if (remainingMillis(deadlineNanos) <= 0) {
                throw HttpTransportException.Timeout(
                    "Call deadline exceeded after ${collected.size()} bytes of the response from $url"
                )
            }
            if (cancelled.get()) {
                throw InterruptedIOException("Call to $url was cancelled while reading the response")
            }

            val read = stream.read(buffer)
            if (read == -1) return collected.toByteArray()
            collected.write(buffer, 0, read)
        }
    }

    // ---- cancellation plumbing ----

    private fun checkNotCancelled(url: URL) {
        if (cancelled.get()) {
            throw InterruptedIOException("Call to $url was cancelled before it started")
        }
    }

    /** Aborts at a phase boundary if [cancel] has been called. See [cancel] for why this is needed. */
    private fun abortIfCancelled(url: URL) {
        if (cancelled.get()) {
            throw InterruptedIOException("Call to $url was cancelled")
        }
    }

    private fun checkDeadline(deadlineNanos: Long, url: URL, phase: String) {
        if (remainingMillis(deadlineNanos) <= 0) {
            throw HttpTransportException.Timeout("Call deadline exceeded $phase for $url")
        }
    }

    /**
     * Releases whichever response stream the platform may have opened, without reading it.
     *
     * Used for statuses that carry no body: the point is to hand the allocation back, not to
     * recover data, and a stream that is closed unread cannot be pooled anyway - so any failure
     * here is irrelevant and the connection gets disconnected regardless.
     */
    private fun closeQuietly(connection: HttpURLConnection) {
        runCatching { connection.errorStream?.close() }
        runCatching { connection.inputStream?.close() }
    }

    /**
     * Publishes [connection] as the live one, then re-checks [cancelled]. See [liveConnection]'s
     * KDoc for why this ordering - publish, then check - is what closes the race in both
     * directions.
     */
    private fun publishConnection(connection: HttpURLConnection) {
        liveConnection.set(connection)
        if (cancelled.get()) {
            connection.disconnect()
            throw InterruptedIOException("Call was cancelled")
        }
    }

    // ---- URL / redirect helpers ----

    private fun parseUrl(rawUrl: String): URL {
        val url = try {
            URL(rawUrl)
        } catch (e: MalformedURLException) {
            throw HttpTransportException("Malformed URL: $rawUrl", e)
        }
        return validateSchemeAndStripFragment(url)
    }

    private fun validateSchemeAndStripFragment(url: URL): URL {
        val protocol = url.protocol?.lowercase()
        if (protocol != "http" && protocol != "https") {
            throw HttpTransportException("Unsupported URL scheme in $url; only http/https are allowed")
        }
        return stripFragment(url)
    }

    private fun stripFragment(url: URL): URL {
        if (url.ref == null) return url
        val withoutFragment = url.toExternalForm().substringBefore('#')
        return try {
            URL(withoutFragment)
        } catch (e: MalformedURLException) {
            throw HttpTransportException("Malformed URL after stripping fragment: $withoutFragment", e)
        }
    }

    private fun resolveRedirectTarget(from: URL, location: String): URL {
        // URL(base, spec) resolves a relative Location the same way a browser would; an absolute
        // Location simply overrides it.
        val resolved = try {
            URL(from, location)
        } catch (e: MalformedURLException) {
            throw HttpTransportException("Malformed Location '$location' from redirect at $from", e)
        }

        val toProtocol = resolved.protocol?.lowercase()
        if (toProtocol != "http" && toProtocol != "https") {
            throw HttpTransportException("Refusing to follow redirect from $from to unsupported scheme: $resolved")
        }
        val fromProtocol = from.protocol?.lowercase()
        if (fromProtocol == "https" && toProtocol == "http") {
            // http -> https is allowed (and common: a plain-http entry point upgrading itself);
            // the reverse would silently drop a request that started encrypted onto a channel
            // that is not, so it is refused instead of followed.
            throw HttpTransportException("Refusing redirect that downgrades https to http: $from -> $resolved")
        }

        return stripFragment(resolved)
    }

    private fun isSameOrigin(a: URL, b: URL): Boolean {
        val portA = if (a.port == -1) a.defaultPort else a.port
        val portB = if (b.port == -1) b.defaultPort else b.port
        return a.protocol.equals(b.protocol, ignoreCase = true) &&
            a.host.equals(b.host, ignoreCase = true) &&
            portA == portB
    }

    // ---- misc helpers ----

    private fun remainingMillis(deadlineNanos: Long): Long {
        return (deadlineNanos - System.nanoTime()) / 1_000_000L
    }

    /**
     * Converts a millisecond budget to nanoseconds without wrapping.
     *
     * [HttpTimeouts.fromSeconds] can only produce values that convert safely, but the data class
     * constructor is public and takes an unbounded `Long`. A plain multiplication of, say,
     * `Long.MAX_VALUE` wraps negative and would turn the longest conceivable budget into an
     * instant timeout.
     */
    private fun toNanosSaturating(millis: Long): Long {
        val safeMillis = millis.coerceAtLeast(0L)
        return if (safeMillis > Long.MAX_VALUE / 1_000_000L) Long.MAX_VALUE else safeMillis * 1_000_000L
    }

    private fun clampToPositiveInt(millis: Long): Int {
        // HttpURLConnection treats a timeout of 0 as infinite, and both setConnectTimeout/
        // setReadTimeout take an Int, so this both rules out 0/negative and guards overflow.
        return millis.coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()
    }

    private fun validateHeaders(headers: HttpHeaders) {
        for (name in headers.names) {
            for (value in headers.values(name)) {
                validateHeaderValue(name, value)
            }
        }
    }

    private fun validateHeaderValue(name: String, value: String) {
        if (value.contains('\r') || value.contains('\n')) {
            throw HttpTransportException("Header '$name' contains a CR or LF character, which is not allowed")
        }
        if (name.contains('\r') || name.contains('\n')) {
            throw HttpTransportException("Header name '$name' contains a CR or LF character, which is not allowed")
        }
    }
}
