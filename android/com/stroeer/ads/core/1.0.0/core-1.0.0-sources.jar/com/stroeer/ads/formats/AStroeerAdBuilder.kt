package com.stroeer.ads.formats

import android.app.Activity
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.bidding.gam.AGamBidManager
import com.stroeer.ads.config.objects.AdsSoundSettingStates
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.exceptions.ContextException
import com.stroeer.ads.reporting.TimeSession
import com.stroeer.ads.reporting.events.AdViewPrepared
import com.stroeer.ads.plugins.identity.IdentityManager
import com.stroeer.ads.bidding.SdkManager
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.bidding.prebid.APrebidSdkAdapter
import com.stroeer.ads.utilities.concurrent.ACoroutinable
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.cancelChildren

abstract class AStroeerAdBuilder(var adConfig: AAdConfiguration) : ACoroutinable(){

    protected lateinit var sdkManager: SdkManager
    protected lateinit var prebidSdkAdapter: APrebidSdkAdapter
    protected lateinit var gamBidManager: AGamBidManager

    var contentUrl: String?
        set(value) {
            adConfig.contentUrl = value
        }
        get() {
            return adConfig.contentUrl
        }

    var googleAdViewBuilder: AdManagerAdRequest.Builder?
        get() {
            return adConfig.localBuilder
        }
        set(value) {
            adConfig.localBuilder = value
        }

    protected fun validateContext() {
        DebugInfoManager.applyDebugModeIfNeeded()

        if (adConfig.activityContext !is Activity) {
            throw ContextException("Context is not instance of Activity")
        }
    }

    protected fun prepareSession(adType: AdType) {
        adConfig.applicationContext?.let{appContext->
            adConfig.session = TimeSession(adType, appContext, adConfig.adSlotId)
        }

        adConfig.sessionStart()
    }

    fun checkActive() : Boolean{
        val active = adConfig.configAdSlot?.active != false

        if(!active){
            Logger.i("[AStroeerAdBuilder] AdSlot is inactive - ${adConfig.adSlotId}")
            adConfig.sessionEnd()
            adConfig.setInActive()
            DebugInfoManager.createDebugInfo(adConfig)
            DebugInfoManager.addInactiveInfo(adConfig)
        }

        return active
    }

    protected fun prepareSdkManager() {
        // Refresh IdentityManager. This is fire and forget
        IdentityManager.instance.refreshAsync()

        this.sdkManager = SdkManager(adConfig, arrayOf(this.prebidSdkAdapter))
    }

    protected fun recordAdViewPreparedEvent() {
        adConfig.session?.recordEvent(AdViewPrepared())
    }

    protected open suspend fun getBids(): Array<SdkResult> {
        IdentityManager.instance.setUserIdToPrebid()

        return this.sdkManager.getBids()
    }

    fun useAdsSoundSettingFrom() {
        val adsSoundSetting = adConfig.config?.common?.soundSetting
        if(adsSoundSetting != null && adsSoundSetting != AdsSoundSettingStates.RESPECT_USER_SOUND_SETTING) {
            MobileAds.setAppMuted(adsSoundSetting == AdsSoundSettingStates.MUTE)
        }
    }

    /**
     * Cancels all coroutines and cleans up resources.
     * Subclasses should call this in their destroy() method.
     */
    protected open fun cancelCoroutines() {
        mainScope.coroutineContext.cancelChildren()
    }
}