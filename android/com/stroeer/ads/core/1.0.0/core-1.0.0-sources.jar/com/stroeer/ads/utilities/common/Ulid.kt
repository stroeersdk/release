package com.stroeer.ads.utilities.common

import java.security.SecureRandom

/**
 * ULIDs as specified at https://github.com/ulid/spec - 26 characters of Crockford base32 over a
 * 48 bit millisecond timestamp followed by 80 bits of randomness.
 *
 * Used where something needs a handle that is unique without coordination and readable in a log.
 * Because the timestamp comes first, ids sort lexicographically in creation order, so a log line
 * carrying one says when the thing was created as well as which one it is.
 *
 * Not a UUID: no dashes, no lower case, half the length, and sortable.
 *
 * One deliberate deviation from the spec: ids generated within the same millisecond are fully
 * random rather than monotonically incremented. That drops the sort guarantee *within* a
 * millisecond - which nothing here needs - and keeps this stateless, so it is safe to call from
 * any thread without locking. Uniqueness is unaffected; it rests on the 80 random bits either way.
 */
internal object Ulid {

    /** Crockford base32 - no I, L, O or U, so nothing reads as a digit by mistake. */
    private const val ENCODING = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

    private const val TIME_CHARS = 10
    private const val RANDOM_BYTES = 10
    private const val RANDOM_CHARS = 16

    /** 2^48 - 1, the largest timestamp the format holds. Encodes as 7ZZZZZZZZZ, the year 10889. */
    private const val MAX_TIME_MILLIS = 0xFFFFFFFFFFFFL

    private val random = SecureRandom()

    fun next(timeMillis: Long = System.currentTimeMillis()): String {
        val chars = CharArray(TIME_CHARS + RANDOM_CHARS)

        // The spec caps the timestamp at 48 bits and says larger values must not be encoded, as
        // they would silently overflow into the randomness. A device whose clock is set absurdly
        // far out is not worth throwing an ad request away over, so the value is clamped instead.
        var remainingTime = timeMillis.coerceIn(0L, MAX_TIME_MILLIS)

        // Most significant character first.
        for (index in TIME_CHARS - 1 downTo 0) {
            chars[index] = ENCODING[(remainingTime and 0x1F).toInt()]
            remainingTime = remainingTime shr 5
        }

        // 80 random bits regrouped into 16 characters of 5 bits each, which comes out even.
        val randomBytes = ByteArray(RANDOM_BYTES).also { random.nextBytes(it) }
        var buffer = 0L
        var bufferedBits = 0
        var index = TIME_CHARS

        for (byte in randomBytes) {
            buffer = (buffer shl 8) or (byte.toLong() and 0xFF)
            bufferedBits += 8

            while (bufferedBits >= 5) {
                bufferedBits -= 5
                chars[index++] = ENCODING[((buffer shr bufferedBits) and 0x1F).toInt()]
            }
        }

        return String(chars)
    }
}
