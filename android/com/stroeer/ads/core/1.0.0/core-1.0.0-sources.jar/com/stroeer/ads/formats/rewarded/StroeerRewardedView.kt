package com.stroeer.ads.formats.rewarded


import android.content.Context
import com.google.android.gms.ads.MobileAds
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException
import com.stroeer.ads.exceptions.PreviousAdLoadIsInProgressException
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.utilities.logging.Logger
import com.stroeer.ads.reporting.events.UnexpectedErrorHappenDuringAdLoading
import com.stroeer.ads.formats.AdType
import com.stroeer.ads.formats.AStroeerAdBuilder
import com.stroeer.ads.bidding.gam.GamRewardedBidManager
import kotlinx.coroutines.*
import java.lang.ref.WeakReference
import kotlin.time.Duration.Companion.milliseconds

class StroeerRewardedView(context: Context) : AStroeerAdBuilder(RewardedConfiguration(context))  {
    private var callBackException: RuntimeException? = null

    val rewardConfig: RewardedConfiguration
        get() = adConfig as RewardedConfiguration

    var loadAfterReady : Boolean
        get(){ return rewardConfig.loadAfterReady }
        set(value){ rewardConfig.loadAfterReady = value}

    init {
        adConfig = RewardedConfiguration(context)
        MobileAds.initialize(context.applicationContext)
        gamBidManager = GamRewardedBidManager(rewardConfig)
    }

    fun load(adSlotId: String, listener: IStroeerRewardedListener? = null){
        mainScope.launch {
            loadAsync(adSlotId, listener)
        }
    }

    suspend fun loadAsync(adSlotId: String, listener: IStroeerRewardedListener?) {
        ConfigurationManager.getInstance().getConfigAsync()

        withContext(Dispatchers.Main) {
            try {

                rewardConfig.publisherListener = listener
                rewardConfig.adSlotId = adSlotId

                if (!ConfigurationManager.getInstance().isLoaded) {
                    Logger.e("[StroeerRewarded] Configuration is not loaded - $adSlotId")
                    invokeFailEvent(listener, adSlotId, ConfigurationIsNotLoadedException())
                    return@withContext
                }

                if (adConfig.status.isLoading()) {
                    Logger.e("[StroeerRewarded] Previous ad load is in progress - $adSlotId")
                    invokeFailEvent(listener, adSlotId, PreviousAdLoadIsInProgressException(), false)
                    return@withContext
                }

                rewardConfig.initialize(adSlotId)

                if(!checkActive()){
                    return@withContext
                }

                // Validate Context - must be Activity
                validateContext()

                prepareSession(AdType.REWARDED)

                cleanLocalVariables()

                useAdsSoundSettingFrom()
                delay(1.milliseconds)

                startGAM()
            } catch(e : TimeoutCancellationException){
                Logger.d("[StroeerRewardedView] Timeout - $adSlotId")
                handleExceptions(e)
            }catch(_ : com.stroeer.ads.exceptions.ContextException){
                Logger.e("[StroeerRewardedView] Context is already dead - $adSlotId")
                rewardConfig.setError()
                // No handleExceptions call - context is dead, can't invoke callbacks or show fallback
            }
            catch (e: Exception) {
                Logger.e("[StroeerRewardedView] Exception occurred in loading rewarded - $adSlotId", e)
                handleExceptions(e)
            }
        }
    }

    private fun startGAM(){
        createGoogleAdView()
        recordAdViewPreparedEvent()
        callDfp()
    }



    private fun createGoogleAdView() {
        gamBidManager.initializeGoogleAdAViewIfNotExist()

        val weakListener = WeakReference(rewardConfig.publisherListener)
        val weakFullListener = WeakReference(weakListener.get() as? IStroeerRewardedFullListener)

        if(weakFullListener.get() != null) {
            Logger.i("[StroeerRewardedView] Full Rewarded Listener is added" )
        }

        gamBidManager.createAdManagerAdView()
    }

    private fun cleanLocalVariables() {
        this.callBackException = null
    }

    private fun callDfp() {
        gamBidManager.callGam(arrayOf())
    }

    fun show() {
        Logger.i("[StroeerRewardedView] Show has been called")
        (gamBidManager as? GamRewardedBidManager)?.show()
    }

    private fun handleExceptions(exception: Exception) {
        Logger.e("[StroeerRewarded] Error caught", exception)
        rewardConfig.session?.recordEvent(UnexpectedErrorHappenDuringAdLoading(exception))
        invokeFailEvent(rewardConfig.publisherListener,rewardConfig.adSlotId, StroeerException(exception))
    }

    private fun invokeFailEvent(listener: IStroeerRewardedListener?, adSlotId: String, exception: StroeerException, closeSession : Boolean = true) {
        if(closeSession) {
            rewardConfig.sessionEnd()
            rewardConfig.setError()
        }
        try {
            listener?.onAdFailedToLoad(exception)
        } catch (ex: RuntimeException) {
            Logger.e("[StroeerRewarded] Exception happen in onAdFailedToLoad callback - $adSlotId", ex)
        }
    }

    /**
     * Destroys the rewarded ad and cleans up resources.
     *
     * Optional - typically not needed for one-shot rewarded ad loads as local variables.
     * Only necessary if storing rewarded ad as a field and want explicit cleanup.
     *
     * Cancels any running load operations and releases resources.
     */
    fun destroy() {
        cancelCoroutines()
        rewardConfig.destroy()
        gamBidManager.destroy()
    }
}
