package com.stroeer.ads.plugins.identity.id5

import com.stroeer.ads.plugins.identity.id5.objects.ID5Data
import com.stroeer.ads.plugins.identity.id5.objects.ID5RequestBody
import com.stroeer.ads.utilities.json.HttpJsonRequest
import com.stroeer.ads.utilities.json.JsonBase
import com.stroeer.ads.utilities.logging.Logger

class ID5HttpRequest {
    /**
     * Sends an ID5 request and returns the parsed response.
     * 
     * @param requestBody ID5 request body.
     * @return ID5Data if successful, null otherwise.
     */
    suspend fun send(requestBody: ID5RequestBody): ID5Data? {
        if (!isValid(requestBody)) {
            return null
        }

        val json = sendRequest(requestBody)
        json?.let{
            try {
                val data = JsonBase.fromJson(json, ID5Data::class.java)
                data?.let{
                    // The body carries the universal UID and signature - console only, never the log file.
                    Logger.dNotPersisted("[ID5HttpRequest] Received ID5Data: " + data.toPrettyJson())
                    Logger.d("[ID5HttpRequest] Received ID5Data (uid present: ${!data.universal_uid.isNullOrBlank()})")
                    return data
                }
            } catch (e: Exception) {
                Logger.e("[ID5HttpRequest] Failed to parse ID5Data from json", e)
            }
        }
        return null
    }

    /**
     * Constructs and sends the HTTP request.
     * 
     * @param requestBody ID5 request body.
     * @return JSON response as a string, null if the request fails.
     */
    private suspend fun sendRequest(requestBody: ID5RequestBody): String? {
        val url = ID5Constants.baseUri
        // The body carries the IP, GAID, consent strings, PUID and hashed email/phone.
        // Console only - persisting it would write those identifiers to stroeer.log.
        Logger.dNotPersisted("[ID5HttpRequest] Sending request to " + url + " with body " + requestBody.toPrettyJson())
        Logger.d("[ID5HttpRequest] Sending request to $url")

        val httpJsonRequest = HttpJsonRequest()
        val timeout = ID5Constants.timeoutInSecs

        val body: String = requestBody.toJson() ?: throw IllegalArgumentException("Request body is null")

        // sendPostJson's default contentType ("application/json; charset=utf-8") is authoritative
        // for the body's Content-Type header, so no headers need to be supplied here - a
        // hand-built "Content-Type": "application/json" would just be a conflicting duplicate.
        return httpJsonRequest.sendPostJson(url, null, body, timeout, this.javaClass)
    }

    /**
     * Validates the request body.
     * 
     * @param requestBody ID5 request body.
     * @return true if valid, false otherwise.
     */
    fun isValid(requestBody: ID5RequestBody?): Boolean {
        if (requestBody == null) return logInvalid("Request body is null")
        if (requestBody.ts == null) return logInvalid("Timestamp is null")
        if (requestBody.partner == null) return logInvalid("Partner is null")
        if (requestBody.bundle == null) return logInvalid("Bundle is null")
        if (requestBody.ver == null) return logInvalid("Version is null")
        if (requestBody.ip == null) return logInvalid("IP is null")
        if (requestBody.ua == null) return logInvalid("User agent is null")
        return true
    }

    /**
     * Logs validation failures.
     * 
     * @param message Error message.
     * @return Always returns false.
     */
    private fun logInvalid(message: String?): Boolean {
        Logger.e("[ID5HttpRequest] $message")
        return false
    }
}
