package com.stroeer.ads.config.objects

/**
 * "BIDCACHE": {
 * "active": true,
 * "ttlSeconds": 18000,
 * "maxBuffer": 3,
 * "minThreshold": 0.10
 * }
 *
 * Drives [com.stroeer.ads.bidding.optimization.BidCaching]. The defaults are what the SDK did
 * before the module existed - caching on, a five hour lifetime and no price floor - so a config
 * without a BIDCACHE block keeps caching exactly as it was.
 */
class ConfigModule_BidCache {
    var active: Boolean = false
    var ttlSeconds: Long = DEFAULT_TTL_SECONDS
    var maxBuffer: Int = DEFAULT_MAX_BUFFER
    var minThreshold: Double = DEFAULT_MIN_THRESHOLD

    /** A remote config can carry a nonsensical value; expiry then falls back to the default. */
    val lifetimeSeconds: Long
        get() = ttlSeconds.takeIf { it > 0 } ?: DEFAULT_TTL_SECONDS

    /** How many creatives a slot holds. Zero or less would make caching pointless, so it falls
     * back to the default rather than turning the cache into a no-op - use `active` for that. */
    val creativesPerSlot: Int
        get() = maxBuffer.takeIf { it > 0 } ?: DEFAULT_MAX_BUFFER

    /** Same for the floor - a NaN threshold would compare false and let every bid in silently. */
    val priceFloor: Double
        get() = minThreshold.takeIf { it.isFinite() && it >= 0.0 } ?: DEFAULT_MIN_THRESHOLD

    companion object {
        const val DEFAULT_TTL_SECONDS = 5L * 60 * 60 // 5 hours in seconds
        const val DEFAULT_MAX_BUFFER = 3

        /** No floor unless the config asks for one - the old hardcoded 0.10 was switched off. */
        const val DEFAULT_MIN_THRESHOLD = 0.0
    }
}
