package com.stroeer.ads.plugins.monitoring.confiant

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.plugins.monitoring.AdMonitorRefresher
import com.stroeer.ads.plugins.monitoring.IAdMonitorCallback
import com.stroeer.ads.plugins.monitoring.IAdMonitoring
import com.stroeer.ads.plugins.monitoring.IAdReloader
import com.stroeer.ads.utilities.concurrent.RunAsync
import com.stroeer.ads.utilities.logging.Logger

class ConfiantLoader private constructor() {

    enum class ConfiantState {
        NOT_INITIALIZED,
        INITIALIZING,
        INITIALIZED,
        FAILED_INITIALIZATION,
        FAILED_NOT_ACTIVATED,
        FAILED_NO_SDK,
        FAILED_NO_PLUGIN,
        FAILED_INVALID_CONFIG
    }

    private var hasConfiant = false
    private var confiantWrapperInstance: IAdMonitoring? = null
    private var status = ConfiantState.NOT_INITIALIZED
    private var testMode = false
    private var reloadMode = false
    private var confiantPropertyId: String? = null
    private var callback: IAdMonitorCallback? = null

    fun initialize(confiantPropertyId: String) {
        initialize(confiantPropertyId, false, null)
    }

    fun initialize(confiantPropertyId: String, enableReload: Boolean, callback: IAdMonitorCallback?) {
        this.confiantPropertyId = confiantPropertyId
        this.reloadMode = enableReload
        this.callback = callback
        initializeAsync()
    }

    @Synchronized
    fun initializeAsync() {
        if (status.ordinal >= ConfiantState.FAILED_NOT_ACTIVATED.ordinal || status == ConfiantState.INITIALIZING || isRunnable()) return

        if (confiantPropertyId.isNullOrEmpty()) {
            Logger.e("[ConfiantPlugin] Confiant property ID is null or empty. Initialization failed.")
            status = ConfiantState.FAILED_INVALID_CONFIG
            callback?.onInitialized(false)
            return
        }

        status = ConfiantState.INITIALIZING
        Logger.d("[ConfiantPlugin] Confiant is initializing")

        RunAsync.run({
            var timeout = 0
            while (!ConfigurationManager.getInstance().isLoaded) {
                try {
                    Thread.sleep(1000)
                    if (++timeout == 3) break
                } catch (e: InterruptedException) {
                    Logger.e("[ConfiantPlugin] Failed to wait for Configuration", e)
                }
            }

            if (ConfigurationManager.getInstance().isLoaded) {
                ConfigurationManager.getInstance().getConfig()?.let { config->
                    if (testMode) {
                        config.modules.confiant.active = true
                        Logger.i("[ConfiantPlugin] Test mode enabled, Confiant module activated")
                    }
                    val confiantConfig = config.modules.confiant

                    if (!confiantConfig.active) {
                        Logger.i("[ConfiantPlugin] Confiant module is not activated")
                        status = ConfiantState.FAILED_NOT_ACTIVATED
                        callback?.onInitialized(false)
                        return@run
                    } else {
                        Logger.i("[ConfiantPlugin] Confiant module is activated")
                    }
                }
            } else {
                Logger.i("[ConfiantPlugin] Configuration not loaded yet")
                status = ConfiantState.NOT_INITIALIZED
                callback?.onInitialized(false)
                return@run
            }

            if (!loadConfiantClasses()) {
                hasConfiant = false
                return@run
            }

            hasConfiant = true

            if (testMode) confiantWrapperInstance!!.enableTestMode()
            if (reloadMode) confiantWrapperInstance!!.enableReload()

            confiantWrapperInstance!!.initialize(confiantPropertyId!!, object : IAdMonitorCallback {
                override fun onInitialized(success: Boolean) {
                    status = if (success) ConfiantState.INITIALIZED else ConfiantState.FAILED_INITIALIZATION
                    callback?.onInitialized(success)
                }
            })
        }, 0) { e ->
            Logger.e("[ConfiantPlugin] Error initializing Confiant SDK:", e)
            status = ConfiantState.NOT_INITIALIZED
            callback?.onInitialized(false)
        }
    }

    fun doesExist() = hasConfiant

    fun enableTestMode() {
        testMode = true
    }

    fun mark(adReloader: IAdReloader) {
        initializeAsync()
        if (isRunnable() && reloadMode) {
            AdMonitorRefresher.getInstance().addNewReloader(adReloader)
            val adView = adReloader.getAdView() ?: return
            confiantWrapperInstance!!.mark(adView, adReloader.getAdSlot())
        }
    }

    fun isRunnable() = hasConfiant && status == ConfiantState.INITIALIZED && confiantWrapperInstance != null

    @Suppress("UNCHECKED_CAST")
    private fun loadConfiantClasses(): Boolean {
        if (confiantWrapperInstance != null) return true

        try {
            val confiantClass = Class.forName("com.stroeer.confiant.ConfiantWrapper") as Class<IAdMonitoring>
            confiantWrapperInstance = confiantClass.getDeclaredConstructor().newInstance()
            Logger.i("[ConfiantPlugin] Confiant Plugin found")
            status = ConfiantState.FAILED_NO_PLUGIN
        } catch (e: Exception) {
            Logger.i("[ConfiantPlugin] Confiant plugin not found")
            return false
        }

        try {
            Class.forName("com.confiant.android.sdk.Confiant")
            Logger.i("[ConfiantPlugin] Confiant SDK found")
            status = ConfiantState.FAILED_NO_SDK
        } catch (e: ClassNotFoundException) {
            Logger.i("[ConfiantPlugin] Confiant SDK not found")
            return false
        }

        return true
    }

    fun setConfiantWrapperInstance(instance: IAdMonitoring) {
        Logger.e("[ConfiantPlugin] Setting ConfiantWrapper instance. This should not be called in production.")
        confiantWrapperInstance = instance
        hasConfiant = true
    }

    fun updateStatus(newStatus: ConfiantState) {
        Logger.e("[ConfiantPlugin] Updating status. This should not be called in production.")
        status = newStatus
    }

    companion object {
        private var instance: ConfiantLoader? = null

        @JvmStatic
        fun getInstance(): ConfiantLoader {
            if (instance == null) instance = ConfiantLoader()
            return instance!!
        }

        @JvmStatic
        fun reset() {
            Logger.e("[ConfiantPlugin] Resetting ConfiantLoader instance. This should not be called in production.")
            instance = null
        }
    }
}
