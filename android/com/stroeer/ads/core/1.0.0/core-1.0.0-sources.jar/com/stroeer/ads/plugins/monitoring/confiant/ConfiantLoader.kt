package com.stroeer.ads.plugins.monitoring.confiant

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.Configuration
import com.stroeer.ads.plugins.monitoring.AdMonitorRefresher
import com.stroeer.ads.plugins.monitoring.IAdMonitorCallback
import com.stroeer.ads.plugins.monitoring.IAdMonitoring
import com.stroeer.ads.plugins.monitoring.IAdReloader
import com.stroeer.ads.utilities.concurrent.RunAsync
import com.stroeer.ads.utilities.logging.Logger
import org.jetbrains.annotations.TestOnly

class ConfiantLoader private constructor() {

    enum class ConfiantState {
        NOT_INITIALIZED,
        INITIALIZING,
        INITIALIZED,
        FAILED_INITIALIZATION,
        FAILED_NOT_ACTIVATED,
        FAILED_NO_SDK,
        FAILED_NO_PLUGIN,
        FAILED_INVALID_CONFIG
    }

    private var confiantWrapperInstance: IAdMonitoring? = null
    @Volatile private var status = ConfiantState.NOT_INITIALIZED
        set(value){
            if(field != value) {
                Logger.d("[ConfiantPlugin] Confiant state changed from $field to $value")
            }
            field = value
        }

    private var testMode = false
    private var reloadMode = false
    private var confiantPropertyId: String? = null
    private var callback: IAdMonitorCallback? = null

    fun initialize(confiantPropertyId: String) {
        initialize(confiantPropertyId, false, null)
    }

    fun initialize(confiantPropertyId: String, enableReload: Boolean, callback: IAdMonitorCallback?) {
        this.confiantPropertyId = confiantPropertyId
        this.reloadMode = enableReload
        this.callback = callback
        initializeAsync()
    }

    @Synchronized
    fun initializeAsync() {
        if (status in TERMINAL_STATES || status == ConfiantState.INITIALIZING || isRunnable()) return

        if (confiantPropertyId.isNullOrEmpty()) {
            Logger.e("[ConfiantPlugin] Confiant property ID is null or empty. Initialization failed.")
            status = ConfiantState.FAILED_INVALID_CONFIG
            callback?.onInitialized(false)
            return
        }

        status = ConfiantState.INITIALIZING
        Logger.d("[ConfiantPlugin] Confiant is initializing")

        RunAsync.run({
            val config = waitForConfiguration()
            if (config == null) {
                Logger.i("[ConfiantPlugin] Configuration not loaded yet")
                status = ConfiantState.NOT_INITIALIZED
                callback?.onInitialized(false)
                return@run
            }

            if (testMode) {
                config.modules.confiant.active = true
                Logger.i("[ConfiantPlugin] Test mode enabled, Confiant module activated")
            }

            if (!config.modules.confiant.active) {
                Logger.i("[ConfiantPlugin] Confiant module is not activated")
                status = ConfiantState.FAILED_NOT_ACTIVATED
                callback?.onInitialized(false)
                return@run
            }
            Logger.i("[ConfiantPlugin] Confiant module is activated")

            if (!loadConfiantClasses()) {
                // loadConfiantClasses() has already set the specific failure status. The
                // publisher still has to be told, otherwise anyone awaiting the callback
                // waits forever.
                callback?.onInitialized(false)
                return@run
            }

            if (testMode) confiantWrapperInstance!!.enableTestMode()
            if (reloadMode) confiantWrapperInstance!!.enableReload()

            confiantWrapperInstance!!.initialize(confiantPropertyId!!, object : IAdMonitorCallback {
                override fun onInitialized(success: Boolean) {
                    status = if (success) ConfiantState.INITIALIZED else ConfiantState.FAILED_INITIALIZATION
                    callback?.onInitialized(success)
                }
            })
        }, 0) { e ->
            Logger.e("[ConfiantPlugin] Error initializing Confiant SDK:", e)
            status = ConfiantState.NOT_INITIALIZED
            callback?.onInitialized(false)
        }
    }

    /**
     * Waits for the remote configuration, for at most [CONFIG_WAIT_ATTEMPTS] intervals.
     *
     * Returns a single snapshot rather than reporting readiness: checking `isLoaded` and then
     * calling `getConfig()` separately is check-then-act, and a reset in between would leave
     * the caller believing configuration was available while it read null.
     */
    private fun waitForConfiguration(): Configuration? {
        var attempts = 0
        while (true) {
            ConfigurationManager.getInstance().getConfig()?.let { return it }

            if (attempts >= CONFIG_WAIT_ATTEMPTS) return null
            attempts++

            try {
                Thread.sleep(CONFIG_WAIT_INTERVAL_MS)
            } catch (e: InterruptedException) {
                // Restore the flag and stop. The counter used to be incremented only after a
                // successful sleep, so an interrupt silently skipped it and loosened the bound.
                Thread.currentThread().interrupt()
                Logger.e("[ConfiantPlugin] Interrupted while waiting for Configuration", e)
                return null
            }
        }
    }

    fun enableTestMode() {
        testMode = true
    }

    fun mark(adReloader: IAdReloader) {
        initializeAsync()

        if (isRunnable()) {
            // AdMonitorRefresher.getInstance().addNewReloader(adReloader)
            val adView = adReloader.getAdView() ?: return
            confiantWrapperInstance!!.mark(adView, adReloader.getAdSlot())
        }
    }

    fun isRunnable() = status == ConfiantState.INITIALIZED && confiantWrapperInstance != null

    /**
     * Seam for the reflective class lookups.
     *
     * Internal rather than published API. Tests cannot mock [Class.forName] itself - static
     * mocking of `java.lang.Class` recurses through MockK's own reflection and overflows the
     * stack - so the lookup is injected here instead.
     */
    internal var classLookup: (String) -> Class<*> = { Class.forName(it) }

    private fun loadConfiantClasses(): Boolean {
        if (confiantWrapperInstance != null) return true

        // The SDK is checked before the plugin: ConfiantWrapper references Confiant SDK
        // types directly, so instantiating it without the SDK on the classpath fails with
        // a LinkageError rather than a clean "plugin missing" result.
        try {
            classLookup(CONFIANT_SDK_CLASS)
            Logger.i("[ConfiantPlugin] Confiant SDK found")
        } catch (_: ClassNotFoundException) {
            Logger.i("[ConfiantPlugin] Confiant SDK not found")
            status = ConfiantState.FAILED_NO_SDK
            return false
        } catch (error: LinkageError) {
            // The class exists but could not be linked or initialized - an incompatible
            // Confiant version, not an absent one. Retryable, and the cause is logged so the
            // two cases stay distinguishable in the field.
            Logger.e("[ConfiantPlugin] Confiant SDK found but could not be linked", error)
            status = ConfiantState.FAILED_INITIALIZATION
            return false
        }

        try {
            confiantWrapperInstance = instantiateConfiantWrapper()
        } catch (_: ClassNotFoundException) {
            Logger.i("[ConfiantPlugin] Confiant plugin not found")
            status = ConfiantState.FAILED_NO_PLUGIN
            return false
        } catch (error: LinkageError) {
            // A partially present or mismatched plugin surfaces as NoClassDefFoundError /
            // ExceptionInInitializerError. Previously this was reported as FAILED_NO_PLUGIN,
            // making an incompatible version indistinguishable from a missing artifact and
            // permanently disabling monitoring.
            Logger.e("[ConfiantPlugin] Confiant plugin found but could not be linked", error)
            status = ConfiantState.FAILED_INITIALIZATION
            return false
        } catch (e: Exception) {
            Logger.e("[ConfiantPlugin] Failed to instantiate the Confiant plugin", e)
            status = ConfiantState.FAILED_INITIALIZATION
            return false
        }

        Logger.i("[ConfiantPlugin] Confiant Plugin found")
        return true
    }

    /**
     * @throws ClassNotFoundException when the plugin artifact is genuinely absent.
     * @throws LinkageError when it is present but cannot be linked.
     */
    @Suppress("UNCHECKED_CAST")
    private fun instantiateConfiantWrapper(): IAdMonitoring {
        val confiantClass = classLookup(CONFIANT_WRAPPER_CLASS) as Class<IAdMonitoring>
        return confiantClass.getDeclaredConstructor().newInstance()
    }

    @TestOnly
    fun setConfiantWrapperInstance(instance: IAdMonitoring) {
        confiantWrapperInstance = instance
        status = ConfiantState.INITIALIZED
    }

    @TestOnly
    fun updateStatus(newStatus: ConfiantState) {
        status = newStatus
    }

    companion object {
        internal const val CONFIANT_SDK_CLASS = "com.confiant.android.sdk.Confiant"
        internal const val CONFIANT_WRAPPER_CLASS = "com.stroeer.confiant.ConfiantWrapper"

        /** Intervals to wait for the remote configuration before giving up (retryable). */
        private const val CONFIG_WAIT_ATTEMPTS = 3
        private const val CONFIG_WAIT_INTERVAL_MS = 1000L

        /**
         * States that initialization cannot recover from, so [initializeAsync] stops retrying.
         * FAILED_INITIALIZATION is deliberately excluded: it stays retryable.
         */
        private val TERMINAL_STATES = setOf(
            ConfiantState.FAILED_NOT_ACTIVATED,
            ConfiantState.FAILED_NO_SDK,
            ConfiantState.FAILED_NO_PLUGIN,
            ConfiantState.FAILED_INVALID_CONFIG
        )

        private var instance: ConfiantLoader? = null

        @JvmStatic
        fun getInstance(): ConfiantLoader {
            if (instance == null) instance = ConfiantLoader()
            return instance!!
        }

        @JvmStatic
        fun reset() {
            Logger.e("[ConfiantPlugin] Resetting ConfiantLoader instance. This should not be called in production.")
            instance = null
        }
    }
}
