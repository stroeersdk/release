package com.stroeer.ads.plugins.monitoring

fun interface IAdMonitorCallback {
    fun onInitialized(success: Boolean)
}
