package com.stroeer.ads.utilities.http

/**
 * Immutable, case-insensitive, multi-value HTTP headers.
 *
 * HTTP header names are case-insensitive by spec, and a single name can legally repeat (e.g.
 * `Set-Cookie`). Lookups are normalized to lowercase internally so `contains("content-type")`
 * and `contains("Content-Type")` agree, while [names] still returns the names as they were
 * originally supplied, for anything that wants to display or iterate them.
 */
class HttpHeaders private constructor(
    private val values: Map<String, List<String>>,
    private val originalNames: Map<String, String>
) {
    /** First value for [name], or null if the header is absent. */
    fun first(name: String): String? = values[name.lowercase()]?.firstOrNull()

    /** All values for [name], preserving order; empty if the header is absent. */
    fun values(name: String): List<String> = values[name.lowercase()] ?: emptyList()

    /** True if a header named [name] is present, regardless of casing. */
    fun contains(name: String): Boolean = values.containsKey(name.lowercase())

    /** The header names as originally supplied (one entry per distinct name, original casing). */
    val names: Set<String> get() = originalNames.values.toSet()

    /**
     * Returns a copy of these headers with [names] removed (case-insensitive).
     *
     * Used when following a redirect that crosses an origin: `Authorization`/`Cookie` must not
     * be replayed against a different host, so [HttpCall] rebuilds its working headers through
     * this rather than forwarding them blindly.
     */
    internal fun without(vararg names: String): HttpHeaders {
        val excluded = names.map { it.lowercase() }.toSet()
        if (excluded.isEmpty()) return this

        val filteredValues = values.filterKeys { it !in excluded }
        val filteredNames = originalNames.filterKeys { it !in excluded }
        return HttpHeaders(filteredValues, filteredNames)
    }

    companion object {
        /** No headers. */
        val EMPTY = HttpHeaders(emptyMap(), emptyMap())

        /** Builds headers from a simple single-valued map, as most callers in this SDK use. */
        fun of(map: Map<String, String>?): HttpHeaders {
            if (map.isNullOrEmpty()) return EMPTY

            val values = LinkedHashMap<String, List<String>>()
            val originalNames = LinkedHashMap<String, String>()
            for ((name, value) in map) {
                val key = name.lowercase()
                values[key] = listOf(value)
                originalNames[key] = name
            }
            return HttpHeaders(values, originalNames)
        }

        /**
         * Builds headers from [HttpURLConnection.getHeaderFields]. That map contains one entry
         * keyed by `null` holding the HTTP status line, which is not a header and must be
         * dropped, or lookups like `contains(null)` would blow up and iteration would surface a
         * bogus "header".
         */
        internal fun fromConnection(map: Map<String?, List<String>>): HttpHeaders {
            val values = LinkedHashMap<String, List<String>>()
            val originalNames = LinkedHashMap<String, String>()
            for ((name, headerValues) in map) {
                if (name == null) continue
                val key = name.lowercase()
                values[key] = headerValues
                originalNames[key] = name
            }
            return HttpHeaders(values, originalNames)
        }
    }
}
