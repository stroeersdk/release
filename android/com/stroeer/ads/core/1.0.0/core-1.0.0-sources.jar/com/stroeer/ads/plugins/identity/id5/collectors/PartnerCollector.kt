package com.stroeer.ads.plugins.identity.id5.collectors

import com.stroeer.ads.plugins.identity.IIdentityCollector

/**
 * Return partner ID
 */
class PartnerCollector : IIdentityCollector<Int?> {
    override suspend fun retrieveData(): Int? {
        return 433
    }
}
