package com.stroeer.ads.plugins.identity.objects

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.utilities.json.JsonBase
import com.stroeer.ads.utilities.logging.Logger
import java.util.Date

class IdentityCache : JsonBase<IdentityCache>() {

    companion object {
        private const val DEFAULT_REFRESH_INTERVAL = (8 * 60 * 60 ).toLong()// 8 hours in seconds
    }

    // In Sec
    var refreshInterval: Long = 0
        get(){
            if (field == 0L) {
                Logger.d("[IdentityCache] Refresh interval is not set. Using the default value.")
                setDefaultRefreshInterval()
            }
            return field
        }

    var deleteCacheInterval: Long = (30 * 24 * 60 * 60).toLong() // 30 days in seconds
    var identityString: String = ""
    var cacheCreationDate: Date = Date()

    fun setDefaultRefreshInterval() {
        val config = ConfigurationManager.getInstance().getConfig()
        if (config?.modules?.id5 == null) {
            Logger.e("[IdentityCache] ID5 configuration is not set. Using the default refresh interval.")
            refreshInterval = DEFAULT_REFRESH_INTERVAL
        } else {
            refreshInterval = config.modules.id5.refreshIntervalInSecs
        }
    }

    fun reset(){
        identityString = ""
    }
}
