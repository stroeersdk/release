package com.stroeer.ads.plugins.identity.collectors

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.plugins.identity.IIdentityCollector

/**
 * Return app name
 */
class NameCollector : IIdentityCollector<String?> {
    override suspend fun retrieveData(): String? {
        return ConfigurationManager.getInstance().getConfig()?.common?.dfpAndroidAppName
    }
}
