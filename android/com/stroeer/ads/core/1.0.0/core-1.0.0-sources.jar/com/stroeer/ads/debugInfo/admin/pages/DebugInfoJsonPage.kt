package com.stroeer.ads.debugInfo.admin.pages

import com.stroeer.ads.debugInfo.DebugInfo
import com.stroeer.ads.debugInfo.DebugInfoManager
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject

internal class DebugInfoJsonPage(
    private val responseFactory: AdminResponseFactory
) {

    fun serve(): NanoHTTPD.Response {
        val list = DebugInfoManager.getInstance().getDebugInfoList()
        val jsonArray = JSONArray()

        for (info in list) {
            val obj = JSONObject()
            obj.put("adSlotId", info.adSlotId ?: "")
            obj.put("servedInTime", info.servedInTime)
            obj.put("html", info.html ?: "")

            if (info is DebugInfo) {
                obj.put("adUnitId", info.adUnitId ?: "")
                obj.put("adSizes", info.adSizes.joinToString(", ") { "${it.width}x${it.height}" })
                obj.put("prebidActive", info.prebidActive ?: false)
                obj.put("prebidConfigId", info.prebidConfigId ?: "")
                obj.put("accountId", info.accountId ?: "")
                obj.put("autoRefreshEnabled", info.autoRefreshEnabled ?: false)
                obj.put("appName", info.appName)
                obj.put("tcString", info.tcString ?: "")
            }

            val source = info.adSourceInfo
            if (source != null) {
                obj.put("adSource", source.adSource.toString())
                obj.put("adSubSource", source.adSubSource)
                obj.put("sdkVersion", source.version)
            }

            val targeting = info.customTargeting
            if (targeting != null) {
                obj.put("customTargeting", JSONObject(targeting))
            }

            val sdkInfos = JSONArray()
            for (sdk in info.sdkDebugInfos) {
                val sdkObj = JSONObject()
                sdkObj.put("sdkType", sdk.sdkType.name)
                sdkObj.put("description", sdk.description ?: "")
                sdkObj.put("createdDate", sdk.createdDate.time)
                sdkObj.put("adSlotId", sdk.adSlotId ?: "")
                if (sdk.keyValues != null) {
                    sdkObj.put("keyValues", JSONObject(sdk.keyValues!!))
                }
                sdkObj.put("requestJson", sdk.requestJson ?: "")
                sdkObj.put("responseJson", sdk.responseJson ?: "")
                sdkInfos.put(sdkObj)
            }
            obj.put("sdkDebugInfos", sdkInfos)

            jsonArray.put(obj)
        }

        return responseFactory.create(NanoHTTPD.Response.Status.OK, "application/json", jsonArray.toString())
    }
}
