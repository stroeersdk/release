package com.stroeer.ads.bidding.optimization

import com.stroeer.ads.bidding.prebid.PrebidBidKeys
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.ConfigModule_BidCache
import com.stroeer.ads.utilities.logging.Logger
import org.prebid.mobile.rendering.bidding.data.bid.Bid
import java.util.concurrent.ConcurrentHashMap

/**
 * The time source behind creative expiry, in epoch seconds.
 *
 * Expiry deliberately does its arithmetic on plain epoch seconds rather than on
 * `kotlin.time.Clock`/`Instant`: those are Kotlin 2.2 stdlib API and this SDK compiles against
 * 2.1 (see the `kotlin` version in gradle/libs.versions.toml). They only ever resolved here
 * because okhttp 5.x happened to force kotlin-stdlib up to 2.2.x, and that dependency is gone.
 *
 * Kept behind this seam instead of calling [System.currentTimeMillis] inline so a test can age a
 * creative past its lifetime without waiting five hours.
 */
internal object OptimizationClock {

    private val systemSeconds: () -> Long = { System.currentTimeMillis() / 1000 }

    @Volatile
    var nowSeconds: () -> Long = systemSeconds

    /** Restores the real clock; tests that replace [nowSeconds] must call this afterwards. */
    fun reset() {
        nowSeconds = systemSeconds
    }
}

/**
 * Keeps the best bids a slot has seen so far, so a later request that comes back empty can still
 * be served from one of them.
 *
 * Per slot at most `maxBuffer` bids are kept, the highest priced ones. Anything older than the
 * configured lifetime is dropped, so an expired creative is never handed out.
 *
 * Whether it caches at all, how long a creative lives and what a bid has to be worth all come from
 * the `BIDCACHE` module of the remote config - see [ConfigModule_BidCache].
 */
internal object BidCaching {
    private val creativeContainers = ConcurrentHashMap<String, List<ExtBid>>()

    /** Module defaults for a config that has not arrived yet or carries no BIDCACHE block. */
    private val defaultSettings = ConfigModule_BidCache()

    /**
     * Read per operation rather than captured once: the config arrives after the SDK starts and is
     * replaced again on every refresh.
     *
     * Resolved per slot like the rest of the ad setup (`AAdConfiguration`), so a slot running an
     * A/B variant caches the way that variant says. [ConfigurationManager.getResolvedConfig] also
     * keeps this off the refresh path - a cache lookup is not a reason to go fetch a config.
     */
    private fun settings(adSlotId: String): ConfigModule_BidCache =
        ConfigurationManager.getInstance().getResolvedConfig(adSlotId)?.modules?.bidCache
            ?: defaultSettings


    /**
     * The highest priced creative of the slot that is still alive, or null if it has none left.
     *
     * The [ExtBid] rather than the bare [Bid], because the caller needs [ExtBid.cacheId] to say
     * which creative it displayed when it comes back to remove it.
     *
     * Nothing is served while the module is inactive. What is already held stays put, so switching
     * the module back on does not start from an empty container.
     */
    fun getCreativeContainer(adSlotId: String): ExtBid? {
        if (!settings(adSlotId).active) {
            return null
        }

        val live = liveBids(adSlotId)
        val best = live.maxByOrNull { it.bid.price }

        if (best == null) {
            Logger.d("[BidCaching] $adSlotId - No creative held")
        } else {
            Logger.d("[BidCaching] $adSlotId - Serving ${describe(best)} out of ${live.size} held - ${describe(live)}")
        }

        return best
    }

    /**
     * Bids below the configured minimum price are not worth holding on to and are ignored. Once
     * the slot is full the new bid only gets in by beating the cheapest one already there.
     *
     * Returns the entry the bid went into, or null when it did not make the cut. The caller needs
     * it to name this creative by [ExtBid.cacheId] if it ends up displaying it.
     */
    fun addCreativeContainer(adSlotId: String, bid: Bid): ExtBid? {
        // One read of the config for the whole call, so the floor and the lifetime a bid is stored
        // with come from the same configuration even if a refresh lands mid-call.
        val settings = settings(adSlotId)

        if (!settings.active) {
            Logger.d("[BidCaching] $adSlotId - Bid caching is inactive, keeping nothing")
            return null
        }

        if (bid.price < settings.priceFloor) {
            Logger.d("[BidCaching] $adSlotId - Dropped bid below the floor of ${settings.priceFloor} - ${describe(bid)}")
            return null
        }

        val updated = creativeContainers.compute(adSlotId) { _, current ->
            ((current ?: emptyList()).filterNot { it.isExpired() } + ExtBid(bid, settings.lifetimeSeconds))
                .sortedByDescending { it.bid.price }
                .take(settings.creativesPerSlot)
        } ?: emptyList()

        // The entry the bid just went into, so the log names the cache id the caller hands back.
        val stored = updated.firstOrNull { it.bid === bid }
        val verdict =
            if (stored != null) "Stored bid ${describe(stored)}"
            else "Dropped cheaper bid ${describe(bid)}"

        Logger.d("[BidCaching] $adSlotId - $verdict, container now ${describe(updated)}")

        return stored
    }

    /**
     * Same as above for a creative that GAM rendered. Nothing over there holds the entry, so the
     * creative is identified by the Prebid cache id that was sent to GAM as targeting.
     *
     * Removal works regardless of [ConfigModule_BidCache.active] - a creative already on screen
     * still has to be spent.
     */
    fun removeCreativeContainerByCacheId(adSlotId: String, cacheId: String) =
        removeMatching(adSlotId, "cacheId=$cacheId") { it.cacheId == cacheId }

    fun removeCreativeContainer(adSlotId: String) {
        val removed = creativeContainers.remove(adSlotId) ?: emptyList()
        Logger.d("[BidCaching] $adSlotId - Cleared ${removed.size} creative(s) - ${describe(removed)}")
    }

    private fun removeMatching(adSlotId: String, displayed: String, match: (ExtBid) -> Boolean) {
        // What the match took out, so the log can name the price leaving the container rather than
        // only the handle the caller happened to identify the creative by.
        var removed: List<ExtBid> = emptyList()

        val remaining = creativeContainers.computeIfPresent(adSlotId) { _, bids ->
            val (matched, kept) = bids.partition(match)
            removed = matched
            kept.ifEmpty { null }
        } ?: emptyList()

        if (removed.isNotEmpty()) {
            Logger.d("[BidCaching] $adSlotId - Removed displayed bid ${describe(removed)}, container now ${describe(remaining)}")
        } else {
            Logger.d("[BidCaching] $adSlotId - Displayed bid $displayed was not held, container now ${describe(remaining)}")
        }
    }

    /**
     * Prunes on read rather than on a timer - a slot nobody asks about costs nothing, and a slot
     * whose bids have all aged out drops out of the map entirely instead of keeping an empty list.
     */
    private fun liveBids(adSlotId: String): List<ExtBid> {
        var expired = 0

        val live = creativeContainers.computeIfPresent(adSlotId) { _, bids ->
            val alive = bids.filterNot { it.isExpired() }
            expired = bids.size - alive.size
            alive.ifEmpty { null }
        } ?: emptyList()

        if (expired > 0) {
            Logger.d("[BidCaching] $adSlotId - Dropped $expired expired creative(s), ${live.size} left")
        }

        return live
    }

    /** Logging only - the cache id names the entry, the price says what it is worth. */
    private fun describe(bids: List<ExtBid>): String =
        bids.joinToString(prefix = "[", postfix = "]") { describe(it) }

    private fun describe(extBid: ExtBid): String =
        "cacheId=${extBid.cacheId} ${describe(extBid.bid)} size=${extBid.bid.width}x${extBid.bid.height} age=${extBid.getAge()}s"

    private fun describe(bid: Bid): String =
        "price=${bid.price}"
}

/**
 * [lifetimeSeconds] is taken from the config when the bid is stored and kept for this entry, so a
 * later config change moves the lifetime of new creatives only - it never shortens or extends the
 * life of one already held.
 */
internal class ExtBid(
    val bid: Bid,
    val lifetimeSeconds: Long = ConfigModule_BidCache.DEFAULT_TTL_SECONDS,
) {
    val createdEpochSeconds : Long = OptimizationClock.nowSeconds()

    /**
     * What identifies this creative once it leaves the SDK - it is the targeting value GAM gets,
     * so it is the only handle the GAM side has on a bid. Null for a bid that was never cached.
     */
    val cacheId : String? = bid.prebid?.targeting?.get(PrebidBidKeys.cache_id.key)

    fun isExpired(nowEpochSeconds : Long = OptimizationClock.nowSeconds()) : Boolean {
        return nowEpochSeconds - createdEpochSeconds > lifetimeSeconds
    }

    fun getAge(nowEpochSeconds : Long = OptimizationClock.nowSeconds()) : Long {
        return nowEpochSeconds - createdEpochSeconds
    }
}
