package com.stroeer.ads.utilities.ui

import com.google.android.gms.ads.AdSize

object SizeUtils {
    fun parseSizeForGAM(size: String?): AdSize? {
        if (size == null) {
            return null
        }

        val sizes: Array<String?> =
            size.split("x".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()

        if (sizes.size != 2) {
            return null
        }

        val width = sizes[0]!!.toInt()
        val height = sizes[1]!!.toInt()

        return AdSize(width, height)
    }

    fun parseSize(size: String?): org.prebid.mobile.AdSize {
        if (size == null) {
            return org.prebid.mobile.AdSize(0,0)
        }

        val sizes: Array<String?> =
            size.split("x".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()

        if (sizes.size != 2) {
            return org.prebid.mobile.AdSize(0,0)
        }

        val width = sizes[0]!!.toInt()
        val height = sizes[1]!!.toInt()

        return org.prebid.mobile.AdSize(width, height)
    }
}

fun AdSize.isNoZeroPixel(): Boolean {
    return this.width > 0 && this.height > 0
}

fun org.prebid.mobile.AdSize.isNoZeroPixel(): Boolean {
    return this.width > 0 && this.height > 0
}

fun AdSize.toPrebid(): org.prebid.mobile.AdSize {
    return org.prebid.mobile.AdSize(this.width, this.height)
}

fun org.prebid.mobile.AdSize.toGAM(): AdSize {
    return AdSize(this.width, this.height)
}