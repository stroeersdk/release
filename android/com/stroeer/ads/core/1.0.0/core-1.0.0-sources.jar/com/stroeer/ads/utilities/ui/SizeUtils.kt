package com.stroeer.ads.utilities.ui

import com.google.android.gms.ads.AdSize
import com.stroeer.ads.utilities.logging.Logger

object SizeUtils {
    fun parseSizeForGAM(size: String?): AdSize? {
        if (size == null) {
            return null
        }

        val sizes: Array<String?> = size.split("x".toRegex()).toTypedArray()

        if (sizes.size != 2) {
            return null
        }

        val width = sizes[0]!!.toIntOrNull()
        val height = sizes[1]!!.toIntOrNull()

        if (width == null || height == null) {
            Logger.w("[SizeUtils] parseSizeForGAM could not parse size \"$size\"")
            return null
        }

        return AdSize(width, height)
    }

    fun parseSize(size: String?): org.prebid.mobile.AdSize {
        if (size == null) {
            return org.prebid.mobile.AdSize(0,0)
        }

        val sizes: Array<String?> = size.split("x".toRegex()).toTypedArray()

        if (sizes.size != 2) {
            return org.prebid.mobile.AdSize(0,0)
        }

        val width = sizes[0]!!.toIntOrNull()
        val height = sizes[1]!!.toIntOrNull()

        if (width == null || height == null) {
            Logger.w("[SizeUtils] parseSize could not parse size \"$size\"")
            return org.prebid.mobile.AdSize(0,0)
        }

        return org.prebid.mobile.AdSize(width, height)
    }
}

fun AdSize.isNoZeroPixel(): Boolean {
    return this.width > 0 && this.height > 0
}

fun org.prebid.mobile.AdSize.isNoZeroPixel(): Boolean {
    return this.width > 0 && this.height > 0
}

fun AdSize.toPrebid(): org.prebid.mobile.AdSize {
    return org.prebid.mobile.AdSize(this.width, this.height)
}

fun org.prebid.mobile.AdSize.toGAM(): AdSize {
    return AdSize(this.width, this.height)
}