package com.stroeer.compose

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import com.stroeer.ads.utilities.logging.Logger

/**
 * Resolves the [Activity] behind a Compose [Context], or null when there is none.
 *
 * `LocalContext.current` is only the Activity itself when the composable sits directly under one.
 * Inside a `Dialog`, under a `ContextThemeWrapper`, or anywhere `LocalContext` has been overridden,
 * it is a [ContextWrapper] around the Activity instead. The ad builders require a real Activity
 * (`AStroeerAdBuilder.validateContext`), so the wrapper chain has to be unwrapped before the
 * context is handed to the SDK.
 */
internal fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) {
            return current
        }
        current = current.baseContext
    }
    return current as? Activity
}

/**
 * The Activity to hand to the SDK for [format], falling back to the raw context when there is no
 * Activity behind it at all - a preview, or a composable hosted outside an Activity. The ad will
 * not load in that case, so say why rather than leaving the caller waiting on a callback that the
 * SDK deliberately does not send once it has rejected the context.
 */
internal fun Context.adContextFor(format: String): Context {
    val activity = findActivity()
    if (activity == null) {
        Logger.e("[$format] No Activity behind the Compose context ($this); Stroeer ads require an Activity context and this ad will not load")
    }
    return activity ?: this
}
