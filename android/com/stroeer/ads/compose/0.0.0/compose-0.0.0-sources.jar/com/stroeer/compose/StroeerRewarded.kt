package com.stroeer.compose

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.rewarded.IStroeerRewardedFullListener
import com.stroeer.ads.formats.rewarded.IStroeerRewardedListener
import com.stroeer.ads.formats.rewarded.StroeerRewardedView

/**
 * Jetpack Compose wrapper around [StroeerRewardedView].
 *
 * Loading starts as soon as the composable enters composition: [StroeerRewardedView.load] is
 * called immediately in a [DisposableEffect] (unless [adSlotId] is blank). No UI node is
 * emitted — the rewarded format is a full-screen overlay, so there is nothing to lay out.
 *
 * Changing [adSlotId] tears down the previous ad (via [key]) and creates a fresh
 * [StroeerRewardedView] for the new slot. Call [StroeerRewardedController.show] only after
 * [onLoaded] has been invoked; showing before the ad is ready is a no-op inside the SDK.
 *
 * The [Context] obtained from [LocalContext] **must** be an `Activity` — [StroeerRewardedView]
 * validates this at load time and will invoke [onFailed] if a non-Activity context is provided.
 *
 * @param adSlotId           Publisher ad slot id to load. Passing a blank string skips loading.
 * @param onLoaded           Invoked when the rewarded ad finishes loading. The [RewardedAd]
 *                           instance may be null in rare error scenarios; prefer treating it as
 *                           a signal that [StroeerRewardedController.show] is safe to call.
 * @param onFailed           Invoked when the rewarded ad fails to load.
 * @param onUserEarnedReward Invoked when the user completes the rewarded interaction. The
 *                           [RewardItem] describes the reward type and amount.
 * @param onClicked          Invoked when the ad is clicked by the user.
 * @param onDismissed        Invoked when the full-screen ad is dismissed and the user returns
 *                           to the app.
 * @param onFailedToShow     Invoked when the ad fails to display after [StroeerRewardedController.show]
 *                           was called. The [StroeerException] parameter may be null.
 * @param onImpression       Invoked when the ad records an impression.
 * @param onShowed           Invoked when the ad has successfully shown its full-screen content.
 * @return A [StroeerRewardedController] whose [StroeerRewardedController.show] method triggers
 *         ad display. Call it only after [onLoaded] fires.
 */
@Composable
fun StroeerRewarded(
    adSlotId: String,
    onLoaded: (RewardedAd?) -> Unit = {},
    onFailed: (StroeerException) -> Unit = {},
    onUserEarnedReward: (RewardItem?) -> Unit = {},
    onClicked: () -> Unit = {},
    onDismissed: () -> Unit = {},
    onFailedToShow: (StroeerException?) -> Unit = {},
    onImpression: () -> Unit = {},
    onShowed: () -> Unit = {},
): StroeerRewardedController = StroeerRewarded(
    adSlotId = adSlotId,
    rewardedFactory = { context -> RealRewardedHost(StroeerRewardedView(context)) },
    onLoaded = onLoaded,
    onFailed = onFailed,
    onUserEarnedReward = onUserEarnedReward,
    onClicked = onClicked,
    onDismissed = onDismissed,
    onFailedToShow = onFailedToShow,
    onImpression = onImpression,
    onShowed = onShowed,
)

/**
 * Internal overload that takes an injectable [rewardedFactory] so tests can supply a fake
 * [RewardedHost] instead of constructing the heavyweight [StroeerRewardedView].
 */
@Composable
internal fun StroeerRewarded(
    adSlotId: String,
    rewardedFactory: (Context) -> RewardedHost,
    onLoaded: (RewardedAd?) -> Unit = {},
    onFailed: (StroeerException) -> Unit = {},
    onUserEarnedReward: (RewardItem?) -> Unit = {},
    onClicked: () -> Unit = {},
    onDismissed: () -> Unit = {},
    onFailedToShow: (StroeerException?) -> Unit = {},
    onImpression: () -> Unit = {},
    onShowed: () -> Unit = {},
): StroeerRewardedController {
    val context = LocalContext.current

    // Always invoke the latest lambdas without forcing the host to be recreated.
    val currentOnLoaded by rememberUpdatedState(onLoaded)
    val currentOnFailed by rememberUpdatedState(onFailed)
    val currentOnUserEarnedReward by rememberUpdatedState(onUserEarnedReward)
    val currentOnClicked by rememberUpdatedState(onClicked)
    val currentOnDismissed by rememberUpdatedState(onDismissed)
    val currentOnFailedToShow by rememberUpdatedState(onFailedToShow)
    val currentOnImpression by rememberUpdatedState(onImpression)
    val currentOnShowed by rememberUpdatedState(onShowed)

    // Scope everything to the slot id: when it changes, the previous host leaves
    // composition (its DisposableEffect destroys it) and a fresh host is created.
    return key(adSlotId) {
        // Single rewarded host instance kept across recompositions for this slot.
        val host = remember { rewardedFactory(context) }

        // Bridge SDK callbacks to the Compose lambdas (kept current via the
        // rememberUpdatedState delegates captured above).
        val listener = remember {
            createRewardedListener(
                onLoaded = { currentOnLoaded(it) },
                onFailed = { currentOnFailed(it) },
                onUserEarnedReward = { currentOnUserEarnedReward(it) },
                onClicked = { currentOnClicked() },
                onDismissed = { currentOnDismissed() },
                onFailedToShow = { currentOnFailedToShow(it) },
                onImpression = { currentOnImpression() },
                onShowed = { currentOnShowed() },
            )
        }

        // Controller exposed to the caller for triggering display.
        val controller = remember(host) { StroeerRewardedController(host::show) }

        // Load the ad and clean up when this slot leaves composition.
        DisposableEffect(host, adSlotId) {
            if (adSlotId.isNotBlank()) {
                host.load(adSlotId, listener)
            }
            onDispose {
                host.destroy()
            }
        }

        controller
    }
}

/**
 * A controller returned by [StroeerRewarded] that lets the caller trigger display of the
 * loaded rewarded ad.
 */
@Stable
class StroeerRewardedController internal constructor(private val showAction: () -> Unit) {
    /**
     * Displays the rewarded ad. Only call this after [onLoaded] has been invoked; calling
     * before the ad is ready is a no-op inside the underlying SDK.
     */
    fun show() {
        showAction()
    }
}

/**
 * Seam over [StroeerRewardedView] so the composable can be tested with a fake that
 * doesn't construct the heavyweight ad view.
 */
internal interface RewardedHost {
    fun load(adSlotId: String, listener: IStroeerRewardedListener?)
    fun show()
    fun destroy()
}

/** Production [RewardedHost] backed by a real [StroeerRewardedView]. */
private class RealRewardedHost(private val view: StroeerRewardedView) : RewardedHost {
    init {
        view.loadAfterReady = false
    }

    override fun load(adSlotId: String, listener: IStroeerRewardedListener?) {
        view.load(adSlotId, listener)
    }

    override fun show() {
        view.show()
    }

    override fun destroy() {
        view.destroy()
    }
}

/**
 * Builds an [IStroeerRewardedFullListener] that forwards each SDK callback to the matching
 * lambda.
 */
internal fun createRewardedListener(
    onLoaded: (RewardedAd?) -> Unit,
    onFailed: (StroeerException) -> Unit,
    onUserEarnedReward: (RewardItem?) -> Unit,
    onClicked: () -> Unit,
    onDismissed: () -> Unit,
    onFailedToShow: (StroeerException?) -> Unit,
    onImpression: () -> Unit,
    onShowed: () -> Unit,
): IStroeerRewardedFullListener = object : IStroeerRewardedFullListener {
    // IStroeerRewardedListener
    override fun onAdLoaded(rewardedAd: RewardedAd?) {
        onLoaded(rewardedAd)
    }

    override fun onAdFailedToLoad(exception: StroeerException) {
        onFailed(exception)
    }

    override fun onUserEarnedReward(item: RewardItem?) {
        onUserEarnedReward(item)
    }

    // IStroeerAdFullListener
    override fun onAdClicked() {
        onClicked()
    }

    override fun onAdDismissedFullScreenContent() {
        onDismissed()
    }

    override fun onAdFailedToShowFullScreenContent(e: StroeerException?) {
        onFailedToShow(e)
    }

    override fun onAdImpression() {
        onImpression()
    }

    override fun onAdShowedFullScreenContent() {
        onShowed()
    }
}
