package com.stroeer.compose

import android.content.Context
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.banner.StroeerBannerListener
import com.stroeer.ads.formats.banner.StroeerBannerView

/**
 * Jetpack Compose wrapper around [StroeerBannerView].
 *
 * The banner is created when the composable enters composition but is **lazily
 * loaded**: [StroeerBannerView.load] is only called once the view is actually
 * visible on screen (see [visibilityThreshold]). This avoids requesting ads for
 * banners that are scrolled off-screen in a `LazyColumn`/`LazyRow`.
 *
 * The underlying view is remembered across recompositions and destroyed when the
 * composable leaves composition. Changing [adSlotId] tears down the previous banner
 * (via [key]) and creates a fresh one for the new slot.
 *
 * @param adSlotId            Publisher ad slot id to load.
 * @param modifier            Modifier for the hosting view.
 * @param contentUrl          Optional content URL for ad targeting. Applied right
 *                            before the banner loads; changing it for an already
 *                            loaded banner has no effect until the slot reloads.
 * @param customTargeting     Per-banner custom targeting key/values. Applied right
 *                            before the banner loads; changing it for an already
 *                            loaded banner has no effect until the slot reloads.
 * @param visibilityThreshold Fraction of the view (0f..1f) that must be visible on
 *                            screen before the ad is loaded. Defaults to 0.5. The
 *                            banner is never loaded while completely off-screen, even
 *                            when this is 0f.
 * @param onLoaded            Invoked when the banner finishes loading.
 * @param onFailed            Invoked when the banner fails to load.
 * @param onOpened            Invoked when the ad opens a full-screen overlay.
 * @param onClosed            Invoked when the ad overlay is closed.
 * @param onClicked           Invoked when the ad is clicked.
 * @param onImpression        Invoked when the ad records an impression.
 */
@Composable
fun StroeerBanner(
    adSlotId: String,
    modifier: Modifier = Modifier,
    contentUrl: String? = null,
    customTargeting: Map<String, String> = emptyMap(),
    visibilityThreshold: Float = 0.5f,
    onLoaded: (StroeerBannerView) -> Unit = {},
    onFailed: (StroeerBannerView, StroeerException) -> Unit = { _, _ -> },
    onOpened: (StroeerBannerView) -> Unit = {},
    onClosed: (StroeerBannerView) -> Unit = {},
    onClicked: (StroeerBannerView) -> Unit = {},
    onImpression: (StroeerBannerView) -> Unit = {},
) {
    StroeerBanner(
        adSlotId = adSlotId,
        modifier = modifier,
        contentUrl = contentUrl,
        customTargeting = customTargeting,
        visibilityThreshold = visibilityThreshold,
        bannerFactory = { context -> RealBannerHost(StroeerBannerView(context)) },
        onLoaded = onLoaded,
        onFailed = onFailed,
        onOpened = onOpened,
        onClosed = onClosed,
        onClicked = onClicked,
        onImpression = onImpression,
    )
}

/**
 * Internal overload that takes an injectable [bannerFactory] so tests can supply a
 * fake [BannerHost] instead of constructing the heavyweight [StroeerBannerView].
 * [initialVisibleEnough] seeds the visibility gate so load behavior can be tested
 * without relying on real (and headless-fragile) layout geometry; it is overwritten
 * by [onGloballyPositioned] on the first layout pass, so production always starts
 * from `false` via the public overload.
 */
@Composable
internal fun StroeerBanner(
    adSlotId: String,
    modifier: Modifier = Modifier,
    contentUrl: String? = null,
    customTargeting: Map<String, String> = emptyMap(),
    visibilityThreshold: Float = 0.5f,
    bannerFactory: (Context) -> BannerHost,
    initialVisibleEnough: Boolean = false,
    onLoaded: (StroeerBannerView) -> Unit = {},
    onFailed: (StroeerBannerView, StroeerException) -> Unit = { _, _ -> },
    onOpened: (StroeerBannerView) -> Unit = {},
    onClosed: (StroeerBannerView) -> Unit = {},
    onClicked: (StroeerBannerView) -> Unit = {},
    onImpression: (StroeerBannerView) -> Unit = {},
) {
    val context = LocalContext.current

    // Always invoke the latest lambdas without forcing the view to be recreated.
    val currentOnLoaded by rememberUpdatedState(onLoaded)
    val currentOnFailed by rememberUpdatedState(onFailed)
    val currentOnOpened by rememberUpdatedState(onOpened)
    val currentOnClosed by rememberUpdatedState(onClosed)
    val currentOnClicked by rememberUpdatedState(onClicked)
    val currentOnImpression by rememberUpdatedState(onImpression)

    // Scope everything to the slot id: when it changes, the previous host leaves
    // composition (its DisposableEffect destroys it) and a fresh host is created.
    key(adSlotId) {
        // Single banner host instance kept across recompositions for this slot.
        val host = remember { bannerFactory(context) }

        // Bridge SDK callbacks to the Compose lambdas (kept current via the
        // rememberUpdatedState delegates captured above).
        val listener = remember {
            createBannerListener(
                onLoaded = { currentOnLoaded(it) },
                onFailed = { view, error -> currentOnFailed(view, error) },
                onOpened = { currentOnOpened(it) },
                onClosed = { currentOnClosed(it) },
                onClicked = { currentOnClicked(it) },
                onImpression = { currentOnImpression(it) },
            )
        }

        // Whether load() has already been called for this slot's host.
        var hasLoaded by remember { mutableStateOf(false) }
        var isVisibleEnough by remember { mutableStateOf(initialVisibleEnough) }

        // Destroy the banner when this slot leaves composition.
        DisposableEffect(host) {
            onDispose {
                host.destroy()
            }
        }

        AndroidView(
            modifier = modifier.onGloballyPositioned { coordinates ->
                isVisibleEnough = isVisibleEnough(coordinates.visibleFraction(), visibilityThreshold)
            },
            factory = { host.view },
            update = {
                if (shouldLoad(adSlotId, isVisibleEnough, hasLoaded)) {
                    // Targeting must be applied before load().
                    host.contentUrl = contentUrl
                    host.setCustomTargeting(customTargeting)
                    host.load(adSlotId, listener)
                    hasLoaded = true
                }
            },
        )
    }
}

/**
 * Seam over [StroeerBannerView] so the composable can be tested with a fake that
 * doesn't construct the heavyweight ad view.
 */
internal interface BannerHost {
    val view: View
    var contentUrl: String?
    fun setCustomTargeting(values: Map<String, String>)
    fun load(adSlotId: String, listener: StroeerBannerListener?)
    fun destroy()
}

/** Production [BannerHost] backed by a real [StroeerBannerView]. */
private class RealBannerHost(private val bannerView: StroeerBannerView) : BannerHost {
    override val view: View = bannerView

    override var contentUrl: String?
        get() = bannerView.contentUrl
        set(value) {
            bannerView.contentUrl = value
        }

    override fun setCustomTargeting(values: Map<String, String>) {
        bannerView.bannerConfig.customTargeting = values.toMutableMap()
    }

    override fun load(adSlotId: String, listener: StroeerBannerListener?) {
        bannerView.load(adSlotId, listener)
    }

    override fun destroy() {
        bannerView.destroy()
    }
}

/**
 * Builds a [StroeerBannerListener] that forwards each SDK callback to the matching
 * lambda. The banner argument is non-null in practice; null callbacks are ignored.
 */
internal fun createBannerListener(
    onLoaded: (StroeerBannerView) -> Unit,
    onFailed: (StroeerBannerView, StroeerException) -> Unit,
    onOpened: (StroeerBannerView) -> Unit,
    onClosed: (StroeerBannerView) -> Unit,
    onClicked: (StroeerBannerView) -> Unit,
    onImpression: (StroeerBannerView) -> Unit,
): StroeerBannerListener = object : StroeerBannerListener() {
    override fun onAdLoaded(banner: StroeerBannerView?) {
        banner?.let { onLoaded(it) }
    }

    override fun onAdFailedToLoad(banner: StroeerBannerView?, error: StroeerException) {
        banner?.let { onFailed(it, error) }
    }

    override fun onAdOpened(banner: StroeerBannerView?) {
        banner?.let { onOpened(it) }
    }

    override fun onAdClosed(banner: StroeerBannerView?) {
        banner?.let { onClosed(it) }
    }

    override fun onAdClicked(banner: StroeerBannerView?) {
        banner?.let { onClicked(it) }
    }

    override fun onAdImpression(banner: StroeerBannerView?) {
        banner?.let { onImpression(it) }
    }
}

/**
 * Whether the banner should be loaded now: a non-blank slot, sufficiently visible,
 * and not already loaded for this slot.
 */
internal fun shouldLoad(adSlotId: String, isVisibleEnough: Boolean, hasLoaded: Boolean): Boolean =
    adSlotId.isNotEmpty() && isVisibleEnough && !hasLoaded

/**
 * Whether [visibleFraction] crosses [visibilityThreshold]. Always false when fully
 * off-screen (fraction 0f), even if the threshold is 0f.
 */
internal fun isVisibleEnough(visibleFraction: Float, visibilityThreshold: Float): Boolean =
    visibleFraction > 0f && visibleFraction >= visibilityThreshold.coerceIn(0f, 1f)

/**
 * Pure visibility arithmetic: the fraction (0f..1f) of a node's area that is visible,
 * given its total size and the visible (window-clipped) extents. Returns 0f for a
 * non-positive total area and clamps the result into 0f..1f.
 */
internal fun calculateVisibleFraction(
    totalWidth: Int,
    totalHeight: Int,
    visibleWidth: Float,
    visibleHeight: Float,
): Float {
    if (totalWidth <= 0 || totalHeight <= 0) return 0f

    val visibleArea = visibleWidth.coerceAtLeast(0f) * visibleHeight.coerceAtLeast(0f)
    val totalArea = totalWidth.toFloat() * totalHeight.toFloat()
    if (totalArea <= 0f) return 0f

    return (visibleArea / totalArea).coerceIn(0f, 1f)
}

/**
 * Fraction (0f..1f) of this laid-out node that currently intersects the window.
 * Returns 0 when the node is detached or has no area.
 */
private fun androidx.compose.ui.layout.LayoutCoordinates.visibleFraction(): Float {
    if (!isAttached) return 0f

    val bounds = boundsInWindow()
    return calculateVisibleFraction(
        totalWidth = size.width,
        totalHeight = size.height,
        visibleWidth = bounds.width,
        visibleHeight = bounds.height,
    )
}
