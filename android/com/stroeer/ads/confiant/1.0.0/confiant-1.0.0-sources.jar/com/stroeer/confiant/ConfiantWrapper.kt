package com.stroeer.confiant

import android.annotation.SuppressLint
import android.view.View
import android.webkit.WebView
import com.confiant.android.sdk.Callback
import com.confiant.android.sdk.Confiant
import com.confiant.android.sdk.DetectionObserving
import com.confiant.android.sdk.DetectionObserving.Mode.WithSlotMatching
import com.confiant.android.sdk.Result
import com.confiant.android.sdk.Settings
import com.confiant.android.sdk.SlotMatching.Marked.SlotView
import com.stroeer.ads.plugins.monitoring.AdMonitorRefresher
import com.stroeer.ads.plugins.monitoring.IAdMonitorCallback
import com.stroeer.ads.plugins.monitoring.IAdMonitoring
import com.stroeer.ads.utilities.logging.Logger

/**
 * ConfiantWrapper is an implementation of the IAdMonitoring interface that
 * integrates with the Confiant SDK to provide ad monitoring capabilities.
 */
class ConfiantWrapper  // Constructor
    : IAdMonitoring {
    // Instance of the Confiant SDK
    private var confiantInstance: Confiant? = null
    private var testMode = false // Indicates if test mode is enabled
    private var isMonitorStarted = false // Tracks if monitoring has started
    private var reloadMode = false // Indicates if reload mode is enabled

    private var monitorCallback: IAdMonitorCallback? = null // Callback for initialization events

    /**
     * Enables test mode for the Confiant SDK.
     * Test mode should be enabled before initializing the SDK.
     */
    override fun enableTestMode() {
        if (confiantInstance != null) {
            e("Settings are already initialized. enableTestMode should be called before initialization.")
            return
        }
        i("Test Mode is enabled. Confiant SDK will block all ads in this mode.")
        testMode = true
    }

    /**
     * Enables reload mode for the Confiant SDK.
     * Reload mode should be enabled before initializing the SDK.
     */
    override fun enableReload() {
        if (confiantInstance != null) {
            e("Settings are already initialized. enableReloadMode should be called before initialization.")
            return
        }
        i("Reload Mode is enabled. Confiant SDK will reload the ad slot if a detection event is detected.")
        reloadMode = true
    }

    /**
     * Creates Confiant SDK settings based on the given property ID.
     * 
     * @param confiantPropertyId the property ID for which to create the settings.
     * @return the created Settings instance or null if creation failed.
     */
    private fun createSettings(confiantPropertyId: String): Settings? {
        // Create settings with slot matching for reload mode
        val settingsResult = Settings.with(
            confiantPropertyId, null, null, null,
            WithSlotMatching(
                Callback { webViewAndEvent: Pair<WebView?, DetectionObserving.Event> ->
                    val webView = webViewAndEvent.component1()
                    val event = webViewAndEvent.component2()
                    val report = event.detectionReport
                    if (report != null) {
                        i("Rule ${report.blockingId} detected suspicious content from ${report.impressionData.provider}; \"${event.placementId}\" was blocked: ${report.isBlocked}")
//                        if (report.isBlocked && event.placementId != null && reloadMode) {
//                            i("Reloading ${event.placementId}...")
//                            AdMonitorRefresher.getInstance().reload(webView, event.placementId)
//                        }
                    }
                }
            ),
            testMode)

        when (settingsResult) {
            is Result.Success -> {
                i("Confiant Settings created successfully.")
                return settingsResult.value
            }

            is Result.Failure -> {
                val error = settingsResult.error
                e("Failed to create Confiant Settings: " + error.localizedMessage + " Code: " + error.code)
            }

        }
        return null
    }

    /**
     * Initializes the Confiant SDK.
     * 
     * @param confiantPropertyId the property ID for initialization.
     * @param callback           the callback to notify about the initialization result.
     */
    override fun initialize(confiantPropertyId: String, callback: IAdMonitorCallback?) {
        monitorCallback = callback
        i("Initializing Confiant SDK...")

        val settings = createSettings(confiantPropertyId)

        if (settings != null) {
            Confiant.initialize(
                settings
            ) { initResult ->
                when (initResult) {
                    is Result.Success -> {
                        confiantInstance = initResult .value
                        i("Successfully initialized Confiant SDK")
                        isMonitorStarted = true
                        monitorCallback?.onInitialized(true)
                    }

                    is Result.Failure -> {
                        val error = initResult.error
                        e("Failed to initialize Confiant SDK: " + error.localizedMessage + " " + error.code)
                        isMonitorStarted = false
                        monitorCallback?.onInitialized(false)
                    }

                }
            }
        } else {
            e("Failed to create settings, initialization aborted.")
            monitorCallback?.onInitialized(false)
        }
    }

    /**
     * Marks an ad view for monitoring with the given placement ID.
     * 
     * @param view        the ad view to be marked.
     * @param placementId the identifier for the ad placement.
     */
    @SuppressLint("DefaultLocale")
    override fun mark(view: View, placementId: String) {
        if (isMonitorStarted) {
            confiantInstance?.mark0(SlotView(view), placementId)
        } else {
            e("Confiant SDK is not initialized. Cannot mark the view.")
        }
    }

    private fun i(message: String?) {
        Logger.i(PREFIX + message)
    }

    private fun e(message: String?) {
        Logger.e(PREFIX + message)
    }

    companion object {
        // Logging utility methods
        private const val PREFIX = "[ConfiantPlugin] "
    }
}