package com.stroeer.confiant;

import android.annotation.SuppressLint;
import android.view.View;
import android.webkit.WebView;

import androidx.annotation.NonNull;

import com.confiant.android.sdk.*;
import com.confiant.android.sdk.Error;
import com.stroeer.plugins.monitoring.AdMonitorRefresher;
import com.stroeer.plugins.monitoring.IAdMonitorCallback;
import com.stroeer.plugins.monitoring.IAdMonitoring;

import kotlin.Pair;

/**
 * ConfiantWrapper is an implementation of the IAdMonitoring interface that
 * integrates with the Confiant SDK to provide ad monitoring capabilities.
 */
public final class ConfiantWrapper implements IAdMonitoring {

    // Instance of the Confiant SDK
    private Confiant confiantInstance = null;
    private boolean testMode = false; // Indicates if test mode is enabled
    private boolean isMonitorStarted = false; // Tracks if monitoring has started
    private boolean reloadMode = false; // Indicates if reload mode is enabled

    private IAdMonitorCallback monitorCallback = null; // Callback for initialization events

    // Constructor
    public ConfiantWrapper() {}

    /**
     * Enables test mode for the Confiant SDK.
     * Test mode should be enabled before initializing the SDK.
     */
    public void enableTestMode() {
        if (confiantInstance != null) {
            e("Settings are already initialized. enableTestMode should be called before initialization.");
            return;
        }
        i("Test Mode is enabled. Confiant SDK will block all ads in this mode.");
        testMode = true;
    }

    /**
     * Enables reload mode for the Confiant SDK.
     * Reload mode should be enabled before initializing the SDK.
     */
    public void enableReload() {
        if (confiantInstance != null) {
            e("Settings are already initialized. enableReloadMode should be called before initialization.");
            return;
        }
        i("Reload Mode is enabled. Confiant SDK will reload the ad slot if a detection event is detected.");
        reloadMode = true;
    }

    /**
     * Creates Confiant SDK settings based on the given property ID.
     *
     * @param confiantPropertyId the property ID for which to create the settings.
     * @return the created Settings instance or null if creation failed.
     */
    private Settings createSettings(String confiantPropertyId) {
        Result<Settings, Error> settingsResult;

        if (reloadMode) {
            // Create settings with slot matching for reload mode
            settingsResult = Settings.with(confiantPropertyId, null, null, null,
                    new DetectionObserving.Mode.WithSlotMatching(
                            (final @NonNull Pair<WebView, DetectionObserving.Event> webViewAndEvent) -> {
                                WebView webView = webViewAndEvent.component1();
                                DetectionObserving.Event event = webViewAndEvent.component2();
                                DetectionObserving.Report report = event.getDetectionReport();

                                if (report != null) {
                                    i(String.format("Rule %s detected suspicious content from %s; \"%s\" was blocked: %s%n",
                                            report.getBlockingId(),
                                            report.getImpressionData().getProvider(),
                                            event.getPlacementId(),
                                            report.isBlocked() ? "true" : "false"));

                                    if (report.isBlocked() && event.getPlacementId() != null) {
                                        AdMonitorRefresher.getInstance().reload(webView, event.getPlacementId());
                                    }
                                }
                            }
                    ),
                    testMode);
        } else {
            // Create settings without slot matching for non-reload mode
            settingsResult = Settings.with(confiantPropertyId, null, null, null,
                    new DetectionObserving.Mode.WithoutSlotMatching(
                            (final @NonNull Pair<WebView, DetectionObserving.Event> webViewAndEvent) -> {
                                DetectionObserving.Event event = webViewAndEvent.component2();
                                DetectionObserving.Report report = event.getDetectionReport();

                                if (report != null) {
                                    i(String.format("Rule %s detected suspicious content from %s; was blocked: %s%n",
                                            report.getBlockingId(),
                                            report.getImpressionData().getProvider(),
                                            report.isBlocked() ? "true" : "false"));
                                }
                            }
                    ),
                    testMode);
        }

        if (settingsResult instanceof Result.Success) {
            i("Confiant Settings created successfully.");
            return ((Result.Success<Settings, Error>) settingsResult).getValue();
        } else if (settingsResult instanceof Result.Failure) {
            Error error = ((Result.Failure<Settings, Error>) settingsResult).getError();
            e("Failed to create Confiant Settings: " + error.getLocalizedMessage() + " Code: " + error.getCode());
        } else {
            e("Failed to create Confiant Settings.");
        }
        return null;
    }

    /**
     * Initializes the Confiant SDK.
     *
     * @param confiantPropertyId the property ID for initialization.
     * @param callback           the callback to notify about the initialization result.
     */
    public void initialize(String confiantPropertyId, IAdMonitorCallback callback) {
        monitorCallback = callback;
        i("Initializing Confiant SDK...");

        Settings settings = createSettings(confiantPropertyId);

        if (settings != null) {
            Confiant.initialize(
                    settings,
                    (final @NonNull Result<Confiant, Error> initResult) -> {
                        if (initResult instanceof Result.Success) {
                            confiantInstance = ((Result.Success<Confiant, Error>) initResult).getValue();
                            i("Successfully initialized Confiant SDK");
                            isMonitorStarted = true;
                            monitorCallback.onInitialized(true);
                        } else if (initResult instanceof Result.Failure) {
                            Error error = ((Result.Failure<Confiant, Error>) initResult).getError();
                            e("Failed to initialize Confiant SDK: " + error.getLocalizedMessage() + " " + error.getCode());
                            monitorCallback.onInitialized(false);
                        } else {
                            e("Failed to initialize Confiant SDK");
                            monitorCallback.onInitialized(false);
                        }
                    }
            );
        } else {
            e("Failed to create settings, initialization aborted.");
            monitorCallback.onInitialized(false);
        }
    }

    /**
     * Marks an ad view for monitoring with the given placement ID.
     *
     * @param view        the ad view to be marked.
     * @param placementId the identifier for the ad placement.
     */
    @SuppressLint("DefaultLocale")
    public void mark(View view, String placementId) {
        if (isMonitorStarted && confiantInstance != null) {
            confiantInstance.mark0(new SlotMatching.Marked.SlotView(view), placementId);
        } else {
            e("Confiant SDK is not initialized. Cannot mark the view.");
        }
    }

    // Logging utility methods
    private static final String PREFIX = "[ConfiantPlugin] ";

    private void i(String message) {
        com.stroeer.utilities.logging.Logger.i(PREFIX + message);
    }

    private void e(String message) {
        com.stroeer.utilities.logging.Logger.e(PREFIX + message);
    }
}