package com.stroeersdk.compose

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.interstitial.IStroeerInterstitialFullListener
import com.stroeer.ads.formats.interstitial.IStroeerInterstitialListener
import com.stroeer.ads.formats.interstitial.StroeerInterstitialView

/**
 * Jetpack Compose wrapper around [StroeerInterstitialView].
 *
 * Loading starts immediately when this composable enters composition; no UI node is
 * emitted. Call [StroeerInterstitialController.show] only after [onLoaded] fires —
 * the ad is not ready before that point.
 *
 * Changing [adSlotId] destroys the previous interstitial and begins loading a fresh one
 * for the new slot (via [key]). The composable leaves composition when removed from the
 * tree; the underlying [StroeerInterstitialView] is destroyed at that point.
 *
 * The [Context] obtained from [LocalContext] **must** be an Activity; passing an
 * Application context will cause the ad load to fail.
 *
 * @param adSlotId       Publisher ad slot id to load. Passing a blank string skips loading.
 * @param onLoaded       Invoked when the interstitial ad has successfully loaded and is
 *                       ready to be shown.
 * @param onFailed       Invoked when the interstitial ad fails to load.
 * @param onClicked      Invoked when the user clicks the interstitial ad.
 * @param onDismissed    Invoked when the interstitial full-screen content is dismissed and
 *                       the user returns to the app.
 * @param onFailedToShow Invoked when the interstitial ad fails to display after [show] is called.
 * @param onImpression   Invoked when the interstitial ad records an impression.
 * @param onShowed       Invoked when the interstitial ad has successfully shown full-screen content.
 * @return A [StroeerInterstitialController] whose [StroeerInterstitialController.show] method
 *         displays the loaded ad.
 */
@Composable
fun StroeerInterstitial(
    adSlotId: String,
    onLoaded: () -> Unit = {},
    onFailed: (StroeerException?) -> Unit = {},
    onClicked: () -> Unit = {},
    onDismissed: () -> Unit = {},
    onFailedToShow: (StroeerException?) -> Unit = {},
    onImpression: () -> Unit = {},
    onShowed: () -> Unit = {},
): StroeerInterstitialController {
    return StroeerInterstitial(
        adSlotId = adSlotId,
        interstitialFactory = { context -> RealInterstitialHost(StroeerInterstitialView(context)) },
        onLoaded = onLoaded,
        onFailed = onFailed,
        onClicked = onClicked,
        onDismissed = onDismissed,
        onFailedToShow = onFailedToShow,
        onImpression = onImpression,
        onShowed = onShowed,
    )
}

/**
 * Internal overload that accepts an injectable [interstitialFactory] so tests can supply
 * a fake [InterstitialHost] instead of constructing the heavyweight [StroeerInterstitialView].
 */
@Composable
internal fun StroeerInterstitial(
    adSlotId: String,
    interstitialFactory: (Context) -> InterstitialHost,
    onLoaded: () -> Unit = {},
    onFailed: (StroeerException?) -> Unit = {},
    onClicked: () -> Unit = {},
    onDismissed: () -> Unit = {},
    onFailedToShow: (StroeerException?) -> Unit = {},
    onImpression: () -> Unit = {},
    onShowed: () -> Unit = {},
): StroeerInterstitialController {
    val context = LocalContext.current

    // Always invoke the latest lambdas without forcing the host to be recreated.
    val currentOnLoaded by rememberUpdatedState(onLoaded)
    val currentOnFailed by rememberUpdatedState(onFailed)
    val currentOnClicked by rememberUpdatedState(onClicked)
    val currentOnDismissed by rememberUpdatedState(onDismissed)
    val currentOnFailedToShow by rememberUpdatedState(onFailedToShow)
    val currentOnImpression by rememberUpdatedState(onImpression)
    val currentOnShowed by rememberUpdatedState(onShowed)

    // Scope everything to the slot id: when it changes, the previous host leaves
    // composition (its DisposableEffect destroys it) and a fresh host is created.
    return key(adSlotId) {
        // Single interstitial host instance kept across recompositions for this slot.
        val host = remember { interstitialFactory(context) }

        // Bridge SDK callbacks to the Compose lambdas (kept current via the
        // rememberUpdatedState delegates captured above).
        val listener = remember {
            createInterstitialListener(
                onLoaded = { currentOnLoaded() },
                onFailed = { e -> currentOnFailed(e) },
                onClicked = { currentOnClicked() },
                onDismissed = { currentOnDismissed() },
                onFailedToShow = { e -> currentOnFailedToShow(e) },
                onImpression = { currentOnImpression() },
                onShowed = { currentOnShowed() },
            )
        }

        // Controller wired to this slot's host; stable identity across recompositions.
        val controller = remember(host) { StroeerInterstitialController(host::show) }

        // Load the ad when this slot enters composition; destroy it on exit.
        DisposableEffect(host, adSlotId) {
            if (adSlotId.isNotBlank()) {
                host.load(adSlotId, listener)
            }
            onDispose {
                host.destroy()
            }
        }

        controller
    }
}

/**
 * Controller returned by [StroeerInterstitial] that lets the caller display the loaded ad.
 *
 * Only call [show] after [onLoaded] fires; calling it before the ad has loaded has no effect.
 */
@Stable
class StroeerInterstitialController internal constructor(private val showAction: () -> Unit) {
    /** Displays the interstitial ad. Has no effect if the ad is not yet loaded. */
    fun show() {
        showAction()
    }
}

/**
 * Seam over [StroeerInterstitialView] so the composable can be tested with a fake that
 * doesn't construct the heavyweight ad view.
 */
internal interface InterstitialHost {
    fun load(adSlotId: String, listener: IStroeerInterstitialListener?)
    fun show()
    fun destroy()
}

/** Production [InterstitialHost] backed by a real [StroeerInterstitialView]. */
private class RealInterstitialHost(private val view: StroeerInterstitialView) : InterstitialHost {
    init {
        view.loadAfterReady = false
    }

    override fun load(adSlotId: String, listener: IStroeerInterstitialListener?) {
        view.load(adSlotId, listener)
    }

    override fun show() {
        view.show()
    }

    override fun destroy() {
        view.destroy()
    }
}

/**
 * Builds an [IStroeerInterstitialFullListener] that forwards each SDK callback to the
 * matching lambda.
 */
internal fun createInterstitialListener(
    onLoaded: () -> Unit,
    onFailed: (StroeerException?) -> Unit,
    onClicked: () -> Unit,
    onDismissed: () -> Unit,
    onFailedToShow: (StroeerException?) -> Unit,
    onImpression: () -> Unit,
    onShowed: () -> Unit,
): IStroeerInterstitialFullListener = object : IStroeerInterstitialFullListener {
    // IStroeerInterstitialListener
    override fun onAdLoaded() {
        onLoaded()
    }

    override fun onAdFailedToLoad(exception: StroeerException?) {
        onFailed(exception)
    }

    // IStroeerAdFullListener
    override fun onAdClicked() {
        onClicked()
    }

    override fun onAdDismissedFullScreenContent() {
        onDismissed()
    }

    override fun onAdFailedToShowFullScreenContent(e: StroeerException?) {
        onFailedToShow(e)
    }

    override fun onAdImpression() {
        onImpression()
    }

    override fun onAdShowedFullScreenContent() {
        onShowed()
    }
}
