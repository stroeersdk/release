package com.stroeer.gravite

import android.annotation.SuppressLint
import android.widget.FrameLayout
import com.google.android.gms.ads.AdSize
import com.intentsoftware.addapptr.AATKit.createBannerCache
import com.intentsoftware.addapptr.AdNetwork
import com.intentsoftware.addapptr.BannerCache
import com.intentsoftware.addapptr.BannerCache.CacheDelegate
import com.intentsoftware.addapptr.BannerCacheConfiguration
import com.intentsoftware.addapptr.BannerRequest
import com.intentsoftware.addapptr.BannerRequestDelegate
import com.intentsoftware.addapptr.BannerSize
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.plugins.backfill.IBackFillBanner
import com.stroeer.plugins.backfill.gravite.IFirstBannerLoaded
import com.stroeer.utilities.logging.Logger

/**
 * GraviteBannerCache is responsible for handling the loading, fetching,
 * and caching of banner ads from AATKit.
 */
class GraviteBanner  // Constructor
    : BannerRequestDelegate, IBackFillBanner {
    // Cache table to store banner cache models with DFP ad unit as key
    private val cacheTable = HashMap<String, BannerCache>()
    private var stroeerToGravitePlacementMapTable: MutableMap<String, String> = mutableMapOf()

    private var cacheSize = 1 // Default cache size

    /**
     * Loads a banner ad for a given ad unit if it is not already cached.
     *
     * This method checks the cache table to determine whether the banner for the provided ad unit
     * has already been created. If not, it sets up a new banner configuration, prepares the banner
     * request with targeting parameters and allowed sizes, and creates a banner cache.
     *
     * @param ylAdUnitData Contains details about the ad unit, such as the DFP Ad Unit ID and available sizes.
     * @param loaded       A callback interface triggered when the first banner is loaded successfully. As the first banner takes time to be loaded, this should be handled.
     */
    @Synchronized
    public override fun loadBanner(bannerConfig: BannerConfiguration, loaded: IFirstBannerLoaded?) {
        val name = bannerConfig.publisherSlotName

        // Convert the ad slot name to the format expected by Gravite
        val placementName = GraviteHelper.convertAdSlot(
            stroeerToGravitePlacementMapTable,
            bannerConfig.publisherSlotName
        )

        // Check if the banner for this ad unit is already cached
        if (placementName != null && !cacheTable.containsKey(name)) {

            // Configure the BannerCache, including placement name and cache size
            val configuration = BannerCacheConfiguration(placementName, cacheSize)
            configuration.delegate = object : CacheDelegate {
                override fun firstBannerLoaded() {
                    // Notify via the provided callback when the first banner is successfully loaded
                    loaded?.onFirstBannerLoaded()
                }
            }

            // Create a BannerRequest and configure it with targeting parameters
            val request = BannerRequest(this)
            request.contentTargetingUrl = "" // No content targeting applied (empty URL)

            // Convert the available ad sizes to Gravite-supported banner sizes
            val allowedBannerSizes: MutableSet<BannerSize> =
                convertAdSizes(bannerConfig.availableBannerSizes)
            if (!allowedBannerSizes.isEmpty()) {
                // Set allowed banner sizes for the banner request
                request.setBannerSizes(allowedBannerSizes)
            }

            // Attach the banner request configuration to the cache configuration
            configuration.requestConfiguration = request

            // Attempt to create a banner cache using the configuration
            val bannerCache = createBannerCache(configuration)
            if (bannerCache != null) {
                // Successfully created banner cache; store it in the cache table
                cacheTable.put(name, bannerCache)
                Logger.d("[GravitePlugin] A banner is created for ad unit: $name")
            } else {
                // Failed to create the banner cache; log an error message
                Logger.e("[GravitePlugin] Failed to create banner for ad unit: $name")
            }
        }
    }

    /**
     * Retrieve the banner ad for the given ad unit.
     *
     * @param bannerConfig The YieldloveAdUnit data containing the DFP Ad Unit ID.
     * @return The FrameLayout containing the banner, or null if no banner is loaded.
     */
    override fun getBanner(bannerConfig : BannerConfiguration): FrameLayout? {
        if (bannerConfig.publisherSlotName.isEmpty()) {
            Logger.e("[GravitePlugin] Placement name is null or empty.")
            return null
        }

        val placementName = GraviteHelper.convertAdSlot(
            stroeerToGravitePlacementMapTable,
            bannerConfig.publisherSlotName
        )
        val cache = cacheTable.get(placementName)

        if (cache != null) {
            Logger.d(String.format("[GravitePlugin] Banner %s is loaded", placementName))
            // Get the banner from the cache
            return cache.consume()
        } else {
            Logger.d(
                String.format(
                    "[GravitePlugin] Banner %s is not loaded. Check Gravite settings/logs.",
                    placementName
                )
            )
            return null
        }
    }

    /**
     * Sets the size of the banner ad cache.
     *
     * @param size The number of banners to cache. Must be a positive integer.
     */
    fun setCacheSize(size: Int) {
        cacheSize = size
    }

    /**
     * Sets the mapping table to convert Stroeer ad slots to Gravite-compatible placement names.
     *
     * @param stroeerToGravite A map where the key is the Stroeer ad slot and the value is the Gravite placement name.
     */
    fun setPlacementMapTable(stroeerToGravite: MutableMap<String, String>) {
        stroeerToGravitePlacementMapTable = stroeerToGravite
    }

    /**
     * Determines whether targeting should be used for a given banner request and ad network.
     * This implementation does not use targeting.
     *
     * @param bannerRequest The banner request for which targeting is being checked.
     * @param adNetwork     The ad network associated with the request. Can be null.
     * @return Always returns false as targeting is not implemented.
     */
    override fun shouldUseTargeting(bannerRequest: BannerRequest, adNetwork: AdNetwork?): Boolean {
        return false // Targeting is not supported in this implementation.
    }

    companion object {
        /**
         * Convert Prebid ad sizes to Gravite-compatible banner sizes.
         * Ad sizes unsupported by Gravite will be ignored.
         *
         * @param bannerSizes Array of AdSize objects (Prebid sizes).
         * @return A set of BannerSize objects supported by Gravite.
         */
        @SuppressLint("DefaultLocale")
        private fun convertAdSizes(bannerSizes: Array<AdSize>): HashSet<BannerSize> {
            val aatSizeConversion = HashSet<BannerSize>()
            for (adSize in bannerSizes) {
                try {
                    for (size in BannerSize.entries) {
                        if (size.width == adSize.width && size.height == adSize.height) {
                            aatSizeConversion.add(size)
                            break // Add the size if a match is found and break the loop
                        }
                    }
                } catch (_ : Exception) {
                    // Safely ignore exceptions during size conversion
                }
            }
            return aatSizeConversion
        }
    }
}