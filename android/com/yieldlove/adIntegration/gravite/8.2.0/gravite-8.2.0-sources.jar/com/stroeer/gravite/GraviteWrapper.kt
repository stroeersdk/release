package com.stroeer.gravite

import android.app.Activity
import android.app.Application
import android.content.Context
import android.util.Log
import com.intentsoftware.addapptr.AATKit
import com.intentsoftware.addapptr.AATKit.disableDebugScreen
import com.intentsoftware.addapptr.AATKit.init
import com.intentsoftware.addapptr.AATKit.onActivityPause
import com.intentsoftware.addapptr.AATKit.onActivityResume
import com.intentsoftware.addapptr.AATKit.setLogLevel
import com.intentsoftware.addapptr.AATKit.setTargetingInfo
import com.intentsoftware.addapptr.AATKitConfiguration
import com.intentsoftware.addapptr.AdNetwork
import com.intentsoftware.addapptr.Consent
import com.intentsoftware.addapptr.NonIABConsent
import com.intentsoftware.addapptr.VendorConsent
import com.intentsoftware.addapptr.VendorConsent.VendorConsentDelegate
import com.stroeer.ads.debugInfo.IDebugInfo
import com.stroeer.ads.formats.AdSource
import com.stroeer.ads.formats.AdSourceInfo
import com.stroeer.plugins.backfill.IBackFill
import com.stroeer.plugins.backfill.IBackFillBanner
import com.stroeer.plugins.backfill.IBackFillInterstitial
import com.stroeer.utilities.logging.Logger

class GraviteWrapper : IBackFill, VendorConsentDelegate {
    private var debugMode = false
    private var testMode = false
    private var testBundleId: String? = null
    private var testAccountId: Int? = null

    private var isGraviteStarted = false
    private var applicationContext: Context? = null

    /**
     * Interstitial ad handler for managing interstitial ads
     */
    private val interstitialBuilder = GraviteInterstitial()

    /**
     * Banner ad handler for managing banner ads
     */
    private val bannerBuilder = GraviteBanner()

    override fun initialize(application: Application) {
        // Configure AATKit

        val config = AATKitConfiguration(application)

        if (testMode) {
            testBundleId.let {
                config.setAlternativeBundleId(testBundleId)
                Logger.i("[Gravite] Test Bundle Id is enabled for $testBundleId")
            }

            testAccountId.let{
                config.setTestModeAccountId(testAccountId!!)
                Logger.i("[Gravite] Test Account Id is enabled for $testAccountId")
            }
        }
        applicationContext = application.applicationContext

        val consent: Consent = VendorConsent(this)
        config.consent = consent

        // Initialize AATKit with the configured options
        init(config)

        // Disable Shake debug mode
        disableDebugScreen()

        if (debugMode) {
            setLogLevel(Log.VERBOSE)
            Logger.i("[Gravite] Debug mode is enabled")
        } else {
            setLogLevel(Log.INFO)
        }
        isGraviteStarted = true

        Logger.i("[Gravite] GravitePlugin is initialized")
    }

    /**
     * Get the banner loader instance (implements IBackFillBanner).
     * 
     * @return this instance for banner loading
     */
    override fun getBannerLoader(): IBackFillBanner {
        return bannerBuilder
    }

    /**
     * Get the interstitial loader instance (implements IBackFillInterstitial).
     * 
     * @return this instance for interstitial loading
     */
    override fun getInterstitialLoader(): IBackFillInterstitial {
        return interstitialBuilder
    }

    /**
     * Set global targeting parameters for ads.
     * 
     * @param targeting Map of targeting information
     */
    override fun setCustomTargeting(targeting: MutableMap<String, MutableList<String>>) {
        setTargetingInfo(targeting)
    }

    override fun setCacheSize(size: Int) {
        Logger.i("[Gravite] Cache Size is changed to $size")
        bannerBuilder.setCacheSize(size)
    }

    override fun setPlacementMapTable(stroeerToGravite: MutableMap<String, String>) {
        bannerBuilder.setPlacementMapTable(stroeerToGravite)
        interstitialBuilder.setPlacementMapTable(stroeerToGravite)
    }

    /**
     * Notify the AATKit that the activity has resumed.
     * This should be called from the activity's onResume().
     * 
     * @param activity Activity instance
     */
    override fun onResume(activity: Activity) {
        onActivityResume(activity)
    }

    /**
     * Notify the AATKit that the activity has paused.
     * This should be called from the activity's onPause().
     * 
     * @param activity Activity instance
     */
    override fun onPause(activity: Activity) {
        onActivityPause(activity)
    }

    override fun enableDebugMode() {
        if (isGraviteStarted) {
            Logger.e("[Gravite] Gravite SDK is already initialized. debugMode should be set before initializing Gravite")
            return
        }

        Logger.i("[Gravite] Debug mode enabled")
        debugMode = true
    }

    override fun enableTestMode(bundleId: String?, accountId: Int?) {
        if (isGraviteStarted) {
            Logger.e("[Gravite] Gravite SDK is already initialized. testMode should be set before initializing Gravite")
            return
        }

        Logger.i("[Gravite] Test mode enabled")
        testMode = true
        testBundleId = bundleId
        testAccountId = accountId
    }

    override fun getDebugInfo(): IDebugInfo? {
        return if (isGraviteStarted) {
            GraviteDebugInfo(getAdSourceInfo())
        } else {
            null
        }
    }


    override fun getVersion(): String {
        return AATKit.version
    }

    override fun getAdSourceInfo(): AdSourceInfo {
        return AdSourceInfo(AdSource.Gravite, getVersion())
    }

    override fun getConsentForNetwork(network: AdNetwork): NonIABConsent {
        return GraviteConsentDecoder.isVendorConsentGiven(applicationContext, network)
    }


    override val consentForAddapptr: NonIABConsent
        get() = NonIABConsent.OBTAINED

    companion object {
        /**
         * Deprecated method to enable debug logging. Should not be used in production.
         * Use 'adb shell setprop log.tag.AATKit V' for logging control.
         * 
         * @param isEnabled True to enable debug mode
         */
        @Deprecated("")
        fun enableDebug(isEnabled: Boolean) {
            val logLevel = if (isEnabled) Log.DEBUG else Log.INFO
            setLogLevel(logLevel)
        }
    }
}