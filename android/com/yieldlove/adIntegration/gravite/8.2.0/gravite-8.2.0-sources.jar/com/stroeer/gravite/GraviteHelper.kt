package com.stroeer.gravite

/**
 * Utility class for handling ad slot transformations for Gravite.
 * Gravite does not allow certain characters in ad slots, such as '?', and this class provides
 * methods to convert or map ad slots accordingly.
 */
object GraviteHelper {
    /**
     * Converts or maps the given ad slot string based on the provided placement map table.
     * If the ad slot is found in the placement map table, the corresponding value is returned.
     * If not, any occurrence of the '?' character in the ad slot is replaced with an underscore ('_').
     * This ensures compatibility with Gravite's constraints.
     *
     * @param placementMapTable a map containing ad slot mappings (key: original ad slot, value: mapped ad slot);
     * may be null or empty if no mappings are needed.
     * @param adSlot the ad slot string to be processed; must not be null.
     * @return the processed ad slot string, either mapped or with '?' replaced by '_'.
     * @throws NullPointerException if the provided adSlot is null.
     */
    fun convertAdSlot(placementMapTable: MutableMap<String, String>, adSlot: String): String? {
        // Validate input map: if null or does not contain the ad slot, proceed with character replacement.
        return if (!placementMapTable.containsKey(adSlot)) {
            // Replace '?' with '_', as '?' is not allowed in Gravite ad slots.
            adSlot.replace('?', '_')
        } else {
            // Return the mapped ad slot from the placement map table.
            placementMapTable[adSlot]
        }
    }
}
