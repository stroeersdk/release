package com.stroeer.gravite

import com.intentsoftware.addapptr.AATKit.createFullscreenPlacement
import com.intentsoftware.addapptr.FullscreenPlacement
import com.intentsoftware.addapptr.FullscreenPlacementListener
import com.intentsoftware.addapptr.Placement
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.interstitial.IStroeerInterstitialListener
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration
import com.stroeer.plugins.backfill.IBackFillInterstitial
import com.stroeer.utilities.logging.Logger

/**
 * GraviteInterstitial is responsible for handling the loading, management,
 * and display of interstitial ads using the AATKit and Yieldlove frameworks.
 * Implements the FullscreenPlacementListener and IBackFillInterstitial interfaces
 * to handle ad events and integrate with backfill systems.
 */
class GraviteInterstitial : FullscreenPlacementListener, IBackFillInterstitial {
    // HashMap to store interstitials with their corresponding DFP ad unit IDs
    private val interstitialTable = HashMap<String?, FullscreenPlacement?>()

    // Map to convert Stroeer ad slots to Gravite-compatible placement names
    private var stroeerToGravitePlacementMapTable: MutableMap<String, String> = mutableMapOf()

    // Listener to notify Yieldlove about interstitial ad events
    private var listener: IStroeerInterstitialListener? = null

    /**
     * Loads an interstitial ad for the given Yieldlove ad unit.
     *
     * @param intConfig Contains details about the ad unit, including DFP Ad Unit ID and slot name.
     * @param listener Listener to handle interstitial ad events.
     */
    override fun loadInterstitial(
        intConfig: InterstitialConfiguration,
        listener: IStroeerInterstitialListener
    ) {
        val placementNameForStroeer = intConfig.publisherSlotName
        val placementName = getPlacementName(placementNameForStroeer)
        this.listener = listener

        // Check if the interstitial is already loaded
        if (placementName != null && !interstitialTable.containsKey(placementName)) {
            val placement = createFullscreenPlacement(placementName)

            if (placement != null) {
                placement.listener = this // Attach this class as the listener for placement events
                interstitialTable.put(placementName, placement)
                placement.startAutoReload()
                Logger.i("[GravitePlugin] Interstitial loaded for ad unit: $placementNameForStroeer with placement(Gravite): $placementName")
            } else {
                Logger.e("[GravitePlugin] Failed to create interstitial for ad unit: $placementNameForStroeer")
                listener.onAdFailedToLoad(StroeerException("Failed to create interstitial for ad unit: $placementNameForStroeer"))
            }
        } else {
            Logger.d("[GravitePlugin] Interstitial already loaded for ad unit: $placementNameForStroeer")
            val ad = interstitialTable.get(placementName)
            ad?.startAutoReload()
        }
    }

    /**
     * Sets the mapping table for converting Stroeer ad slots to Gravite placements.
     *
     * @param stroeerToGravite Mapping table with Stroeer ad slots as keys and Gravite placements as values.
     */
    fun setPlacementMapTable(stroeerToGravite: MutableMap<String, String>) {
        stroeerToGravitePlacementMapTable = stroeerToGravite
    }

    /**
     * Displays the interstitial ad for the given Yieldlove ad unit.
     *
     * @param intConfig Contains details about the ad unit, including DFP Ad Unit ID.
     */
    public override fun showInterstitial(intConfig: InterstitialConfiguration) {
        val placementName = getPlacementName(intConfig.publisherSlotName)
        val placement = interstitialTable.get(placementName)

        if (placement != null && placement.hasAd()) {
            placement.show()
            Logger.d("[GravitePlugin] Interstitial shown for ad unit: $placementName")
        } else if (placement == null) {
            Logger.d("[GravitePlugin] No interstitial found for ad unit: $placementName")
        } else {
            Logger.d("[GravitePlugin] Interstitial not ready yet for ad unit: $placementName")
        }
    }

    private fun getPlacementName(placementNameInStroeer: String): String? {
        return GraviteHelper.convertAdSlot(
            stroeerToGravitePlacementMapTable,
            placementNameInStroeer
        )
    }

    /**
     * Checks if an interstitial ad is available for the given Yieldlove ad unit.
     *
     * @param intConfig Contains details about the ad unit, including DFP Ad Unit ID.
     * @return true if the interstitial ad is available, false otherwise.
     */
    public override fun isInterstitialAvailable(intConfig: InterstitialConfiguration): Boolean {
        val placementName = getPlacementName(intConfig.publisherSlotName)
        val placement = interstitialTable.get(placementName)
        return placement != null && placement.hasAd()
    }

    // Callback triggered when an ad pauses the app
    override fun onPauseForAd(placement: Placement) {
        Logger.d("[GraviteInterstitial] Ad paused for placement: " + placement.name)
    }

    // Callback triggered when the app resumes after an ad
    override fun onResumeAfterAd(placement: Placement) {
        Logger.d("[GraviteInterstitial] Ad resumed after placement: " + placement.name)
    }

    // Callback triggered when an ad becomes available for a placement
    override fun onHaveAd(placement: Placement) {
        Logger.d("[GraviteInterstitial] Ad available for placement: " + placement.name)
    }

    // Callback triggered when no ad is available for a placement
    override fun onNoAd(placement: Placement) {
        Logger.d("[GraviteInterstitial] No ad available for placement: " + placement.name)
        listener!!.onAdFailedToLoad(StroeerException("No ad available for placement: " + placement.name))
        val ad = interstitialTable.get(placement.name)
        ad?.stopAutoReload()
    }
}
