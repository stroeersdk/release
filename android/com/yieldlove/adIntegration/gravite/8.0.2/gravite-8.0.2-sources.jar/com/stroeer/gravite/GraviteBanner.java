package com.stroeer.gravite;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.ads.AdSize;
import com.intentsoftware.addapptr.AATKit;
import com.intentsoftware.addapptr.AdNetwork;
import com.intentsoftware.addapptr.BannerCache;
import com.intentsoftware.addapptr.BannerCacheConfiguration;
import com.intentsoftware.addapptr.BannerRequest;
import com.intentsoftware.addapptr.BannerRequestDelegate;
import com.intentsoftware.addapptr.BannerSize;
import com.stroeer.plugins.backfill.IBackFillBanner;
import com.stroeer.plugins.backfill.gravite.IFirstBannerLoaded;
import com.stroeer.utilities.logging.Logger;
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * GraviteBannerCache is responsible for handling the loading, fetching,
 * and caching of banner ads from AATKit.
 */
public final class GraviteBanner implements BannerRequestDelegate, IBackFillBanner {

    // Cache table to store banner cache models with DFP ad unit as key
    private final HashMap<String, BannerCache> cacheTable = new HashMap<>();
    private Map<String, String> stroeerToGravitePlacementMapTable = null;

    private int cacheSize = 1;  // Default cache size

    // Constructor
    public GraviteBanner() {}

    /**
     * Loads a banner ad for a given ad unit if it is not already cached.
     *
     * This method checks the cache table to determine whether the banner for the provided ad unit
     * has already been created. If not, it sets up a new banner configuration, prepares the banner
     * request with targeting parameters and allowed sizes, and creates a banner cache.
     *
     * @param ylAdUnitData Contains details about the ad unit, such as the DFP Ad Unit ID and available sizes.
     * @param loaded       A callback interface triggered when the first banner is loaded successfully. As the first banner takes time to be loaded, this should be handled.
     */
    @Override
    public synchronized void loadBanner(YieldloveAdUnit ylAdUnitData, IFirstBannerLoaded loaded) {
        String name = ylAdUnitData.getPlacementName();

        // Check if the banner for this ad unit is already cached
        if (!cacheTable.containsKey(name)) {
            // Convert the ad slot name to the format expected by Gravite
            String placementName = GraviteHelper.convertAdslot(stroeerToGravitePlacementMapTable, ylAdUnitData.getPlacementName());

            // Configure the BannerCache, including placement name and cache size
            BannerCacheConfiguration configuration = new BannerCacheConfiguration(placementName, cacheSize);
            configuration.setDelegate(new BannerCache.CacheDelegate() {
                @Override
                public void firstBannerLoaded() {
                    // Notify via the provided callback when the first banner is successfully loaded
                    loaded.onFirstBannerLoaded();
                }
            });

            // Create a BannerRequest and configure it with targeting parameters
            BannerRequest request = new BannerRequest(this);
            request.setContentTargetingUrl("");  // No content targeting applied (empty URL)

            // Convert the available ad sizes to Gravite-supported banner sizes
            Set<BannerSize> allowedBannerSizes = GraviteBanner.convertAdSizes(ylAdUnitData.availableBannerSizes);
            if (!allowedBannerSizes.isEmpty()) {
                // Set allowed banner sizes for the banner request
                request.setBannerSizes(allowedBannerSizes);
            }

            // Attach the banner request configuration to the cache configuration
            configuration.setRequestConfiguration(request);

            // Attempt to create a banner cache using the configuration
            BannerCache bannerCache = AATKit.createBannerCache(configuration);
            if (bannerCache != null) {
                // Successfully created banner cache; store it in the cache table
                cacheTable.put(name,bannerCache);
                Logger.d("[GravitePlugin] A banner is created for ad unit: " + name);
            } else {
                // Failed to create the banner cache; log an error message
                Logger.e("[GravitePlugin] Failed to create banner for ad unit: " + name);
            }
        }
    }

    /**
     * Retrieve the banner ad for the given ad unit.
     *
     * @param ylAdUnitData The YieldloveAdUnit data containing the DFP Ad Unit ID.
     * @return The FrameLayout containing the banner, or null if no banner is loaded.
     */
    @Override
    public android.widget.FrameLayout getBanner(YieldloveAdUnit ylAdUnitData) {
        String placementName = GraviteHelper.convertAdslot(stroeerToGravitePlacementMapTable, ylAdUnitData.getPlacementName());
        BannerCache cache = cacheTable.get(placementName);

        if (cache != null) {
            Logger.d(String.format("[GravitePlugin] Banner %s is loaded", placementName));
            // Get the banner from the cache
            return cache.consume();
        } else {
            Logger.d(String.format("[GravitePlugin] Banner %s is not loaded. Check Gravite settings/logs.", placementName));
            return null;
        }
    }

    /**
     * Convert Prebid ad sizes to Gravite-compatible banner sizes.
     * Ad sizes unsupported by Gravite will be ignored.
     *
     * @param bannerSizes Array of AdSize objects (Prebid sizes).
     * @return A set of BannerSize objects supported by Gravite.
     */
    @SuppressLint("DefaultLocale")
    private static HashSet<BannerSize> convertAdSizes(AdSize[] bannerSizes) {
        HashSet<BannerSize> aatSizeConversion = new HashSet<>();
        if (bannerSizes != null) {
            for (AdSize adSize : bannerSizes) {
                try {
                    for (BannerSize size : BannerSize.values()) {
                        if (size.getWidth() == adSize.getWidth() && size.getHeight() == adSize.getHeight()) {
                            aatSizeConversion.add(size);
                            break;  // Add the size if a match is found and break the loop
                        }
                    }
                } catch (Exception ignored) {
                    // Safely ignore exceptions during size conversion
                }
            }
        }
        return aatSizeConversion;
    }

    /**
     * Sets the size of the banner ad cache.
     *
     * @param size The number of banners to cache. Must be a positive integer.
     */
    public void setCacheSize(int size) {
        cacheSize = size;
    }

    /**
     * Sets the mapping table to convert Stroeer ad slots to Gravite-compatible placement names.
     *
     * @param stroeerToGravite A map where the key is the Stroeer ad slot and the value is the Gravite placement name.
     */
    public void setPlacementMapTable(Map<String, String> stroeerToGravite) {
        stroeerToGravitePlacementMapTable = stroeerToGravite;
    }

    /**
     * Determines whether targeting should be used for a given banner request and ad network.
     * This implementation does not use targeting.
     *
     * @param bannerRequest The banner request for which targeting is being checked.
     * @param adNetwork     The ad network associated with the request. Can be null.
     * @return Always returns false as targeting is not implemented.
     */
    @Override
    public boolean shouldUseTargeting(@NonNull BannerRequest bannerRequest, @Nullable AdNetwork adNetwork) {
        return false; // Targeting is not supported in this implementation.
    }
}