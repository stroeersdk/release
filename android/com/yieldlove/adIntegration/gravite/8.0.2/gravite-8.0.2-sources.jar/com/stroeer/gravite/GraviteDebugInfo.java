package com.stroeer.gravite;

import androidx.annotation.NonNull;

import com.intentsoftware.addapptr.AATKit;
import com.intentsoftware.addapptr.internal.module.debugscreen.AATKitDebugInfo;
import com.intentsoftware.addapptr.internal.module.debugscreen.PlacementDebugInfo;
import com.stroeer.ads.debugInfo.IDebugInfo;
import com.stroeer.ads.debugInfo.ISdkDebugInfo;
import com.stroeer.ads.formats.AdSourceInfo;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class GraviteDebugInfo implements IDebugInfo {
    public AdSourceInfo adSourceInfo;

    public GraviteDebugInfo(AdSourceInfo sourceInfo) {
        this.adSourceInfo = sourceInfo;
    }

    @NonNull
    @Override
    public String toString() {
        AATKitDebugInfo info = AATKit.getDebugInfoObject();

        if (info == null) {
            return "Gravite debug information is empty";
        }

        return "AATKitDebugInfo {\n" +
                "  testBundleId = '" + safe(info.getTestBundleId()) + "'\n" +
                "  testId = " + safe(info.getTestId()) + "\n" +
                "  consentType = '" + safe(info.getConsentType()) + "'\n" +
                "  consentStringVersion = " + safe(info.getConsentStringVersion()) + "\n" +
                "  usedConsent = '" + safe(info.getUsedConsent()) + "'\n" +
                safe(getPlacementDebugInfoString(info.getPlacementDebugInfo())) +
                "  availableAdNetworks = " + safe(info.getAvailableAdNetworks()) + "\n" +
                "  disabledAdNetworks = " + safe(info.getDisabledAdNetworks()) + "\n" +
                "  removedAdNetworks = " + safe(info.getRemovedAdNetworks()) + "\n" +
                "  unsupportedAdNetworks = " + safe(info.getUnsupportedAdNetworks()) + "\n" +
                "  extraSDKs = " + safe(info.getExtraSDKs()) + "\n" +
                "  deviceType = '" + safe(info.getDeviceType()) + "'\n" +
                "  advertisingId = '" + safe(info.getAdvertisingId()) + "'\n" +
                "}";
    }

    public String getPlacementDebugInfoString(List<PlacementDebugInfo> info) {
        StringBuilder placementInfoString = new StringBuilder();
        for (int i = 0; i < info.size(); i++) {
            PlacementDebugInfo placementInfo = info.get(i);
            if (placementInfo != null) {
                placementInfoString.append("PlacementDebugInfo [")
                        .append(i)
                        .append("] {\n")
                        .append("  placementName = '").append(safe(placementInfo.getPlacementName())).append("'\n")
                        .append("  placementType = '").append(safe(placementInfo.getPlacementType())).append("'\n")
                        .append("  bannerAutoReloadInterval = ").append(placementInfo.getBannerAutoReloadInterval()).append("\n")
                        .append("  initialDelay = ").append(placementInfo.getInitialDelay()).append("\n")
                        .append("  remainingTime = ").append(placementInfo.getRemainingTime()).append("\n")
                        .append("  loadedAdsNetworkName = '").append(safe(placementInfo.getLoadedAdsNetworkName())).append("'\n")
                        .append("  isLoadingNewAd = ").append(placementInfo.isLoadingNewAd()).append("\n")
                        .append("  isAdQualityActive = ").append(placementInfo.isAdQualityActive()).append("\n")
                        .append("  lastShownAdNetworkName = '").append(safe(placementInfo.getLastShownAdNetworkName())).append("'\n")
                        .append("  placementHistory = ").append(safeArray(placementInfo.getPlacementHistory())).append("\n")
                        .append("  adsAttachedToLayout = ").append(safe(placementInfo.getAdsAttachedToLayout())).append("\n")
                        .append("  activeFrequencyCapping = ").append(getFrequencyCappingString(placementInfo.getActiveFrequencyCapping())).append("\n")
                        .append("}\n\n");
            }
        }

        return placementInfoString.toString();
    }

    private String getFrequencyCappingString(PlacementDebugInfo.FrequencyCappingDebugInfo fc) {
        if (fc == null) return "null";
        return "FrequencyCappingDebugInfo {\n" +
                "    maxImpressionsPerSession = " + fc.getMaxImpressionsPerSession() + "\n" +
                "    maxImpressionsPerHour = " + fc.getMaxImpressionsPerHour() + "\n" +
                "    maxImpressionsPerDay = " + fc.getMaxImpressionsPerDay() + "\n" +
                "    maxImpressionsPerWeek = " + fc.getMaxImpressionsPerWeek() + "\n" +
                "    maxImpressionsPerMonth = " + fc.getMaxImpressionsPerMonth() + "\n" +
                "    minTimeBetweenImpressions = " + fc.getMinTimeBetweenImpressions() + "\n" +
                "  }";
    }

    private String safeArray(Object[] array) {
        return array == null ? "null" : Arrays.toString(array);
    }

    private String safe(Object value) {
        return value == null ? "null" : value.toString();
    }

    @Override
    public AdSourceInfo getAdSourceInfo() {
        return adSourceInfo;
    }

    @Override
    public String getPublisherSlotName() {
        return "Gravite";
    }

    @Override
    public int getServedInTime() {
        return 0;
    }

    @Override
    public @Nullable Map<@NotNull String, @Nullable String> getCustomTargeting() {
        return Collections.emptyMap();
    }

    @Override
    public void setCustomTargeting(@Nullable Map<@NotNull String, @Nullable String> stringStringMap) {

    }

    @Override
    public @NotNull List<@NotNull ISdkDebugInfo> getSdkDebugInfos() {
        return Collections.emptyList();
    }

    @Override
    public @Nullable String getHtml() {
        return "";
    }

    @Override
    public void setHtml(@Nullable String s) {

    }
}