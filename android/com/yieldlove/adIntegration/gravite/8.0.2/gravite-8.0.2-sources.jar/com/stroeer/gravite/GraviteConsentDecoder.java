package com.stroeer.gravite;

import android.content.Context;

import androidx.preference.PreferenceManager;

import com.intentsoftware.addapptr.AdNetwork;
import com.intentsoftware.addapptr.NonIABConsent;
import com.stroeer.consent.ConsentManager;

import java.util.HashMap;
import java.util.Map;

public class GraviteConsentDecoder {
    // Vendor ID mapping for known AdNetworks
    private static final Map<AdNetwork, Integer> VENDOR_IDS = new HashMap<>();

    static {
        VENDOR_IDS.put(AdNetwork.ADMOB, 755);
        VENDOR_IDS.put(AdNetwork.AMAZONHB, 793);
        VENDOR_IDS.put(AdNetwork.APPLOVIN, 333);
        VENDOR_IDS.put(AdNetwork.APPNEXUS, 32);
        VENDOR_IDS.put(AdNetwork.DFP, 755);
        VENDOR_IDS.put(AdNetwork.FACEBOOK, 804);
        VENDOR_IDS.put(AdNetwork.FEEDAD, 781);
        VENDOR_IDS.put(AdNetwork.INMOBI, 333);
        VENDOR_IDS.put(AdNetwork.KIDOZ, 1278);
        VENDOR_IDS.put(AdNetwork.MINTEGRAL, 867);
        VENDOR_IDS.put(AdNetwork.OGURY, 31);
        VENDOR_IDS.put(AdNetwork.PUBNATIVE, 82);
        VENDOR_IDS.put(AdNetwork.SMARTAD, 82);
        VENDOR_IDS.put(AdNetwork.TAPPX, 628);
        VENDOR_IDS.put(AdNetwork.TEADS, 132);
        VENDOR_IDS.put(AdNetwork.UNITY, 1126);
        VENDOR_IDS.put(AdNetwork.YOC, 154);
        VENDOR_IDS.put(AdNetwork.VUNGLE2, 667);
        VENDOR_IDS.put(AdNetwork.SUPERAWESOME, 858);
        VENDOR_IDS.put(AdNetwork.ADMOBBIDDING, 755);
    }

    public static NonIABConsent isVendorConsentGiven(Context applicationContext, AdNetwork adNetwork) {
        if(VENDOR_IDS.containsKey(adNetwork)) {
            String consentString = PreferenceManager.getDefaultSharedPreferences(applicationContext).getString("IABTCF_TCString", "");
            return ConsentManager.hasVendorConsent(VENDOR_IDS.get(adNetwork)) ? NonIABConsent.OBTAINED : NonIABConsent.WITHHELD;
        }
        return NonIABConsent.UNKNOWN;
    }
}
