package com.stroeer.gravite;

import androidx.annotation.NonNull;

import com.intentsoftware.addapptr.AATKit;
import com.intentsoftware.addapptr.FullscreenPlacement;
import com.intentsoftware.addapptr.FullscreenPlacementListener;
import com.intentsoftware.addapptr.Placement;
import com.stroeer.ads.formats.interstitial.IStroeerInterstitialListener;
import com.stroeer.plugins.backfill.IBackFillInterstitial;
import com.stroeer.utilities.logging.Logger;
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit;
import com.stroeer.ads.exceptions.StroeerException;

import java.util.HashMap;
import java.util.Map;

/**
 * GraviteInterstitial is responsible for handling the loading, management,
 * and display of interstitial ads using the AATKit and Yieldlove frameworks.
 * Implements the FullscreenPlacementListener and IBackFillInterstitial interfaces
 * to handle ad events and integrate with backfill systems.
 */
public class GraviteInterstitial implements FullscreenPlacementListener, IBackFillInterstitial {

    // HashMap to store interstitials with their corresponding DFP ad unit IDs
    private final HashMap<String, FullscreenPlacement> interstitialTable = new HashMap<>();

    // Map to convert Stroeer ad slots to Gravite-compatible placement names
    private Map<String, String> stroeerToGravitePlacementMapTable = null;

    // Listener to notify Yieldlove about interstitial ad events
    private IStroeerInterstitialListener listener;

    /**
     * Loads an interstitial ad for the given Yieldlove ad unit.
     *
     * @param ylAdUnitData Contains details about the ad unit, including DFP Ad Unit ID and slot name.
     * @param listener Listener to handle interstitial ad events.
     */
    @Override
    public void loadInterstitial(YieldloveAdUnit ylAdUnitData, IStroeerInterstitialListener listener) {
        String placementNameForStroeer = ylAdUnitData.getPlacementName();
        String placementName = getPlacementName(placementNameForStroeer);
        this.listener = listener;

        // Check if the interstitial is already loaded
        if (!interstitialTable.containsKey(placementName)) {
            FullscreenPlacement placement = AATKit.createFullscreenPlacement(placementName);

            if (placement != null) {
                placement.setListener(this); // Attach this class as the listener for placement events
                interstitialTable.put(placementName, placement);
                placement.startAutoReload();
                Logger.i("[GravitePlugin] Interstitial loaded for ad unit: " + placementNameForStroeer + " with placement(Gravite): " + placementName);
            } else {
                Logger.e("[GravitePlugin] Failed to create interstitial for ad unit: " + placementNameForStroeer);
                listener.onAdFailedToLoad( new StroeerException("Failed to create interstitial for ad unit: " + placementNameForStroeer));
            }
        } else {
            Logger.d("[GravitePlugin] Interstitial already loaded for ad unit: " + placementNameForStroeer);
            FullscreenPlacement ad = interstitialTable.get(placementName);
            if(ad != null){
                ad.startAutoReload();
            }
        }
    }

    /**
     * Sets the mapping table for converting Stroeer ad slots to Gravite placements.
     *
     * @param stroeerToGravite Mapping table with Stroeer ad slots as keys and Gravite placements as values.
     */
    public void setPlacementMapTable(Map<String, String> stroeerToGravite) {
        stroeerToGravitePlacementMapTable = stroeerToGravite;
    }

    /**
     * Displays the interstitial ad for the given Yieldlove ad unit.
     *
     * @param ylAdUnitData Contains details about the ad unit, including DFP Ad Unit ID.
     */
    @Override
    public void showInterstitial(YieldloveAdUnit ylAdUnitData) {
        String placementName = getPlacementName(ylAdUnitData.getPlacementName());
        FullscreenPlacement placement = interstitialTable.get(placementName);

        if (placement != null && placement.hasAd()) {
            placement.show();
            Logger.d("[GravitePlugin] Interstitial shown for ad unit: " + placementName);
        } else if (placement == null) {
            Logger.d("[GravitePlugin] No interstitial found for ad unit: " + placementName);
        } else {
            Logger.d("[GravitePlugin] Interstitial not ready yet for ad unit: " + placementName);
        }
    }

    private String getPlacementName(String placementNameInStroeer){
        return GraviteHelper.convertAdslot(stroeerToGravitePlacementMapTable, placementNameInStroeer);
    }

    /**
     * Checks if an interstitial ad is available for the given Yieldlove ad unit.
     *
     * @param ylAdUnitData Contains details about the ad unit, including DFP Ad Unit ID.
     * @return true if the interstitial ad is available, false otherwise.
     */
    @Override
    public boolean isInterstitialAvailable(YieldloveAdUnit ylAdUnitData) {
        String placementName = getPlacementName(ylAdUnitData.getPlacementName());
        FullscreenPlacement placement = interstitialTable.get(placementName);
        return placement != null && placement.hasAd();
    }

    // Callback triggered when an ad pauses the app
    @Override
    public void onPauseForAd(@NonNull Placement placement) {
        Logger.d("[GraviteInterstitial] Ad paused for placement: " + placement.getName());
    }

    // Callback triggered when the app resumes after an ad
    @Override
    public void onResumeAfterAd(@NonNull Placement placement) {
        Logger.d("[GraviteInterstitial] Ad resumed after placement: " + placement.getName());
    }

    // Callback triggered when an ad becomes available for a placement
    @Override
    public void onHaveAd(@NonNull Placement placement) {
        Logger.d("[GraviteInterstitial] Ad available for placement: " + placement.getName());
    }

    // Callback triggered when no ad is available for a placement
    @Override
    public void onNoAd(@NonNull Placement placement) {
        Logger.d("[GraviteInterstitial] No ad available for placement: " + placement.getName());
        listener.onAdFailedToLoad(new StroeerException("No ad available for placement: " + placement.getName()));
        FullscreenPlacement ad = interstitialTable.get(placement.getName());
        if(ad != null) {
            ad.stopAutoReload();
        }
    }
}
