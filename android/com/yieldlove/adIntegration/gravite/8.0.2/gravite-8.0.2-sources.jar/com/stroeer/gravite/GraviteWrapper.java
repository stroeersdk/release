package com.stroeer.gravite;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.intentsoftware.addapptr.AATKit;
import com.intentsoftware.addapptr.AATKitConfiguration;
import com.intentsoftware.addapptr.AdNetwork;
import com.intentsoftware.addapptr.Consent;
import com.intentsoftware.addapptr.NonIABConsent;
import com.intentsoftware.addapptr.VendorConsent;
import com.stroeer.ads.debugInfo.IDebugInfo;
import com.stroeer.plugins.backfill.*;
import com.stroeer.utilities.logging.Logger;
import com.stroeer.ads.formats.AdSourceInfo;
import com.stroeer.ads.formats.AdSource;


import java.util.List;
import java.util.Map;

public final class GraviteWrapper implements IBackFill, VendorConsent.VendorConsentDelegate {

    private boolean debugMode = false;
    private boolean testMode = false;
    private String testBundleId = null;
    private Integer testAccountId = null;

    private boolean isGraviteStarted = false;
    private Context applicationContext;

    /**
     * Interstitial ad handler for managing interstitial ads
     */
    private final GraviteInterstitial interstitialBuilder = new GraviteInterstitial();

    /**
     * Banner ad handler for managing banner ads
     */
    private final GraviteBanner bannerBuilder = new GraviteBanner();

    public void initialize(Application application) {

        // Configure AATKit
        AATKitConfiguration config = new AATKitConfiguration(application);

        if (testMode) {
            if(testBundleId != null) {
                config.setAlternativeBundleId(testBundleId);
                Logger.i("[Gravite] Test Bundle Id is enabled for " + testBundleId);
            }

            if(testAccountId != null) {
                config.setTestModeAccountId(testAccountId);
                Logger.i("[Gravite] Test Account Id is enabled for " + testAccountId);
            }
        }
        applicationContext = application.getApplicationContext();

        Consent consent = new VendorConsent(this);
        config.setConsent(consent);

        // Initialize AATKit with the configured options
        AATKit.init(config);

        // Disable Shake debug mode
        AATKit.disableDebugScreen();

        if(debugMode) {
            AATKit.setLogLevel(Log.VERBOSE);
            Logger.i("[Gravite] Debug mode is enabled");
        }else {
            AATKit.setLogLevel(Log.INFO);
        }
        isGraviteStarted = true;

        Logger.i("[Gravite] GravitePlugin is initialized");
    }

    /**
     * Get the banner loader instance (implements IBackFillBanner).
     *
     * @return this instance for banner loading
     */
    public IBackFillBanner getBannerLoader() {
        return bannerBuilder;
    }

    /**
     * Get the interstitial loader instance (implements IBackFillInterstitial).
     *
     * @return this instance for interstitial loading
     */
    public IBackFillInterstitial getInterstitialLoader() {
        return interstitialBuilder;
    }

    /**
     * Deprecated method to enable debug logging. Should not be used in production.
     * Use 'adb shell setprop log.tag.AATKit V' for logging control.
     *
     * @param isEnabled True to enable debug mode
     */
    @Deprecated(forRemoval = true)
    public static void enableDebug(boolean isEnabled) {
        int logLevel = isEnabled ? Log.DEBUG : Log.INFO;
        AATKit.setLogLevel(logLevel);
    }

    /**
     * Set global targeting parameters for ads.
     *
     * @param targeting Map of targeting information
     */
    @Override
    public void setCustomTargeting(Map<String, List<String>> targeting) {
        if (targeting != null) {
            AATKit.setTargetingInfo(targeting);
        }
    }

    @Override
    public void setCacheSize(int size) {
        Logger.i("[Gravite] Cache Size is changed to " + size);
        bannerBuilder.setCacheSize(size);
    }

    public void setPlacementMapTable(Map<String, String> stroeerToGravite) {
        bannerBuilder.setPlacementMapTable(stroeerToGravite);
        interstitialBuilder.setPlacementMapTable(stroeerToGravite);
    }

    /**
     * Notify the AATKit that the activity has resumed.
     * This should be called from the activity's onResume().
     *
     * @param activity Activity instance
     */
    public void onResume(Activity activity) {
        AATKit.onActivityResume(activity);
    }

    /**
     * Notify the AATKit that the activity has paused.
     * This should be called from the activity's onPause().
     *
     * @param activity Activity instance
     */
    public void onPause(Activity activity) {
        AATKit.onActivityPause(activity);
    }

    public void enableDebugMode() {
        if (isGraviteStarted) {
            Logger.e("[Gravite] Gravite SDK is already initialized. debugMode should be set before initializing Gravite");
            return;
        }

        Logger.i("[Gravite] Debug mode enabled");
        debugMode = true;
    }

    public void enableTestMode(String bundleId, Integer accountId) {
        if (isGraviteStarted) {
            Logger.e("[Gravite] Gravite SDK is already initialized. testMode should be set before initializing Gravite");
            return;
        }

        Logger.i("[Gravite] Test mode enabled");
        testMode = true;
        testBundleId = bundleId;
        testAccountId = accountId;
    }

    public IDebugInfo getDebugInfo() {
        if(isGraviteStarted) {
            return new GraviteDebugInfo(getAdSourceInfo());
        } else {
            return null;
        }
    }


    public String getVersion(){
        return AATKit.getVersion();
    }

    public AdSourceInfo getAdSourceInfo() {
        return new AdSourceInfo(AdSource.Gravite, AATKit.getVersion());
    }

    @NonNull
    @Override
    public NonIABConsent getConsentForNetwork(@NonNull AdNetwork network) {
        return GraviteConsentDecoder.isVendorConsentGiven(applicationContext, network);
    }



    @NonNull
    @Override
    public NonIABConsent getConsentForAddapptr() {
        return NonIABConsent.OBTAINED;
    }
}