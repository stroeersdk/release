package com.stroeer.cmp

import android.view.View
import android.view.ViewGroup
import com.sourcepoint.cmplibrary.NativeMessageController
import com.sourcepoint.cmplibrary.SpClient
import com.sourcepoint.cmplibrary.core.nativemessage.MessageStructure
import com.sourcepoint.cmplibrary.model.ConsentAction
import com.sourcepoint.cmplibrary.model.exposed.SPConsents
import org.json.JSONObject

/**
 * When the consent is loaded or while the consent is loading,
 * the developer can customize the actions
 */
internal class ConsentListener(
    private val listener: IStroeerConsentListener?,
    private val mainViewGroup: ViewGroup?
) : SpClient {
    override fun onUIReady(view: View) {
        listener?.onConsentUIReady(view)
        showMessageWebView(view)
    }

    @Deprecated("onMessageReady callback will be removed in favor of onMessageReady(message: MessageStructure, messageController: NativeMessageController). Currently this callback is disabled.")
    override fun onMessageReady(message: JSONObject) {
        println("message ready")
    }

    override fun onUIFinished(view: View) {
        listener?.onConsentUIFinished(view)
        removeWebView(view)
    }

    override fun onConsentReady(consent: SPConsents) {
        listener?.onConsentReady(consent)
    }

    override fun onError(error: Throwable) {
        listener?.onError(error)
    }

    override fun onAction(view: View, consentAction: ConsentAction): ConsentAction {
        return listener?.onAction(view, consentAction) ?: consentAction
    }

    override fun onNativeMessageReady(
        message: MessageStructure,
        messageController: NativeMessageController
    ) {
    }

    override fun onSpFinished(sPConsents: SPConsents) {
    }

    override fun onNoIntentActivitiesFound(url: String) {
    }

    private fun showMessageWebView(view: View) {
        if (this.isMainViewGroupSet && !this.hasParent(view)) {
            val layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            view.setLayoutParams(layoutParams)
            view.bringToFront()
            view.requestLayout()

            this.mainViewGroup!!.addView(view)
        }
    }

    private fun removeWebView(view: View) {
        if (this.isMainViewGroupSet && this.hasParent(view)) {
            this.mainViewGroup!!.removeView(view)
        }
    }

    private fun hasParent(view: View): Boolean {
        return view.parent != null
    }

    private val isMainViewGroupSet: Boolean
        get() = this.mainViewGroup != null

    override fun onMessageInactivityTimeout() {
    }
}