/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.yieldlove.adIntegration.cmp;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.yieldlove.adIntegration.cmp";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final int VERSION_CODE = 196;
  // Field from default config.
  public static final String VERSION_NAME = "8.3.0";
}
