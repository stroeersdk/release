package com.stroeer.cmp

import android.app.Activity
import android.view.ViewGroup
import com.sourcepoint.cmplibrary.SpConsentLib
import com.sourcepoint.cmplibrary.consent.CustomConsentClient
import com.sourcepoint.cmplibrary.creation.SpConfigDataBuilder
import com.sourcepoint.cmplibrary.creation.makeConsentLib
import com.sourcepoint.cmplibrary.data.network.util.CampaignType
import com.sourcepoint.cmplibrary.model.CampaignsEnv
import com.sourcepoint.cmplibrary.model.MessageLanguage
import com.sourcepoint.cmplibrary.model.PMTab
import com.sourcepoint.cmplibrary.model.exposed.SPConsents
import com.sourcepoint.cmplibrary.util.clearAllData
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.ConfigModule_SourcePoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.collections.toTypedArray

open class StroeerConsent private constructor(private val context: Activity) {
    protected var authId: String? = null
    internal var consentListener: ConsentListener? = null
    protected var language: MessageLanguage? = null
    protected val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    @JvmOverloads
    constructor(context: Activity, mainView: Int, authId: String? = null) : this(context) {
        this.consentListener = ConsentListener(null, context.findViewById<ViewGroup?>(mainView))
        authId?.let{
            this.authId = authId
        }
    }

    constructor(context: Activity, listener: StroeerConsentListener?) : this(context) {
        this.consentListener = ConsentListener(listener, null)
    }

    constructor(context: Activity, listener: StroeerConsentListener?, authId: String?) : this(
        context,
        listener
    ) {
        this.authId = authId
    }

    /**
     * Display Privacy Manager in the language.
     * @param language Language to be displayed
     */
    fun showPrivacyManager(language: MessageLanguage?) {
        this.showPrivacyManager(null, language)
    }

    /**
     * Display Privacy Manager
     * This will use the consent configuration.
     * @param layoutName the layout you want to display
     * @param language Language to be displayed
     */
    /**
     * Display Privacy Manager by default
     * The Privacy Manager will be displayed on the root layer
     * This will use the default language without layout.
     */
    /**
     * Display Privacy Manager on the specific layout.
     * @param layoutName Language to be displayed
     */
    @JvmOverloads
    fun showPrivacyManager(layoutName: String? = null, language: MessageLanguage? = null) {
        this.language = language

        mainScope.launch {
            try {
                val spConfig = askForConfig(layoutName)
                if(spConfig != null) {
                    val consentLib = this@StroeerConsent.buildGDPRConsentLib(spConfig)
                    this@StroeerConsent.tryToShowPrivacyManager(consentLib, spConfig.privacyManagerId)
                }
                else{
                    Logger.e("[StroeerConsent] Error showing Privacy Manager: Configuration is null or not loaded")
                }

            }catch (e: Exception){
                Logger.e("[StroeerConsent] Error showing Privacy Manager: ${e.message}" )
            }
        }
    }

    /**
     * Load Gdpr and display the consent dialog
     * if the active is false, this will not show anything
     *
     * "SOURCEPOINT": {
     * "sourcepointAccountId": "375",
     * "active": false,
     * "propertyId": "11668",
     * "propertyName": "inapp.android.test",
     * "privacyManagerId": "211291"
     * }
     *
     */

    @JvmOverloads
    fun collect(layoutName: String? = null) {
        mainScope.launch {
            try {
                val consentLib = this@StroeerConsent.getGdprLib(layoutName)
                consentLib?.let {
                    this@StroeerConsent.tryToShowMessage(
                        consentLib
                    )
                }
            }catch(e: Exception){
                Logger.e("[StroeerConsent] Error in collect: ${e.message}")
            }

        }
    }

    fun collect(language: MessageLanguage?) {
        this.language = language
        this.collect()
    }

    fun collect(layoutName: String?, language: MessageLanguage?) {
        this.language = language
        this.collect(layoutName)
    }

    suspend fun customConsentTo(
        vendors: MutableCollection<String>,
        categories: MutableCollection<String>,
        legIntCategories: MutableCollection<String>
    ) {
        try{
            val spLib = getGdprLib(null)
            tryToSetCustomConsent(
                vendors,
                categories,
                legIntCategories,
                spLib
            )
        }catch(e: Exception){
            Logger.e("[StroeerConsent] Error in customConsentTo: ${e.message}")
        }
    }

    suspend fun customConsentTo(
        vendors: MutableCollection<String>,
        categories: MutableCollection<String>,
        legIntCategories: MutableCollection<String>,
        customConsentListener: CustomConsentListener
    ) {
        try{
            val consentLib = getGdprLib(null)
            tryToSetCustomConsentWithCallback(
                vendors,
                categories,
                legIntCategories,
                consentLib,
                customConsentListener
            )
        }catch(e: Exception){
            Logger.e("[StroeerConsent] Error in customConsentTo: ${e.message}")
        }
    }

    suspend fun customConsentTo(
        vendors: MutableCollection<String>,
        categories: MutableCollection<String>,
        legIntCategories: MutableCollection<String>,
        onCustomConsentReady: CustomConsentClient
    ) {
        try {
            val spLib = getGdprLib(null)
            tryToSetCustomConsentForUnity(
                vendors,
                categories,
                legIntCategories,
                onCustomConsentReady,
                spLib
            )
        }catch(e: Exception){
            Logger.e("[StroeerConsent] Error in customConsentTo: ${e.message}")
        }
    }

    fun clearConsent() {
        clearAllData()
    }

    private suspend fun askForConfig(layoutName: String?): ConfigModule_SourcePoint? {
        val config = ConfigurationManager.getInstance().getConfigAsync()
        return config?.modules?.sourcePoint?.getSourcePoint()
    }

    private fun buildGDPRConsentLib(config: ConfigModule_SourcePoint): SpConsentLib {
        val builder = SpConfigDataBuilder()
            .addAccountId(config.accountId)
            .addPropertyId(config.propertyId)
            .addPropertyName(config.propertyName)
            .addCampaign(CampaignType.GDPR)
            .addCampaignsEnv(CampaignsEnv.PUBLIC)

        if (this.language != null) {
            builder.addMessageLanguage(this.language!!)
        }

        return makeConsentLib(
            builder.build(),
            this.context,
            this.consentListener!!
        )
    }

    private suspend fun getGdprLib(layoutName: String?): SpConsentLib? {

        try {
            val spConfig = askForConfig(layoutName)
            if(spConfig != null) {
                return buildGDPRConsentLib(spConfig)
            }
            else{
                Logger.e("[StroeerConsent] Error showing Privacy Manager: Configuration is null or not loaded")
            }

        }catch (e: Exception){
            Logger.e("[StroeerConsent] Error showing Privacy Manager: ${e.message}" )
        }

        return null
    }

    private fun tryToShowMessage(consentLib: SpConsentLib?) {
        if (consentLib != null) {
            if (this.authId == null) {
                consentLib.loadMessage()
            } else {
                consentLib.loadMessage(this.authId)
            }
        } else {
            Logger.e("[StroeerConsent] SourcePoint Consent Library is null in tryToShowMessage")
        }
    }

    private fun tryToShowPrivacyManager(consentLib: SpConsentLib?, privacyManagerId: String) {
        if (consentLib != null) {
            consentLib.loadPrivacyManager(privacyManagerId, PMTab.DEFAULT, CampaignType.GDPR)
        } else {
            Logger.e("[StroeerConsent] SourcePoint Consent Library is null in tryToShowPrivacyManager")
        }
    }

    private fun tryToSetCustomConsent(
        vendors: MutableCollection<String>,
        categories: MutableCollection<String>,
        legIntCategories: MutableCollection<String>,
        consentLib: SpConsentLib?
    ) {
        if (consentLib != null) {
            consentLib.customConsentGDPR(
                ArrayList<String>(vendors),
                ArrayList<String>(categories),
                ArrayList<String>(legIntCategories)
            ) { sPConsents: SPConsents? -> Unit }
        } else {
            Logger.e("[StroeerConsent] SourcePoint Consent Library is null in tryToSetCustomConsent")
        }
    }

    private fun tryToSetCustomConsentWithCallback(
        vendors: MutableCollection<String>,
        categories: MutableCollection<String>,
        legIntCategories: MutableCollection<String>,
        consentLib: SpConsentLib?,
        listener: CustomConsentListener
    ) {
        if (consentLib != null) {
            consentLib.customConsentGDPR(
                ArrayList<String>(vendors),
                ArrayList<String>(categories),
                ArrayList<String>(legIntCategories)
            ) { spConsents: SPConsents? ->
                listener.onCustomConsentReady(spConsents)
                Unit
            }
        } else {
            Logger.e("[StroeerConsent] SourcePoint Consent Library is null in tryToSetCustomConsentWithCallback")
        }
    }

    private fun tryToSetCustomConsentForUnity(
        vendors: MutableCollection<String>,
        categories: MutableCollection<String>,
        legIntCategories: MutableCollection<String>,
        onCustomConsentReady: CustomConsentClient,
        consentLib: SpConsentLib?
    ) {
        if (consentLib != null) {
            consentLib.customConsentGDPR(
                vendors.toTypedArray<String>(),
                categories.toTypedArray<String>(),
                legIntCategories.toTypedArray<String>(),
                onCustomConsentReady
            )
        } else {
            Logger.e("[StroeerConsent] SourcePoint Consent Library is null in tryToSetCustomConsentForUnity")
        }
    }
}