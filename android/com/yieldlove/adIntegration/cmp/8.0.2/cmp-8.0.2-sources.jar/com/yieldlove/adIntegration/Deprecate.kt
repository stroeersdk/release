package com.yieldlove.adIntegration

import android.app.Activity
import com.stroeer.cmp.StroeerConsent
import com.stroeer.cmp.StroeerConsentListener

@Deprecated ("Use StroeerConsent from com.stroeer.cmp package instead", ReplaceWith("StroeerConsent"))
class YieldloveConsent : StroeerConsent {

    @JvmOverloads
    constructor(context: Activity, mainView: Int, authId: String? = null) : super(context, mainView, authId)

    constructor(context: Activity, listener: StroeerConsentListener?) : super(context, listener)

    constructor(context: Activity, listener: StroeerConsentListener?, authId: String?) : super( context, listener)
}