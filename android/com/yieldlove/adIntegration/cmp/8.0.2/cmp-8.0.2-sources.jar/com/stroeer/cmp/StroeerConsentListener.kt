package com.stroeer.cmp

open class StroeerConsentListener : IStroeerConsentListener{
    override fun onConsentUIReady(v: android.view.View) {
        // Implementation here
    }

    override fun onConsentUIFinished(v: android.view.View) {
        // Implementation here
    }

    override fun onConsentReady(c: com.sourcepoint.cmplibrary.model.exposed.SPConsents) {
        // Implementation here
    }

    override fun onError(v: Throwable?) {
        // Implementation here
    }

    override fun onAction(
        view: android.view.View,
        consentAction: com.sourcepoint.cmplibrary.model.ConsentAction
    ): com.sourcepoint.cmplibrary.model.ConsentAction {
        // Implementation here
        return consentAction
    }
}