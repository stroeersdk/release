package com.stroeer.cmp

import android.view.View
import com.sourcepoint.cmplibrary.model.ConsentAction
import com.sourcepoint.cmplibrary.model.exposed.SPConsents

interface IStroeerConsentListener {
    fun onConsentUIReady(v: View)
    fun onConsentUIFinished(v: View)
    fun onConsentReady(c: SPConsents)
    fun onError(v: Throwable?)
    fun onAction(view: View, consentAction: ConsentAction): ConsentAction
}
