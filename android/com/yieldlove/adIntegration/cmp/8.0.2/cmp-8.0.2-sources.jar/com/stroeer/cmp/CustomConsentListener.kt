package com.stroeer.cmp

import com.sourcepoint.cmplibrary.model.exposed.SPConsents

interface CustomConsentListener {
    fun onCustomConsentReady(spConsents: SPConsents?)
}