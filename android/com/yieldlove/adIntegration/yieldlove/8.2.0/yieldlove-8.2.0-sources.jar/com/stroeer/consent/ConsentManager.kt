package com.stroeer.consent

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import com.iabtcf.decoder.TCString
import com.stroeer.utilities.logging.Logger

object ConsentManager {

    private const val KEY_TC_STRING = "IABTCF_TCString"
    @Volatile private var prefs: SharedPreferences? = null

    @JvmStatic fun initialize(context: Context) { if (prefs == null) synchronized(this) { if (prefs == null) prefs = PreferenceManager.getDefaultSharedPreferences(context.applicationContext) } }

    @JvmStatic fun getConsent(): String? = prefs?.getString(KEY_TC_STRING, null)

    @JvmStatic fun setConsent(value: String) { prefs?.edit()?.putString(KEY_TC_STRING, value)?.apply() }

    @JvmStatic fun clearConsent() { prefs?.edit()?.clear()?.apply() }

    @JvmStatic @JvmOverloads fun hasVendorConsent(vendorId: Int, consentString: String? = getConsent()): Boolean = try {
        consentString?.isNotEmpty() == true && TCString.decode(consentString).vendorConsent.contains(vendorId)
    } catch (t: Throwable) {
        Logger.e("[ConsentManager] Decode error", t); false
    }
}