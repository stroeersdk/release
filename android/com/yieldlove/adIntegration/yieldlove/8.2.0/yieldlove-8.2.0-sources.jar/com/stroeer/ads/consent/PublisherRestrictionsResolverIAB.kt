package com.stroeer.ads.consent

import android.content.Context
import com.stroeer.ads.consent.ConsentRestrictionType.Companion.from
import org.jetbrains.annotations.TestOnly

class PublisherRestrictionsResolverIAB(applicationContext: Context) :
    IPublisherRestrictionsResolver {
    private var reader: IConsentReader = ConsentReaderIAB(applicationContext)
    private var evaluator: IConsentEvaluator = ConsentEvaluatorIAB(this.reader)
    private val nonFlexiblePurpose1Id = 1

    override fun resolve(vendorId: Int, purposeId: Int): Boolean {
        val type = this.getPublisherPurposeRestriction(vendorId, purposeId)
        return when (type) {
            ConsentRestrictionType.REQUIRE_CONSENT -> this.evaluator.evaluateConsentRequired(
                vendorId,
                purposeId
            )

            ConsentRestrictionType.REQUIRE_LEGITIMATE_INTEREST, ConsentRestrictionType.UNDEFINED -> {
                if (purposeId == this.nonFlexiblePurpose1Id) {
                    return this.evaluator.evaluateConsentRequired(vendorId, purposeId)
                }
                return this.evaluator.evaluateLegitimateInterestRequired(vendorId, purposeId)
            }

            else -> false
        }
    }

    private fun getPublisherPurposeRestriction(
        vendorId: Int,
        purposeId: Int
    ): ConsentRestrictionType {
        val encodedString = this.reader.getPublisherRestrictionsFor(purposeId)
        encodedString?.let{
            if (!encodedString.isEmpty() && encodedString.length >= vendorId) {
                val type = encodedString[this.convertIdToIndex(vendorId)].toString().toInt()
                return from(type)
            }
        }

        return ConsentRestrictionType.UNDEFINED
    }

    private fun convertIdToIndex(vendorId: Int): Int {
        return vendorId - 1
    }

    @TestOnly
    fun setReader(reader : IConsentReader){
        this.reader = reader
    }

    @TestOnly
    fun setEvaluator(evaluator : IConsentEvaluator){
        this.evaluator = evaluator
    }
}

