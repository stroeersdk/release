package com.stroeer.plugins.identity.collectors

import androidx.preference.PreferenceManager
import com.stroeer.plugins.identity.ACollectorWithContext
import java.util.concurrent.CompletableFuture

/**
 * Return GPP SID. Collect from IABGPP_GppSID.
 */
class GppSidCollector : ACollectorWithContext<String?>() {
    override suspend fun  retrieveData(): String? {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        return sharedPreferences.getString(
                GPP_SID_KEY,
                null
            )
    }

    companion object {
        private const val GPP_SID_KEY = "IABGPP_GppSID"
    }
}
