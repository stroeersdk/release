package com.stroeer.plugins.identity.collectors

import android.content.Context
import android.telephony.TelephonyManager
import com.stroeer.plugins.identity.ACollectorWithContext
import java.util.Locale

/**
 * Return country code. Collect from SIM card, Network, or device's default locale.
 */
class CountryCodeCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String {
        var countryCode: String? = null
        // Get the Telephony Manager
        val telephonyManager =
            applicationContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager?

        if (telephonyManager != null) {
            // 1. Try getting country from SIM card
            countryCode = telephonyManager.simCountryIso
            if (!countryCode.isNullOrEmpty()) {
                return countryCode.uppercase(Locale.getDefault()) // Return uppercase ISO country code
            }

            // 2. Try getting country from Network
            countryCode = telephonyManager.networkCountryIso
            if (!countryCode.isNullOrEmpty()) {
                return countryCode.uppercase(Locale.getDefault())
            }
        }

        return Locale.getDefault().country.uppercase(Locale.getDefault())
    }
}
