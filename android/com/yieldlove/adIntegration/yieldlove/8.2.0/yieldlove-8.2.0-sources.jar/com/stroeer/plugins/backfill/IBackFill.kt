package com.stroeer.plugins.backfill

import android.app.Activity
import android.app.Application
import com.stroeer.ads.debugInfo.IDebugInfo
import com.stroeer.ads.formats.AdSourceInfo

interface IBackFill {
    fun initialize(application: Application)
    fun getBannerLoader(): IBackFillBanner?
    fun getInterstitialLoader() : IBackFillInterstitial?
    fun enableDebugMode()
    fun enableTestMode(bundleId: String?, accountId: Int?)
    fun onResume(activity: Activity)
    fun onPause(activity: Activity)
    fun setCustomTargeting(targeting: MutableMap<String, MutableList<String>>)
    fun setCacheSize(size: Int)
    fun setPlacementMapTable(stroeerToGravite: MutableMap<String, String>)
    fun getVersion(): String
    fun getDebugInfo(): IDebugInfo?
    fun getAdSourceInfo(): AdSourceInfo
}