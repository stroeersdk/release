package com.stroeer.ads.bidding.prebid

import android.content.Context
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration

class InterstitialPrebidSdkAdapter(context: Context, adUnitConverter: PrebidAdUnitConverter) :
    APrebidSdkAdapter(context, adUnitConverter) {
    override fun initPrebidAdUnit() {
        super.initPrebidAdUnit()
        adConfig.prebidAdUnit = this.adUnitConverter.convertToPrebidInterstitialAdUnit(adConfig as InterstitialConfiguration)
    }

    override val identifier: String?
        get() = null
}
