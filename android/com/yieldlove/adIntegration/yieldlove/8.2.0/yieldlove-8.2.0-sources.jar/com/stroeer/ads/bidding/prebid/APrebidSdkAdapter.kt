package com.stroeer.ads.bidding.prebid

import android.content.Context
import android.text.TextUtils
import com.stroeer.ads.config.ConfigConstants
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.debugInfo.NetworkDebugInfo
import com.stroeer.ads.debugInfo.SdkType
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.bidding.ISdkAdapter
import com.stroeer.ads.debugInfo.SdkDebugInfo
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.bidding.SdkResultCode
import com.stroeer.utilities.json.JsonPrinter
import com.stroeer.utilities.json.OrtbJsonHelper
import com.stroeer.utilities.json.OrtbJsonHelper.Companion.apply
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.jetbrains.annotations.TestOnly
import org.json.JSONException
import org.json.JSONObject
import org.prebid.mobile.PrebidEventDelegate
import org.prebid.mobile.PrebidMobile
import org.prebid.mobile.ResultCode
import org.prebid.mobile.TargetingParams
import org.prebid.mobile.api.data.BidInfo
import org.prebid.mobile.rendering.bidding.data.bid.BidResponse
import kotlin.coroutines.resume

abstract class APrebidSdkAdapter(protected val context: Context, protected val adUnitConverter: AdUnitConverter) : ISdkAdapter {
    protected lateinit var adConfig : AAdConfiguration

    override suspend fun prepare(){
        ConfigurationManager.getInstance().getConfig()?.common?.androidStoreUrl?.let {
            TargetingParams.setStoreUrl(it)
        }
        ConfigurationManager.getInstance().getConfig()?.common?.androidBundleId?.let {
            TargetingParams.setBundleName(it)
        }

        PrebidMobile.setTimeoutMillis(ConfigurationManager.getInstance().getConfig()?.common?.dfpAdRequestTimeoutMs ?: 3000)
    }

    override suspend fun getBid(adConfig : AAdConfiguration): SdkResult {
        this.adConfig = adConfig
        this.initPrebidAdUnit()
        return if(this.isSdkInitialized()){
                    this.getBidFromPrebid()
                } else {
                    SdkResult(SdkResultCode.NOT_INITIALIZED, null)
                }
    }

    protected suspend fun getBidFromPrebid(): SdkResult {
        try {
            updateDebugInfoForSend()

            if (adConfig.realTimeAuctionEnabled) {
                this.updateContentUrl()

                return suspendCancellableCoroutine { cont ->
                    cont.invokeOnCancellation { cause ->
                        Logger.w("[Prebid] Continuation cancelled : \"${adConfig.adUnitId}\"\n\t$cause\n")
                    }

                    if(!cont.isActive){
                        Logger.e("[Prebid] Prebid result ${adConfig.adUnitId}")
                        return@suspendCancellableCoroutine
                    }

                    val unit = adConfig.prebidAdUnit
                    if (unit == null) {
                        Logger.e("[Prebid] Prebid AdUnit is null. Cannot fetch demand.")
                        cont.resume(SdkResult.FAILED)
                        return@suspendCancellableCoroutine
                    }

                    // create custom targeting
                    val customTargeting = adConfig.customTargeting
                        .takeIf { it.isNotEmpty() } // If not empty
                        ?.entries
                        ?.joinToString(", ") { (k, v) -> "$k=$v" }
                        ?.let { ", $it" }
                        ?: ""

                    // add ad unit
                    unit.impOrtbConfig = getImpSetup(adConfig.adUnitId, customTargeting)

                    unit.fetchDemand { bidInfo: BidInfo ->
                        Logger.i("[Prebid] Prebid result: ${bidInfo.resultCode}")
                        val sdkResult = getSdkResult(bidInfo.resultCode, bidInfo.targetingKeywords)

                        // Add debugInfo
                        updatedDebugInfoForResult(bidInfo.targetingKeywords?.toMutableMap())

                        cont.resume(sdkResult)
                    }
                }
            } else {
                Logger.d("[Prebid] Prebid is skipped due to non-rtaAuction " + adConfig.adUnitId)
                return SdkResult.SKIPPED
            }
        } catch (e: Exception) {
            Logger.e("[Prebid] Exception occurred in getting Prebid bid", e)
            return SdkResult.FAILED
        }
    }

    protected fun updateDebugInfoForSend(){
        if(ConfigurationManager.isInspectionMode) {
            if(adConfig is BannerConfiguration) {
                adConfig.debugInfo?.let {
                    val adConfig = adConfig as BannerConfiguration
                    val sizes = adConfig.availableBannerSizes
                    val formatted = sizes
                        .sortedWith(compareBy({ it.width }, { it.height }))
                        .joinToString(separator = ", ") { "${it.width}x${it.height}" }

                    val prebidDebugInfo = SdkDebugInfo().apply {
                        description = "Send To Prebid"
                        publisherSlotName = adConfig.publisherSlotName
                    }

                    prebidDebugInfo.keyValues =
                        adConfig.customTargeting.toMutableMap()
                    prebidDebugInfo.keyValues?.put(
                        "rtbAuction*",
                        adConfig.realTimeAuctionEnabled.toString()
                    )
                    prebidDebugInfo.keyValues?.put("adUnitID", adConfig.adUnitId)
                    prebidDebugInfo.keyValues?.put("configID", adConfig.configAdSlot?.prebidConfigId)
                    prebidDebugInfo.keyValues?.put("size", formatted)
                    prebidDebugInfo.keyValues?.put("contentUrl", adConfig.contentUrl)
                    adConfig.debugInfo?.sdkDebugInfos!!.add(prebidDebugInfo)
                }
            }
        }
    }

    protected fun updatedDebugInfoForResult(keyValues : MutableMap<String, String?>?, bidResponse : BidResponse? = null){
        if(ConfigurationManager.isInspectionMode) {
            // Add debugInfo
            adConfig.debugInfo?.let {
                val prebidDebugInfo = SdkDebugInfo()
                prebidDebugInfo.publisherSlotName = adConfig.publisherSlotName
                prebidDebugInfo.description = "Received From Prebid"
                prebidDebugInfo.keyValues = keyValues

                bidResponse?.let{
                    var indexer = 1 // just for avoiding duplicate keys
                    val allSeatBids = bidResponse.seatbids
                    for(seatBid in allSeatBids){
                        for(bid in seatBid.bids){
                            @Suppress("SpellCheckingInspection")
                            try {
                                prebidDebugInfo.keyValues?.put("${indexer}__seat", seatBid.seat)
                                prebidDebugInfo.keyValues?.put("${indexer}_adomain", bid.adomain[0])
                                prebidDebugInfo.keyValues?.put("${indexer}_crid", bid.crid)
                                prebidDebugInfo.keyValues?.put("${indexer}_id", bid.id)
                                prebidDebugInfo.keyValues?.put("${indexer}_impid", bid.impId)
                                prebidDebugInfo.keyValues?.put("${indexer}_price", bid.price.toString())
                                prebidDebugInfo.keyValues?.put("${indexer}_size", "${bid.width}x${bid.height}")
                                indexer++
                            }catch(e : Exception){
                                Logger.e("[APrebidSdkAdapter] Failed to add data to the debug information", e)
                            }
                        }
                    }
                }
                it.sdkDebugInfos.add(prebidDebugInfo)
            }
        }
    }

    protected suspend fun isSdkInitialized(): Boolean{
        if (PrebidMobile.isSdkInitialized()) return true
        withTimeoutOrNull(10000) {
            while (!PrebidMobile.isSdkInitialized()) {
                delay(200)
            }
        }

        if(!PrebidMobile.isSdkInitialized()){
            Logger.e("[Prebid] Prebid SDK is not initialized")
        }
        return PrebidMobile.isSdkInitialized()
    }

    protected fun getSdkResult(resultCode: ResultCode, map: Map<String, String?>?): SdkResult {
        val translatedYlKeyValues = HashMap<String, String>()
        PrebidToGAMKeyValueMapper.addPrebidMetadata(translatedYlKeyValues, adConfig.configAdSlot!!.prebidConfigId!!, resultCode)
        PrebidToGAMKeyValueMapper.addBidsIntoAdRequestBuilder(map, translatedYlKeyValues)

        return SdkResult(remapResultCode(resultCode), translatedYlKeyValues)
    }

    protected open fun initPrebidAdUnit(){
        val prebidAccountId = ConfigurationManager.getInstance().getConfig()!!.modules.prebid!!.yieldloveAccountId
        if(prebidAccountId.isNullOrEmpty()) {
            throw IllegalStateException("[APrebidSdkAdapter] Prebid Server Account ID is not set in configuration.")
        }
        PrebidMobile.setPrebidServerAccountId(prebidAccountId)
    }

    private fun remapResultCode(resultCode: ResultCode): SdkResultCode {
        return when (resultCode) {
            ResultCode.SUCCESS -> SdkResultCode.SUCCESS
            ResultCode.TIMEOUT -> SdkResultCode.TIMEOUT
            ResultCode.NO_BIDS -> SdkResultCode.NO_BIDS
            else -> SdkResultCode.FAILED
        }
    }


    protected fun updateContentUrl() {
        val contentUrl = adConfig.contentUrl
        if (TextUtils.isEmpty(contentUrl)) {
            return
        }

        try {
            OrtbJsonHelper.addOrUpdate(contentUrl!!, "app", "content", "url")
            apply()
        } catch (e: Exception) {
            Logger.e("[Prebid] Failed to set setAppContentUrl", e)
        }
    }



    private fun setServerTimeout() {
        // initial timeout
        PrebidMobile.setTimeoutMillis(3_000)
    }

    init {
        this.setServerTimeout()
        this.setCustomHeaders()
        this.initialize()
    }

    @Synchronized
    private fun initialize() {
        initialize(this.context)
    }

    private fun setCustomHeaders() {
        val customHeaders = HashMap<String, String>()
        customHeaders["X-SDK-Version"] = BuildConfig.VERSION_NAME
        customHeaders["X-Bundle"] = this.context.packageName
        PrebidMobile.setCustomHeaders(customHeaders)
    }

    protected fun getPrebidAdCacheIdFromTargeting(keyValuesFromPrebid: MutableMap<String, String>?): String? {
        return keyValuesFromPrebid?.get(PrebidToGAMKeyValueMapper.CustomTargetingMapping.cache_id.ylKey)
    }

    @TestOnly
    fun setConfig(aConfig: AAdConfiguration){
        adConfig = aConfig
    }

    @Suppress("SpellCheckingInspection")
    protected fun getImpSetup(adUnitId: String, customTargeting: String) : String{
        return """
                {
                  "displaymanager": "StroeerSDK",
                  "displaymanagerver": "${BuildConfig.VERSION_NAME}",
                  "ext": {
                    "data": {
                        "adslot": "$adUnitId",
                        "pbadslot": "$adUnitId"
                        $customTargeting
                    }
                  }
                }
                """.trimIndent()
    }

    companion object {
        @JvmStatic
        fun initialize(context: Context){
            PrebidMobile.setCreativeFactoryTimeout(15000)

            // Even if this is called multiple times, the SDK will only be initialized once.
            PrebidMobile.initializeSdk(context, ConfigConstants.PREBID_URL) { status ->
                Logger.i("[Prebid] Prebid SDK initialized with status: $status")
                PrebidMobile.setEventDelegate(prebidEventDelegate)
                OrtbJsonHelper.addOrUpdate(JSONObject(), "ext", "prebid", "cache", "bids")
                TargetingParams.setOmidPartnerName(ConfigConstants.OMID_PARTNER_NAME)
                TargetingParams.setOmidPartnerVersion(ConfigConstants.OMID_PARTNER_VERSION)
            }
        }
        // setEventDelegate is a weak reference, so we need to keep a strong reference to it
        private val prebidEventDelegate: PrebidEventDelegate = PrebidEventDelegate { request, response ->
            try {
                if (ConfigurationManager.isDebugMode) {
                    CoroutineScope(Dispatchers.IO).launch {
                        val nInfo = NetworkDebugInfo(request.optString("id", "unknown"))
                        try {
                            DebugInfoManager.getInstance().addNetworkDebugInfo(nInfo)
                            nInfo.sdkType = SdkType.Prebid
                            nInfo.request = request
                            nInfo.response = response
                            nInfo.requestString = JsonPrinter.print(request, "adm")
                            nInfo.responseString = JsonPrinter.print(response, "adm")

                            Logger.d("[PREBID-REQUEST]\n${nInfo.requestString}")
                            Logger.d("[PREBID-RESPONSE]\n${nInfo.responseString}")

                        }catch (exception : Exception){
                            Logger.e("[Prebid] Failed to put network info", exception)
                        }
                    }
                }
            } catch (e: JSONException) {
                Logger.e("[Prebid] Failed to log Prebid event", e)
            }
        }
    }
}
