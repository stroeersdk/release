package com.stroeer.plugins.identity.collectors

/**
 * Return IPv6 address
 */
class IPv6Collector : IPv4Collector() {
    override val checkURL: String = "https://api64.ipify.org"

    override fun getWifiIPAddress(): String? {
        return getNetworkIPAddress( true)
    }

    override val mobileIPAddress: String?
        get() = getNetworkIPAddress(true)

    override fun isValidFormat(ip: String): Boolean {
        return ip.matches("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b".toRegex())
    }
}
