package com.stroeer.plugins.identity.collectors

import com.stroeer.plugins.identity.IIdentityCollector

/**
 * Return maid type, Google is gaid. Constant value.
 */
class MaidTypeCollector : IIdentityCollector<String?> {
    override suspend fun retrieveData(): String? {
        return "gaid"
    }
}
