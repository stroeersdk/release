package com.stroeer.plugins.identity.id5.objects

/**
 * "ext": {
 * *         "linkType": 0
 * *     }
 */
@Suppress("ClassName")
class ID5Data_Ext {
    var linkType: Int = 0
}
