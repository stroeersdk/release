package com.stroeer.plugins.backfill.gravite

import android.app.Activity
import android.app.Application
import com.stroeer.ads.debugInfo.IDebugInfo
import com.stroeer.ads.formats.AdSourceInfo
import com.stroeer.plugins.backfill.IBackFill
import com.stroeer.plugins.backfill.IBackFillBanner
import com.stroeer.plugins.backfill.IBackFillInterstitial
import com.stroeer.plugins.backfill.IInitializationCallback
import com.stroeer.plugins.backfill.error.DirectCallToGravite
import com.stroeer.utilities.logging.Logger
import java.util.HashMap

/**
 * Singleton class to manage the integration and lifecycle of the Gravite SDK.
 */
class GraviteLoader  // Private constructor to enforce singleton pattern
private constructor() {
    private var graviteWrapperInstance: IBackFill? = null

    private var debugMode = false
    private var testMode = false
    private var testBundleId: String? = null
    private var testAccountId: Int? = null

    /**
     * Checks if Gravite SDK is started.
     * 
     * @return True if Gravite is started, false otherwise.
     */
    var isGraviteStarted: Boolean = false
        private set
    private var forceToExecute = false
    private var directGraviteCall = false
    private var cacheSize = 1
    private var stroeerToGravitePlacementMapTable: MutableMap<String, String>? = null


    /**
     * Initializes the Gravite SDK.
     * 
     * @param application The application instance.
     * @param callback    The callback to notify initialization status.
     */
    fun initialize(application: Application, callback: IInitializationCallback?) {
        try {
            // Check if the Gravite SDK class is present
            Class.forName("com.intentsoftware.addapptr.AATKit")
        } catch (e: Exception) {
            Logger.i("[Gravite] Gravite is not found")
            returnToCallback(callback, false)
            return
        }

        Logger.i("[Gravite] Gravite is found")

        // Load the Gravite wrapper class dynamically
        try {
            @Suppress("UNCHECKED_CAST")
            val graviteClass =
                Class.forName("com.stroeer.gravite.GraviteWrapper") as Class<IBackFill>
            graviteWrapperInstance = graviteClass.getDeclaredConstructor().newInstance()
        } catch (_ : Exception) {
            Logger.i("[Gravite] GravitePlugin is not found")
            returnToCallback(callback, false)
            return
        }

        if( graviteWrapperInstance == null){
            returnToCallback(callback, false)
            return
        }

        graviteWrapperInstance?.let { it->
            // Enable debug mode if configured
            if (debugMode) {
                it.enableDebugMode()
            }

            // Enable test mode if configured
            if (testMode) {
                it.enableTestMode(testBundleId, testAccountId)
            }

            // Initialize the Gravite SDK
            it.initialize(application)

            // Additional settings.
            it.setCacheSize(cacheSize)
            stroeerToGravitePlacementMapTable?.let { table ->
                it.setPlacementMapTable(table)
            }

            isGraviteStarted = true
            returnToCallback(callback, true)
        }
    }

    /**
     * Helper method to return the initialization status to the callback.
     * 
     * @param callback      The initialization callback.
     * @param isInitialized True if initialization was successful, false otherwise.
     */
    private fun returnToCallback(callback: IInitializationCallback?, isInitialized: Boolean) {
        callback?.onInitialized(isInitialized)
    }

    /**
     * Enables debug mode for the Gravite SDK.
     */
    fun enableDebugMode() {
        debugMode = true
    }

    /**
     * Enables test mode for the Gravite SDK.
     * 
     * @param bundleId      The test bundle ID.
     * @param accountId     The test account ID.
     * @param forceToExecute If true, forces the SDK to execute in test mode.
     */
    fun enableTestMode(bundleId: String?, accountId: Int?, forceToExecute: Boolean) {
        testMode = true
        testBundleId = bundleId
        testAccountId = accountId
        this.forceToExecute = forceToExecute
    }

    /**
     * Enables direct calls to Gravite, bypassing normal bidding flow.
     */
    fun enableDirectGraviteCall() {
        this.directGraviteCall = true
    }

    /**
     * Handles activity lifecycle onResume event.
     * 
     * @param activity The current activity.
     */
    fun onResume(activity: Activity) {
        if (isGraviteStarted) {
            graviteWrapperInstance?.onResume(activity)
        }
    }

    /**
     * Handles activity lifecycle onPause event.
     * 
     * @param activity The current activity.
     */
    fun onPause(activity: Activity) {
        if (isGraviteStarted) {
            graviteWrapperInstance?.onPause(activity)
        }
    }

    val bannerLoader: IBackFillBanner?
        /**
         * Returns the banner loader instance from Gravite.
         * 
         * @return The banner loader instance, or null if Gravite is not started.
         */
        get() {
            if (isGraviteStarted) {
                return graviteWrapperInstance?.getBannerLoader()
            }
            return null
        }

    val interstitialLoader: IBackFillInterstitial?
        /**
         * Returns the interstitial loader instance from Gravite.
         * 
         * @return The interstitial loader instance, or null if Gravite is not started.
         */
        get() {
            if (isGraviteStarted) {
                return graviteWrapperInstance?.getInterstitialLoader()
            }
            return null
        }

    /**
     * Checks if force execution mode is enabled.
     * 
     * @return True if force execution is enabled and Gravite is started, false otherwise.
     */
    fun isForceToExecute(): Boolean {
        return isGraviteStarted && forceToExecute
    }

    /**
     * Checks if direct calls to Gravite are enabled.
     * 
     * @return True if direct calls are enabled, false otherwise.
     */
    fun isDirectGraviteCall(): Boolean {
        return isGraviteStarted && directGraviteCall
    }

    /**
     * Throws a DirectCallToGravite exception if a direct call to Gravite is detected.
     * 
     * @throws DirectCallToGravite if the method is invoked directly without proper setup or validation.
     */
    fun throwExceptionIfDirectGraviteCall() {
        if (isDirectGraviteCall()) {
            try {
                throw DirectCallToGravite()
            } catch (e: DirectCallToGravite) {
                throw e
            }
        }
    }

    /**
     * Sets the cache size for the current instance.
     * This method allows dynamic adjustment of the cache size based on application requirements.
     * 
     * @param cacheSize The size to set for the cache.
     */
    fun setCacheSize(cacheSize: Int) {
        this.cacheSize = cacheSize
    }


    /**
     * Sets the mapping table between Stroeer and Gravite placements
     * 
     * @param stroeerToGravite A map containing the mapping of Stroeer placements to Gravite placements.
     */
    fun setPlacementMapTable(stroeerToGravite: MutableMap<String, String>) {
        // Build a string representation of the mapping table for logging purposes
        val sb = StringBuilder()
        for (entry in stroeerToGravite.entries) {
            sb.append(entry.key)
                .append(" : ")
                .append(entry.value)
                .append("\n")
        }

        Logger.d("[Gravite] Placement Map Table: \n$sb")
        stroeerToGravitePlacementMapTable = stroeerToGravite
    }

    fun getPlacementConverted(placement: String?): String? {
        stroeerToGravitePlacementMapTable?.let{
            val converted = it[placement]
            if (converted != null) {
                return converted
            }
        }
        return placement
    }


    private val customTargeting: MutableMap<String, MutableList<String>> =
        HashMap<String, MutableList<String>>()

    fun setCustomTargeting(targeting: Map<String, List<String>>?) {

        // If Gravite isn't ready or wrapper missing, do nothing.
        if (!isGraviteStarted || graviteWrapperInstance == null) {
            return

        }

        // If caller passes null or empty, do nothing.
        if (targeting.isNullOrEmpty()) {
            return
        }

        for ((key, values) in targeting) {

            val newValues: MutableList<String> = values.toMutableList()

            val unique = LinkedHashSet<String>()
            // Get or create current list for this key
            val existing = customTargeting[key]
            if (existing != null) {
                unique.addAll(existing)
            }

            for (v in newValues) {
                if (v.isNotEmpty()) {
                    unique.add(v)
                }
            }

            customTargeting[key] = ArrayList(unique)
        }

        // Push a defensive copy to Gravite so external code can't mutate our map.
        graviteWrapperInstance?.setCustomTargeting(HashMap(customTargeting))

    }

    val version: String?
        /**
         * Retrieves the version of the Gravite SDK if it is initialized.
         * 
         * @return The version of the Gravite SDK as a String. Returns "Unknown" if the Gravite SDK has not been started.
         */
        get() {
            return if (isGraviteStarted) {
                graviteWrapperInstance?.getVersion()
            } else {
                "Unknown"
            }
        }

    val adSource: AdSourceInfo?
        /**
         * Creates and returns an AdSourceInfo object with the Gravite ad source and its version.
         * 
         * @return An AdSourceInfo object containing the ad source and version information.
         */
        get() = graviteWrapperInstance!!.getAdSourceInfo()

    val debugInfo: IDebugInfo?
        get() = graviteWrapperInstance!!.getDebugInfo()

    companion object {
        @JvmStatic
        fun getInstance(): GraviteLoader {
            instance?.let { return it }
            synchronized(this) {
                if (instance == null) {
                    instance = GraviteLoader()
                }
                return instance!!
            }
        }

        private var instance : GraviteLoader? = null
    }
}
