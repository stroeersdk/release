package com.stroeer.ads.bidding.prebid

import android.webkit.WebView

object HTMLInjector {
    fun injectImpressionAndClickTracking() : String{
        return  """
            (function() {
              try {
                if (window.__stroeerInjected) { return; }
                window.__stroeerInjected = true;

                function safeCall(fn) {
                  try { fn(); } catch (e) {}
                }

                function reportClick(url) {
                  safeCall(function() {
                    if (!url) { url = ''; }
                    if (window.StroeerBridge && window.StroeerBridge.onClick) { window.StroeerBridge.onClick(String(url)); }
                  });
                }

                function hookWindow(win) {
                  safeCall(function() {
                    if (!win || win.__stroeerWinHooked) { return; }
                    win.__stroeerWinHooked = true;

                    safeCall(function() {
                      var origOpen = win.open;
                      win.open = function(u) {
                        reportClick(u);
                        return null;
                      };
                      win.open.toString = function() { return String(origOpen); };
                    });

                    safeCall(function() {
                      if (win.location && win.location.assign) {
                        var origAssign = win.location.assign.bind(win.location);
                        win.location.assign = function(u) { reportClick(u); };
                        win.location.assign.toString = function() { return String(origAssign); };
                      }
                    });

                    safeCall(function() {
                      if (win.location && win.location.replace) {
                        var origReplace = win.location.replace.bind(win.location);
                        win.location.replace = function(u) { reportClick(u); };
                        win.location.replace.toString = function() { return String(origReplace); };
                      }
                    });

                    safeCall(function() {
                      win.addEventListener('click', function(ev) {
                        try {
                          var a = ev.target && ev.target.closest ? ev.target.closest('a') : null;
                          var href = a && a.href ? a.href : '';
                          if (href) { reportClick(href); }
                        } catch (e) {}
                      }, true);
                    });
                  });
                }

                function hookSameOriginFrames() {
                  safeCall(function() {
                    hookWindow(window);
                    var frames = document.querySelectorAll('iframe');
                    for (var i = 0; i < frames.length; i++) {
                      var f = frames[i];
                      safeCall(function() {
                        if (!f || !f.contentWindow) { return; }
                        hookWindow(f.contentWindow);
                      });
                    }
                  });
                }

                function observeVisibility() {
                  safeCall(function() {
                    if (!('IntersectionObserver' in window)) { sendImpressionOnce(); return; }
                    var target = document.body;
                    if (!target) { sendImpressionOnce(); return; }
                    var obs = new IntersectionObserver(function(entries) {
                      safeCall(function() {
                        for (var i = 0; i < entries.length; i++) {
                          if (entries[i].isIntersecting && entries[i].intersectionRatio > 0) {
                            sendImpressionOnce();
                            obs.disconnect();
                            break;
                          }
                        }
                      });
                    }, { threshold: [0.01] });
                    obs.observe(target);
                  });
                }

                observeVisibility();
                hookSameOriginFrames();
                setInterval(hookSameOriginFrames, 500);
              } catch (e) {}
            })();
        """.trimIndent()
    }

    fun wrapHtml(inner: String, gen: Int, w: Int, h: Int): String {
        return """
            <!doctype html>
            <html>
              <head>
                <meta charset="utf-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
                <style>
                  html, body { margin:0; padding:0; background:transparent; width:100%; height:100%; overflow:hidden; }
                  body { display:flex; justify-content:center; align-items:flex-start; }
                  /* Fixed-size slot that becomes the positioning root for "position:absolute; left:0; top:0" creatives */
                  #slot { position:relative; width:${w}px; height:${h}px; margin:0 auto; overflow:hidden; }
                </style>
                <script>
                  (function() {
                    try {
                      var gen = $gen;
                      function pingReady() {
                        try { if (window.StroeerBridge && window.StroeerBridge.onReady) { window.StroeerBridge.onReady(gen); } } catch (e) {}
                      }

                      function reportClick(u) {
                        try { if (window.StroeerBridge && window.StroeerBridge.onClick) { window.StroeerBridge.onClick(String(u || '')); } } catch (e) {}
                      }

                      try {
                        var origOpen = window.open;
                        window.open = function(u) { reportClick(u); return null; };
                        window.open.toString = function() { return String(origOpen); };
                      } catch (e) {}

                      try {
                        if (window.location && window.location.assign) {
                          var origAssign = window.location.assign.bind(window.location);
                          window.location.assign = function(u) { reportClick(u); };
                          window.location.assign.toString = function() { return String(origAssign); };
                        }
                      } catch (e) {}

                      try {
                        if (window.location && window.location.replace) {
                          var origReplace = window.location.replace.bind(window.location);
                          window.location.replace = function(u) { reportClick(u); };
                          window.location.replace.toString = function() { return String(origReplace); };
                        }
                      } catch (e) {}

                      if (document.readyState === 'interactive' || document.readyState === 'complete') {
                        setTimeout(pingReady, 0);
                      } else {
                        document.addEventListener('DOMContentLoaded', function() { pingReady(); }, { once:true });
                      }
                      window.addEventListener('load', function() { pingReady(); }, { once:true });
                      setTimeout(pingReady, 50);
                      setTimeout(pingReady, 250);
                    } catch (e) {}
                  })();
                </script>
              </head>
              <body>
                <div id="slot">$inner</div>
              </body>
            </html>
        """.trimIndent()
    }
}