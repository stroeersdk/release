package com.stroeer.plugins.identity.objects

class IdentityCustomInfo {
    var email: String? = null
    var phone: String? = null
    var puid: String? = null
    var regionCode: String? = null
    var cityCode: String? = null
}
