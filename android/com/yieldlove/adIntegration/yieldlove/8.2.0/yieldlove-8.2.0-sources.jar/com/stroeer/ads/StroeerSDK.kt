package com.stroeer.ads

import android.content.Context
import com.stroeer.ads.bidding.gam.GlobalGamManager
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.IConfigurationListener
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.debugInfo.admin.AdminHttpServer
import com.stroeer.ads.exceptions.MissingApplicationNameException
import com.stroeer.ads.bidding.prebid.APrebidSdkAdapter
import com.stroeer.consent.ConsentManager
import com.stroeer.plugins.backfill.gravite.GraviteLoader
import com.stroeer.plugins.identity.IdentityManager
import com.stroeer.utilities.json.OrtbJsonHelper
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import kotlin.collections.forEach

open class StroeerSDK protected constructor() {
    init {
        try {
            val array = JSONArray()
            array.put(BuildConfig.VERSION_NAME)
            OrtbJsonHelper.addOrUpdate(array, "app", "ext", "data", "androidYlSdkVersion")
            OrtbJsonHelper.apply()
        } catch (e: Exception) {
            Logger.e("[StroeerSDK] Failed to set global ORTB config", e)
        }
    }


    companion object {
        @Volatile
        var instance: StroeerSDK = StroeerSDK()

        /**
         * Set Application name.
         * Publisher should know this, Stroeer server distinguishes the applications
         * Example app name is appDpfTest
         * @param applicationName Application Name
         */
        @JvmStatic
        fun setApplicationName(applicationContext: Context, applicationName: String) {
            Logger.initialize(applicationContext)
            APrebidSdkAdapter.initialize(applicationContext)

            DebugInfoManager.applyDebugModeIfNeeded()

            if (applicationName.isEmpty()) {
                throw MissingApplicationNameException()
            }

            if (ConfigurationManager.isDebugBuild) {
                Logger.e("[ConfigurationManager] This application uses the debug build of StroeerSDK. Please review the build settings")
            }

            Logger.i("StroeerSDK Version: ${ConfigurationManager.version}")

            ConfigurationManager.getInstance().initialize(applicationContext,applicationName,
                object : IConfigurationListener {
                    override fun onSuccess() {
                        IdentityManager.instance.initialize(applicationContext, null)
                    }

                    override fun onFailed() {
                        Logger.e("[StroeerSDK] ConfigurationManager failed to load configuration")
                    }
                })

            ConsentManager.initialize(applicationContext)
            AdminHttpServer.launch(applicationContext)
        }

        @JvmStatic
        fun enableDebugMode() {
            contextCheck()
            ConfigurationManager.enableDebugMode()

        }

        @JvmStatic
        fun enableInspectionMode() {
            contextCheck()
            ConfigurationManager.enableInspectionMode()
        }

        private fun contextCheck(){
            if(ConfigurationManager.getInstance().applicationContext == null){
                Logger.e("[StroeerSDK] Inspection mode should be enabled after setApplicationName is called. SDK will work anyway, but some feature may not work properly")
            }
        }

        @JvmStatic
        @Synchronized
        fun setGlobalCustomTargeting(targeting: Map<String, List<String>>) {
            try {
                if (targeting.isEmpty()) {
                    return
                }

                val graviteTargeting = mutableMapOf<String, List<String>>()

                for ((key, rawValues) in targeting) {
                    val values = rawValues
                        .map { it.trim() }
                        .filter { it.isNotEmpty() }
                        .distinct()

                    if (values.isEmpty()) {
                        continue
                    }

                    when (key) {
                        "context" -> {
                            OrtbJsonHelper.addOrUpdate(createDataForRequest("context", values), "app", "content", "data", )

                            // For GAM
                            GlobalGamManager.adRequestBuilder.addCustomTargeting("context_keyword", values)

                            // Gravite
                            graviteTargeting["context_keyword"] = values
                        }

                        "user" -> {
                            // For Prebid
                            OrtbJsonHelper.addOrUpdate(createDataForRequest("interests", values), "user", "data" )

                            // For GAM
                            GlobalGamManager.adRequestBuilder.addCustomTargeting("user_keyword", values)

                            // Gravite
                            graviteTargeting["user_keyword"] = values
                        }

                        else -> {
                            // For GAM
                            GlobalGamManager.adRequestBuilder.addCustomTargeting(key, values)

                            // For Prebid -- PBS may not accept this structure depending on the key / placement
                            OrtbJsonHelper.addOrUpdate(JSONArray(values), "ext", "data", key)

                            // Gravite
                            graviteTargeting[key] = values
                        }
                    }
                }

                if (graviteTargeting.isNotEmpty()) {
                    GraviteLoader.getInstance().setCustomTargeting(graviteTargeting)
                }
            } catch (e: Exception) {
                Logger.e("[StroeerSDK] Failed to set custom targeting", e)
            }
        }

        private fun createDataForRequest(name: String, values : List<String>) : JSONArray{
            val segmentArray = JSONArray().apply {
                values.forEach { value ->
                    put(JSONObject().put("value", value))
                }
            }

            val dataObject = JSONObject().apply {
                put("name", name)
                put("segment", segmentArray)
            }

            return JSONArray().apply {
                put(dataObject)
            }
        }

        @Deprecated(
            message = "Use setGlobalCustomTargeting(targeting: Map<String, List<String>>) instead.",
            replaceWith = ReplaceWith("setGlobalCustomTargeting(mapOf(\"user_keyword\" to targeting))")
        )
        @JvmStatic
        fun setUserTargeting(targeting: List<String>) {
            setGlobalCustomTargeting(mapOf("user_keyword" to targeting))
        }

        @Deprecated(
            message = "Use setGlobalCustomTargeting(targeting: Map<String, List<String>>) instead.",
            replaceWith = ReplaceWith("setGlobalCustomTargeting(targeting)")
        )
        @JvmStatic
        @Synchronized
        fun setCustomTargeting(targeting: MutableMap<String, MutableList<String>>) {
            setGlobalCustomTargeting(targeting)
        }

        @Deprecated(
            message = "Use setGlobalCustomTargeting(targeting: Map<String, List<String>>) instead.",
            replaceWith = ReplaceWith(
                "setGlobalCustomTargeting(mapOf(\"context_keyword\" to targeting))"
            )
        )
        @JvmStatic
        fun setContextTargeting(targeting: List<String>) {
            setGlobalCustomTargeting(mapOf("context_keyword" to targeting))
        }

        @Deprecated(
            message = "Use setGlobalCustomTargeting(targeting: Map<String, List<String>>) instead.",
            replaceWith = ReplaceWith("setGlobalCustomTargeting(targeting)")
        )
        @JvmStatic
        @Synchronized
        fun setContextDataTargeting(targeting: MutableMap<String, MutableList<String>>) {
            setGlobalCustomTargeting(targeting)
        }
    }
}
