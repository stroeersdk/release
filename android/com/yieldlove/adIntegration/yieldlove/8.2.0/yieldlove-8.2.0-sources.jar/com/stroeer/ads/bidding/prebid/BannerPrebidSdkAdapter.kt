package com.stroeer.ads.bidding.prebid

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.view.View
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.admanager.AdManagerAdView
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.exceptions.ContextException
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.AdCategory
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.formats.banner.IBannerListenerRunner
import com.stroeer.ads.reporting.events.GamRespondedSuccessfully
import com.stroeer.ads.reporting.events.RequestFinished
import com.stroeer.ads.debugInfo.SdkDebugInfo
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.bidding.SdkResultCode
import com.stroeer.utilities.ui.SizeUtils
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.jetbrains.annotations.TestOnly
import org.prebid.mobile.PrebidMobile
import org.prebid.mobile.ResultCode
import org.prebid.mobile.api.exceptions.AdException
import org.prebid.mobile.api.rendering.BannerView
import org.prebid.mobile.api.rendering.listeners.BannerViewListener
import org.prebid.mobile.rendering.bidding.data.bid.Bid
import org.prebid.mobile.rendering.bidding.interfaces.BannerEventHandler
import org.prebid.mobile.rendering.bidding.listeners.BannerEventListener
import java.lang.ref.WeakReference
import kotlin.coroutines.resume

class BannerPrebidSdkAdapter(context: Context, adUnitConverter: AdUnitConverter) : APrebidSdkAdapter(context, adUnitConverter) {

    override var identifier: String? = null
        private set

    private var prebidAdSize: AdSize? = null
    private var activityCallbacks: Application.ActivityLifecycleCallbacks? = null
    private var watchedActivityRef: WeakReference<Activity>? = null
    private var watchedAppRef: WeakReference<Application>? = null
    private var detachListenerRef: WeakReference<View.OnAttachStateChangeListener>? = null

    override suspend fun getBid(adConfig: AAdConfiguration): SdkResult {

        if (!isSdkInitialized()) {
            return SdkResult.FAILED
        }

        if (adConfig !is BannerConfiguration) {
            throw IllegalArgumentException("[BannerPrebidSdkAdapter] Invalid configuration type. Expected BannerConfiguration but got " + adConfig::class.java.simpleName)
        }

        this.adConfig = adConfig

        initPrebidAdUnit()
        updateContentUrl()
        updateDebugInfoForSend()

        var sdkResult = SdkResult.SKIPPED
        return withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                if (adConfig.activityContext == null) {
                    cont.resume(SdkResult.FAILED)
                    return@suspendCancellableCoroutine
                }

                adConfig.prebidBannerView = PrebidBannerView(adConfig.activityContext!!, adConfig.configAdSlot!!.prebidConfigId!!, object : BannerEventHandler {

                    override fun getAdSizeArray(): Array<out org.prebid.mobile.AdSize?> {
                        val sizes = adConfig.availableBannerSizes.map { size ->
                            org.prebid.mobile.AdSize(size.width, size.height)
                        }
                        return sizes.toTypedArray()
                    }

                    override fun setBannerEventListener(bannerViewListener: BannerEventListener) {
                        adConfig.prebidEventHandler = bannerViewListener
                    }

                    override fun requestAdWithBid(bid: Bid?) {
                        Logger.d("[BannerPrebidSdkAdapter] requestAdWithBid is called - ${adConfig.publisherSlotName}")
                        sdkResult = renderBidInPrebidHtmlBannerView(adConfig, bid)
                        cont.resume(sdkResult)
                    }

                    override fun trackImpression() {
                    }

                    override fun destroy() {
                        Logger.d("[BannerPrebidSdkAdapter] destroy is called - ${adConfig.publisherSlotName}")
                        unregisterActivityWatcher()
                        if (cont.isActive) {
                            cont.resume(SdkResult.NOT_AVAILABLE)
                        }
                    }
                })

                adConfig.prebidBannerView?.pbAdSlot = adConfig.adUnitId

                // create custom targeting
                val customTargeting = adConfig.customTargeting
                    .takeIf { it.isNotEmpty() } // If not empty
                    ?.entries
                    ?.joinToString(", ") { (k, v) -> "$k=$v" }
                    ?.let { ", $it" }
                    ?: ""

                // update imp json
                adConfig.prebidBannerView?.impOrtbConfig = getImpSetup(adConfig.adUnitId, customTargeting)

                val publisherSlotName = adConfig.publisherSlotName
                val weakListener = WeakReference(adConfig.userListener)
                val weakConfig = WeakReference(adConfig)
                val weakView = WeakReference(adConfig.bannerView)

                adConfig.prebidBannerView?.setBannerListener(object : BannerViewListener {

                    override fun onAdLoaded(bannerView: BannerView?) {
                        Logger.i("[Prebid] onAdLoaded is called - ${adConfig.publisherSlotName}")
                        try {
                            weakConfig.get()?.session?.recordEvent(GamRespondedSuccessfully())
                            Logger.d("[Prebid] The size = ${weakConfig.get()?.adSize?.width} x ${weakConfig.get()?.adSize?.height} - $publisherSlotName")
                            weakConfig.get()?.let { it.session?.recordEvent(RequestFinished()); DebugInfoManager.updateServeTime(it) }
                            weakConfig.get()?.sessionEnd()
                            weakConfig.get()?.setReady()
                            weakView.get()?.addDebugLabel()
                            weakListener.get()?.onAdLoaded(weakView.get())
                        } catch (ex: RuntimeException) {
                            Logger.e("[Prebid] Exception thrown during onAdLoaded callback - $publisherSlotName", ex)
                        }
                    }

                    override fun onAdFailed(bannerView: BannerView?, exception: AdException?) {
                        Logger.i("[Prebid] onAdFailed is called - ${adConfig.publisherSlotName} - ${exception?.message}")
                        sdkResult.resultCode = SdkResultCode.FAILED
                        sdkResult.errorMessage = exception?.message
                        updateDebugInfoForFail(mutableMapOf<String, String?>().apply { put("failed", exception?.message) })
                        weakView.get()?.addDebugLabel()
                    }

                    override fun onAdDisplayed(bannerView: BannerView?) {
                        Logger.i("[Prebid] onAdDisplayed (onAdImpression) is called - ${adConfig.publisherSlotName}")
                        try {
                            adConfig.userListener?.onAdImpression(adConfig.bannerView)
                        } catch (e: Exception) {
                            Logger.e("[Prebid] Exception is thrown during onAdImpression callback. - ${adConfig.publisherSlotName}", e)
                        }
                    }

                    override fun onAdClicked(bannerView: BannerView?) {
                        Logger.i("[Prebid] onAdClicked is called - ${adConfig.publisherSlotName}")
                        try {
                            adConfig.userListener?.onAdClicked(adConfig.bannerView)
                        } catch (e: Exception) {
                            Logger.e("[Prebid] Exception is thrown during onAdClicked callback. - ${adConfig.publisherSlotName}", e)
                        }
                    }

                    override fun onAdClosed(bannerView: BannerView?) {
                        Logger.i("[Prebid] onAdClosed is called - ${adConfig.publisherSlotName}")
                        try {
                            adConfig.userListener?.onAdClosed(adConfig.bannerView)
                        } catch (e: Exception) {
                            Logger.e("[Prebid] Exception is thrown during onAdClosed callback. - ${adConfig.publisherSlotName}", e)
                        }
                    }
                })

                Logger.d("[BannerPrebidSdkAdapter] Prebid loadAd is called - ${adConfig.publisherSlotName}")
                adConfig.prebidBannerView?.loadAd()

                SdkResult(sdkResult.resultCode, sdkResult.keyValues)
            }
        }
    }

    fun createAndLoadPrebidHtmlBannerView(adConfig: BannerConfiguration) {

        val publisherSlotName = adConfig.publisherSlotName
        val weakListener = WeakReference(adConfig.userListener)
        val weakConfig = WeakReference(adConfig)
        val weakView = WeakReference(adConfig.bannerView)

        adConfig.prebidHtmlBannerView = PrebidHtmlBannerView(adConfig.activityContext!!)
        adConfig.adSize?.let {size ->
            adConfig.prebidHtmlBannerView?.setAdSize(
                size.width,
                size.height
            )
        }
        adConfig.prebidHtmlBannerView?.setListener(object : IBannerListenerRunner {

            override fun onAdClosed() {
                Logger.i("[PrebidHtml] onAdClosed is called - $publisherSlotName")
                try {
                    weakListener.get()?.onAdClosed(weakView.get())
                } catch (e: Exception) {
                    Logger.e("[PrebidHtml] Exception during onAdClosed callback - $publisherSlotName", e)
                }
            }

            override fun onAdFailedToLoad(error: StroeerException) {
                Logger.i("[PrebidHtml] onAdFailedToLoad is called - $publisherSlotName - ${error.message}")
                updateDebugInfoForFail(mutableMapOf<String, String?>().apply { put("failed", error.message) })
                weakView.get()?.addDebugLabel()
            }

            override fun onAdOpened() {
                Logger.i("[PrebidHtml] onAdOpened is called - $publisherSlotName")
            }

            override fun onAdLoaded() {
                Logger.i("[PrebidHtml] onAdLoaded is called - $publisherSlotName")
                try {
                    weakConfig.get()?.session?.recordEvent(GamRespondedSuccessfully())
                    weakConfig.get()?.let { it.session?.recordEvent(RequestFinished()); DebugInfoManager.updateServeTime(it) }
                    weakConfig.get()?.sessionEnd()
                    weakConfig.get()?.setReady()
                    weakView.get()?.addDebugLabel()
                    weakListener.get()?.onAdLoaded(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e("[PrebidHtml] Exception during onAdLoaded callback - $publisherSlotName", ex)
                }
            }

            override fun onAdClicked() {
                Logger.i("[PrebidHtml] onAdClicked is called - $publisherSlotName")
                try {
                    weakListener.get()?.onAdClicked(weakView.get())
                } catch (e: Exception) {
                    Logger.e("[PrebidHtml] Exception during onAdClicked callback - $publisherSlotName", e)
                }
            }

            override fun onAdImpression() {
                Logger.i("[PrebidHtml] onAdImpression is called - $publisherSlotName")
                try {
                    weakView.get()?.getBuilder()?.scheduleRefresh()
                    weakListener.get()?.onAdImpression(weakView.get())
                } catch (e: Exception) {
                    Logger.e("[PrebidHtml] Exception during onAdImpression callback - $publisherSlotName", e)
                }
            }
        })

        adConfig.bannerView?.addBannerAdView(adConfig.prebidHtmlBannerView!!)
        registerActivityWatcher(adConfig.activityContext, adConfig.prebidHtmlBannerView)
    }

    private fun renderBidInPrebidHtmlBannerView(adConfig: BannerConfiguration, bid: Bid?): SdkResult {

        val publisherSlotName = adConfig.publisherSlotName

        if (bid != null) {
            var resultCode = ResultCode.NO_BIDS

            adConfig.prebidBannerView?.price = bid.price
            adConfig.prebidBannerView?.targeting = bid.prebid.targeting
            adConfig.adSize = bid.prebid.targeting["hb_size"]?.let { SizeUtils.parseSize(it) }

            // somehow, gdrp_consent is null
            if (!bid.adm.isNullOrEmpty()) {
                bid.adm = bid.adm.replace("\${GDPR_CONSENT}", adConfig.consentReader.tCString)
                resultCode = ResultCode.SUCCESS
            }

            val sdkResult = getSdkResult(resultCode, bid.prebid.targeting)

            if (resultCode == ResultCode.SUCCESS && !bid.adm.isNullOrEmpty()) {

                identifier = getPrebidAdCacheIdFromTargeting(sdkResult.keyValues)
                savePrebidAdSize(sdkResult.keyValues, sdkResult.resultCode)
                updatedDebugInfoForResult(bid.prebid.targeting.toMutableMap(), adConfig.prebidBannerView?.bidResponse)

                if(ConfigurationManager.forcePrebidRendering || adConfig.prebidBannerView?.isDirectRenderingEnabled() == true) {
                    sdkResult.category = AdCategory.CAMPAIGN

                    Logger.d("[BannerPrebidSdkAdapter] Rendering HTML in PrebidHtmlBannerView - $publisherSlotName - cacheId=$identifier")
                    createAndLoadPrebidHtmlBannerView(adConfig)
                    adConfig.prebidHtmlBannerView?.setHtml(bid.adm)
                }
            } else {
                Logger.d("[BannerPrebidSdkAdapter] No bids / empty adm - $publisherSlotName")
                unregisterActivityWatcher()
            }

            return sdkResult
        } else {
            unregisterActivityWatcher()
            return getSdkResult(ResultCode.NO_BIDS, mutableMapOf())
        }
    }

    @TestOnly
    fun renderBidInPrebidHtmlBannerViewTest (adConfig: BannerConfiguration, bid: Bid?): SdkResult {
        return renderBidInPrebidHtmlBannerView(adConfig, bid)
    }

    private fun registerActivityWatcher(ctx: Context?, view: PrebidHtmlBannerView?) {
        unregisterActivityWatcher()

        val activity = ctx as? Activity ?: return
        val app = activity.application ?: return

        watchedActivityRef = WeakReference(activity)
        watchedAppRef = WeakReference(app)

        val viewRef = WeakReference(view)

        val detachListener = object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
            }
            override fun onViewDetachedFromWindow(v: View) {
                unregisterActivityWatcher()
            }
        }
        detachListenerRef = WeakReference(detachListener)
        view?.addOnAttachStateChangeListener(detachListener)

        activityCallbacks = object : Application.ActivityLifecycleCallbacks {

            override fun onActivityResumed(a: Activity) {
                val watched = watchedActivityRef?.get()
                if (watched != null && watched === a) {
                    viewRef.get()?.onHostResumed()
                }
            }

            override fun onActivityPaused(a: Activity) {
                val watched = watchedActivityRef?.get()
                if (watched != null && watched === a) {
                    viewRef.get()?.onHostPaused()
                }
            }

            override fun onActivityDestroyed(a: Activity) {
                val watched = watchedActivityRef?.get()
                if (watched != null && watched === a) {
                    unregisterActivityWatcher()
                }
            }

            override fun onActivityCreated(a: Activity, b: Bundle?) {
            }

            override fun onActivityStarted(a: Activity) {
            }

            override fun onActivityStopped(a: Activity) {
            }

            override fun onActivitySaveInstanceState(a: Activity, outState: Bundle) {
            }
        }

        app.registerActivityLifecycleCallbacks(activityCallbacks)
    }

    private fun unregisterActivityWatcher() {
        val cb = activityCallbacks
        activityCallbacks = null

        val app = watchedAppRef?.get()
        watchedAppRef = null

        val view = (adConfig as? BannerConfiguration)?.prebidHtmlBannerView
        val detachListener = detachListenerRef?.get()
        detachListenerRef = null
        if (view != null && detachListener != null) {
            try {
                view.removeOnAttachStateChangeListener(detachListener)
            } catch (_: Throwable) {
            }
        }

        watchedActivityRef = null

        if (app != null && cb != null) {
            try {
                app.unregisterActivityLifecycleCallbacks(cb)
            } catch (_: Throwable) {
            }
        }
    }

    private fun updateDebugInfoForFail(keyValues: MutableMap<String, String?>?) {
        if (ConfigurationManager.isInspectionMode) {
            adConfig.debugInfo?.let {
                val prebidDebugInfo = SdkDebugInfo()
                prebidDebugInfo.publisherSlotName = adConfig.publisherSlotName
                prebidDebugInfo.description = "Failed from Prebid"
                prebidDebugInfo.keyValues = keyValues
                it.sdkDebugInfos.add(prebidDebugInfo)
            }
        }
    }

    private fun savePrebidAdSize(keyValuesFromPrebid: MutableMap<String, String>?, resultCode: SdkResultCode) {
        keyValuesFromPrebid?.let {
            if (resultCode == SdkResultCode.SUCCESS) {
                val size = keyValuesFromPrebid[PrebidToGAMKeyValueMapper.CustomTargetingMapping.size.ylKey]
                this.prebidAdSize = SizeUtils.parseSizeForGAM(size)
            }
        }
    }

    fun resizeAd(adManagerAdView: AdManagerAdView?) {
        adManagerAdView?.let {
            if (prebidAdSize != null && SizeUtils.isNoZeroPixel(prebidAdSize!!)) {
                adManagerAdView.setAdSizes(prebidAdSize!!)
                adConfig.adSize = prebidAdSize?.let { org.prebid.mobile.AdSize(it.width, it.height) }
                Logger.i("[BannerPrebidSdkAdapter] Resizing ad to: " + prebidAdSize!!.width + "x" + prebidAdSize!!.height)
            }
        }
    }
}