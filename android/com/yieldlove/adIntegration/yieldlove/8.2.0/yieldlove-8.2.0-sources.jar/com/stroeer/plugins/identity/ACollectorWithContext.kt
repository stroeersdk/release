package com.stroeer.plugins.identity

import com.stroeer.utilities.concurrent.ACoroutinable
import android.content.Context

abstract class ACollectorWithContext<T> : IIdentityCollector<T?>, ACoroutinable(){
    abstract override suspend fun retrieveData(): T?

    companion object {
        lateinit var applicationContext: Context
            internal set
    }
}
