package com.stroeer.ads.config.loaders

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.stroeer.ads.config.ConfigConstants

class PreferenceFetcher(applicationContext: Context) : IFetcher {
    private val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
    private val legacyPreferences : SharedPreferences = applicationContext.getSharedPreferences(
        ConfigConstants.EXTERNAL_CONFIG_SHARED_PREFS_FILE_KEY, Context.MODE_PRIVATE
    );

    override suspend fun load(appName: String?): String? {
        return sharedPreferences.getString(ConfigConstants.PREFS_CONFIG, null)
    }

    override fun store(json: String?) {
        sharedPreferences.edit { putString(ConfigConstants.PREFS_CONFIG, json) }
        legacyPreferences.edit {
            putString(ConfigConstants.EXTERNAL_CONFIG_CONTENT_KEY, json)
                .putLong(
                    ConfigConstants.EXTERNAL_CONFIG_LAST_FETCH_IN_MILLIS_KEY,
                    System.currentTimeMillis()
                )
        }
    }

    override fun delete() {
        sharedPreferences.edit { remove(ConfigConstants.PREFS_CONFIG) }
        legacyPreferences.edit {
            remove(ConfigConstants.EXTERNAL_CONFIG_CONTENT_KEY)
        }
    }
}

