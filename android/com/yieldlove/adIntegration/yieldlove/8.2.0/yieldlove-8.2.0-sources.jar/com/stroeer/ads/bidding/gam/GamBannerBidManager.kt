package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.admanager.AdManagerAdView
import com.stroeer.ads.exceptions.DfpBannerLoadAdError
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.bidding.SdkResult


class GamBannerBidManager(bannerConfig: BannerConfiguration) : AGamBidManager(bannerConfig){

    val bannerConfig : BannerConfiguration
        get() {return adConfig as BannerConfiguration}

    override fun initializeGoogleAdAViewIfNotExist(){
        super.initializeGoogleAdAViewIfNotExist()

        if(bannerConfig.adManagerAdView == null && context != null){
           bannerConfig.adManagerAdView = AdManagerAdView(context!!)
        }
    }

    override fun createAdManagerAdView(listener: Any) {
        prepareRequestBuilder()

        listener as IGamBannerEventListener

        bannerConfig.adManagerAdView?.let{ adView->
            if(!bannerConfig.isRefreshing) {
                adView.setAdSizes(*bannerConfig.availableBannerSizes)
            }
            adView.adListener = object : AdListener() {
                override fun onAdClosed() {
                    listener.onAdClosed()
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    listener.onAdFailedToLoad(DfpBannerLoadAdError(loadAdError))
                }

                override fun onAdOpened() {
                    listener.onAdOpened()
                }

                override fun onAdLoaded() {
                    adView.adSize?.let { size->
                        bannerConfig.adSize =
                            org.prebid.mobile.AdSize(size.width, size.height)
                    }
                    listener.onAdLoaded()
                }

                override fun onAdClicked() {
                    listener.onAdClicked()
                }

                override fun onAdImpression() {
                    listener.onAdImpression()
                }
            }

            // This is for webview rendering
            if(adView.parent == null){

                bannerConfig.bannerView?.addBannerAdView(adView)
            }
        }
    }

    override fun callDfp(results: Array<SdkResult>) {
        super.callDfp(results)

        if (bannerConfig.adManagerAdView != null && bannerConfig.requestBuilder != null) {
            // GAM doesn't allow to put twice.
            // This is a problem when refreshBanner.
            @Suppress("SENSELESS_COMPARISON")
            if(bannerConfig.adManagerAdView!!.adUnitId == null) {
                bannerConfig.adManagerAdView!!.adUnitId = bannerConfig.adUnitId
            }

            bannerConfig.adManagerAdView!!.loadAd(request!!)
        }
    }
}