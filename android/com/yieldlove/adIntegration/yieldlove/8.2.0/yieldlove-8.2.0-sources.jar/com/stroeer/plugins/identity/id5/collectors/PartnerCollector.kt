package com.stroeer.plugins.identity.id5.collectors

import com.stroeer.plugins.identity.IIdentityCollector

/**
 * Return partner ID
 */
class PartnerCollector : IIdentityCollector<Int?> {
    override suspend fun retrieveData(): Int? {
        return 433
    }
}
