package com.stroeer.ads.bidding.prebid

import com.google.android.gms.ads.AdSize
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration
import org.prebid.mobile.AdUnit
import org.prebid.mobile.BannerAdUnit
import org.prebid.mobile.BannerBaseAdUnit
import org.prebid.mobile.BannerParameters
import org.prebid.mobile.InterstitialAdUnit
import org.prebid.mobile.Signals

class PrebidAdUnitConverter : AdUnitConverter {
    override fun convertToBannerAdUnit(bannerConfig : BannerConfiguration): AdUnit {
        val sizes = bannerConfig.availableBannerSizes
        val mainAdSize = sizes[0] // main size is like 31 * 37

        val bannerAdUnit = BannerAdUnit(
            bannerConfig.configAdSlot!!.prebidConfigId!!,
            mainAdSize.width,
            mainAdSize.height
        )

        setPrebidAdUnitParameters( bannerAdUnit)

        for (adSize in sizes) {
            addAdditionalSizeIfAllowed(mainAdSize, bannerAdUnit, adSize)
        }
        setPrebidAdUnitAdSlot(bannerConfig.adUnitId, bannerAdUnit)
        return bannerAdUnit
    }

    override fun convertToPrebidInterstitialAdUnit(intConfig : InterstitialConfiguration): AdUnit {
        val interstitialAdUnit = InterstitialAdUnit(intConfig.configAdSlot!!.prebidConfigId!!, 10, 10)
        setPrebidAdUnitParameters(interstitialAdUnit)
        setPrebidAdUnitAdSlot(intConfig.adUnitId, interstitialAdUnit)
        return interstitialAdUnit
    }

    private fun addAdditionalSizeIfAllowed(
        mainAdSize: AdSize,
        adUnit: BannerAdUnit,
        adSize: AdSize
    ) {
        if (adSize.width != mainAdSize.width && adSize.height != mainAdSize.height) {
            adUnit.bannerParameters?.adSizes?.add(org.prebid.mobile.AdSize(adSize.width, adSize.height))
        }
    }

    private fun setPrebidAdUnitParameters(
        adUnit: BannerBaseAdUnit
    ) {
        val parameters = BannerParameters()
        val openRtbApi = ConfigurationManager.getInstance().getConfig()?.openRtb?.framework
        val signals: MutableList<Signals.Api> = ArrayList()
        if(!openRtbApi.isNullOrEmpty()) {
            for (api in openRtbApi) {
                signals.add(Signals.Api(api))
            }
        }
        parameters.api = signals
        parameters.adSizes = mutableSetOf()

        adUnit.bannerParameters = parameters
    }

    private fun setPrebidAdUnitAdSlot(
        adUnitId : String,
        adUnit: AdUnit
    ) {
        adUnit.impOrtbConfig = """
                {
                  "ext": {
                    "data": {
                        "adslot": "$adUnitId",
                        "pbadslot": "$adUnitId"
                    }
                  }
                }
                """.trimIndent()
    }
}
