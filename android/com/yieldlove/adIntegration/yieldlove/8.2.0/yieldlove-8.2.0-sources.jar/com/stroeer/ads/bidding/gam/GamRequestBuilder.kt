package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig

class GamRequestBuilder(
    private var localBuilder: AdManagerAdRequest.Builder,
    private val config: AAdConfiguration
) {
    private val keyValuesFromAdapter: MutableMap<String, String?> = HashMap()

    fun addKeyValuesFromAdapter(keyValues: MutableMap<String, String>?): GamRequestBuilder {
        keyValues?.let{
            for (key in keyValues.keys) {
                this.keyValuesFromAdapter[key] = keyValues[key]
            }
        }
        return this
    }

    fun build(): AdManagerAdRequest {
        val builder = GamAdRequestBuilderMerger.merge(GlobalGamManager.adRequestBuilder, localBuilder)

        for (key in this.keyValuesFromAdapter.keys) {
            builder.addCustomTargeting(key, this.keyValuesFromAdapter[key]!!)
        }

        // CustomTargeting
        val customTargeting = this.config.customTargeting
        for (key in customTargeting.keys) {
            builder.addCustomTargeting(key, customTargeting[key]!!)
        }

        // SetTimeout
        try {
            builder.setHttpTimeoutMillis(this.config.requestTimeoutInMs.toInt())
        }catch(e: Exception){
            Logger.e("[GamRequestBuilder] Failed to set ad request timeout: ${this.config.requestTimeoutInMs} ms - ${e.message}", e)
        }

        // Adding Android SDK Version
        builder.addCustomTargeting("androidYlSdkVersion", listOf(BuildConfig.VERSION_NAME))

        return builder.build()
    }
}