package com.stroeer.ads.bidding.gam

import android.app.Activity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.admanager.AdManagerInterstitialAd
import com.google.android.gms.ads.admanager.AdManagerInterstitialAdLoadCallback
import com.stroeer.ads.exceptions.DfpInterstitialLoadAdError
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration
import com.stroeer.ads.bidding.SdkResult

class GamInterstitialBidManager(intConfig: InterstitialConfiguration) : AGamBidManager(intConfig){

    val intConfig : InterstitialConfiguration
        get() {return adConfig as InterstitialConfiguration}

    var listener : IGamInterstitialEventListener? =  null

    /** The Google Ad Manager interstitial ad object associated with this configuration. */
    var adManagerInterstitialAd: AdManagerInterstitialAd? = null

    override fun createAdManagerAdView(listener: Any) {
        prepareRequestBuilder()

        this.listener = listener as IGamInterstitialEventListener
    }

    override fun callDfp(results: Array<SdkResult>) {
        super.callDfp(results)

        context?.let { context ->
            AdManagerInterstitialAd.load(
                context, intConfig.adUnitId, intConfig.requestBuilder!!.build(),
                object : AdManagerInterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        listener?.onAdFailedToLoad(DfpInterstitialLoadAdError(loadAdError))
                    }

                    override fun onAdLoaded(adManagerInterstitialAd: AdManagerInterstitialAd) {
                        this@GamInterstitialBidManager.adManagerInterstitialAd =
                            adManagerInterstitialAd

                        listener?.let {
                            if (it.isFullListener()) {
                                adManagerInterstitialAd.fullScreenContentCallback =
                                    object : FullScreenContentCallback() {
                                        override fun onAdFailedToShowFullScreenContent(var1: AdError) {
                                            listener?.onAdFailedToShowFullScreenContent(
                                                DfpInterstitialLoadAdError(var1)
                                            )
                                        }

                                        override fun onAdShowedFullScreenContent() {
                                            listener?.onAdShowedFullScreenContent()
                                        }

                                        override fun onAdDismissedFullScreenContent() {
                                            listener?.onAdDismissedFullScreenContent()
                                        }

                                        override fun onAdImpression() {
                                            listener?.onAdImpression()
                                        }

                                        override fun onAdClicked() {
                                            listener?.onAdClicked()
                                        }
                                    }
                            }
                        }

                        listener?.onAdLoaded()
                    }
                })
        }
    }

    fun show(){
        intConfig.activityContext?.let {
            adManagerInterstitialAd?.show(it as Activity)
        }
    }

    override fun destroy(){
        listener = null
        adManagerInterstitialAd?.fullScreenContentCallback = null
        adManagerInterstitialAd = null
    }
}