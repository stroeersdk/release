package com.stroeer.ads.bidding.gam

import com.stroeer.ads.formats.banner.IBannerListenerRunner

interface IGamBannerEventListener : IBannerListenerRunner {

}