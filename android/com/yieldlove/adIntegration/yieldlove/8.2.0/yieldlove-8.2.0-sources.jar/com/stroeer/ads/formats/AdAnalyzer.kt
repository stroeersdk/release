package com.stroeer.ads.formats

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import com.stroeer.ads.exceptions.analyzer.NoWebViewFoundException
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout

object AdAnalyzer {
    private const val INNER_HTML_SCRIPT = "document.body.innerHTML"

    private fun recursivelyFindWebView(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                recursivelyFindWebView(view.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    private suspend fun getInnerHtmlScript(webView: WebView): String? =
            suspendCancellableCoroutine { cont ->
                // Ensure we’re on the right thread even without Main set
                webView.post {
                    webView.evaluateJavascript(INNER_HTML_SCRIPT) { html ->
                        if (cont.isActive) cont.resume(html)
                    }
                }
            }

    suspend fun getHtmlFromAdView(adView: View?): String? {
        requireNotNull(adView) { "adView is null" }

        val webView = recursivelyFindWebView(adView)
            ?: throw NoWebViewFoundException()

        return getInnerHtmlScript(webView)
    }
}