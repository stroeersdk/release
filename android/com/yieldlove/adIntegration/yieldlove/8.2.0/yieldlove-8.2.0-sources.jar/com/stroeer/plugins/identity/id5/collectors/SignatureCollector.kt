package com.stroeer.plugins.identity.id5.collectors

import androidx.preference.PreferenceManager
import com.stroeer.plugins.identity.ACollectorWithContext
import com.stroeer.plugins.identity.id5.ID5Constants

/**
 * Return iD5 signature
 */
class SignatureCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        val signature = sharedPreferences.getString(ID5Constants.prefId5Signature, null)
        return if (signature.isNullOrEmpty()) null else signature
    }
}
