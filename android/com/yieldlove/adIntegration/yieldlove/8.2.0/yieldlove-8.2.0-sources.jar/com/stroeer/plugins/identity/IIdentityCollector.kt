package com.stroeer.plugins.identity

import java.util.concurrent.CompletableFuture

interface IIdentityCollector<T> {
    suspend fun retrieveData(): T?
}
