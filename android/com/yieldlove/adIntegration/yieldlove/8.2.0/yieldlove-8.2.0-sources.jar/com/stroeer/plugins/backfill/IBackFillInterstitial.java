package com.stroeer.plugins.backfill;

import com.stroeer.ads.formats.interstitial.IStroeerInterstitialListener;
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration;

public interface IBackFillInterstitial {
    void loadInterstitial(InterstitialConfiguration intConfig, IStroeerInterstitialListener listener);
    void showInterstitial(InterstitialConfiguration intConfig);
    boolean isInterstitialAvailable(InterstitialConfiguration intConfig);
}
