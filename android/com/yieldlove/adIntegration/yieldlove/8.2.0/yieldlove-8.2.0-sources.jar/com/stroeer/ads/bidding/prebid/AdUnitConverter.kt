package com.stroeer.ads.bidding.prebid

import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration
import org.prebid.mobile.AdUnit

interface AdUnitConverter {
    fun convertToBannerAdUnit(bannerConfig : BannerConfiguration): AdUnit
    fun convertToPrebidInterstitialAdUnit(intConfig : InterstitialConfiguration): AdUnit
}
