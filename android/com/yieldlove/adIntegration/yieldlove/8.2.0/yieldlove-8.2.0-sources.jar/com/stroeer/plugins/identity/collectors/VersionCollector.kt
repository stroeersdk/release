package com.stroeer.plugins.identity.collectors

import com.stroeer.plugins.identity.ACollectorWithContext
import com.stroeer.utilities.logging.Logger

/**
 * Return version name
 */
class VersionCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        return try {
            val pInfo = applicationContext.packageManager
                .getPackageInfo(applicationContext.packageName, 0)
            pInfo.versionName
        } catch (ex: Exception) {
            Logger.e("[VersionCollector] Failed to get version name", ex)
            "Unknown"
        }
    }
}
