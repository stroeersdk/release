package com.stroeer.ads.bidding.prebid

enum class PrebidBidKeys(val key: String) {
    env("hb_env"),
    pb("hb_pb"),
    bidder("hb_bidder"),
    cache_id("hb_cache_id"),
    size("hb_size");

}