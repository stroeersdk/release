package com.stroeer.ads.bidding

import com.stroeer.ads.formats.AAdConfiguration

interface ISdkAdapter {
    suspend fun getBid(adConfig : AAdConfiguration): SdkResult
    suspend fun prepare()
    val identifier: String?
}
