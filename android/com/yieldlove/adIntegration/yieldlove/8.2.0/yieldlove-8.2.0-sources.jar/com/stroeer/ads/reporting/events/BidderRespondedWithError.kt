package com.stroeer.ads.reporting.events

import com.google.gson.JsonObject
//import com.stroeer.ads.bidding.ISdkAdapter
import com.stroeer.ads.bidding.ISdkAdapter

//class BidderRespondedWithError(var adapter: ISdkAdapter, exception: Exception?) :
//    TimeErrorEvent(exception) {
//    override fun toJsonObject(): JsonObject {
//        val jsonObject = super.toJsonObject()
//        jsonObject.addProperty("bidder", adapter.name)
//        return jsonObject
//    }
//}

class BidderRespondedWithError(var adapter: ISdkAdapter, exception: Exception?) :
    TimeErrorEvent(exception) {
    override fun toJsonObject(): JsonObject {
        val jsonObject = super.toJsonObject()
        //jsonObject.addProperty("bidder", adapter.name)
        return jsonObject
    }
}