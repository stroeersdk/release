package com.stroeer.ads.formats

import com.stroeer.ads.bidding.ISdkAdapter
import com.stroeer.ads.bidding.prebid.APrebidSdkAdapter

object BidderRecognizer {
    private const val PREBID = "Prebid"
    private const val UNKNOWN_BIDDER = "unknownBidder"

    fun getBidderName(adapter: ISdkAdapter?): String {
        return if (adapter is APrebidSdkAdapter) {
            PREBID
        } else {
            UNKNOWN_BIDDER
        }
    }
}