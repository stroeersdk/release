package com.stroeer.plugins.backfill

import android.widget.FrameLayout
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.plugins.backfill.gravite.IFirstBannerLoaded

/**
 * Interface to handle loading and retrieving banners for backfill ad units.
 */
interface IBackFillBanner {
    /**
     * Load a banner ad for backfill using the specified ad unit data.
     *
     * @param loaded Data object containing the ad unit information needed to load the banner.
     */
    fun loadBanner(bannerConfig: BannerConfiguration, loaded: IFirstBannerLoaded?)

    /**
     * Retrieve the currently loaded banner for the specified ad unit.
     *
     * @param bannerConfig Data object containing the ad unit information for which the banner is being retrieved.
     * @return The FrameLayout containing the banner, or null if no banner is available.
     */
    fun getBanner(bannerConfig: BannerConfiguration): FrameLayout?
}