package com.stroeer.plugins.identity.id5

import com.stroeer.plugins.identity.id5.objects.ID5Data
import com.stroeer.plugins.identity.id5.objects.ID5RequestBody
import com.stroeer.utilities.json.HttpJsonRequest
import com.stroeer.utilities.json.JsonBase
import com.stroeer.utilities.logging.Logger
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody

class ID5HttpRequest {
    /**
     * Sends an ID5 request and returns the parsed response.
     * 
     * @param requestBody ID5 request body.
     * @return ID5Data if successful, null otherwise.
     */
    suspend fun send(requestBody: ID5RequestBody): ID5Data? {
        if (!isValid(requestBody)) {
            return null
        }

        val json = sendRequest(requestBody)
        json?.let{
            try {
                val data = JsonBase.fromJson(json, ID5Data::class.java)
                data?.let{
                    Logger.d("[ID5HttpRequest] Received ID5Data: " + data.toPrettyJson())
                    return data
                }
            } catch (e: Exception) {
                Logger.e("[ID5HttpRequest] Failed to parse ID5Data from json", e)
            }
        }
        return null
    }

    /**
     * Constructs and sends the HTTP request.
     * 
     * @param requestBody ID5 request body.
     * @return JSON response as a string, null if the request fails.
     */
    private suspend fun sendRequest(requestBody: ID5RequestBody): String? {
        val url = ID5Constants.baseUri
        Logger.d("[ID5HttpRequest] Sending request to " + url + " with body " + requestBody.toPrettyJson())

        val httpJsonRequest = HttpJsonRequest()
        val timeout = ID5Constants.timeoutInSecs

        val headers: HashMap<String, String> = object : HashMap<String, String>() {
            init {
                put("Content-Type", "application/json")
            }
        }

        val body: RequestBody =
            requestBody.toJson()
                ?.toRequestBody("application/json; charset=utf-8".toMediaType())
                ?: throw IllegalArgumentException("Request body is null")

        return httpJsonRequest.sendPostJson(url, headers, body, timeout, this.javaClass)
    }

    /**
     * Validates the request body.
     * 
     * @param requestBody ID5 request body.
     * @return true if valid, false otherwise.
     */
    fun isValid(requestBody: ID5RequestBody?): Boolean {
        if (requestBody == null) return logInvalid("Request body is null")
        if (requestBody.ts == null) return logInvalid("Timestamp is null")
        if (requestBody.partner == null) return logInvalid("Partner is null")
        if (requestBody.bundle == null) return logInvalid("Bundle is null")
        if (requestBody.ver == null) return logInvalid("Version is null")
        if (requestBody.ip == null) return logInvalid("IP is null")
        if (requestBody.ua == null) return logInvalid("User agent is null")
        return true
    }

    /**
     * Logs validation failures.
     * 
     * @param message Error message.
     * @return Always returns false.
     */
    private fun logInvalid(message: String?): Boolean {
        Logger.e("[ID5HttpRequest] $message")
        return false
    }
}
