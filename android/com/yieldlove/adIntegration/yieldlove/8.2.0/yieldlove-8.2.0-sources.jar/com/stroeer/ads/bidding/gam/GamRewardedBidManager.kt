package com.stroeer.ads.bidding.gam

import android.app.Activity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.rewarded.RewardItem
import com.stroeer.ads.exceptions.DfpRewardedLoadAdError
import com.stroeer.ads.formats.rewarded.RewardedConfiguration
import com.stroeer.ads.bidding.SdkResult

class GamRewardedBidManager(rewardConfig: RewardedConfiguration) : AGamBidManager(rewardConfig){

    val rewardConfig : RewardedConfiguration
        get() {return adConfig as RewardedConfiguration}

    var listener : IGamRewardedEventListener? =  null

    private var rewardedAd: RewardedAd? = null

    override fun createAdManagerAdView(listener: Any) {
        prepareRequestBuilder()

        this.listener = listener as IGamRewardedEventListener
    }

    override fun callDfp(results: Array<SdkResult>) {
        // results should not be used
        super.callDfp(results)

        context?.let { context ->
                RewardedAd.load(
                    context,
                    rewardConfig.adUnitId,
                    request!!,
                    object : RewardedAdLoadCallback() {
                        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                            listener?.onAdFailedToLoad(DfpRewardedLoadAdError(loadAdError))
                        }

                        override fun onAdLoaded(rewaredAd: RewardedAd) {
                            rewardedAd = rewaredAd
                            listener?.onAdLoaded(rewaredAd)
                        }
                    })
            }
    }

    fun show(){
        rewardConfig.activityContext?.let{
            if(listener?.isFullRewardEventListener() ?: false) {
                rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        listener?.onAdDismissedFullScreenContent()
                        rewardedAd = null
                    }

                    override fun onAdFailedToShowFullScreenContent(err: AdError) {
                        listener?.onAdFailedToShowFullScreenContent(DfpRewardedLoadAdError(err))
                        rewardedAd = null
                    }

                    override fun onAdClicked() {
                        listener?.onAdClicked()
                    }

                    override fun onAdImpression() {
                        listener?.onAdImpression()
                    }

                    override fun onAdShowedFullScreenContent(){
                        listener?.onAdShowedFullScreenContent()
                    }
                }
            }
            rewardedAd?.show(it as Activity, object : OnUserEarnedRewardListener {
                override fun onUserEarnedReward(p0: RewardItem) {
                    listener?.onUserEarnedReward(p0)
                }
            })
        }
    }

    override fun destroy(){
        listener = null
        rewardedAd?.fullScreenContentCallback = null
        rewardedAd = null
    }
}