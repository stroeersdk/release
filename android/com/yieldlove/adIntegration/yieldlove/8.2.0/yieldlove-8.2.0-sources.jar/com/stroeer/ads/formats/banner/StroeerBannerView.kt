package com.stroeer.ads.formats.banner

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.google.android.gms.ads.admanager.AdManagerAdView
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugLabel
import com.stroeer.ads.exceptions.PreviousAdLoadIsInProgressException
import com.stroeer.ads.formats.AdStatus
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.R
import kotlinx.coroutines.*
import org.jetbrains.annotations.TestOnly

/**
 * Custom view for displaying banner ads.
 * Handles loading, lifecycle, debug gesture detection, and developer mode.
 */
open class StroeerBannerView : FrameLayout {
    private var isUserStillTouchingTheAd = false
    private val longPressHandler = Handler(Looper.getMainLooper())

    private val bannerBuilder: StroeerBannerBuilder

    var destroyWhenDetached : Boolean = false


    @TestOnly
    internal fun getBuilder() : StroeerBannerBuilder {
        return bannerBuilder
    }

    val bannerConfig : BannerConfiguration
        get(){
            return bannerBuilder.bannerConfig
        }

    val publisherSlotName : String
        get(){
            return bannerConfig.publisherSlotName
        }

    val adSize : Size
        get() {
            val width = bannerConfig.adSize?.width ?: 0
            val height = bannerConfig.adSize?.height ?: 0
            return Size(width, height)
        }

    val googleAdView : AdManagerAdView?
        get() {
            return bannerConfig.adManagerAdView
        }

    /**
     * Property for setting/getting the content URL for ad targeting.
     */
    var contentUrl: String?
        set(value) {
            bannerBuilder.contentUrl = value
        }
        get() {
            return bannerBuilder.contentUrl
        }

    /**
     * Constructor used when inflating from XML.
     */
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        bannerBuilder = StroeerBannerBuilder(context, this)
    }

    /**
     * Constructor used when creating view programmatically.
     */
    constructor(context: Context) : super(context) {
        bannerBuilder = StroeerBannerBuilder(context, this)
    }

    /**
     * Loads a banner with a listener for ad events.
     */
    @JvmOverloads
    fun load(publisherSlotName: String, listener: StroeerBannerListener? = null) {
        bannerBuilder.load(publisherSlotName, listener)
    }

    fun refresh(){
        if(bannerConfig.status == AdStatus.UNINITIALIZED ||  bannerConfig.status.isLoading()) {
            Logger.e("[StroeerBannerBuilder] The ads is not ready to be refreshed. Current status: ${bannerConfig.status}")
            return
        }

        bannerBuilder.refreshBanner()
    }
    /**
     * Cleans up resources when the view is detached from the window.
     */
    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if(destroyWhenDetached) {
            destroy()
        }
    }

    /**
     * Destroys the banner and clears child views.
     */
    fun destroy() {
        bannerBuilder.destroy()
        this.removeAllViews()
    }

    /**
     * Adds the given banner view as a child and attaches debug label if in inspection mode.
     */
    internal fun addBannerAdView(view: View) {
        removeAllViews()

        // UI Setting
        val params = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        params.topMargin = 0
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        view.layoutParams = params

        addView(view)
    }

    /**
     * Adds a floating debug label view to the banner container.
     */
    internal fun addDebugLabel() {
        if(ConfigurationManager.isInspectionMode) {
            bannerConfig.debugInfo?.let {
                val debugLabel =
                    inflate(this.context, R.layout.stroeer_debug_label, null) as DebugLabel
                debugLabel.setDebugInfo(it)

                super.addView(
                    debugLabel, super.childCount, ViewGroup.LayoutParams(
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT
                    )
                )
            }
        }
    }

    /**
     * Intercepts touch events to detect debug gesture (three-finger tap).
     */
    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        val action = ev.actionMasked

        if (action == MotionEvent.ACTION_CANCEL || action == MotionEvent.ACTION_UP) {
            return false
        }

        if (shouldIntercept(action)) {
            return isDebugGesture(ev)
        }
        return false
    }

    /**
     * Checks if the action should be intercepted (multi-touch event).
     */
    private fun shouldIntercept(action: Int): Boolean {
        return (action and MotionEvent.ACTION_MASK) == MotionEvent.ACTION_POINTER_DOWN
    }

    /**
     * Checks if the gesture qualifies as the debug gesture (three fingers).
     */
    private fun isDebugGesture(ev: MotionEvent): Boolean {
        return ev.pointerCount == 3 || ev.pointerCount == 2
    }

    /**
     * Handles touch events for long-press detection to enable developer mode.
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_MOVE) {
            longPressHandler.postDelayed(mLongPressed, 3000)
            isUserStillTouchingTheAd = true
        }

        if (event.action == MotionEvent.ACTION_CANCEL || event.action == MotionEvent.ACTION_UP) {
            if (isUserStillTouchingTheAd) {
                isUserStillTouchingTheAd = false
                longPressHandler.removeCallbacks(mLongPressed)
            }
        }
        return false
    }

    // Runnable for long-press gesture to enable developer mode
    private val mLongPressed: Runnable = object : Runnable {
        override fun run() {
            if (isUserStillTouchingTheAd) {
                ConfigurationManager.enableInspectionMode()
                showDeveloperModeConfirmation()
                longPressHandler.removeCallbacks(this)
            }
        }
    }

    /**
     * Shows a dialog to confirm developer mode has been enabled.
     */
    private fun showDeveloperModeConfirmation() {
        val builder = AlertDialog.Builder(this.context)
        builder.setTitle("StroeerSDK Debugging Mode")
            .setMessage("StroeerSDK debugging mode has been switched on. Force close the app to switch it back off.")
        builder.setPositiveButton("OK", null)
        val dialog = builder.create()
        dialog.show()
    }
}