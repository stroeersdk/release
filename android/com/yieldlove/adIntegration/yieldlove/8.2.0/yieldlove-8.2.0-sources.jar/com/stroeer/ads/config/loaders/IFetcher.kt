package com.stroeer.ads.config.loaders

interface IFetcher {
    suspend fun load(appName: String?): String?
    fun store(json: String?)
    fun delete()
}
