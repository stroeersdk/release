package com.stroeer.ads.bidding.gravite

import android.widget.FrameLayout
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.SdkType
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.formats.banner.StroeerBannerView
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration
import com.stroeer.ads.debugInfo.SdkDebugInfo
import com.stroeer.plugins.backfill.gravite.GraviteLoader
import com.stroeer.plugins.backfill.gravite.IFirstBannerLoaded
import com.stroeer.utilities.logging.Logger
import org.prebid.mobile.AdSize
import org.prebid.mobile.rendering.models.openrtb.bidRequests.imps.Banner

class GraviteBidManager (val adConfig : AAdConfiguration) {

    val isDirectGravite : Boolean
        get() {return GraviteLoader.getInstance().isDirectGraviteCall() }


    /**
     * return : if direct rendering is running, it should return false to avoid rendering
     * */
    fun prepareBanner(): Boolean{
        if (GraviteLoader.getInstance().isGraviteStarted) {
            val bannerLoader = GraviteLoader.getInstance().bannerLoader
            adConfig as BannerConfiguration
            bannerLoader?.loadBanner(adConfig, object : IFirstBannerLoaded {
                override fun onFirstBannerLoaded() {
                    if (isDirectGravite)
                        renderGraviteBanner()
                }
            })

            if (isDirectGravite) {
                renderGraviteBanner()
                return false
            }
        }
        return true
    }

    /**
     * : if direct rendering is running, it should return false to avoid rendering
     */
    fun prepareInterstitial(): Boolean{
        if (GraviteLoader.getInstance().isGraviteStarted) {
            adConfig as InterstitialConfiguration
            try {
                val interstitialLoader = GraviteLoader.getInstance().interstitialLoader
                interstitialLoader?.loadInterstitial(adConfig, adConfig.userListener)
            } catch (e: Exception) {
                Logger.e("[Interstitial] Failed to call BackFill Interstitial", e)
            }
            return !isDirectGravite
        }

        return true
    }

    fun renderGraviteBanner(): Boolean {
        adConfig as BannerConfiguration
        if(GraviteLoader.getInstance().isGraviteStarted && adConfig.bannerView != null) {
            val bannerLoader = GraviteLoader.getInstance().bannerLoader
            var banner: FrameLayout? = null
            if (bannerLoader != null) {
                banner = bannerLoader.getBanner(adConfig)
            }

            val view = adConfig.bannerView as StroeerBannerView
            view.removeAllViews()

            if (banner == null) {
                updateDebugInfoForFail()
                view.addDebugLabel()
                Logger.w("[Banner] Gravite Banner does not return any ads for ad unit: " + adConfig.publisherSlotName)
            }else{
                adConfig.graviteView = banner
                GraviteLoader.getInstance().adSource?.let { adConfig.source = it }

                try {
                    val scale = adConfig.applicationContext?.resources?.displayMetrics?.density
                    scale?.let {
                        adConfig.adSize = AdSize((banner.layoutParams.width / scale).toInt(), (banner.layoutParams.height / scale).toInt())
                        // view.layoutParams = param
                        Logger.d("[GraviteBanner] size : " + adConfig.publisherSlotName + " : " + adConfig.adSize?.width + "x" + adConfig.adSize?.height)
                    }

                    view.addBannerAdView(banner)
                    view.addDebugLabel()

                } catch (e: Exception) {
                    Logger.e("[Banner] Failed to set AdSize for Gravite Banner", e)
                }
                updateDebugInfo()

                return true
            }
        }
        return false
    }

    fun checkForceToCallGravite() : Boolean{
        if (GraviteLoader.getInstance().isForceToExecute()) {
            if (ConfigurationManager.isInspectionMode) {
                adConfig.debugInfo?.let {
                    val gamSdkDebugInfo = SdkDebugInfo()
                    gamSdkDebugInfo.publisherSlotName =
                        adConfig.publisherSlotName
                    gamSdkDebugInfo.description = "Force to call Gravite"
                    gamSdkDebugInfo.sdkType = SdkType.Gravite
                    it.sdkDebugInfos.add(gamSdkDebugInfo)
                }
            }
            return true
        }
        return false
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    // Update debugInfo
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    fun updateDebugInfo(){
        if(ConfigurationManager.isInspectionMode){
            val converted = GraviteLoader.getInstance().getPlacementConverted(adConfig.publisherSlotName)

            // Add debugInfo
            adConfig.debugInfo?.let {
                val gamSdkDebugInfo = SdkDebugInfo()
                gamSdkDebugInfo.publisherSlotName = adConfig.publisherSlotName
                gamSdkDebugInfo.description = "Banner From Gravite"
                gamSdkDebugInfo.keyValues = mutableMapOf("conversion" to "$converted",  "debugInfo" to GraviteLoader.getInstance().debugInfo.toString())

                gamSdkDebugInfo.sdkType = SdkType.Gravite
                it.sdkDebugInfos.add(gamSdkDebugInfo)
            }
        }
    }

    fun updateDebugInfoForFail(){
        if(ConfigurationManager.isInspectionMode){

            val converted = GraviteLoader.getInstance().getPlacementConverted(adConfig.publisherSlotName)

            // Add debugInfo
            adConfig.debugInfo?.let {
                val gamSdkDebugInfo = SdkDebugInfo()
                gamSdkDebugInfo.publisherSlotName = adConfig.publisherSlotName
                gamSdkDebugInfo.description = "Failed From Gravite"
                gamSdkDebugInfo.keyValues = mutableMapOf("errorMessage" to "No Ads",
                                                         "conversion" to "$converted")
                gamSdkDebugInfo.sdkType = SdkType.Gravite
                it.sdkDebugInfos.add(gamSdkDebugInfo)
            }
        }
    }
}