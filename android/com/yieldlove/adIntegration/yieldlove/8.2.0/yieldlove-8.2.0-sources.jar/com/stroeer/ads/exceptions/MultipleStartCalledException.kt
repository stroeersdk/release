package com.stroeer.ads.exceptions

class MultipleStartCalledException :
    RuntimeException("Start event was called more than once in session.")