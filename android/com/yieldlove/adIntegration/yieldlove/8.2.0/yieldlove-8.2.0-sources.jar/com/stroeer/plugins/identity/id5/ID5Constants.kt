package com.stroeer.plugins.identity.id5

import com.stroeer.ads.config.ConfigConstants

object ID5Constants {

    var timeoutInSecs: Int = ConfigConstants.CONFIG_TIMEOUT

    var vendorId: Int = 131
    var baseUri: String = "https://api.id5-sync.com/ga/v1"
    var source: String = "id5-sync.com"

    var refreshIntervalInSecs: Int = 8 * 60 * 60 // 8 hours
    var deleteIntervalInSecs: Long = 30L * 24 * 60 * 60 // 30 days

    var prefId5Cache: String = "ID5_CACHE"
    var prefId5CacheDate: String = "ID5_CACHE_DATE"
    var prefId5Signature: String = "ID5_SIGNATURE"
}