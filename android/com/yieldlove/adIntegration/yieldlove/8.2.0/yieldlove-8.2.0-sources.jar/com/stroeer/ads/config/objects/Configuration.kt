package com.stroeer.ads.config.objects

import com.google.gson.GsonBuilder
import com.google.gson.JsonParseException
import com.stroeer.ads.config.objects.deserializer.ConfigAdSlot_Deserializer
import com.stroeer.ads.config.objects.deserializer.ConfigModules_Deserializer
import com.stroeer.utilities.logging.Logger

/**
 * {
 * "common": {
 * "dfpAppNetwork": "4444",
 * "androidBundleId": "testing.bundle.id.001",
 * "androidStoreUrl": "https://storeurl.test",
 * "dfpAdRequestTimeoutMs": 123456,
 * "dfpiOSAppName": "m.app.ios_toi_sd",
 * "dfpAndroidAppName": "m.app.droid_toi_sd",
 * "updateIntervalMs": 86400000,
 * "setAppMuted": "true"
 * },
 * "formats": {
 * "mobilead6x1": {
 * "active": true,
 * "availableOn": [
 * "b1",
 * "b2",
 * "b3",
 * "b4",
 * "b5"
 * ],
 * "dfpSizes": {
 * "iosAdSizes": [
 * "kGADAdSizeBanner"
 * ],
 * "androidAdSizes": [
 * "BANNER"
 * ],
 * "customAdSizes": []
 * }
 * },
 * "mobilead4x1": {
 * "active": true,
 * "availableOn": [
 * "b1",
 * "b2",
 * "b3",
 * "b4"
 * ],
 * "dfpSizes": {
 * "iosAdSizes": [],
 * "androidAdSizes": [],
 * "customAdSizes": [
 * {
 * "w": 320,
 * "h": 75
 * }
 * ]
 * }
 * },
 * "mobilead3x1": {
 * "active": false,
 * "availableOn": [
 * "b1",
 * "b2",
 * "b3",
 * "b4"
 * ],
 * "dfpSizes": {
 * "iosAdSizes": [
 * "kGADAdSizeLargeBanner"
 * ],
 * "androidAdSizes": [
 * "LARGE_BANNER"
 * ],
 * "customAdSizes": []
 * }
 * },
 * "mobilead2x1": {
 * "active": true,
 * "availableOn": [
 * "b1",
 * "b2",
 * "b3",
 * "b4"
 * ],
 * "dfpSizes": {
 * "iosAdSizes": [],
 * "androidAdSizes": [],
 * "customAdSizes": [
 * {
 * "w": 320,
 * "h": 150
 * }
 * ]
 * }
 * },
 * "mediumRectangle": {
 * "active": true,
 * "availableOn": [
 * "b2",
 * "b3",
 * "b4"
 * ],
 * "dfpSizes": {
 * "iosAdSizes": [
 * "kGADAdSizeMediumRectangle"
 * ],
 * "androidAdSizes": [
 * "MEDIUM_RECTANGLE"
 * ],
 * "customAdSizes": []
 * }
 * },
 * "mobileInterstitial": {
 * "active": true,
 * "availableOn": [
 * "int"
 * ],
 * "dfpSizes": {
 * "iosAdSizes": [],
 * "androidAdSizes": [],
 * "customAdSizes": [
 * {
 * "w": 320,
 * "h": 480
 * }
 * ]
 * }
 * },
 * "fullBanner-468x60": {
 * "active": true,
 * "availableOn": [],
 * "dfpSizes": {
 * "iosAdSizes": [
 * "kGADAdSizeFullBanner"
 * ],
 * "androidAdSizes": [
 * "FULL_BANNER"
 * ],
 * "customAdSizes": []
 * }
 * },
 * "leaderboard-728x90": {
 * "active": true,
 * "availableOn": [],
 * "dfpSizes": {
 * "iosAdSizes": [
 * "kGADAdSizeLeaderboard"
 * ],
 * "androidAdSizes": [
 * "LEADERBOARD"
 * ],
 * "customAdSizes": []
 * }
 * }
 * },
 * "modules": [
 * {
 * "PREBID": {
 * "yieldloveAccountId": "t-online"
 * }
 * },
 * {
 * "SOURCEPOINT": {
 * "sourcepointAccountId": "375",
 * "active": true,
 * "propertyId": "12345",
 * "propertyName": "test.ios.app",
 * "privacyManagerId": "51252"
 * }
 * }
 * ],
 * "openRtb": {
 * "apis": [
 * {
 * "framework": 3
 * },
 * {
 * "framework": 5
 * },
 * {
 * "framework": 6
 * }
 * ]
 * },
 * "zonesAndPageTypes": {
 * "level1": {
 * "homepage": {
 * "keyValues": {
 * "test": "testValue"
 * }
 * }
 * },
 * "level2": {
 * "sport": {
 * "keyValues": {
 * "country": "de"
 * }
 * }
 * },
 * "pageType": {
 * "rubrik": {
 * "keyValues": {
 * "sport": "football"
 * }
 * }
 * }
 * },
 * "adSlots": {
 * "b1": {
 * "prebidConfigId": "23904",
 * "autoRefreshTimeMs": "1000",
 * "rtaAuction": true,
 * "keyValues": {
 * "af": "moad2x1,moad3x1,moad4x1,moad6x1,mpres2x1,mpres3x1,mpres4x1,mpres6x1",
 * "adslot": "topmobile",
 * "as": "topmobile"
 * },
 * "customAdSizes": [
 * {
 * "w": 37,
 * "h": 31
 * }
 * ]
 * },
 * "b2": {
 * "prebidConfigId": "23928",
 * "rtaAuction": false,
 * "keyValues": {
 * "af": "moad2x1,moad3x1,moad4x1,moad6x1,mrec",
 * "adslot": "topmobile2",
 * "as": "topmobile2"
 * },
 * "customAdSizes": [
 * {
 * "w": 37,
 * "h": 32
 * }
 * ]
 * },
 * "b3": {
 * "prebidConfigId": "23931",
 * "keyValues": {
 * "af": "moad2x1,moad3x1,moad4x1,moad6x1,mrec",
 * "adslot": "topmobile3",
 * "as": "topmobile3"
 * },
 * "customAdSizes": [
 * {
 * "w": 37,
 * "h": 33
 * }
 * ]
 * },
 * "b4": {
 * "prebidConfigId": "23933",
 * "keyValues": {
 * "af": "moad2x1,moad3x1,moad4x1,moad6x1,mrec",
 * "adslot": "topmobile4",
 * "as": "topmobile4"
 * },
 * "customAdSizes": [
 * {
 * "w": 37,
 * "h": 34
 * }
 * ]
 * },
 * "b5": {
 * "prebidConfigId": "23934",
 * "keyValues": {
 * "af": "moad6x1,stick",
 * "adslot": "topmobile5",
 * "as": "topmobile5"
 * },
 * "customAdSizes": [
 * {
 * "w": 37,
 * "h": 35
 * }
 * ]
 * },
 * "int": {
 * "prebidConfigId": "23935",
 * "keyValues": {
 * "af": "int",
 * "adslot": "interstitial",
 * "as": "interstitial"
 * },
 * "customAdSizes": [
 * {
 * "w": 40,
 * "h": 31
 * }
 * ]
 * }
 * }
 * }
 */
class Configuration {
    var common: ConfigCommon? = null
    var formats: MutableMap<String, ConfigFormat?>? = null
    var modules: ConfigModules = ConfigModules()
    var openRtb: ConfigOpenRtb? = null
    var zonesAndPageTypes: ConfigZonesAndPageTypes? = null
    var adSlots: MutableMap<String, ConfigAdSlot?>? = null
    var tasks: ConfigTasks? = null

    val isValid: Boolean
        get() = common != null

    companion object {
        @JvmStatic
        fun fromJson(json: String?): Configuration? {
            val gson = GsonBuilder()
                .registerTypeAdapter(ConfigModules::class.java, ConfigModules_Deserializer())
                .registerTypeAdapter(ConfigAdSlot::class.java, ConfigAdSlot_Deserializer())
                .create()

            val config = gson.fromJson(json, Configuration::class.java)
            if (config == null) {
                throw JsonParseException("Failed to parse Configuration JSON")
            }
            return config
        }
    }

    fun getAdSlot(publisherSlotName: String): ConfigAdSlot? {
        val adSlot = adSlots?.get(publisherSlotName)
        adSlot?.let{
            return adSlot
        }

        return adSlots?.get(getPlacementName(publisherSlotName))
    }

    fun getBannerNames(): List<String> =
        adSlots
            ?.mapNotNull { (name, slot) -> name.takeIf { slot?.isBanner() == true } }
            ?: emptyList()

    fun getInterstitialNames() : List<String> =
        adSlots
            ?.mapNotNull { (name, slot) -> name.takeIf { slot?.isInterstitial() == true } }
            ?: emptyList()


    fun getPlacementName(publisherSlotName: String) : String{
        return getSlotNameWithoutSdiPrefix(publisherSlotName)
    }

    fun getSlotNameWithoutSdiPrefix(publisherSlotName: String): String {
        if(publisherSlotName.isEmpty()){
            throw Exception("publisherSlotName is empty")
        }
        try {
            if (common != null && common!!.isSDI) {
                val adSlotNameParts: Array<String?> =
                    publisherSlotName.split("_".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                return adSlotNameParts[adSlotNameParts.size - 1] ?: publisherSlotName
            }
        }catch(e: Exception){
            Logger.e("[Configuration] Failed to parse adSlotName", e)
        }
        return publisherSlotName
    }

    fun getAdUnitId(publisherSlotName: String): String {
        val dfpAppNetwork: String = this.common!!.dfpAppNetwork!!

        val adSlotNameWithoutSuffix: String = publisherSlotName.replaceFirst("\\?.*".toRegex(), "")

        if (common!!.isSDI ) {
            return "/$dfpAppNetwork/${this.common!!.dfpAndroidAppName}/$adSlotNameWithoutSuffix"
        }

        return "/$dfpAppNetwork/$adSlotNameWithoutSuffix"
    }
}
