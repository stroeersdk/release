package com.stroeer.ads.formats.banner

import com.stroeer.ads.exceptions.StroeerException

interface IBannerListenerRunner{
    fun onAdClosed()
    fun onAdFailedToLoad(error:StroeerException)
    fun onAdOpened()
    fun onAdLoaded()
    fun onAdClicked()
    fun onAdImpression()
}