package com.stroeer.ads.formats.banner

import android.content.Context
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.admanager.AdManagerAdView
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.ConfigAdSlot
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.refresh.RefreshTimer
import com.stroeer.ads.bidding.prebid.PrebidBannerView
import com.stroeer.ads.bidding.prebid.PrebidHtmlBannerView
import com.stroeer.utilities.logging.Logger
import org.prebid.mobile.rendering.bidding.listeners.BannerEventListener

/**
 * Holds configuration for a single banner ad instance.
 *
 * Extends [AAdConfiguration] to add banner-specific properties such as
 * refresh timers, listeners, and the underlying [AdManagerAdView].
 */
class BannerConfiguration(context: Context) : AAdConfiguration(context) {

    /** Listener for banner ad lifecycle events (load, click, impression, etc.). */
    var userListener: IStroeerBannerListener? = null

    /** The Main BannerView containing GAM / Prebid / Gravite **/
    var bannerView: StroeerBannerView? = null

    /** Optional timer used for auto-refreshing the banner at a defined interval. */
    var timer: RefreshTimer? = null

    /** Refresh interval (in milliseconds) for auto-refreshing the banner. */
    var refreshTime: Int? = null

    var isRefreshing : Boolean = false

    /** The Google Ad Manager ad view associated with this configuration. */
    var adManagerAdView: AdManagerAdView? = null

    /** The Prebid BannerView associated with this configuration. */
    var prebidBannerView: PrebidBannerView? = null
    var prebidEventHandler : BannerEventListener? = null
    var prebidHtmlBannerView : PrebidHtmlBannerView? = null

    /** Gravite View */
    var graviteView: View? = null

    var availableBannerSizes: Array<AdSize> = arrayOf()

    /**
     * Initializes the configuration with the given placement name.
     *
     * - Calls the parent [AAdConfiguration.initialize].
     * - Retrieves configuration data from [ConfigurationManager].
     * - Extracts the `autoRefreshTimeMs` for this specific ad slot, if available.
     *
     * @param publisherSlotName The publisher slot name identifying this banner placement.
     */
    override fun initialize(publisherSlotName: String) {
        super.initialize(publisherSlotName)
        refreshTime = configAdSlot?.autoRefreshTimeMs
        // availableBannerSizes = configAdSlot.
        configAdSlot?.let{
            populateAvailableBannerSizes(it)
        }
    }

    /**
     * Cleans up resources used by this banner configuration.
     *
     * - Calls the parent [AAdConfiguration.destroy].
     * - Cancels and clears any active [RefreshTimer].
     * - Releases the [userListener] reference to avoid memory leaks.
     */
    override fun destroy() {
        timer?.clearScheduledTasks()
        timer = null
        userListener = null

        destroyViews()
        super.destroy()
    }

    override fun destroyViews(){
        bannerView?.removeAllViews()

        adManagerAdView?.let{
            try {
                val parent = it.parent as View?
                if (parent is ViewGroup) {
                    parent.removeView(it)
                }
            } catch (e: Exception) {
                Logger.e("[BannerConfiguration] Failed to remove AdView from parent", e)
            }
            it.adListener = object : AdListener() {}
            it.destroy()
            adManagerAdView = null
            Logger.d("[BannerConfiguration] GAM Banner is destroyed - $publisherSlotName")
        }

        prebidBannerView?.let{
            it.setBannerListener(null)
            it.destroy()
            Logger.d("[BannerConfiguration] Prebid Banner is destroyed - $publisherSlotName")
            prebidBannerView = null
            prebidEventHandler = null
        }


        graviteView?.let { obj ->
            try {
                obj.javaClass.getMethod("destroy").invoke(obj)
            } catch (_ : Exception) {
                Logger.e("[BannerConfiguration] Failed to destroy Gravite Banner")
            }
            graviteView = null
            Logger.d("[BannerConfiguration] Gravite Banner is destroyed - $publisherSlotName")
        }

        prebidHtmlBannerView?.let {obj->
            obj.destroy()
            prebidHtmlBannerView = null
            Logger.d("[BannerConfiguration] Prebid HTML Banner is destroyed - $publisherSlotName")
        }

        Logger.i("[BannerConfiguration] Banner is destroyed - $publisherSlotName")
    }

    private fun populateAvailableBannerSizes(configAd: ConfigAdSlot) {
        val list = mutableListOf<AdSize>()

        // Add custom sizes from configuration
        configAd.customAdSizes?.let { cusSizes ->
            for (size in cusSizes) {
                list.add(AdSize(size.w, size.h))
            }
        }

        // Add sizes from formats
        val formats = ConfigurationManager.getInstance().getConfig()?.formats
        formats?.let {
            formats.forEach{ (_, value)->
                if(value?.active == true){
                    if(value.availableOn?.contains(placementName) == true){

                        value.dfpSizes?.let{ dfpSizes->
                            // Add DFP sizes if available
                            list.addAll(dfpSizes.convertBannerSizesForDfp())

                            // Add custom sizes from DFP configuration if available
                            dfpSizes.customAdSizes?.let { cusSizes ->
                                for (size in cusSizes) {
                                    list.add(AdSize(size.w, size.h))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (list.isEmpty()) {
            list.add(AdSize(0, 0))
        }

        availableBannerSizes = list.toTypedArray()
    }
}