package com.stroeer.ads.consent

class ConsentEvaluatorIAB(private val reader: IConsentReader) : IConsentEvaluator {
    override fun evaluateConsentRequired(vendorId: Int, purposeId: Int): Boolean {
        return this.hasVendorAndPurposeConsent(vendorId, purposeId)
    }

    override fun evaluateLegitimateInterestRequired(vendorId: Int, purposeId: Int): Boolean {
        return this.hasVendorAndPurposeConsent(
            vendorId,
            purposeId
        ) || this.hasLiVendorAndPurposeConsent(vendorId, purposeId)
    }

    private fun hasVendorAndPurposeConsent(vendorId: Int, purposeId: Int): Boolean {
        val vendorsConsent = this.reader.vendorConsents
        val purposesConsent = this.reader.purposeConsents

        return this.consentBinaryStringContains(vendorsConsent, vendorId) &&
                this.consentBinaryStringContains(purposesConsent, purposeId)
    }

    private fun hasLiVendorAndPurposeConsent(vendorId: Int, purposeId: Int): Boolean {
        val vendorsLiConsent = this.reader.vendorLIConsents
        val purposesLiConsent = this.reader.purposeLIConsents

        return this.consentBinaryStringContains(vendorsLiConsent, vendorId) &&
                this.consentBinaryStringContains(purposesLiConsent, purposeId)
    }

    private fun consentBinaryStringContains(binaryString: String?, id: Int): Boolean {
        if (binaryString != null && !binaryString.isEmpty() && binaryString.length >= id) {
            return binaryString[this.convertIdToIndex(id)] == symbolOfBinaryPermission
        }
        return false
    }

    private fun convertIdToIndex(vendorId: Int): Int {
        return vendorId - 1
    }

    companion object Companion {
        private const val symbolOfBinaryPermission = '1'
    }
}

