package com.stroeer.ads.formats

import android.content.Context
import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.bidding.gam.GamRequestBuilder
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.ConfigAdSlot
import com.stroeer.ads.consent.ConsentReaderIAB
import com.stroeer.ads.debugInfo.IDebugInfo
import com.stroeer.ads.reporting.ISession
import com.stroeer.utilities.logging.Logger
import java.lang.ref.WeakReference

/**
 * Base class that holds ad configuration and initialization logic for ad units.
 * Manages configuration loading, consent readers, and ad-related session data.
 *
 * @property context The Android context used for initialization.
 */
abstract class AAdConfiguration(private val context: Context){
    /** Optional debug information object used for developer/QA inspections. */
    var debugInfo: IDebugInfo? = null
    var prebidAdUnit: org.prebid.mobile.AdUnit? = null
    var identifier: String? = null

    var adSize: org.prebid.mobile.AdSize? = null
    var requestTimeoutInMs : Long = 3000

    var realTimeAuctionEnabled : Boolean = true  // rtaAction
    var contentUrl: String? = null

    // Full ad unit ID. ex// "/1234567/sports/banner"
    var adUnitId : String = ""

    /** Weak reference to the activity context to avoid memory leaks. */
    private var activityContextRef: WeakReference<Context> = WeakReference(context)

    /** Returns the current activity context if still valid, otherwise null. */
    val activityContext: Context?
        get() = activityContextRef.get()

    /** Returns the application context if the activity context is available. */
    val applicationContext: Context?
        get() = activityContext?.applicationContext

    /** Name of the publisher-defined slot where this ad will be displayed. */
    @Suppress("PropertyName")
    protected lateinit var _publisherSlotName: String
    var publisherSlotName get() = if(::_publisherSlotName.isInitialized) _publisherSlotName else "undefined"
        set(value) { _publisherSlotName = value}

    var placementName : String = ""

    /** The session object that tracks reporting and analytics for this ad. */
    var session: ISession? = null
    fun sessionStart() {
        session?.start()
    }
    fun sessionEnd(){
        session?.stop()
    }

    /** current status of the ad */
    var status = AdStatus.UNINITIALIZED
        set(value) {
            if(field != value)
                Logger.d("[${this::class.simpleName}] \"$publisherSlotName\" status changed: ($field->$value)")
            field = value
        }

    fun setReady() {
        if(status.isLoading())
            status = AdStatus.READY
    }

    fun setError(){ status = AdStatus.ERROR }

    /** Information about the ad source (DSP, network, etc.). */
    var source: AdSourceInfo = AdSourceInfo()

    /** Request builder used for constructing ad requests. */
    var requestBuilder: GamRequestBuilder? = null

    /** Local builder instance for creating ad requests (lazily initialized). */
    var localBuilder : AdManagerAdRequest.Builder? = null

    /** Reader for IAB TCF consent strings. */
    val consentReader: ConsentReaderIAB = ConsentReaderIAB(context)

    var configAdSlot : ConfigAdSlot? = null

    var customTargeting : MutableMap<String, String> = mutableMapOf()
    /**
     * Initializes the ad configuration with a given placement name.
     *
     * @param publisherSlotName The publisher slot name for this ad placement.
     */
    open fun initialize(publisherSlotName: String) {

        val config = ConfigurationManager.getInstance().getConfig()!!

        this.publisherSlotName = publisherSlotName
        status = AdStatus.LOADING

        placementName = config.getPlacementName(publisherSlotName)

        configAdSlot = config.getAdSlot(placementName)

        configAdSlot?.let{ config ->
            realTimeAuctionEnabled = config.rtaAuction ?: true
        }

        requestTimeoutInMs = ConfigurationManager.getInstance().requestTimeout

        adUnitId = createAdUnitId(publisherSlotName)
    }

    /**
     * Cleans up and releases references to avoid memory leaks.
     * Should be called when the ad configuration is no longer needed.
     */
    open fun destroy() {
        Logger.d("[AdConfiguration] Destroy - $publisherSlotName")
        activityContextRef.clear()
        requestBuilder = null
        localBuilder = null
        status = AdStatus.DESTROYED
    }

    open fun destroyViews(){

    }

    protected fun createAdUnitId(adSlotName: String): String {
        return ConfigurationManager.getInstance().getConfig()!!.getAdUnitId(adSlotName)
    }
}