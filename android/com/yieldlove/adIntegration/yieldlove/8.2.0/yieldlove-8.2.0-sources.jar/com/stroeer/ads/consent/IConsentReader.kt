package com.stroeer.ads.consent

interface IConsentReader {
    val vendorConsents: String?
    val purposeConsents: String?
    val vendorLIConsents: String?
    val purposeLIConsents: String?
    fun getPublisherRestrictionsFor(purposeId: Int): String?
}
