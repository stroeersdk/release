package com.stroeer.plugins.identity.collectors

import com.stroeer.plugins.identity.ACollectorWithContext

/**
 * Return language
 */
class LanguageCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        val locales = applicationContext.resources.configuration.locales
        val acceptLanguage = StringBuilder()

        for (i in 0 until locales.size()) {
            val locale = locales[i]
            acceptLanguage.append(locale.toLanguageTag())

            if (i == 0) {
                acceptLanguage.append(",")
            } else {
                acceptLanguage.append(";q=").append("%.1f".format(1.0 - (i * 0.1)))
                if (i < locales.size() - 1) {
                    acceptLanguage.append(",")
                }
            }
        }
        return acceptLanguage.toString()
    }
}
