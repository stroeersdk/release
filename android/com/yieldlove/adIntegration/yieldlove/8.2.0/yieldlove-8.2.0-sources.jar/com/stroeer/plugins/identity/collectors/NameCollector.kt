package com.stroeer.plugins.identity.collectors

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.plugins.identity.IIdentityCollector

/**
 * Return app name
 */
class NameCollector : IIdentityCollector<String?> {
    override suspend fun retrieveData(): String? {
        return ConfigurationManager.getInstance().getConfig()?.common?.dfpAndroidAppName
    }
}
