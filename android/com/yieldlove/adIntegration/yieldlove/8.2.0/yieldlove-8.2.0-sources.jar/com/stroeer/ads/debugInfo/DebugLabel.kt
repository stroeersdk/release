package com.stroeer.ads.debugInfo

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.widget.AppCompatTextView

class DebugLabel(context: Context, attrs: AttributeSet?) : AppCompatTextView(context, attrs) {
    private var debugInfo: IDebugInfo? = null

    private val handleTouch: OnTouchListener = object : OnTouchListener {
        @SuppressLint("ClickableViewAccessibility")
        override fun onTouch(v: View?, event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_UP) {
                showDebugInfoPanel()
            }

            return true
        }
    }

    init {
        initView()
    }

    fun setDebugInfo(debugInfo: IDebugInfo) {
        this.debugInfo = debugInfo
        this.text = getDebugLabelText(debugInfo)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initView() {
        this.setTextColor(Color.WHITE)
        this.setOnTouchListener(handleTouch)
    }

    private fun getDebugLabelText(debugInfo: IDebugInfo): StringBuilder {
        val labelText = StringBuilder()
        labelText.append("Banner: ").append(debugInfo.publisherSlotName)
        labelText.append("\nServed in: ").append(debugInfo.servedInTime).append(" ms")
        return labelText
    }

    private fun showDebugInfoPanel() {
        debugInfo?.let {
            val intent = DebuggerActivity.createIntent(this.context)
            intent.putExtra(DebuggerActivity.AD_UNIT_ID, debugInfo!!.publisherSlotName)
            // DebugInfoManager.getInstance().addDebugInfo(debugInfo!!)
            context.startActivity(intent)
        }
    }
}
