package com.stroeer.utilities.json

import com.stroeer.utilities.concurrent.ACoroutinable
import com.stroeer.utilities.http.SharedHttpClient.createClientWithTimeout
import com.stroeer.utilities.logging.Logger
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response

class HttpJsonRequest : ACoroutinable(){

    suspend fun sendGetJson(
        url: String,
        headers: Map<String, String>?,
        timeoutInSecs: Int,
        senderClass: Class<*>
    ): String? {
        return withContext(ioDispatcher) {
            val request = createBuilder(url, headers)
                .get()
                .build()

            sendRequest(request, timeoutInSecs, senderClass)
        }
    }

    suspend fun sendPostJson(
        url: String,
        headers: Map<String, String>?,
        body: RequestBody,
        timeoutInSecs: Int,
        senderClass: Class<*>
    ): String? {
        return withContext(ioDispatcher) {
            val request = createBuilder(url, headers)
                .post(body)
                .build()

            sendRequest(request, timeoutInSecs, senderClass)
        }
    }

    private fun sendRequest(
        request: Request,
        timeoutInSecs: Int,
        senderClass: Class<*>
    ): String? {
        val resolvedTimeoutInSecs = if (timeoutInSecs > 0) timeoutInSecs else 5
        val client = createClient(resolvedTimeoutInSecs)
        val senderClassName = senderClass.simpleName

        return try {
            client.newCall(request).execute().use { response ->
                handleResponse(response, request, senderClassName)
            }
        } catch (e: Exception) {
            Logger.e(
                "[$senderClassName] Failed to fetch data - ${e.message}",
                e
            )
            null
        }
    }

    private fun createClient(timeoutInSecs: Int): OkHttpClient {
        return createClientWithTimeout(timeoutInSecs)
    }

    private fun createBuilder(
        url: String,
        headers: Map<String, String>?
    ): Request.Builder {
        val builder = Request.Builder()
            .url(url)

        headers?.forEach { (key, value) ->
            builder.addHeader(key, value)
        }

        return builder
    }

    private fun handleResponse(
        response: Response,
        request: Request,
        senderClassName: String
    ): String? {
        val responseBody = response.body

        if (response.isSuccessful && responseBody != null) {
            Logger.d("[$senderClassName] Fetched data successfully: ${request.url}")
            return responseBody.string()
        }

        val errorBody = responseBody?.string()
        if (errorBody != null) {
            Logger.e("[$senderClassName] Failed to fetch data - ${response.message}\n$errorBody")
        } else {
            Logger.e("[$senderClassName] Failed to fetch data - ${response.message}")
        }

        return null
    }
}