package com.stroeer.ads.consent

import android.content.Context
import androidx.preference.PreferenceManager

class ConsentReaderIAB(// see IABTCF strings
    // in https://github.com/InteractiveAdvertisingBureau/GDPR-Transparency-and-Consent-Framework/blob/master/TCFv2/IAB%20Tech%20Lab%20-%20CMP%20API%20v2.md#in-app-details
    private val applicationContext: Context
) : IConsentReader {
    override val vendorConsents: String
        get() = this.getBinaryStringFromSharedPreferences(IABTCF_VendorConsents_KEY)

    override val purposeConsents: String
        get() = this.getBinaryStringFromSharedPreferences(IABTCF_PurposeConsents_KEY)

    override val vendorLIConsents: String
        get() = this.getBinaryStringFromSharedPreferences(IABTCF_VendorLIConsents_KEY)

    override val purposeLIConsents: String
        get() = this.getBinaryStringFromSharedPreferences(IABTCF_PurposeLIConsents_KEY)

    override fun getPublisherRestrictionsFor(purposeId: Int): String {
        return this.getPublisherRestrictionsFromSharedPreferences(purposeId)
    }

    val tCString: String
        get() = this.getBinaryStringFromSharedPreferences(IABTCF_TCString_KEY)

    private fun getPublisherRestrictionsFromSharedPreferences(purposeId: Int): String {
        return PreferenceManager.getDefaultSharedPreferences(applicationContext)
            .getString(this.getPurposeRestrictionKey(purposeId), "")!!
    }

    private fun getBinaryStringFromSharedPreferences(keyName: String?): String {
        return PreferenceManager.getDefaultSharedPreferences(applicationContext)
            .getString(keyName, "")!!
    }

    private fun getPurposeRestrictionKey(purposeId: Int): String {
        return IABTCF_PublisherRestrictionsKEY_Pattern.replace(
            IABTCF_PublisherRestrictionsId_ReplaceHolder, purposeId.toString()
        )
    }

    @Suppress("ConstPropertyName")
    companion object Companion {
        const val IABTCF_VendorConsents_KEY: String = "IABTCF_VendorConsents"
        const val IABTCF_PurposeConsents_KEY: String = "IABTCF_PurposeConsents"
        const val IABTCF_VendorLIConsents_KEY: String = "IABTCF_VendorLegitimateInterests"
        const val IABTCF_PurposeLIConsents_KEY: String = "IABTCF_PurposeLegitimateInterests"
        const val IABTCF_PublisherRestrictionsKEY_Pattern: String =
            "IABTCF_PublisherRestrictions{ID}"
        const val IABTCF_PublisherRestrictionsId_ReplaceHolder: String = "{ID}"
        const val IABTCF_TCString_KEY: String = "IABTCF_TCString"
    }
}
