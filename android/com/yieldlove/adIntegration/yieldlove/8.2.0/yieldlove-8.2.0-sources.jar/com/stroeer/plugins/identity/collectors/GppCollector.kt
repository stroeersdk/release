package com.stroeer.plugins.identity.collectors

import androidx.preference.PreferenceManager
import com.stroeer.plugins.identity.ACollectorWithContext
import java.util.concurrent.CompletableFuture

/**
 * Return GPP. Collect from IABTCF_GPP.
 */
class GppCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        val consentString = sharedPreferences.getString(PREFERENCES_NAME, null)
        return if (consentString.isNullOrEmpty()) {
            null
        } else {
            consentString
        }
    }

    companion object {
        private const val PREFERENCES_NAME = "IABTCF_GPP"
    }
}
