package com.stroeer.ads.bidding.prebid

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import com.stroeer.utilities.logging.Logger
import org.prebid.mobile.AdSize
import org.prebid.mobile.api.rendering.BannerView
import org.prebid.mobile.api.rendering.listeners.BannerViewListener
import org.prebid.mobile.rendering.bidding.interfaces.BannerEventHandler
import org.prebid.mobile.rendering.bidding.listeners.BannerEventListener
import java.lang.ref.WeakReference

class PrebidBannerView : BannerView {

    var price : Double? = null
    var targeting : Map<String, String> = mapOf()

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, configId: String, size: AdSize) : super(context, configId, size)
    constructor(context: Context, configId: String, eventHandler: BannerEventHandler) : super(
        context,
        configId,
        eventHandler
    )

    override fun destroy(){
        clearAnimation()
        super.destroy()
        try {
            val parent = parent as View?
            if (parent is ViewGroup) {
                parent.removeView(this)
            }
        } catch (e: Exception) {
            Logger.e("[BannerConfiguration] Failed to remove Prebid BannerView from parent", e)
        }
    }

    fun isDirectRenderingEnabled() : Boolean{
        return targeting["dr"] == "true"
    }
}