package com.stroeer.plugins.identity.collectors

import android.webkit.WebSettings
import com.stroeer.plugins.identity.ACollectorWithContext

/**
 * Return user agent
 */
class UaCollector : ACollectorWithContext<String?>() {
    override suspend fun retrieveData(): String? {
        return WebSettings.getDefaultUserAgent(applicationContext)
    }
}
