package com.stroeer.ads.bidding.prebid

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.AttributeSet
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.net.toUri
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.banner.IBannerListenerRunner
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.roundToInt

class PrebidHtmlBannerView : FrameLayout {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val listenerRef = AtomicReference<IBannerListenerRunner?>()

    private val destroyed = AtomicBoolean(false)
    private val loadedSent = AtomicBoolean(false)
    private val failedSent = AtomicBoolean(false)
    private val impressionSent = AtomicBoolean(false)
    private val browserOpened = AtomicBoolean(false)

    private val loadGeneration = AtomicInteger(0)
    private val sizeLock = Any()

    private var webView: WebView? = null
    private val LOCALHOST_BASE_URL : String = "https://localhost/"
    private val lastBaseUrl: String = LOCALHOST_BASE_URL
    private var lastHtml: String? = null

    private var sizeWidthPx: Int = 0
    private var sizeHeightPx: Int = 0

    private var loadTimeoutMs: Long = 8000L
    private var watchdogRunnable: Runnable? = null

    constructor(context: Context) : super(context) { initView() }
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) { initView() }
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) { initView() }

    fun setListener(listener: IBannerListenerRunner) {
        listenerRef.set(listener)
    }

    fun setLoadTimeoutMs(timeoutMs: Long) {
        loadTimeoutMs = if (timeoutMs > 0L) timeoutMs else 8000L
    }

    fun setAdSize(widthDp: Int, heightDp: Int) {

        if (destroyed.get()) {
            return
        }

        val metrics = resources.displayMetrics
        sizeWidthPx = dpToPx(widthDp, metrics)
        sizeHeightPx = dpToPx(heightDp, metrics)

        runOnMain(Runnable { applySize() })
    }

    fun setHtml(html: String) {
        if (destroyed.get()) {
            return
        }

        lastHtml = html

        val gen = loadGeneration.incrementAndGet()
        loadedSent.set(false)
        failedSent.set(false)
        impressionSent.set(false)

        viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                if (!isShown) return true

                // Once the webview is shown, then don't draw again.
                viewTreeObserver.removeOnPreDrawListener(this)
                runOnMain(Runnable {
                    if (destroyed.get()) {
                        return@Runnable
                    }
                    val wv = ensureWebView()
                    applySize()
                    prepareForNewLoad(wv, gen)
                    scheduleWatchdog(gen)

                    try {
                        wv.loadDataWithBaseURL(lastBaseUrl, HTMLInjector.wrapHtml(lastHtml ?: "", gen, sizeWidthPx, sizeHeightPx), "text/html", StandardCharsets.UTF_8.name(), null)
                        notifyImpression()
                    } catch (t: Throwable) {
                        notifyFailedOnce(StroeerException("PrebidHtmlBannerView: loadDataWithBaseURL failed - $t"), gen)
                    }
                })

                return true
            }
        })
    }

    fun onHostResumed() {
        if (browserOpened.compareAndSet(true, false)) {
            runOnMain(Runnable { notifyClosed() })
        }
        runOnMain(Runnable {
            resumeWebView()
        })
    }

    fun onHostPaused() {
        runOnMain(Runnable {
            resumeWebView()
        })
    }

    fun destroy() {
        if (!destroyed.compareAndSet(false, true)) {
            return
        }
        runOnMain(Runnable {
            cancelWatchdog()
            val wv = webView
            webView = null
            removeAllViews()
            if (wv != null) {
                try {
                    wv.stopLoading()
                } catch (_: Throwable) {
                }
                try {
                    wv.webViewClient = WebViewClient()
                } catch (_: Throwable) {
                }
                try {
                    wv.webChromeClient = WebChromeClient()
                } catch (_: Throwable) {
                }
                try {
                    wv.removeAllViews()
                } catch (_: Throwable) {
                }
                try {
                    wv.destroy()
                } catch (_: Throwable) {
                }
            }
        })
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        onHostPaused()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        runOnMain(Runnable {
            resumeWebView()
        })
    }

    private fun resumeWebView() {
        val wv = webView ?: return
        try {
            wv.onResume()
        } catch (_: Throwable) {
        }
    }

    private fun initView() {
        isClickable = true
        isFocusable = true
        runOnMain(Runnable { ensureWebView(); applySize() })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView(): WebView {
        val existing = webView
        if (existing != null) {
            return existing
        }

        val wv = WebView(context.applicationContext)
        wv.visibility = VISIBLE
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.overScrollMode = OVER_SCROLL_NEVER
        wv.setBackgroundColor(0x00000000)
        try {
            wv.setLayerType(LAYER_TYPE_HARDWARE, null)
        } catch (_: Throwable) {
        }

        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadsImagesAutomatically = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        try {
            s.offscreenPreRaster = true
        } catch (_: Throwable) {
        }

        wv.addJavascriptInterface(BannerJsBridge(), "StroeerBridge")

        wv.webChromeClient = object : WebChromeClient() {

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val transport = resultMsg.obj as WebView.WebViewTransport
                val tmp = WebView(view.context)
                tmp.settings.javaScriptEnabled = true
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        val u = request.url?.toString() ?: return true
                        openExternalFromWebView(u)
                        return true
                    }

                    @Deprecated("Deprecated in Java")
                    override fun shouldOverrideUrlLoading(v: WebView, url: String): Boolean {
                        openExternalFromWebView(url)
                        return true
                    }
                }
                transport.webView = tmp
                resultMsg.sendToTarget()
                return true
            }
        }

        wv.webViewClient = object : WebViewClient() {

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                injectImpressionAndClickTracking(view, loadGeneration.get())
                notifyLoadedOnce(loadGeneration.get())
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url?.toString()
                if (u.isNullOrBlank()) {
                    return false
                }
                return handleNavigation(u, request.isForMainFrame, request.hasGesture())
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleNavigation(url, true, false)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    notifyFailedOnce(StroeerException("PrebidHtmlBannerView: WebView error ${error.errorCode}: ${error.description}"), loadGeneration.get())
                }
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                notifyFailedOnce(StroeerException("PrebidHtmlBannerView: render process gone"), loadGeneration.get())

                // if somehow webview is broken, then hide it and prevent further issues
                runOnMain{
                    webView?.let { wv ->
                        try {
                            (wv.parent as? ViewGroup)?.removeView(wv)
                        } catch (_: Throwable) { }
                    }
                    webView = null

                    visibility = GONE
                    layoutParams = layoutParams?.apply {
                        height = 0
                        width = 0
                    } ?: LayoutParams(0, 0)
                    requestLayout()
                }
                return true
            }
        }

        removeAllViews()
        addView(wv)
        webView = wv
        return wv
    }

    private fun applySize(){
        if (destroyed.get()) {
            return
        }

        applySize(this, false)
        webView?.let{
            applySize(it, true)
        }
    }

    private fun applySize(target: View, allowWrapContentFallback: Boolean) {
        val width = if (sizeWidthPx > 0) sizeWidthPx else if (allowWrapContentFallback) LayoutParams.WRAP_CONTENT else return
        val height = if (sizeHeightPx > 0) sizeHeightPx else if (allowWrapContentFallback) LayoutParams.WRAP_CONTENT else return

        val params = (target.layoutParams as? LayoutParams)
            ?: LayoutParams(width, height)

        params.width = width
        params.height = height
        params.gravity = Gravity.CENTER_HORIZONTAL

        target.layoutParams = params
        target.requestLayout()
    }

    private fun prepareForNewLoad(wv: WebView, gen: Int) {
        cancelWatchdog()
        try {
            wv.stopLoading()
        } catch (_: Throwable) {
        }
        try {
            wv.loadUrl("about:blank")
        } catch (_: Throwable) {
        }
        loadedSent.set(false)
        failedSent.set(false)
        impressionSent.set(false)
        if (gen == loadGeneration.get()) {
            wv.visibility = VISIBLE
        }
    }

    private fun scheduleWatchdog(gen: Int) {
        cancelWatchdog()
        val r = Runnable {
            if (destroyed.get()) {
                return@Runnable
            }
            if (gen != loadGeneration.get()) {
                return@Runnable
            }
            if (loadedSent.get() || failedSent.get()) {
                return@Runnable
            }
            notifyFailedOnce(StroeerException("PrebidHtmlBannerView: load timeout ${loadTimeoutMs}ms"), gen)
        }
        watchdogRunnable = r
        mainHandler.postDelayed(r, loadTimeoutMs)
    }

    private fun cancelWatchdog() {
        watchdogRunnable?.also { mainHandler.removeCallbacks(it) }
        watchdogRunnable = null
    }

    private fun handleNavigation(url: String, isMainFrame: Boolean, hasGesture: Boolean): Boolean {
        val lower = url.lowercase()

        if (lower.startsWith("about:") || lower.startsWith("data:") || lower.startsWith("javascript:")) {
            return false
        }

        if (isLocalhostNav(lower)) {
            return true
        }

        if (!hasGesture && !isMainFrame) {
            return true
        }

        openExternalFromWebView(url)
        return true
    }

    private fun isLocalhostNav(lower: String): Boolean {
        return lower == LOCALHOST_BASE_URL || lower == "http://localhost/" || lower.startsWith(LOCALHOST_BASE_URL) || lower.startsWith("http://localhost/")
    }

    private fun openExternalFromWebView(url: String) {
        if (destroyed.get()) {
            return
        }

        val lower = url.lowercase()
        if (lower.startsWith("about:") || lower.startsWith("data:") || lower.startsWith("javascript:")) {
            return
        }
        if (isLocalhostNav(lower)) {
            return
        }

        notifyClicked()
        val intent = Intent(Intent.ACTION_VIEW, safeUri(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
            browserOpened.set(true)
            notifyOpened()
        } catch (e: ActivityNotFoundException) {
            notifyFailedOnce(StroeerException("PrebidHtmlBannerView: no handler for url=$url - $e"), loadGeneration.get())
        } catch (t: Throwable) {
            notifyFailedOnce(StroeerException("PrebidHtmlBannerView: failed to open browser for url=$url - $t"), loadGeneration.get())
        }
    }

    @SuppressLint("UseKtx")
    private fun safeUri(url: String): Uri {
        return try {
            url.toUri()
        } catch (_: Throwable) {
            Uri.parse(url)  // Just in case
        }
    }

    private fun injectImpressionAndClickTracking(view: WebView, gen: Int) {
        if (destroyed.get() || gen != loadGeneration.get()) {
            return
        }

        try {
            view.evaluateJavascript(HTMLInjector.injectImpressionAndClickTracking(), null)
        } catch (_: Throwable) {
        }
    }

    private fun runOnMain(block: Runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block.run()
        } else {
            mainHandler.post(block)
        }
    }

    private fun notifyLoadedOnce(gen: Int) {
        if (destroyed.get()) {
            return
        }
        if (gen != loadGeneration.get()) {
            return
        }
        if (failedSent.get()) {
            return
        }
        if (!loadedSent.compareAndSet(false, true)) {
            return
        }
        cancelWatchdog()
        val l = listenerRef.get() ?: return
        runOnMain(Runnable { l.onAdLoaded() })
    }

    private fun notifyFailedOnce(error: StroeerException, gen: Int) {
        if (destroyed.get()) {
            return
        }
        if (gen != loadGeneration.get()) {
            return
        }
        if (loadedSent.get()) {
            return
        }
        if (!failedSent.compareAndSet(false, true)) {
            return
        }
        cancelWatchdog()
        val l = listenerRef.get() ?: return
        runOnMain { l.onAdFailedToLoad(error) }
    }

    private fun notifyOpened() {
        val l = listenerRef.get() ?: return
        runOnMain{l.onAdOpened() }
    }

    private fun notifyClosed() {
        val l = listenerRef.get() ?: return
        runOnMain{ l.onAdClosed() }
    }

    private fun notifyClicked() {
        val l = listenerRef.get() ?: return
        runOnMain { l.onAdClicked() }
    }

    private fun notifyImpression() {
        val l = listenerRef.get() ?: return
        runOnMain { l.onAdImpression() }
    }

    private inner class BannerJsBridge {

        @JavascriptInterface
        fun onClick(href: String?) {
            if (destroyed.get()) {
                return
            }
            val u = href ?: ""
            if (u.isBlank()) {
                notifyClicked()
                return
            }
            runOnMain { openExternalFromWebView(u) }
        }

        @JavascriptInterface
        fun onReady(gen: Int) {
            notifyLoadedOnce(gen)
        }
    }

    private fun dpToPx(dp: Int, metrics: DisplayMetrics): Int {
        return (dp.toFloat() * metrics.density).roundToInt()
    }
}