package com.stroeer.plugins.monitoring;

import android.view.View;
import com.stroeer.utilities.logging.Logger;

import java.util.HashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * AdMonitorRefresher manages ad reloading with scheduling mechanisms, ensuring
 * each ad slot can be reloaded within a defined retry limit and reset after a specific period.
 */
public class AdMonitorRefresher {

    // Maximum number of retry attempts allowed per ad slot
    public final int MAX_RETRY_NUM = 1;

    /**
     * Inner class ResetScheduler handles individual ad reload tracking and scheduling.
     */
    static class ResetScheduler {
        // Time interval for resetting the reload counter (in seconds)
        public final long RESET_TIME = 10;

        private int reloaderCounter = 0; // Counter to track reload attempts
        private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        private ScheduledFuture<?> scheduledTask = null;
        private final Lock lock = new ReentrantLock(); // Lock for thread safety
        protected IAdReloader adReloader; // Ad reloader instance


        /**
         * Constructor that initializes the ResetScheduler with an IAdReloader.
         *
         * @param adReloader the IAdReloader instance.
         */
        public ResetScheduler(IAdReloader adReloader) {
            this.adReloader = adReloader;
        }

        /**
         * Resets the reload counter to zero in a thread-safe manner.
         */
        public void resetCounter() {
            lock.lock(); // Acquire lock to ensure thread safety
            try {
                reloaderCounter = 0;
            } finally {
                lock.unlock(); // Release the lock
            }
        }

        /**
         * Increments the reload counter in a thread-safe manner.
         */
        public void updateCounter() {
            lock.lock(); // Acquire lock to ensure thread safety
            try {
                reloaderCounter++;
            } finally {
                lock.unlock(); // Release the lock
            }
        }


        public void startScheduler() {
            if(scheduledTask != null) {
                scheduledTask.cancel(true);
            }
            updateCounter();

            scheduledTask = scheduler.schedule(this::resetCounter, RESET_TIME, TimeUnit.SECONDS);
        }

        /**
         * Retrieves the current value of the reloader counter in a thread-safe manner.
         *
         * @return the current reload counter.
         */
        public int getCounter() {
            lock.lock();
            try {
                return reloaderCounter;
            } finally {
                lock.unlock();
            }
        }
    }

    // Singleton instance of AdMonitorRefresher
    private static final AdMonitorRefresher instance = new AdMonitorRefresher();

    // HashMap to manage ResetScheduler instances for different ad slots
    private final HashMap<String, ResetScheduler> monitorMaps = new HashMap<>();

    // Private constructor to enforce singleton pattern
    private AdMonitorRefresher() {}

    /**
     * Returns the singleton instance of AdMonitorRefresher.
     *
     * @return the singleton instance.
     */
    public static AdMonitorRefresher getInstance() {
        return instance;
    }

    /**
     * Adds a new IAdReloader to the monitor or updates the existing one.
     *
     * @param adReloader the IAdReloader instance to be added or updated.
     */
    public void addNewReloader(IAdReloader adReloader) {
        String adSlot = adReloader.getAdSlot();

        ResetScheduler monitor = monitorMaps.get(adSlot);
        if (monitor != null) {
            monitor.adReloader = adReloader;
        } else {
            monitorMaps.put(adSlot, new ResetScheduler(adReloader));
        }
    }

    /**
     * Attempts to reload the ad for the specified slot view and placement ID,
     * subject to retry limits and monitoring constraints.
     *
     * @param slotView    the view associated with the ad slot.
     * @param placementId the identifier for the ad placement.
     */
    public void reload(View slotView, String placementId) {
        // Check if the placement ID is valid and exists in the monitor map
        if (placementId == null || !monitorMaps.containsKey(placementId)) {
            Logger.e("[MonitoringPlugin] AdReloader is not initialized");
            return;
        }

        ResetScheduler monitor = monitorMaps.get(placementId);

        // Check if the monitor exists and has not exceeded the retry limit
        if (monitor == null || monitor.getCounter() >= MAX_RETRY_NUM) {
            return;
        }

        monitor.startScheduler();

        // Log the reload attempt and invoke the reload method on the adReloader
        Logger.i("[MonitoringPlugin] Attempted to reload - " + placementId + " (" + monitor.getCounter() + " attempt)");
        if (monitor.adReloader != null) {
            monitor.adReloader.reloadAd(slotView, placementId);
        }
    }

    // In AdMonitorRefresher class (for testing purposes)
    HashMap<String, ResetScheduler> getMonitorMap() {
        return monitorMaps;
    }
}