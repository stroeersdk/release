package com.stroeer.ads.debugInfo

import java.util.Date

class SdkDebugInfo() : ISdkDebugInfo {
    override var publisherSlotName: String? = null // As each sdk has different publisherSlotName, but mostly it will be the same
    override val createdDate: Date = Date()
    override var sdkType  = SdkType.Prebid
    override var description: String? = null
    override var keyValues: MutableMap<String, String?>? = null
    override var requestJson: String? = null
    override var responseJson: String? = null
}