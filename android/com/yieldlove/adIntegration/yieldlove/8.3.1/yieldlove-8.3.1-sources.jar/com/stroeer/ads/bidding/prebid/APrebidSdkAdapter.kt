package com.stroeer.ads.bidding.prebid

import android.content.Context
import android.text.TextUtils
import com.stroeer.ads.config.ConfigConstants
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.debugInfo.NetworkDebugInfo
import com.stroeer.ads.debugInfo.SdkType
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.bidding.ISdkAdapter
import com.stroeer.ads.debugInfo.SdkDebugInfo
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.bidding.SdkResultCode
import com.stroeer.ads.exceptions.ContextException
import com.stroeer.utilities.json.JsonPrinter
import com.stroeer.utilities.json.OrtbJsonHelper
import com.stroeer.utilities.json.OrtbJsonHelper.Companion.apply
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONException
import org.json.JSONObject
import org.prebid.mobile.PrebidEventDelegate
import org.prebid.mobile.PrebidMobile
import org.prebid.mobile.ResultCode
import org.prebid.mobile.TargetingParams
import org.prebid.mobile.api.data.BidInfo
import org.prebid.mobile.rendering.bidding.data.bid.BidResponse
import kotlin.collections.component1
import kotlin.collections.component2
import kotlin.coroutines.resume
import kotlin.time.Duration.Companion.milliseconds

abstract class APrebidSdkAdapter(protected val adConfig : AAdConfiguration, protected val adUnitConverter: AdUnitConverter) : ISdkAdapter {

    override suspend fun prepare(){
        adConfig.config?.let{  config ->
            config.common?.let { common ->
                common.androidStoreUrl?.let {
                    TargetingParams.setStoreUrl(it)
                }
                common.androidBundleId?.let {
                    TargetingParams.setBundleName(it)
                }
                PrebidMobile.setTimeoutMillis(config.prebidRequestTimeout.toInt())
            }
        }
    }

    override suspend fun getBid(): SdkResult {
        this.initPrebidAdUnit()
        return if(this.isSdkInitialized()){
                    this.getBidFromPrebid()
                } else {
                    SdkResult(SdkResultCode.NOT_INITIALIZED, null)
                }
    }

    protected suspend fun getBidFromPrebid(): SdkResult {
        try {
            updateDebugInfoForSend()

            if (adConfig.realTimeAuctionEnabled) {
                this.updateContentUrl()

                return suspendCancellableCoroutine { cont ->
                    cont.invokeOnCancellation { cause ->
                        Logger.w("[Prebid] Continuation cancelled : \"${adConfig.adUnitId}\"\n\t$cause\n")
                    }

                    if(!cont.isActive){
                        Logger.e("[Prebid] Prebid result ${adConfig.adUnitId}")
                        return@suspendCancellableCoroutine
                    }

                    val adUnit = adConfig.prebidAdUnit
                    if (adUnit == null) {
                        Logger.e("[Prebid] No Prebid ad unit available for \"${adConfig.adUnitId}\"")
                        cont.resume(SdkResult.FAILED)
                        return@suspendCancellableCoroutine
                    }

                    // add ad unit
                    adUnit.impOrtbConfig = getImpSetup(adConfig.adUnitId, createTargeting(adConfig))

                    // The coroutine is resumed from this callback. Prebid guarantees it fires within
                    // its configured request timeout (PrebidMobile.setTimeoutMillis, set in prepare()),
                    // so we don't impose a separate timeout here. If the builder's scope is cancelled
                    // first, invokeOnCancellation (above) handles cleanup and the late callback below
                    // is ignored via the cont.isActive guard.
                    adUnit.fetchDemand { bidInfo: BidInfo ->
                        Logger.i("[Prebid] Prebid result: ${bidInfo.resultCode}")
                        val sdkResult = getSdkResult(bidInfo.resultCode, bidInfo.targetingKeywords)

                        // Add debugInfo
                        updatedDebugInfoForResult(bidInfo.targetingKeywords?.toMutableMap())

                        if (cont.isActive) {
                            cont.resume(sdkResult)
                        } else {
                            Logger.w("[Prebid] Late Prebid callback ignored for \"${adConfig.adUnitId}\"")
                        }
                    }
                }
            } else {
                Logger.d("[Prebid] Prebid is skipped due to non-rtaAuction - ${adConfig.adUnitId}")
                return SdkResult.SKIPPED
            }
        } catch (e: Exception) {
            Logger.e("[Prebid] Exception occurred in getting Prebid bid", e)
            return SdkResult.FAILED
        }
    }

    protected fun updateDebugInfoForSend(){
        if(ConfigurationManager.isInspectionMode) {
            if(adConfig is BannerConfiguration) {
                adConfig.debugInfo?.let {
                    val adConfig = adConfig as BannerConfiguration
                    val sizes = adConfig.availableBannerSizes
                    val formatted = sizes
                        .sortedWith(compareBy({ it.width }, { it.height }))
                        .joinToString(separator = ", ") { "${it.width}x${it.height}" }

                    val prebidDebugInfo = SdkDebugInfo().apply {
                        description = "Send To Prebid"
                        adSlotId = adConfig.adSlotId
                    }

                    prebidDebugInfo.keyValues = adConfig.customTargeting.toMutableMap()
                    prebidDebugInfo.keyValues?.put("rtbAuction", adConfig.realTimeAuctionEnabled.toString())
                    prebidDebugInfo.keyValues?.put("adUnitID", adConfig.adUnitId)
                    prebidDebugInfo.keyValues?.put("configID", adConfig.configAdSlot?.prebidConfigId)
                    prebidDebugInfo.keyValues?.put("size", formatted)
                    prebidDebugInfo.keyValues?.put("contentUrl", adConfig.contentUrl)
                    adConfig.debugInfo?.sdkDebugInfos!!.add(prebidDebugInfo)
                }
            }
        }
    }

    protected fun updatedDebugInfoForResult(keyValues : MutableMap<String, String?>?, bidResponse : BidResponse? = null){
        if(ConfigurationManager.isInspectionMode) {
            // Add debugInfo
            adConfig.debugInfo?.let {
                val prebidDebugInfo = SdkDebugInfo()
                prebidDebugInfo.adSlotId = adConfig.adSlotId
                prebidDebugInfo.description = "Received From Prebid"
                prebidDebugInfo.keyValues = keyValues

                bidResponse?.let{
                    var indexer = 1 // just for avoiding duplicate keys
                    val allSeatBids = bidResponse.seatbids
                    for(seatBid in allSeatBids){
                        for(bid in seatBid.bids){
                            @Suppress("SpellCheckingInspection")
                            try {
                                prebidDebugInfo.keyValues?.put("${indexer}__seat", seatBid.seat)
                                prebidDebugInfo.keyValues?.put("${indexer}_adomain", bid.adomain[0])
                                prebidDebugInfo.keyValues?.put("${indexer}_crid", bid.crid)
                                prebidDebugInfo.keyValues?.put("${indexer}_id", bid.id)
                                prebidDebugInfo.keyValues?.put("${indexer}_impid", bid.impId)
                                prebidDebugInfo.keyValues?.put("${indexer}_price", bid.price.toString())
                                prebidDebugInfo.keyValues?.put("${indexer}_size", "${bid.width}x${bid.height}")
                                indexer++
                            }catch(e : Exception){
                                Logger.e("[APrebidSdkAdapter] Failed to add data to the debug information", e)
                            }
                        }
                    }
                }
                it.sdkDebugInfos.add(prebidDebugInfo)
            }
        }
    }

    protected suspend fun isSdkInitialized(): Boolean{
        if (PrebidMobile.isSdkInitialized()) return true
        withTimeoutOrNull(10000.milliseconds) {
            while (!PrebidMobile.isSdkInitialized()) {
                delay(200.milliseconds)
            }
        }

        if(!PrebidMobile.isSdkInitialized()){
            Logger.e("[Prebid] Prebid SDK is not initialized")
        }
        return PrebidMobile.isSdkInitialized()
    }

    protected fun getSdkResult(resultCode: ResultCode, map: Map<String, String?>?): SdkResult {
        val translatedYlKeyValues = HashMap<String, String>()
        PrebidToGAMKeyValueMapper.addPrebidMetadata(translatedYlKeyValues, adConfig.configAdSlot!!.prebidConfigId!!, resultCode)
        PrebidToGAMKeyValueMapper.addBidsIntoAdRequestBuilder(map, translatedYlKeyValues)

        return SdkResult(remapResultCode(resultCode), translatedYlKeyValues)
    }

    protected open fun initPrebidAdUnit(){
        val prebidAccountId = adConfig.config?.modules?.prebid?.yieldloveAccountId
        if(prebidAccountId.isNullOrEmpty()) {
            throw IllegalStateException("[APrebidSdkAdapter] Prebid Server Account ID is not set in configuration.")
        }
        PrebidMobile.setPrebidServerAccountId(prebidAccountId)
    }

    private fun remapResultCode(resultCode: ResultCode): SdkResultCode {
        return when (resultCode) {
            ResultCode.SUCCESS -> SdkResultCode.SUCCESS
            ResultCode.TIMEOUT -> SdkResultCode.TIMEOUT
            ResultCode.NO_BIDS -> SdkResultCode.NO_BIDS
            else -> SdkResultCode.FAILED
        }
    }


    protected fun updateContentUrl() {
        var contentUrl = adConfig.contentUrl

        // if local contentUrl is not set or empty, use the global one from ConfigurationManager
        if (contentUrl.isNullOrEmpty()) {
            contentUrl = ConfigurationManager.getInstance().contentUrl
        }

        if (TextUtils.isEmpty(contentUrl)) {
            return
        }

        try {
            OrtbJsonHelper.addOrUpdate(contentUrl!!, "app", "content", "url")
            apply()
        } catch (e: Exception) {
            Logger.e("[Prebid] Failed to set setAppContentUrl", e)
        }
    }



    private fun setServerTimeout() {
        // initial timeout
        PrebidMobile.setTimeoutMillis(3_000)
    }

    init {
        this.setServerTimeout()
        this.setCustomHeaders()
        this.initialize()
    }

    @Synchronized
    private fun initialize() {
        if(this.adConfig.activityContext == null){
            throw ContextException("[APrebidSdkAdapter] Activity context is required for Prebid SDK initialization.")
        }

        this.adConfig.activityContext?.let{
            initialize(it)
        }
    }

    private fun setCustomHeaders() {
        val customHeaders = HashMap<String, String>()
        customHeaders["X-SDK-Version"] = BuildConfig.VERSION_NAME
        customHeaders["X-Bundle"] = this.adConfig.activityContext?.packageName ?: "unknown"
        PrebidMobile.setCustomHeaders(customHeaders)
    }

    protected fun getPrebidAdCacheIdFromTargeting(keyValuesFromPrebid: MutableMap<String, String>?): String? {
        return keyValuesFromPrebid?.get(PrebidToGAMKeyValueMapper.CustomTargetingMapping.cache_id.ylKey)
    }

    internal fun createTargeting(config : AAdConfiguration) : MutableMap<String, String> {
        val targeting = mutableMapOf<String, String>()

        // This should not be in Prebid Request
//        config.configAdSlot?.keyValues?.let{ kvs ->
//            kvs.forEach { (key, value) ->
//                if(value.isNotEmpty()) {
//                    targeting[key] = value.joinToString(",")
//                }
//            }
//        }

        config.customTargeting.forEach { kv ->
            targeting[kv.key] = kv.value
        }

        return targeting
    }

    /**
     * Builds the imp level ORTB config.
     *
     * Assembled with [JSONObject] rather than by interpolating into a JSON template: a key or
     * value carrying a quote, a backslash or a control character would otherwise produce a
     * document Prebid cannot parse, and Prebid drops the whole imp config when that happens -
     * taking "adslot" and "pbadslot" down with the targeting that broke it.
     *
     * Targeting is applied after the slot fields, so it keeps the precedence it had while the
     * config was a string: a targeting key named "adslot" still wins, but deterministically now
     * rather than as a duplicate member the parser resolves however it likes.
     */
    @Suppress("SpellCheckingInspection")
    protected fun getImpSetup(adUnitId: String, customTargeting: Map<String, String>) : String{
        val data = JSONObject()
            .put("adslot", adUnitId)
            .put("pbadslot", adUnitId)

        customTargeting.forEach { (key, value) ->
            data.put(key, value)
        }

        return JSONObject()
            .put("displaymanager", "StroeerSDK")
            .put("displaymanagerver", BuildConfig.VERSION_NAME)
            .put("ext", JSONObject().put("data", data))
            .toString()
    }

    companion object {
        @JvmStatic
        fun initialize(applicationContext: Context){
            PrebidMobile.setCreativeFactoryTimeout(15000)

            // Even if this is called multiple times, the SDK will only be initialized once.
            PrebidMobile.initializeSdk(applicationContext, ConfigConstants.PREBID_URL) { status ->
                Logger.i("[Prebid] Prebid SDK initialized with status: $status")
                PrebidMobile.setEventDelegate(prebidEventDelegate)
                OrtbJsonHelper.addOrUpdate(JSONObject(), "ext", "prebid", "cache", "bids")
                TargetingParams.setOmidPartnerName(ConfigConstants.OMID_PARTNER_NAME)
                TargetingParams.setOmidPartnerVersion(ConfigConstants.OMID_PARTNER_VERSION)
            }
        }
        // setEventDelegate is a weak reference, so we need to keep a strong reference to it
        private val prebidEventDelegate: PrebidEventDelegate = PrebidEventDelegate { request, response ->
            try {
                if (ConfigurationManager.isDebugMode) {
                    CoroutineScope(Dispatchers.IO).launch {
                        val nInfo = NetworkDebugInfo(request.optString("id", "unknown"))
                        try {
                            DebugInfoManager.getInstance().addNetworkDebugInfo(nInfo)
                            nInfo.sdkType = SdkType.Prebid
                            nInfo.request = request
                            nInfo.response = response
                            nInfo.requestString = JsonPrinter.print(request, "adm")
                            nInfo.responseString = JsonPrinter.print(response, "adm")

                            Logger.d("[PREBID-REQUEST]\n${nInfo.requestString}")
                            Logger.d("[PREBID-RESPONSE]\n${nInfo.responseString}")

                        }catch (exception : Exception){
                            Logger.e("[Prebid] Failed to put network info", exception)
                        }
                    }
                }
            } catch (e: JSONException) {
                Logger.e("[Prebid] Failed to log Prebid event", e)
            }
        }
    }
}
