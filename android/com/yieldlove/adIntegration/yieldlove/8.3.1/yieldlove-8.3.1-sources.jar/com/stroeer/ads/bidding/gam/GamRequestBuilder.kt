package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.config.ConfigConstants
import com.stroeer.ads.config.ConfigurationManager
import com.yieldlove.adIntegration.BuildConfig

class GamRequestBuilder(
    private val config: AAdConfiguration
) {
    private val keyValuesFromAdapter: MutableMap<String, String?> = HashMap()

    fun addKeyValuesFromSdks(keyValues: MutableMap<String, String>?): GamRequestBuilder {
        keyValues?.let{
            for (key in keyValues.keys) {
                this.keyValuesFromAdapter[key] = keyValues[key]
            }
        }
        return this
    }

    fun build(): AdManagerAdRequest {

        if(config.localBuilder == null){
            // Somehow, localBuilder is null, which means prepareRequestBuilder() was not called before build().
            // This is a critical error, so we log it and create a new AdManagerAdRequest.Builder to avoid crashing.
            Logger.e("[GamRequestBuilder] localBuilder is null - prepareRequestBuilder() must run before build().")
            config.localBuilder = AdManagerAdRequest.Builder()
        }

        val builder = GamAdRequestBuilderMerger.merge(GlobalGamManager.adRequestBuilder, config.localBuilder!!)

        // The slot's own content url wins; the configured one fills in. Resolved here, per
        // request, so that clearing the configuration actually stops it being sent.
        if (config.contentUrl.isNullOrEmpty()) {
            ConfigurationManager.getInstance().contentUrl
                ?.takeIf { it.isNotEmpty() }
                ?.let { builder.setContentUrl(it) }
        }

        // Key Values from Configuration
        this.config.configAdSlot?.keyValues?.let { kvs ->
            for ((key, value) in kvs) {
                if(value.isNotEmpty()) {
                    builder.addCustomTargeting(key, value.joinToString(","))
                }
            }
        }

        // CustomTargeting
        for ((key, value) in this.config.customTargeting) {
            builder.addCustomTargeting(key, value)
        }

        // Adapter targeting values are nullable; skip nulls so a single missing
        // value can't NPE and abort the whole GAM request.
        for ((key, value) in this.keyValuesFromAdapter) {
            if (value != null) {
                builder.addCustomTargeting(key, value)
            }
        }

        // SetTimeout
        this.config.config?.gamRequestTimeout?.let { timeout->
            try {
                builder.setHttpTimeoutMillis(timeout.toInt())
            }catch(e: Exception){
                Logger.e("[GamRequestBuilder] Failed to set ad request timeout: $timeout ms - ${e.message}", e)
            }
        }

        // Adding Android SDK Version
        builder.addCustomTargeting("androidYlSdkVersion", listOf(BuildConfig.VERSION_NAME))

        return builder.build()
    }
}

