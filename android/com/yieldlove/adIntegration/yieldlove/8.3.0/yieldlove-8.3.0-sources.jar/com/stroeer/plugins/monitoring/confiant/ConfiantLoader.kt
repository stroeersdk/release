package com.stroeer.plugins.monitoring.confiant

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.plugins.monitoring.AdMonitorRefresher
import com.stroeer.plugins.monitoring.IAdMonitorCallback
import com.stroeer.plugins.monitoring.IAdMonitoring
import com.stroeer.plugins.monitoring.IAdReloader
import com.stroeer.utilities.concurrent.RunAsync
import com.stroeer.utilities.logging.Logger
import org.jetbrains.annotations.TestOnly

class ConfiantLoader private constructor() {

    enum class ConfiantState {
        NOT_INITIALIZED,
        INITIALIZING,
        INITIALIZED,
        FAILED_INITIALIZATION,
        FAILED_NOT_ACTIVATED,
        FAILED_NO_SDK,
        FAILED_NO_PLUGIN,
        FAILED_INVALID_CONFIG
    }

    private var confiantWrapperInstance: IAdMonitoring? = null
    @Volatile private var status = ConfiantState.NOT_INITIALIZED
        set(value){
            if(field != value) {
                Logger.d("[ConfiantPlugin] Confiant state changed from $field to $value")
            }
            field = value
        }

    private var testMode = false
    private var reloadMode = false
    private var confiantPropertyId: String? = null
    private var callback: IAdMonitorCallback? = null

    fun initialize(confiantPropertyId: String) {
        initialize(confiantPropertyId, false, null)
    }

    fun initialize(confiantPropertyId: String, enableReload: Boolean, callback: IAdMonitorCallback?) {
        this.confiantPropertyId = confiantPropertyId
        this.reloadMode = enableReload
        this.callback = callback
        initializeAsync()
    }

    @Synchronized
    fun initializeAsync() {
        if (status in TERMINAL_STATES || status == ConfiantState.INITIALIZING || isRunnable()) return

        if (confiantPropertyId.isNullOrEmpty()) {
            Logger.e("[ConfiantPlugin] Confiant property ID is null or empty. Initialization failed.")
            status = ConfiantState.FAILED_INVALID_CONFIG
            callback?.onInitialized(false)
            return
        }

        status = ConfiantState.INITIALIZING
        Logger.d("[ConfiantPlugin] Confiant is initializing")

        RunAsync.run({
            var timeout = 0
            while (!ConfigurationManager.getInstance().isLoaded) {
                try {
                    Thread.sleep(1000)
                    if (++timeout == 3) break
                } catch (e: InterruptedException) {
                    Logger.e("[ConfiantPlugin] Failed to wait for Configuration", e)
                }
            }

            if (ConfigurationManager.getInstance().isLoaded) {
                ConfigurationManager.getInstance().getConfig()?.let { config->
                    if (testMode) {
                        config.modules.confiant.active = true
                        Logger.i("[ConfiantPlugin] Test mode enabled, Confiant module activated")
                    }
                    val confiantConfig = config.modules.confiant

                    if (!confiantConfig.active) {
                        Logger.i("[ConfiantPlugin] Confiant module is not activated")
                        status = ConfiantState.FAILED_NOT_ACTIVATED
                        callback?.onInitialized(false)
                        return@run
                    } else {
                        Logger.i("[ConfiantPlugin] Confiant module is activated")
                    }
                }
            } else {
                Logger.i("[ConfiantPlugin] Configuration not loaded yet")
                status = ConfiantState.NOT_INITIALIZED
                callback?.onInitialized(false)
                return@run
            }

            if (!loadConfiantClasses()) {
                return@run
            }

            if (testMode) confiantWrapperInstance!!.enableTestMode()
            if (reloadMode) confiantWrapperInstance!!.enableReload()

            confiantWrapperInstance!!.initialize(confiantPropertyId!!, object : IAdMonitorCallback {
                override fun onInitialized(success: Boolean) {
                    status = if (success) ConfiantState.INITIALIZED else ConfiantState.FAILED_INITIALIZATION
                    callback?.onInitialized(success)
                }
            })
        }, 0) { e ->
            Logger.e("[ConfiantPlugin] Error initializing Confiant SDK:", e)
            status = ConfiantState.NOT_INITIALIZED
            callback?.onInitialized(false)
        }
    }

    fun enableTestMode() {
        testMode = true
    }

    fun mark(adReloader: IAdReloader) {
        initializeAsync()

        if (isRunnable()) {
            // AdMonitorRefresher.getInstance().addNewReloader(adReloader)
            val adView = adReloader.getAdView() ?: return
            confiantWrapperInstance!!.mark(adView, adReloader.getAdSlot())
        }
    }

    fun isRunnable() = status == ConfiantState.INITIALIZED && confiantWrapperInstance != null

    private fun loadConfiantClasses(): Boolean {
        if (confiantWrapperInstance != null) return true

        // The SDK is checked before the plugin: ConfiantWrapper references Confiant SDK
        // types directly, so instantiating it without the SDK on the classpath fails with
        // a LinkageError rather than a clean "plugin missing" result.
        try {
            Class.forName("com.confiant.android.sdk.Confiant")
            Logger.i("[ConfiantPlugin] Confiant SDK found")
        } catch (_: ClassNotFoundException) {
            Logger.i("[ConfiantPlugin] Confiant SDK not found")
            status = ConfiantState.FAILED_NO_SDK
            return false
        }

        val wrapper = instantiateConfiantWrapper()
        if (wrapper == null) {
            Logger.i("[ConfiantPlugin] Confiant plugin not found")
            status = ConfiantState.FAILED_NO_PLUGIN
            return false
        }

        confiantWrapperInstance = wrapper
        Logger.i("[ConfiantPlugin] Confiant Plugin found")
        return true
    }

    @Suppress("UNCHECKED_CAST")
    private fun instantiateConfiantWrapper(): IAdMonitoring? = try {
        val confiantClass = Class.forName("com.stroeer.confiant.ConfiantWrapper") as Class<IAdMonitoring>
        confiantClass.getDeclaredConstructor().newInstance()
    } catch (_: Exception) {
        null
    } catch (_: LinkageError) {
        // A partially present plugin surfaces as NoClassDefFoundError, which is an Error.
        // Without this it would escape to the RunAsync handler and leave the loader in a
        // retryable state, re-running initialization on every mark().
        null
    }

    @TestOnly
    fun setConfiantWrapperInstance(instance: IAdMonitoring) {
        confiantWrapperInstance = instance
        status = ConfiantState.INITIALIZED
    }

    @TestOnly
    fun updateStatus(newStatus: ConfiantState) {
        status = newStatus
    }

    companion object {
        /**
         * States that initialization cannot recover from, so [initializeAsync] stops retrying.
         * FAILED_INITIALIZATION is deliberately excluded: it stays retryable.
         */
        private val TERMINAL_STATES = setOf(
            ConfiantState.FAILED_NOT_ACTIVATED,
            ConfiantState.FAILED_NO_SDK,
            ConfiantState.FAILED_NO_PLUGIN,
            ConfiantState.FAILED_INVALID_CONFIG
        )

        private var instance: ConfiantLoader? = null

        @JvmStatic
        fun getInstance(): ConfiantLoader {
            if (instance == null) instance = ConfiantLoader()
            return instance!!
        }

        @JvmStatic
        fun reset() {
            Logger.e("[ConfiantPlugin] Resetting ConfiantLoader instance. This should not be called in production.")
            instance = null
        }
    }
}
