package com.stroeer.ads.bidding

import com.stroeer.ads.formats.AAdConfiguration

interface ISdkAdapter {
    suspend fun getBid(): SdkResult
    suspend fun prepare()
}
