package com.stroeer.ads.config.objects

import com.stroeer.ads.config.ConfigConstants

/**
 * "common": {
 * "dfpAppNetwork": "36930962",
 * "dfpiOSAppName": "m.app.ios_sport1.de_sd",
 * "dfpAndroidAppName": "m.app.droid_sport1.de_sd",
 * "dfpAdRequestTimeoutMs": 7000,
 * "prebidAdRequestTimeoutMs": 5000,
 * "updateIntervalMs": 60000,
 * "androidStoreUrl": "https://play.google.com/store/apps/details?id=sport1.mobile.android.apps&hl=de&gl=US",
 * "androidBundleId": "sport1.mobile.android.apps",
 * "iOSStoreUrl": "https://apps.apple.com/de/app/sport1-sport-fussball-news/id300000385",
 * "iOSITunesId": "300000385"
 * "setAppMuted": true
 * },
 *
 * iOS data will be ignored
 */
class ConfigCommon {
    var dfpAppNetwork: String? = null
    var dfpAndroidAppName: String? = null
    var dfpAdRequestTimeoutMs: Int = ConfigConstants.DEFAULT_REQUEST_TIMEOUT_MS
    var prebidAdRequestTimeoutMs: Int = ConfigConstants.DEFAULT_REQUEST_TIMEOUT_MS

    var updateIntervalMs: Int? = null
    var rtaAuction: Boolean? = null

    var androidStoreUrl: String? = null
    var androidBundleId: String? = null

    var inventoryStructure: String? = null
    var setAppMuted: Boolean? = null

    val soundSetting: AdsSoundSettingStates
        get() {
            return if (setAppMuted == null) {
                AdsSoundSettingStates.RESPECT_USER_SOUND_SETTING
            } else {
                if (setAppMuted!!) AdsSoundSettingStates.MUTE else AdsSoundSettingStates.UNMUTE
            }
        }

    val inventoryStructureSetting: InventoryStructureSettings?
        get() {
            if (inventoryStructure == null) {
                return InventoryStructureSettings.STROEER_DIGITAL_INVENTORY
            }
            return InventoryStructureSettings.parse(
                inventoryStructure!!
            )
        }

    val isSDI: Boolean
        get() = this.inventoryStructureSetting == InventoryStructureSettings.STROEER_DIGITAL_INVENTORY
}
