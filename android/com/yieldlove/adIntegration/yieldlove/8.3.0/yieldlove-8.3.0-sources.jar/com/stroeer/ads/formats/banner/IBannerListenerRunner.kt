package com.stroeer.ads.formats.banner

import com.stroeer.ads.exceptions.StroeerException

interface IBannerListenerRunner{
    fun onAdClosed()
    fun onAdFailedToLoad(error:StroeerException, description : String, beforeStart: (suspend () -> Unit)? = null, finish : Boolean = false)
    fun onAdOpened()
    fun onAdLoaded(beforeStart: (suspend () -> Boolean)? = null)
    fun onAdClicked()
    fun onAdImpression()
}