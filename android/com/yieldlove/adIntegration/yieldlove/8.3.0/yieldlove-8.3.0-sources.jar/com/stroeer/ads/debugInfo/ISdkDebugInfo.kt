package com.stroeer.ads.debugInfo

import java.util.Date

interface ISdkDebugInfo {
    val createdDate : Date
    var adSlotId : String?
    val sdkType: SdkType
    var description : String?
    val keyValues: MutableMap<String, String?>?
    var requestJson : String?
    var responseJson : String?
}
