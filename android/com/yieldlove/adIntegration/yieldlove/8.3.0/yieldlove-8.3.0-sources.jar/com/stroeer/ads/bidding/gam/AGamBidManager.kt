package com.stroeer.ads.bidding.gam

import android.content.Context
import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.exceptions.ContextException
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.reporting.events.GamRequested
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.bidding.SdkResult


abstract class AGamBidManager(val adConfig: AAdConfiguration){

    val context: Context?
        get(){
            return if (ConfigurationManager.ignoreAdViewMemoryLeaked)
                adConfig.applicationContext
            else
                adConfig.activityContext
        }

    var request : AdManagerAdRequest? = null

    open fun initializeGoogleAdAViewIfNotExist(){
        if(context == null){
            throw ContextException("Failed to initialize Google Ad Instance as Context is null - ${adConfig.adSlotId}")
        }
    }

    abstract fun createAdManagerAdView()


    protected fun prepareRequestBuilder() {
        adConfig.localBuilder = adConfig.localBuilder ?: AdManagerAdRequest.Builder()

        ConfigurationManager.getInstance().contentUrl?.let{
            GlobalGamManager.adRequestBuilder.setContentUrl(it)
        }

        adConfig.contentUrl?.let {
            adConfig.localBuilder!!.setContentUrl(it)
        }

        adConfig.requestBuilder = GamRequestBuilder(adConfig)
    }


    open fun callGam(results: Array<SdkResult>) {
        adConfig.session?.recordEvent(GamRequested())

        val requestBuilder = adConfig.requestBuilder
        if (requestBuilder == null) {
            Logger.e("[AGamBidManager] requestBuilder is null - createAdManagerAdView() must run before callDfp(). Aborting GAM request for ${adConfig.adSlotId}")
            return
        }

        for (result in results) {
            requestBuilder.addKeyValuesFromSdks(result.keyValues)
        }

        request = requestBuilder.build()

        request?.let {
            Logger.i("[AGamBidManager] Custom Targeting for Ad request is built: ${it.customTargeting}")
            DebugInfoManager.addSendGAM(adConfig,it.customTargeting.keySet()?.associateWith { key -> it.customTargeting.getString(key) })
        }
    }

    open fun destroy() {
        request = null
    }
}