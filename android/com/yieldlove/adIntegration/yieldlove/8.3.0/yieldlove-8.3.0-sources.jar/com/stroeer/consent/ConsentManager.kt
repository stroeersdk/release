package com.stroeer.consent

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import com.iabtcf.decoder.TCString
import com.stroeer.utilities.logging.Logger

object ConsentManager {

    // IABTCF SharedPreferences keys — see the IAB TCF v2 CMP API spec:
    // https://github.com/InteractiveAdvertisingBureau/GDPR-Transparency-and-Consent-Framework/blob/master/TCFv2/IAB%20Tech%20Lab%20-%20CMP%20API%20v2.md#in-app-details
    @Suppress("ConstPropertyName")
    const val IABTCF_TCString_KEY: String = "IABTCF_TCString"
    @Suppress("ConstPropertyName")
    const val IABTCF_VendorConsents_KEY: String = "IABTCF_VendorConsents"
    @Suppress("ConstPropertyName")
    const val IABTCF_PurposeConsents_KEY: String = "IABTCF_PurposeConsents"
    @Suppress("ConstPropertyName")
    const val IABTCF_VendorLIConsents_KEY: String = "IABTCF_VendorLegitimateInterests"
    @Suppress("ConstPropertyName")
    const val IABTCF_PurposeLIConsents_KEY: String = "IABTCF_PurposeLegitimateInterests"
    @Suppress("ConstPropertyName")
    const val IABTCF_PublisherRestrictionsKEY_Pattern: String = "IABTCF_PublisherRestrictions{ID}"
    @Suppress("ConstPropertyName")
    const val IABTCF_PublisherRestrictionsId_ReplaceHolder: String = "{ID}"

    @Volatile private var prefs: SharedPreferences? = null

    @JvmStatic fun initialize(context: Context) { if (prefs == null) synchronized(this) { if (prefs == null) prefs = PreferenceManager.getDefaultSharedPreferences(context.applicationContext) } }

    @JvmStatic fun getConsent(): String? = prefs?.getString(IABTCF_TCString_KEY, null)

    /** TC string, or an empty string when consent is absent or the manager is not initialized. */
    @JvmStatic fun getTcStringOrEmpty(): String = getConsent().orEmpty()

    @JvmStatic fun setConsent(value: String) { prefs?.edit()?.putString(IABTCF_TCString_KEY, value)?.apply() }

    @JvmStatic fun clearConsent() { prefs?.edit()?.clear()?.apply() }

    @JvmStatic @JvmOverloads fun hasVendorConsent(vendorId: Int, consentString: String? = getConsent()): Boolean = try {
        consentString?.isNotEmpty() == true && TCString.decode(consentString).vendorConsent.contains(vendorId)
    } catch (t: Throwable) {
        Logger.e("[ConsentManager] Decode error", t); false
    }
}
