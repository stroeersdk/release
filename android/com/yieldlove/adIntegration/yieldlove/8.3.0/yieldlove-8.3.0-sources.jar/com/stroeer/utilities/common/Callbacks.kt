package com.stroeer.utilities.common

typealias Action = () -> Unit
typealias ActionT<T> = (T) -> Unit