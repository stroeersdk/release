package com.stroeer.ads.debugInfo.admin

import android.content.Context
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.consent.ConsentManager
import com.stroeer.ads.debugInfo.DebugInfo
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.utilities.logging.Logger
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.net.NetworkInterface

// Bind to loopback only: the admin server must be reachable from the device itself
// (e.g. via adb forward), never from other hosts on the network.
class AdminHttpServer private constructor(private val appContext: Context) : NanoHTTPD("127.0.0.1", PORT) {

    companion object {
        private const val PORT = 9890
        private const val TAG = "[AdminHttpServer]"

        @Volatile
        private var instance: AdminHttpServer? = null

        fun launch(context: Context) {
            if (instance?.isAlive == true) return
            try {
                val server = AdminHttpServer(context.applicationContext)
                server.start(SOCKET_READ_TIMEOUT, false)
                instance = server
                Logger.i("$TAG Admin server started on port $PORT")
            } catch (e: Exception) {
                Logger.e("$TAG Failed to start admin server", e)
            }
        }

        fun shutdown() {
            instance?.stop()
            instance = null
        }
    }

    override fun serve(session: IHTTPSession): Response {
        return when (session.uri) {
            "/", "/admin" -> serveDashboard()
            "/debugenable" -> enableInspection()
            "/debuginfo" -> serveDebugInfoPage()
            "/api/debuginfo" -> serveDebugInfoJson()
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not Found")
        }
    }

    private fun enableInspection(): Response {
        ConfigurationManager.enableInspectionMode()
        Logger.i("$TAG Inspection mode enabled via admin server")
        return newFixedLengthResponse(Response.Status.OK, "application/json", """{"status":"ok"}""")
    }

    private fun serveDashboard(): Response {
        val inspectionEnabled = ConfigurationManager.isInspectionMode
        val html = loadHtmlTemplate("admin/dashboard.html")
            .replace("{{SDK_VERSION}}", ConfigurationManager.version)
            .replace("{{DEVICE_IP}}", getDeviceIpAddress())
            .replace("{{INSPECTION_CLASS}}", if (inspectionEnabled) "on" else "off")
            .replace("{{INSPECTION_STATUS}}", if (inspectionEnabled) "ON" else "OFF")
            .replace("{{BUTTON_DISABLED}}", if (inspectionEnabled) "disabled" else "")
            .replace("{{TC_STRING}}", ConsentManager.getTcStringOrEmpty().ifEmpty { "Not available" })

        return newFixedLengthResponse(Response.Status.OK, "text/html", html)
    }

    private fun serveDebugInfoPage(): Response {
        val html = loadHtmlTemplate("admin/debuginfo.html")
        return newFixedLengthResponse(Response.Status.OK, "text/html", html)
    }

    private fun serveDebugInfoJson(): Response {
        val list = DebugInfoManager.getInstance().getDebugInfoList()
        val jsonArray = JSONArray()
        for (info in list) {
            val obj = JSONObject()
            obj.put("adSlotId", info.adSlotId ?: "")
            obj.put("servedInTime", info.servedInTime)
            obj.put("html", info.html ?: "")

            if (info is DebugInfo) {
                obj.put("adUnitId", info.adUnitId ?: "")
                obj.put("adSizes", info.adSizes.joinToString(", ") { "${it.width}x${it.height}" })
                obj.put("prebidActive", info.prebidActive ?: false)
                obj.put("prebidConfigId", info.prebidConfigId ?: "")
                obj.put("accountId", info.accountId ?: "")
                obj.put("autoRefreshEnabled", info.autoRefreshEnabled ?: false)
                obj.put("appName", info.appName)
                obj.put("tcString", info.tcString ?: "")
            }

            val source = info.adSourceInfo
            if (source != null) {
                obj.put("adSource", source.adSource.toString())
                obj.put("adSubSource", source.adSubSource)
                obj.put("sdkVersion", source.version)
            }

            val targeting = info.customTargeting
            if (targeting != null) {
                obj.put("customTargeting", JSONObject(targeting))
            }

            val sdkInfos = JSONArray()
            for (sdk in info.sdkDebugInfos) {
                val sdkObj = JSONObject()
                sdkObj.put("sdkType", sdk.sdkType.name)
                sdkObj.put("description", sdk.description ?: "")
                sdkObj.put("createdDate", sdk.createdDate.time)
                sdkObj.put("adSlotId", sdk.adSlotId ?: "")
                if (sdk.keyValues != null) {
                    sdkObj.put("keyValues", JSONObject(sdk.keyValues!!))
                }
                sdkObj.put("requestJson", sdk.requestJson ?: "")
                sdkObj.put("responseJson", sdk.responseJson ?: "")
                sdkInfos.put(sdkObj)
            }
            obj.put("sdkDebugInfos", sdkInfos)

            jsonArray.put(obj)
        }
        return newFixedLengthResponse(Response.Status.OK, "application/json", jsonArray.toString())
    }

    private fun loadHtmlTemplate(path: String = "admin/dashboard.html"): String {
        return appContext.assets.open(path)
            .bufferedReader()
            .use { it.readText() }
    }

    private fun getDeviceIpAddress(): String {
        try {
            for (netInfo in NetworkInterface.getNetworkInterfaces()) {
                for (addr in netInfo.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (_: Exception) {}
        return "unknown"
    }
}
