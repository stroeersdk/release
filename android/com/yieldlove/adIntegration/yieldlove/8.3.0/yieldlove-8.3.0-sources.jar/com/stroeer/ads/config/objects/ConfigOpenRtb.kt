package com.stroeer.ads.config.objects

/**
 * "openRtb": {
 * "apis": [
 * {
 * "framework": 3
 * },
 * {
 * "framework": 5
 * },
 * {
 * "framework": 6
 * },
 * {
 * "framework": 7
 * }
 * ]
 */
class ConfigOpenRtb {
    var apis: Array<ConfigApis>? = null

    val framework: Array<Int>?
        get() = apis
            ?.takeIf { it.isNotEmpty() }
            ?.map { it.framework }
            ?.toTypedArray()
}
