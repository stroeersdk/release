package com.stroeer.plugins.monitoring

fun interface IAdMonitorCallback {
    fun onInitialized(success: Boolean)
}
