package com.stroeer.ads.debugInfo

import com.google.android.gms.ads.AdSize
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.formats.AdSourceInfo

class DebugInfo : IDebugInfo{
    override var customTargeting: Map<String, String?>? = null
    override val sdkDebugInfos: MutableList<ISdkDebugInfo> = mutableListOf()
    override var adSlotId: String? = null
    override var servedInTime: Int = 0
    override var adSourceInfo: AdSourceInfo? = null
    override var html: String? = null

    var adUnitId: String? = null
    var adSizes: Array<AdSize> = arrayOf()
    var prebidActive: Boolean? = null
    var prebidConfigId: String? = null
    var accountId: String? = null
    var autoRefreshEnabled: Boolean? = null
    var appName: String = ConfigurationManager.getInstance().applicationName
    var tcString: String? = null
    var id: String? = null
    var active: Boolean = true

    override fun toString(): String {
        val str = StringBuilder()
        str.append("Ad Slot Info").append(System.lineSeparator())
        str.append("Ad Unit: ").append(adUnitId).append(System.lineSeparator())
        str.append("Ad Sizes: ")
        for (adSize in adSizes) {
            str.append(adSize.toString()).append(", ")
        }
        str.append(System.lineSeparator())
        str.append("Key Values: ").append(this.customTargeting.toString()).append(System.lineSeparator())
        str.append("GDPR String: ").append(this.tcString).append(System.lineSeparator())
        str.append("Auto Refresh: ").append(this.autoRefreshEnabled).append(System.lineSeparator())
        str.append(System.lineSeparator())
        str.append(System.lineSeparator()).append("General Info").append(System.lineSeparator())
        str.append("Prebid Active: ").append(this.prebidActive).append(System.lineSeparator())
        str.append("YL AccountId: ").append(this.accountId).append(System.lineSeparator())
        str.append("YL ConfigId: ").append(this.prebidConfigId).append(System.lineSeparator())
        str.append("YL App name: ").append(this.appName).append(System.lineSeparator())

        str.append("YL Publisher call string: ").append(adSlotId)
            .append(System.lineSeparator())

        str.append("Ad Source : ").append(adSourceInfo).append(System.lineSeparator())


        return str.toString()
    }
}
