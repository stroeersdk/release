package com.stroeer.ads.formats.banner

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.debugInfo.SdkDebugInfo
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.reporting.events.RequestFinished
import com.stroeer.utilities.logging.Logger
import com.stroeer.utilities.concurrent.ACoroutinable
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

internal open class PublisherBannerListenerRunner(bannerConfig: BannerConfiguration) : IBannerListenerRunner, ACoroutinable() {

    // Because Google SDK has the strong references to AdListener, we have to use WeakReference here to avoid memory leak
    val adSlotId = bannerConfig.adSlotId
    val weakListener = WeakReference(bannerConfig.publisherListener)
    val weakConfig = WeakReference(bannerConfig)
    val weakView = WeakReference(bannerConfig.bannerView)

    private var adLoadedSignal = CompletableDeferred<Unit>()

    fun reset(){
        adLoadedSignal = CompletableDeferred()
    }

    override fun onAdLoaded(beforeStart: (suspend () -> Boolean)? ) {
        Logger.i("[PublisherBannerListenerRunner] onAdLoaded has been called (${weakConfig.get()?.adSize?.width}x${weakConfig.get()?.adSize?.height}) - $adSlotId")
        mainScope.launch {
            if(beforeStart?.invoke() == false){
                Logger.i("[PublisherBannerListenerRunner] onAdLoaded has been called is cancelled. onAdLoaded beforeStart callback returned false - $adSlotId")
                return@launch
            }

            weakConfig.get()?.let {
                it.session?.recordEvent(RequestFinished())
                DebugInfoManager.updateServeTime(it)
                weakView.get()?.addDebugLabel()
                adLoadedSignal.complete(Unit)

                try {
                    it.sessionEnd()
                    it.setReady()
                    weakListener.get()?.onAdLoaded(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherBannerListenerRunner] Exception thrown during onAdLoaded callback - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdFailedToLoad(error: StroeerException, description : String, beforeStart: (suspend () -> Unit)?, finish : Boolean) {
        Logger.i("[PublisherBannerListenerRunner] onAdFailedToLoad has been called. - $adSlotId : ${error.message}")

        weakConfig.get()?.let{
            mainScope.launch {

                beforeStart?.invoke()
                if(finish) {
                    it.session?.recordEvent(RequestFinished())
                    DebugInfoManager.updateServeTime(it)
                    weakView.get()?.addDebugLabel()
                    invokeOnFail(weakListener.get(), weakConfig.get(), error, true)
                }
            }
        }
    }

    override fun onAdOpened() {
        Logger.i("[PublisherBannerListenerRunner] onAdOpened has been called. - $adSlotId")
        weakListener.get()?.let{ listener ->
            mainScope.launch {
                try {
                    listener.onAdOpened(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherBannerListenerRunner] Exception is thrown during onAdOpened callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdClosed() {
        Logger.i("[PublisherBannerListenerRunner] onAdClosed has been called. - $adSlotId")
        weakListener.get()?.let{ listener ->
            mainScope.launch {
                try {
                    listener.onAdClosed(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherBannerListenerRunner] Exception is thrown during onAdClosed callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdClicked() {
        Logger.i("[PublisherBannerListenerRunner] onAdClicked has been called. - $adSlotId")
        weakListener.get()?.let { listener ->
            mainScope.launch {
                try {
                    listener.onAdClicked(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherBannerListenerRunner] Exception is thrown during onAdClicked callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdImpression() {
        weakListener.get()?.let {listener ->
            mainScope.launch {
                try {
                    adLoadedSignal.await()
                    Logger.i("[PublisherBannerListenerRunner] onAdImpression has been called. - $adSlotId")
                    weakView.get()?.getBuilder()?.scheduleRefresh()
                    listener.onAdImpression(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherBannerListenerRunner] Exception is thrown during onAdImpression callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    fun updateDebugInfoForFail(adConfig: BannerConfiguration, description: String, keyValues: MutableMap<String, String?>?) {
        if (ConfigurationManager.isInspectionMode) {
            adConfig.debugInfo?.let {
                val prebidDebugInfo = SdkDebugInfo()
                prebidDebugInfo.adSlotId = adConfig.adSlotId
                prebidDebugInfo.description = description
                prebidDebugInfo.keyValues = keyValues
                it.sdkDebugInfos.add(prebidDebugInfo)
            }
        }
    }

    companion object {
        fun invokeOnFail(listener: IStroeerBannerListener?, config: BannerConfiguration?, exception: StroeerException, closeSession : Boolean) {
            Logger.e("[StroeerBannerBuilder] onAdFailedToLoad called - ${config?.adSlotId} : ${exception.message}")

            config?.let {
                if(closeSession) {
                    config.sessionEnd()
                    config.setError()
                }

                try {
                    listener?.onAdFailedToLoad(config.bannerView, exception)
                } catch (ex: Exception) {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception thrown during onAdFailedToLoad callback - ${it.adSlotId}",
                        ex
                    )
                }
            }
        }
    }
}