package com.stroeer.ads.debugInfo

import com.stroeer.ads.formats.AdSourceInfo

interface IDebugInfo {
    override fun toString(): String

    val adSlotId: String?

    val adSourceInfo: AdSourceInfo?

    val servedInTime: Int

    var customTargeting : Map<String, String?>?

    val sdkDebugInfos : MutableList<ISdkDebugInfo>

    var html : String?
}

