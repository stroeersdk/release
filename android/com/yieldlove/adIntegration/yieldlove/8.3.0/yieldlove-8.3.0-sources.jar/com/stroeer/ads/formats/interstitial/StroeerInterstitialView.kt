package com.stroeer.ads.formats.interstitial

import android.content.Context
import com.google.android.gms.ads.MobileAds
import com.stroeer.ads.bidding.gam.GamInterstitialBidManager
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException
import com.stroeer.ads.exceptions.PreviousAdLoadIsInProgressException
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.AStroeerAdBuilder
import com.stroeer.ads.formats.AdType
import com.stroeer.ads.reporting.events.UnexpectedErrorHappenDuringAdLoading
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.bidding.prebid.InterstitialPrebidSdkAdapter
import com.stroeer.ads.bidding.prebid.PrebidAdUnitConverter
import com.stroeer.ads.config.ConfigurationManager
import kotlinx.coroutines.*
import java.lang.ref.WeakReference
import kotlin.time.Duration.Companion.milliseconds

class StroeerInterstitialView(context: Context) : AStroeerAdBuilder(InterstitialConfiguration(context)) {

    val intConfig : InterstitialConfiguration
        get() = adConfig as InterstitialConfiguration

    var loadAfterReady : Boolean
        get(){ return intConfig.loadAfterReady }
        set(value){ intConfig.loadAfterReady = value}

    init {
        MobileAds.initialize(context.applicationContext)
        prebidSdkAdapter = InterstitialPrebidSdkAdapter(intConfig, PrebidAdUnitConverter())
        gamBidManager = GamInterstitialBidManager(intConfig)
    }

    fun load(adSlotId: String, listener: IStroeerInterstitialListener?){
       mainScope.launch {
            loadAsync(adSlotId, listener)
        }
    }

    suspend fun loadAsync(adSlotId: String, listener: IStroeerInterstitialListener? = null) {
        ConfigurationManager.getInstance().getConfigAsync()

        intConfig.interstitialView = this

        withContext(Dispatchers.Main) {
            try {

                Logger.d("[StroeerInterstitialView] Loading interstitial - $adSlotId")

                // Set publisher slot and listener name for error message handling
                intConfig.adSlotId = adSlotId
                intConfig.publisherListener = listener

                if(!ConfigurationManager.getInstance().isLoaded) {
                    Logger.e("[StroeerInterstitialView] Configuration is not loaded -  $adSlotId")
                    PublisherInterstitialListenerRunner.invokeOnFail(listener, intConfig, ConfigurationIsNotLoadedException(), true)
                    return@withContext
                }

                if (intConfig.status.isLoading()) {
                    Logger.e("[StroeerInterstitialView] Previous interstitial load is still in progress -  $adSlotId")
                    PublisherInterstitialListenerRunner.invokeOnFail(listener, intConfig, PreviousAdLoadIsInProgressException(), false)
                    return@withContext
                }

                intConfig.initialize(adSlotId)

                if(!checkActive()){
                    return@withContext
                }

                // Validate Context - must be Activity
                validateContext()

                prepareSession(AdType.INTERSTITIAL)

                cleanLocalVariables()

                prepareSdkManager()

                useAdsSoundSettingFrom()

                delay(1.milliseconds)
                val bidResults = getBids()

                recordAdViewPreparedEvent()

                delay(1.milliseconds)
                startGAM(bidResults)

            }catch(e : TimeoutCancellationException){
                Logger.d("[StroeerInterstitialView] Timeout - $adSlotId")
                handleExceptions(e)
            }catch(_ : com.stroeer.ads.exceptions.ContextException){
                Logger.e("[StroeerInterstitialView] Context is already dead - $adSlotId")
                intConfig.setError()
                // No handleExceptions call - context is dead, can't invoke callbacks or show fallback
            }
            catch (e: Exception) {
                Logger.e("[StroeerInterstitialView] Exception occurred in loading interstitial - $adSlotId", e)
                handleExceptions(e)
            }
        }
    }

    private fun cleanLocalVariables() {

    }

    fun show() {
        if (intConfig.status.isReady()) {
            intConfig.activityContext?.let { it ->
                (gamBidManager as? GamInterstitialBidManager)?.show()
            }
        }
    }

    private fun startGAM(bidResults: Array<SdkResult>){
        createGoogleAdView ()
        recordAdViewPreparedEvent()
        callDfp(bidResults)
    }

    private fun createGoogleAdView(){
        gamBidManager.initializeGoogleAdAViewIfNotExist()

        val weakListener = WeakReference(intConfig.publisherListener)
        val weakFullListener = WeakReference(weakListener.get() as? IStroeerInterstitialFullListener)

        if(weakFullListener.get() != null) {
            Logger.i("[StroeerInterstitialView] Full Interstitial Listener is added" )
        }

        gamBidManager.createAdManagerAdView()
    }

    private fun callDfp(results: Array<SdkResult>) {
        gamBidManager.callGam(results)
    }

    private fun handleExceptions(exception: Exception) {
        Logger.e("[StroeerInterstitialView] Error caught", exception)
        intConfig.session?.recordEvent(UnexpectedErrorHappenDuringAdLoading(exception))
        intConfig.publisherInterstitialListenerRunner?.onAdFailedToLoad(StroeerException(exception), "Failed to load interstitial ad", null, true)
    }

    /**
     * Destroys the interstitial ad and cleans up resources.
     *
     * Optional - typically not needed for one-shot interstitial loads as local variables.
     * Only necessary if storing interstitial as a field and want explicit cleanup.
     *
     * Cancels any running load operations and releases resources.
     */
    fun destroy() {
        cancelCoroutines()
        intConfig.destroy()
        gamBidManager.destroy()
    }
}