package com.stroeer.ads.formats.interstitial

import android.content.Context
import com.google.android.gms.ads.admanager.AdManagerInterstitialAd
import com.stroeer.ads.formats.AAdConfiguration

/**
 * Holds configuration for an interstitial ad instance.
 *
 * Extends [AAdConfiguration] to add interstitial-specific properties such as
 * the Google Ad Manager interstitial object and event listener.
 */
class InterstitialConfiguration(context: Context) : AAdConfiguration(context) {

    /** Listener for interstitial ad lifecycle events (load, show, dismiss, etc.). */
    var publisherListener: IStroeerInterstitialListener? = null
        set(value) {
            field = value
            publisherInterstitialListenerRunner = if(field != null){
                PublisherInterstitialListenerRunner(this)
            }else {
                null
            }
        }

    var publisherInterstitialListenerRunner : PublisherInterstitialListenerRunner? = null

    /** Flag indicating whether to load the ad immediately after it's ready. */
    var loadAfterReady: Boolean = true

    var interstitialView: StroeerInterstitialView? = null

    /** The Google Ad Manager interstitial ad object associated with this configuration. */
    var adManagerInterstitialAd: AdManagerInterstitialAd? = null

    /**
     * Cleans up resources used by this interstitial configuration.
     *
     * - Calls [AAdConfiguration.destroy] to release base resources.
     * - Clears the [fullScreenContentCallback] to avoid memory leaks.
     * - Releases the [adManagerInterstitialAd] reference.
     * - Clears the [publisherListener] reference.
     */
    override fun destroy() {
        super.destroy()

        publisherListener = null
        interstitialView = null
        adManagerInterstitialAd?.fullScreenContentCallback = null
        adManagerInterstitialAd = null

    }
}