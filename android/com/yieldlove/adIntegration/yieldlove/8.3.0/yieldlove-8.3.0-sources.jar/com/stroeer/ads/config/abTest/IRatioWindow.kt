package com.stroeer.ads.config.abTest

internal interface IRatioWindow {
    val slotsName: String
    fun useMain(): Boolean
    fun getConfiguredRatio(): String
    fun getCurrentRunningRatio(): String
}
