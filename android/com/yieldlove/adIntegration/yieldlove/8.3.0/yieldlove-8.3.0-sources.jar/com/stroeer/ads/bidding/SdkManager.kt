package com.stroeer.ads.bidding

import com.stroeer.ads.exceptions.ContextException
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.reporting.events.BidRequested
import com.stroeer.ads.reporting.events.BidderRespondedSuccessfully
import com.stroeer.ads.reporting.events.BidderRespondedWithError
import com.stroeer.ads.reporting.events.BidsProcessed

import com.stroeer.utilities.logging.Logger
import kotlinx.coroutines.*

class SdkManager(private val adConfig : AAdConfiguration, private val sdkAdapters: Array<ISdkAdapter> = arrayOf()) {
    private val results: Array<SdkResult> =  Array(this.sdkAdapters.size) { SdkResult(SdkResultCode.FAILED, null) }

    suspend fun getBids(): Array<SdkResult> {
        // Currently we have only one. So, disabled this as it triggers additional delay.
//        coroutineScope {
//            val deferred = sdkAdapters.indices.map { i ->
//                async { results[i] = getBidFromAdapter(i, adConfig) }   // inherits current dispatcher
//            }
//            deferred.awaitAll() // List<SdkResult>
//        }
        results[0] = getBidFromAdapter(0)

        adConfig.session?.recordEvent(BidsProcessed())
        return this.results
    }

    private suspend fun getBidFromAdapter(adapterIndex: Int) : SdkResult {
        try {
            val adapter = sdkAdapters[adapterIndex];
            adConfig.session?.recordEvent(BidRequested(adapter))
            adapter.prepare()
            val sdkResult = adapter.getBid()
            adConfig.session?.recordEvent(BidderRespondedSuccessfully(adapter, sdkResult.resultCode))
            return sdkResult
        }catch(e : ContextException){
            Logger.e("[SdkManager] ContextException occurred - ${adConfig.adSlotId}", e)
            adConfig.session?.recordEvent(BidderRespondedWithError(sdkAdapters[adapterIndex], e))
        }catch(e : TimeoutCancellationException){
            Logger.d("[SdkManager] TimeoutCancellationException occurred - ${adConfig.adSlotId}")
            adConfig.session?.recordEvent(BidderRespondedWithError(sdkAdapters[adapterIndex], e))
        }
        catch(e: Exception){
            Logger.e("[SdkManager] Exception occurred in handling exception - ${adConfig.adSlotId}", e)
            adConfig.session?.recordEvent(BidderRespondedWithError(sdkAdapters[adapterIndex], e))
        }

        return SdkResult.FAILED
    }
}

