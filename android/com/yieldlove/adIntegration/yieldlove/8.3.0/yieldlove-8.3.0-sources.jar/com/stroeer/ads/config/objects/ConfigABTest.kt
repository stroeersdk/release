package com.stroeer.ads.config.objects

//{
//    "abTest": {
//        "active": true,
//        "name": "test1",
//        "groups": [
//        {
//            "slots": ["b1"],
//            "scope": "session",
//            "ratio": {
//                "main": 5,
//                "test": 5
//            }
//        },
//        {
//            "slots": ["*"],
//            "scope": "request",
//            "ratio": {
//                "main": 10,
//                "test": 0
//            }
//        }
//        ]
//    }
//}

class ConfigABTest {
    var active: Boolean = false
    var name: String = "test"
    var groups: List<ConfigABTestGroup> = emptyList()
}

class ConfigABTestGroup {
    var slots: List<String> = emptyList()
    var scope: String = "request"
    var ratio: ConfigTestRatio = ConfigTestRatio()
}

class ConfigTestRatio {
    var main: Int = 1
    var test: Int = 0
}