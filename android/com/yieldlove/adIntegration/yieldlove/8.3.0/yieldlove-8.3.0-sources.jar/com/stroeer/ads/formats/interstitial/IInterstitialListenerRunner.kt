package com.stroeer.ads.formats.interstitial

import com.stroeer.ads.exceptions.StroeerException

interface IInterstitialListenerRunner {
    fun onAdLoaded(beforeStart: (suspend () -> Boolean)? = null)
    fun onAdFailedToLoad(error: StroeerException, description : String, beforeStart: (suspend () -> Unit)? = null, finish : Boolean = false)
    fun onAdClicked()
    fun onAdDismissedFullScreenContent()
    fun onAdFailedToShowFullScreenContent(exception : StroeerException)
    fun onAdImpression()
    fun onAdShowedFullScreenContent()
}