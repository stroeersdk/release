package com.stroeer.ads.bidding.prebid

import android.content.Context
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration

class InterstitialPrebidSdkAdapter(private val intConfig : InterstitialConfiguration, adUnitConverter: PrebidAdUnitConverter) :
    APrebidSdkAdapter(intConfig, adUnitConverter) {
    override fun initPrebidAdUnit() {
        super.initPrebidAdUnit()
        adConfig.prebidAdUnit = this.adUnitConverter.convertToPrebidInterstitialAdUnit(intConfig)
    }
}
