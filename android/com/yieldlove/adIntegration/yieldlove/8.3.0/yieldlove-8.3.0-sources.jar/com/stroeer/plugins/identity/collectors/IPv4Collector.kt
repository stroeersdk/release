package com.stroeer.plugins.identity.collectors

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.stroeer.plugins.identity.ACollectorWithContext
import com.stroeer.utilities.http.SharedHttpClient.createClientWithTimeout
import com.stroeer.utilities.logging.d
import com.stroeer.utilities.logging.e
import kotlinx.coroutines.sync.withLock
import okhttp3.Request
import java.net.NetworkInterface
import java.util.Collections

/*
    * Return IPv4 address
 */
open class IPv4Collector : ACollectorWithContext<String?>() {

    protected val timeoutInSecs: Int = 3
    protected open val checkURL: String = "https://checkip.amazonaws.com/"

    // Cache is per-instance: IPv4Collector and IPv6Collector must NOT share it, otherwise the
    // collector that runs second returns the other protocol's cached address.
    protected var currentIP: String = EMPTY_IP
    protected var lastUpdate: Long = 0

    fun needToUpdate(now : Long) : Boolean{
        return currentIP == EMPTY_IP || (now - lastUpdate) > RECHECK_PERIOD
    }

    override suspend fun retrieveData(): String? {
        mutex.withLock {
            val now = System.currentTimeMillis()
            if (!needToUpdate(now)) {
                return currentIP
            }

            try {
                val publicIp = getPublicIPAddress(checkURL)
                val localIp = getIPAddress(applicationContext)

                if (!publicIp.isNullOrEmpty() && isValidFormat(publicIp)) {
                    lastUpdate = now
                    currentIP = publicIp
                } else if (!localIp.isNullOrEmpty() && isValidFormat(localIp)) {
                    lastUpdate = now
                    currentIP = localIp
                }
            } catch (ex: Exception) {
                d("Failed to get IP addresses", ex)
            }
            return currentIP
        }
    }

    fun getIPAddress(context: Context): String? {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = cm.activeNetwork

            if (activeNetwork != null) {
                val capabilities = cm.getNetworkCapabilities(activeNetwork)
                if (capabilities != null) {
                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        return mobileIPAddress
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        return getWifiIPAddress()
                    }
                }
            }
            null
        } catch (ex: Exception) {
            d("Failed to get IP address", ex)
            null
        }
    }

    protected open fun getWifiIPAddress(): String? {
        return getNetworkIPAddress(false)
    }

    protected open val mobileIPAddress: String?
        get() = getNetworkIPAddress(false)

    fun getNetworkIPAddress(ipv6: Boolean): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            for (networkInterface in Collections.list(interfaces)) {
                val addresses = networkInterface.inetAddresses
                for (address in Collections.list(addresses)) {
                    if (!address.isLoopbackAddress) {
                        if (!ipv6 && address?.hostAddress?.contains(".") == true) {
                            return address.hostAddress
                        } else if (ipv6 && address?.hostAddress?.contains(":") == true) {
                            return address.hostAddress
                        }
                    }
                }
            }
        } catch (ex: Exception) {
            e("Failed to get IP address", ex)
        }
        return null
    }

    fun getPublicIPAddress(url: String): String? {
        val client = createClientWithTimeout(timeoutInSecs)
        val request = Request.Builder()
            .url(url)
            .get()
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val responseBody = response.body
                if (response.isSuccessful) {
                    responseBody.string().trim { it <= ' ' }.replace("\n", "")
                } else {
                    null
                }
            }
        } catch (ex: Exception) {
            d("Failed to fetch public IP", ex)
            null
        }
    }

    open fun isValidFormat(ip: String): Boolean {
        return ip.matches("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b".toRegex())
    }

    companion object {
        const val EMPTY_IP: String = "0.0.0.0"
        const val RECHECK_PERIOD : Long = 10 * 60 * 1000 // 10 minutes
    }
}
