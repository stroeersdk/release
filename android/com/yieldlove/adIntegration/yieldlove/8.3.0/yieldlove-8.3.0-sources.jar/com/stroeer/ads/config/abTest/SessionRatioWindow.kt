package com.stroeer.ads.config.abTest

import android.content.Context
import androidx.preference.PreferenceManager
import com.stroeer.ads.config.ConfigConstants

/**
 * Per-session window: same shuffled window as RatioWindow, but the window and its current
 * index are persisted to SharedPreferences so they survive app restarts. Each session
 * consumes exactly one slot from the window (sticky for the session lifetime) and the
 * advanced index is written back immediately. When the window is exhausted it rebuilds
 * and reshuffles, exactly like RatioWindow does in memory.
 *
 * Pref format: "<window as 0/1 CSV>|<index>|<accMain>|<accTest>"
 */
internal class SessionRatioWindow(
    slotsName: String,
    main: Int,
    test: Int,
    context: Context?
) : ARatioWindow(slotsName, main, test) {

    private val prefKey = ConfigConstants.PREFS_AB_SESSION_PREFIX + slotsName

    private val prefs = context?.let { PreferenceManager.getDefaultSharedPreferences(it) }

    // Sticky decision for the current session (null until first useMain() call).
    private var sessionDecision: Boolean? = null

    init {
        restoreOrBuild()
    }

    override fun scopeLabel() = "Session"

    override fun useMain(): Boolean {
        sessionDecision?.let { return it }

        if (index >= window.size) {
            rebuildWindow()
            persist()
        }

        val decision = window[index++]
        sessionDecision = decision
        if (decision) accumulatedMain++ else accumulatedTest++
        persist()
        return decision
    }

    private fun restoreOrBuild() {
        val stored = prefs?.getString(prefKey, null)
        if (stored != null) {
            val parts = stored.split("|")
            val restoredWindow = parts.getOrNull(0)
                ?.split(",")
                ?.mapNotNull { it.toIntOrNull()?.let { v -> v == 1 } }
                ?: emptyList()
            val restoredIndex = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val restoredMain  = parts.getOrNull(2)?.toIntOrNull() ?: 0
            val restoredTest  = parts.getOrNull(3)?.toIntOrNull() ?: 0

            // Only reuse if the window size still matches the configured ratio.
            if (restoredWindow.size == main + test) {
                window.addAll(restoredWindow)
                index = restoredIndex.coerceIn(0, window.size)
                accumulatedMain = restoredMain
                accumulatedTest = restoredTest
                return
            }
        }
        rebuildWindow()
    }

    private fun persist() {
        val windowStr = window.joinToString(",") { if (it) "1" else "0" }
        prefs?.edit()?.putString(prefKey, "$windowStr|$index|$accumulatedMain|$accumulatedTest")?.apply()
    }
}
