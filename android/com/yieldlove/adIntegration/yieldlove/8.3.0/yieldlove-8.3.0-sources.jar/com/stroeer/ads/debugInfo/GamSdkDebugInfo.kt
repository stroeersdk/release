package com.stroeer.ads.debugInfo

import java.util.Date

class GamSdkDebugInfo() : ISdkDebugInfo {
    override var adSlotId: String? = null
    override val createdDate: Date = Date()
    override val sdkType = SdkType.GAM
    override var description : String? = "Send to GAM"
    override var keyValues: MutableMap<String, String?>? = null
    override var requestJson: String? = null
    override var responseJson: String? = null
}