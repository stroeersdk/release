package com.stroeer.ads.config.loaders

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.stroeer.ads.config.ConfigConstants

class PreferenceFetcher(
    applicationContext: Context,
    private val prefsConfigKey: String = ConfigConstants.PREFS_CONFIG
) : IFetcher {
    private val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
    private val legacyPreferences: SharedPreferences = applicationContext.getSharedPreferences(
        ConfigConstants.EXTERNAL_CONFIG_SHARED_PREFS_FILE_KEY, Context.MODE_PRIVATE
    )

    override suspend fun load(appName: String?): String? {
        val cached = sharedPreferences.getString(prefsConfigKey, null)
        if(cached.isNullOrBlank()){
            // Fallback to legacy storage for main config only, test configs are not migrated
            if (prefsConfigKey == ConfigConstants.PREFS_CONFIG) {
                val legacyConfig = legacyPreferences.getString(ConfigConstants.EXTERNAL_CONFIG_CONTENT_KEY, null)
                if (!legacyConfig.isNullOrBlank()) {
                    // Migrate to new storage and delete legacy entry
                    store(legacyConfig)
                    legacyPreferences.edit { remove(ConfigConstants.EXTERNAL_CONFIG_CONTENT_KEY) }
                    return legacyConfig
                }
            }
            return null
        } else {
            return cached
        }
    }

    override fun store(json: String?) {
        sharedPreferences.edit { putString(prefsConfigKey, json) }
    }

    override fun delete() {
        sharedPreferences.edit { remove(prefsConfigKey) }
        if (prefsConfigKey == ConfigConstants.PREFS_CONFIG) {
            legacyPreferences.edit {
                remove(ConfigConstants.EXTERNAL_CONFIG_CONTENT_KEY)
            }
        }
    }
}

