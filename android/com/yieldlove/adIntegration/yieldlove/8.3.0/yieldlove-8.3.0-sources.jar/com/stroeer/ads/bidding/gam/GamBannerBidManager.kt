package com.stroeer.ads.bidding.gam

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.admanager.AdManagerAdView
import com.stroeer.ads.exceptions.DfpBannerLoadAdError
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.formats.AdAnalyzer
import com.stroeer.ads.formats.AdSource
import com.stroeer.ads.reporting.events.AdAnalyzed
import com.stroeer.ads.reporting.events.GamRespondedSuccessfully
import com.stroeer.ads.reporting.events.GamRespondedWithError
import com.stroeer.utilities.logging.Logger
import com.stroeer.utilities.ui.isNoZeroPixel
import com.stroeer.utilities.ui.toGAM
import java.lang.ref.WeakReference
import kotlin.math.roundToInt


class GamBannerBidManager(bannerConfig: BannerConfiguration) : AGamBidManager(bannerConfig){

    val bannerConfig : BannerConfiguration
        get() {return adConfig as BannerConfiguration}

    override fun initializeGoogleAdAViewIfNotExist(){
        super.initializeGoogleAdAViewIfNotExist()

        if(bannerConfig.adManagerAdView == null && context != null){
           bannerConfig.adManagerAdView = AdManagerAdView(context!!)
        }
    }

    override fun createAdManagerAdView() {
        prepareRequestBuilder()

        bannerConfig.adManagerAdView?.let{ adView->
            if(adView.adSizes == null) {
                adView.setAdSizes(*bannerConfig.availableBannerSizes)
            }

            val weakConfig = WeakReference(bannerConfig)

            adView.adListener = object : AdListener() {
                override fun onAdClosed() {
                    weakConfig.get()?.publisherBannerListenerRunner?.onAdClosed()
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    val error = DfpBannerLoadAdError(loadAdError)

                    weakConfig.get()?.session?.recordEvent(GamRespondedWithError(error))
                    weakConfig.get()?.let {
                        DebugInfoManager.addDebugInfoForFail(it, "Failed From GAM", error)
                        it.publisherBannerListenerRunner?.onAdFailedToLoad(error,loadAdError.message,null,true)
                    }
                }

                override fun onAdOpened() {
                    weakConfig.get()?.publisherBannerListenerRunner?.onAdOpened()
                }

                override fun onAdLoaded() {
                    weakConfig.get()?.let {
                        it.adManagerAdView?.adSize?.let { size ->
                            Logger.i("[GamBannerBidManager] GAM Banner is loaded ($size) - ${weakConfig.get()?.adSlotId}")
                            it.adSize =
                                org.prebid.mobile.AdSize(size.width, size.height)
                        }

                    }


                    weakConfig.get()?.publisherBannerListenerRunner?.onAdLoaded(
                        beforeStart = {
                            weakConfig.get()?.let {
                                it.session?.recordEvent(GamRespondedSuccessfully())

                                try {
                                    val html =
                                        AdAnalyzer.getHtmlFromAdView(it.adManagerAdView)
                                    if (html.isNullOrEmpty()){
                                        Logger.d("[GamBannerBidManager] Failed to analyze ad body - ${weakConfig.get()?.adSlotId}\nhtml is null or empty")
                                    } else{
                                        analyzeAdBody(html)
                                    }
                                } catch (exception: Exception) {
                                    Logger.d("[GamBannerBidManager] Failed to analyze ad body - ${weakConfig.get()?.adSlotId}\n${exception.message}")
                                }
                            }

                            return@onAdLoaded true
                    })
                }

                override fun onAdClicked() {
                    weakConfig.get()?.publisherBannerListenerRunner?.onAdClicked()
                }

                override fun onAdImpression() {

                    weakConfig.get()?.let { config ->
                        config.adManagerAdView?.let { adManagerAdView ->
                            getWebViewSize(adManagerAdView)?.let { (width, height) ->
                                if (width > 0 && height > 0 && config.adSize != org.prebid.mobile.AdSize(width, height)) {
                                    config.adSize = org.prebid.mobile.AdSize(width, height)
                                    Logger.i("[GamBannerBidManager] GAM Banner is resized to ($width x $height) - ${config.adSlotId}")
                                }
                            }
                        }
                    }

                    weakConfig.get()?.publisherBannerListenerRunner?.onAdImpression()
                }
            }

            if(adView.parent == null){
                bannerConfig.bannerView?.addBannerAdView(adView)
            }
        }
    }

    override fun callGam(results: Array<SdkResult>) {
        super.callGam(results)

        val builtRequest = request ?: return

        if (bannerConfig.adManagerAdView != null && bannerConfig.requestBuilder != null) {
            // GAM doesn't allow to put twice.
            // This is a problem when refreshBanner.
            @Suppress("UselessCallOnNotNull")
            if(bannerConfig.adManagerAdView!!.adUnitId.isNullOrEmpty()) {
                bannerConfig.adManagerAdView!!.adUnitId = bannerConfig.adUnitId
            }

            bannerConfig.adManagerAdView!!.loadAd(builtRequest)
        }
        else{
            Logger.e("[GamBannerBidManager] Failed to load GAM ad - adManagerAdView or requestBuilder is null - ${bannerConfig.adSlotId}")
        }
    }



    private fun analyzeAdBody(html: String) {
        val prebidIdentifier = bannerConfig.prebidCacheIdentifier
        var desc = AdSource.STROEER
        if (prebidIdentifier != null && html.contains(prebidIdentifier)) {
            resizeAd(bannerConfig.adManagerAdView)
        } else {
            desc = AdSource.GOOGLE
        }

        DebugInfoManager.addFinalResultToDebugInfo(bannerConfig, desc)
        bannerConfig.source.adSubSource = desc
        Logger.i("[PublisherBannerListenerRunner] Banner contains $desc ad in ${bannerConfig.adSlotId}")
        bannerConfig.session?.recordEvent(AdAnalyzed(desc))
    }

    fun resizeAd(adManagerAdView: AdManagerAdView?) {
        adManagerAdView?.let {
            if (adConfig.prebidAdSize?.isNoZeroPixel() == true) {
                adConfig.prebidAdSize?.let{ size->
                    adManagerAdView.setAdSizes(size.toGAM())
                    Logger.i("[BannerPrebidSdkAdapter] Resizing ad to: " + size.width + "x" + size.height)
                }
            }
        }
    }

    fun getWebViewSize(adView: AdManagerAdView): Pair<Int, Int>? {
        fun find(view: View): WebView? {
            if (view is WebView) return view

            if (view is ViewGroup) {
                for (index in 0 until view.childCount) {
                    find(view.getChildAt(index))?.let { return it }
                }
            }

            return null
        }

        val webView = find(adView) ?: return null
        val density = webView.resources.displayMetrics.density

        return (webView.width / density).roundToInt() to (webView.height / density).roundToInt()
    }
}