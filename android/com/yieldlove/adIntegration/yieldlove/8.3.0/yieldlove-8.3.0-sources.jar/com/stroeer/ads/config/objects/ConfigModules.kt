package com.stroeer.ads.config.objects

/**
 * "modules": [
 * {
 * "PREBID": {
 * "yieldloveAccountId": "fussball-live-ticker-herzrasen"
 * },
 * "CRITEO": {
 * "accountId": "B-058707"
 * }
 * },
 * {
 * "SOURCEPOINT": {
 * "active": true,
 * "propertyId": "10629",
 * "propertyName": "android.app.herzrasen",
 * "privacyManagerId": "406840"
 * },
 * "iOSSOURCEPOINT": {
 * "active": true,
 * "propertyId": "10630",
 * "propertyName": "ios.app.herzrasen",
 * "privacyManagerId": "406870"
 * }
 * }
 * ],
 */
class ConfigModules {
    var prebid: ConfigModule_Prebid? = null
    var sourcePoint: ConfigModule_SourcePoint? = null
    var id5: ConfigModule_ID5 = ConfigModule_ID5() // Create default instance
    var confiant: ConfigModule_Confiant = ConfigModule_Confiant() // Create default instance
}
