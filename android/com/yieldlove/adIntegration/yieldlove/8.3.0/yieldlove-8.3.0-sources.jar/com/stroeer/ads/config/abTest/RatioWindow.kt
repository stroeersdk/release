package com.stroeer.ads.config.abTest

internal class RatioWindow(slotsName: String, main: Int, test: Int) : ARatioWindow(slotsName, main, test) {

    init {
        rebuildWindow()
    }

    override fun scopeLabel() = "Request"

    override fun useMain(): Boolean {
        if (window.isEmpty()) {
            accumulatedMain++
            return true
        }
        if (index >= window.size) rebuildWindow()

        return if (window[index++]) {
            accumulatedMain++
            true
        } else {
            accumulatedTest++
            false
        }
    }
}
