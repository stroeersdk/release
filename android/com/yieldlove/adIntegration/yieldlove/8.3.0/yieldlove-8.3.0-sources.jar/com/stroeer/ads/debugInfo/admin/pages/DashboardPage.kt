package com.stroeer.ads.debugInfo.admin.pages

import android.content.Context
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.consent.ConsentManager
import com.stroeer.utilities.logging.Logger
import fi.iki.elonen.NanoHTTPD

internal class DashboardPage(
    private val appContext: Context,
    private val responseFactory: AdminResponseFactory
) {

    fun serve(): NanoHTTPD.Response {
        val inspectionEnabled = ConfigurationManager.isInspectionMode
        val html = AdminPageUtils.loadHtmlTemplate(appContext, "admin/dashboard.html")
            .replace("{{SDK_VERSION}}", ConfigurationManager.version)
            .replace("{{DEVICE_IP}}", AdminPageUtils.getDeviceIpAddress())
            .replace("{{INSPECTION_CLASS}}", if (inspectionEnabled) "on" else "off")
            .replace("{{INSPECTION_STATUS}}", if (inspectionEnabled) "ON" else "OFF")
            .replace("{{BUTTON_DISABLED}}", if (inspectionEnabled) "disabled" else "")
            .replace("{{TC_STRING}}", ConsentManager.getTcStringOrEmpty().ifEmpty { "Not available" })

        return responseFactory.create(NanoHTTPD.Response.Status.OK, "text/html", html)
    }

    fun enableInspection(): NanoHTTPD.Response {
        ConfigurationManager.enableInspectionMode()
        Logger.i("[DashboardPage] Inspection mode enabled via admin server")
        return responseFactory.create(NanoHTTPD.Response.Status.OK, "application/json", """{"status":"ok"}""")
    }
}
