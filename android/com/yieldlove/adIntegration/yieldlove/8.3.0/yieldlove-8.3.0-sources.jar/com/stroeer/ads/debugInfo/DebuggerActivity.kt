package com.stroeer.ads.debugInfo

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.widget.ImageButton
import android.view.View
import android.view.ViewGroup
import android.widget.TableRow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.stroeer.utilities.logging.Logger
import com.stroeer.utilities.ui.ToastUtil
import com.yieldlove.adIntegration.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Locale

private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<String>() {
    override fun areItemsTheSame(oldItem: String, newItem: String) = oldItem == newItem
    override fun areContentsTheSame(oldItem: String, newItem: String) = oldItem == newItem
}

class DebuggerActivity : AppCompatActivity() {

    private lateinit var recyclerForLog: RecyclerView
    private lateinit var toolbar: Toolbar

    private lateinit var searchView: SearchView
    private lateinit var refreshLogButton: ImageButton
    private lateinit var clearLogsButton: ImageButton
    private lateinit var singleInfoButton: ImageButton
    private lateinit var multipleInfoButton: ImageButton
    private lateinit var adUnitSearchView: SearchView
    private var allAdUnitInfos = listOf<ISdkDebugInfo>()
    private val allLogs = mutableListOf<String>()
    private val adapter = LogAdapter()

    private lateinit var recyclerForAdUnit: RecyclerView
    private val adapterAdUnit = SdkDebugInfoAdapter()

    private var debugInfo: IDebugInfo? = null

    private enum class ButtonType{
        AdUnit,
        Network,
        Log,
        Support
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val adUnitId = intent.getStringExtra(AD_UNIT_ID)
        debugInfo = DebugInfoManager.getInstance().getDebugInfo(adUnitId!!)

        setContentView(R.layout.stroeer_activity_debugger)

        recyclerForLog = findViewById(R.id.rvLogs)
        recyclerForAdUnit = findViewById(R.id.rvAdUnit)

        searchView = findViewById(R.id.searchView)
        refreshLogButton = findViewById(R.id.refreshLogButton)
        clearLogsButton = findViewById(R.id.clearLogsButton)
        singleInfoButton = findViewById(R.id.infoCropButton)
        multipleInfoButton = findViewById(R.id.infoViewAgentButton)
        adUnitSearchView = findViewById(R.id.adUnitSearchView)
        toolbar = findViewById(R.id.loggerTopToolbar)

        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        refreshLogButton.setOnClickListener { lifecycleScope.launch { loadLogs() } }
        clearLogsButton.setOnClickListener { clearLogs() }
        singleInfoButton.setOnClickListener { showSingleAdUnitInfo() }
        multipleInfoButton.setOnClickListener { showAllAdUnitInfo() }

        adUnitSearchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = true
            override fun onQueryTextChange(newText: String?): Boolean {
                filterAdUnitInfos(newText.orEmpty())
                return true
            }
        })

        recyclerForLog.layoutManager = LinearLayoutManager(this)
        recyclerForLog.adapter = adapter
        recyclerForLog.setHasFixedSize(true)
        attachDoubleTapListenerToLogs()

        recyclerForAdUnit.layoutManager = LinearLayoutManager(this)
        recyclerForAdUnit.adapter = adapterAdUnit
        recyclerForAdUnit.setHasFixedSize(true)
        attachDoubleTapListenerToAdUnit()

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = true
            override fun onQueryTextChange(newText: String?): Boolean {
                val q = newText.orEmpty()
                adapter.searchQuery = q
                filterLogs(q)
                return true
            }
        })

        showAdUnitInfo()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.stroeer_logger_top_menu, menu)
        switchUis(ButtonType.AdUnit)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.debugInfoId -> { showAdUnitInfo(); true }
            R.id.networkInfoId -> { showNetworkInfo(); true }
            R.id.loggerId -> { showLoggerInfo(); true }
            R.id.supportId -> { showSupport(); true }
            R.id.closeLogId -> { finish(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAdUnitInfo() {
        showSingleAdUnitInfo()
    }

    private fun showSingleAdUnitInfo() {
        switchUis(ButtonType.AdUnit)
        lifecycleScope.launch {
            adapter.submitList(emptyList())
            if (debugInfo == null) {
                allLogs.add("Debug info is not set.")
                allAdUnitInfos = emptyList()
            } else {
                allAdUnitInfos = debugInfo!!.sdkDebugInfos.reversed()
            }
            adapterAdUnit.submitList(allAdUnitInfos)
        }
    }

    private fun showAllAdUnitInfo() {
        switchUis(ButtonType.AdUnit)
        lifecycleScope.launch {
            adapter.submitList(emptyList())
            allAdUnitInfos = DebugInfoManager.getInstance().getDebugInfoList()
                .flatMap { it.sdkDebugInfos }
                .reversed()
            adapterAdUnit.submitList(allAdUnitInfos)
        }
    }

    private fun filterAdUnitInfos(query: String) {
        if (query.isBlank()) {
            adapterAdUnit.submitList(allAdUnitInfos)
        } else {
            adapterAdUnit.submitList(allAdUnitInfos.filter {
                it.adSlotId?.contains(query, ignoreCase = true) == true
            })
        }
    }

    private fun showNetworkInfo() {
        switchUis(ButtonType.Network)
        lifecycleScope.launch { loadNetworkLogs() }
    }

    private fun showLoggerInfo() {
        switchUis(ButtonType.Log)
        lifecycleScope.launch { loadLogs() }
    }

    private fun showSupport(){
        switchUis(ButtonType.Support)
    }

    private fun switchUis(uiNum: ButtonType) {
        recyclerForAdUnit.visibility = View.GONE
        recyclerForLog.visibility = View.GONE
        searchView.visibility = View.VISIBLE
        refreshLogButton.visibility = View.GONE
        clearLogsButton.visibility = View.GONE
        singleInfoButton.visibility = View.GONE
        multipleInfoButton.visibility = View.GONE
        adUnitSearchView.visibility = View.GONE
        adUnitSearchView.setQuery("", false)

        when (uiNum) {
            ButtonType.AdUnit -> {
                searchView.visibility = View.GONE
                recyclerForAdUnit.visibility = View.VISIBLE
                adUnitSearchView.visibility = View.VISIBLE
                singleInfoButton.visibility = View.VISIBLE
                multipleInfoButton.visibility = View.VISIBLE
            }
            ButtonType.Network -> {
                recyclerForLog.visibility = View.VISIBLE
            }
            ButtonType.Log -> {
                recyclerForLog.visibility = View.VISIBLE
                refreshLogButton.visibility = View.VISIBLE
                clearLogsButton.visibility = View.VISIBLE
            }
            ButtonType.Support -> {
                searchView.visibility = View.GONE
            }
        }
    }

    private suspend fun loadNetworkLogs() {
        allLogs.clear()
        adapterAdUnit.submitList(emptyList())
        withContext(Dispatchers.IO) {
            try {
                for (entry in debugInfo!!.sdkDebugInfos.reversed()) {
                    if (entry.requestJson != null || entry.responseJson != null) {
                        val stringBuilder = StringBuilder()
                        stringBuilder.append(entry.description).append("-").append(entry.adSlotId).append("\n")
                        entry.requestJson?.let { stringBuilder.append("[Request]\n").append(entry.requestJson) }
                        entry.responseJson?.let { stringBuilder.append("\n\n[Response]\n").append(entry.responseJson) }
                        allLogs.add(stringBuilder.toString())
                    }
                }
                allLogs.add("[HTML]\n${debugInfo!!.html}")
            } catch (e: Exception) {
                Logger.e("[DebuggerActivity] Failed to load network information", e)
            }
        }
        withContext(Dispatchers.Main) { adapter.submitList(allLogs.toList()) { scrollToBottom() } }
    }

    private suspend fun loadLogs() = withContext(Dispatchers.IO) {
        allLogs.clear()
        adapterAdUnit.submitList(emptyList())
        try {
            val proc = Runtime.getRuntime().exec(arrayOf("sh", "-c", "logcat -d -v long *:V"))
            BufferedReader(InputStreamReader(proc.inputStream)).useLines { lines ->
                val timestampPattern = Regex("^(?:\\[\\s*)?\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}")
                val buffer = ArrayDeque<String>(10000)
                val entryBuilder = StringBuilder()
                lines.forEach { rawLine ->
                    val line = rawLine
                    if (timestampPattern.containsMatchIn(line)) {
                        if (entryBuilder.isNotEmpty()) {
                            if (buffer.size == 10000) buffer.removeFirst()
                            buffer.addLast(entryBuilder.toString())
                            entryBuilder.clear()
                        }
                        entryBuilder.append(line)
                    } else {
                        entryBuilder.append('\n').append(line)
                    }
                }
                if (entryBuilder.isNotEmpty()) {
                    if (buffer.size == 10000) buffer.removeFirst()
                    buffer.addLast(entryBuilder.toString())
                }
                allLogs.addAll(buffer)
            }
        } catch (e: Exception) {
            Logger.e("[DebuggerActivity] Failed to load logcat", e)
        }
        withContext(Dispatchers.Main) { adapter.submitList(allLogs.toList()) { scrollToBottom() } }
    }

    private fun filterLogs(query: String) {
        val filtered = if (query.isBlank()) allLogs else {
            val orGroups = query.split("|").map { it.trim() }.filter { it.isNotEmpty() }
            allLogs.filter { line ->
                orGroups.any { group -> group.split(Regex("\\s+")).all { term -> line.contains(term, ignoreCase = true) } }
            }
        }
        adapter.submitList(filtered.toList())
    }

    private fun clearLogs() {
        lifecycleScope.launch(Dispatchers.IO) { Runtime.getRuntime().exec("logcat -c") }
        allLogs.clear()
        adapter.submitList(emptyList())
    }

    private fun scrollToBottom() {
        if (adapter.itemCount > 0) recyclerForLog.scrollToPosition(adapter.itemCount - 1)
    }

    private inner class LogAdapter : ListAdapter<String, LogRowVH>(DIFF_CALLBACK) {
        var searchQuery: String = ""
            @SuppressLint("NotifyDataSetChanged")
            set(value) {
                field = value
                notifyDataSetChanged()
            }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogRowVH {
            val context = parent.context
            val row = TableRow(context)
            val pad = (8 * resources.displayMetrics.density).toInt()
            row.setPadding(pad, pad, pad, pad)
            val tv = TextView(context)
            tv.layoutParams = TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tv.setLineSpacing(0f, 1.2f)
            row.addView(tv)
            return LogRowVH(row, tv)
        }
        override fun onBindViewHolder(holder: LogRowVH, position: Int) { holder.bind(getItem(position), searchQuery) }
    }

    private class LogRowVH(itemView: TableRow, private val textView: TextView) : RecyclerView.ViewHolder(itemView) {
        fun bind(fullLine: String, query: String) {
            val spannable = SpannableString(fullLine)
            if (query.isNotBlank()) {
                val terms = query.split("|").flatMap { it.trim().split(Regex("\\s+")) }.filter { it.isNotEmpty() }.distinct()
                val lower = fullLine.lowercase()
                for (term in terms) {
                    var idx = lower.indexOf(term.lowercase())
                    while (idx >= 0) {
                        spannable.setSpan(ForegroundColorSpan(Color.RED), idx, idx + term.length, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE)
                        idx = lower.indexOf(term.lowercase(), idx + term.length)
                    }
                }
            }
            textView.text = spannable
            val headerLine = fullLine.substringBefore('\n')
            val level = Regex("\\b([VDIWEF])\\/").find(headerLine)?.groupValues?.get(1) ?: ""
            textView.setTextColor(when (level) { "E" -> Color.rgb(179, 0, 0); "D" -> Color.rgb(0, 120, 0); "W" -> Color.rgb(255, 140, 0); else -> Color.BLACK })
        }
    }

    private class SdkDebugInfoAdapter : ListAdapter<ISdkDebugInfo, SdkDebugInfoAdapter.VH>(Diff) {
        object Diff : DiffUtil.ItemCallback<ISdkDebugInfo>() {
            override fun areItemsTheSame(old: ISdkDebugInfo, new: ISdkDebugInfo): Boolean = old.createdDate == new.createdDate && old.description == new.description
            override fun areContentsTheSame(old: ISdkDebugInfo, new: ISdkDebugInfo): Boolean = old.createdDate == new.createdDate
        }
        @SuppressLint("SetTextI18n")
        inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvDate = itemView.findViewById<TextView>(R.id.tvDate)
            private val tvTitle = itemView.findViewById<TextView>(R.id.tvTitle)
            private val tvKV = itemView.findViewById<TextView>(R.id.tvKV)
            fun bind(item: ISdkDebugInfo) {
                val sdf = SimpleDateFormat("\uD83D\uDD67 d MMM yyyy 'at' h:mm:ss.SSS a", Locale.getDefault())
                tvDate.text = sdf.format(item.createdDate)
                tvTitle.text = "[${item.adSlotId}] ${item.description}"
                val entries = item.keyValues?.toSortedMap()?.entries ?: emptySet()
                if (entries.isNotEmpty()) {
                    val maxKeyLen = entries.maxOf { it.key.length } - 1
                    tvKV.text = entries.joinToString(separator = "\n") { (key, value) ->
                        var newfeed = ""
                        value?.let { if (it.length >= 30) { newfeed = "\n  " } }
                        key.padEnd(maxKeyLen, ' ') + " : $newfeed$value"
                    }
                    tvKV.typeface = Typeface.MONOSPACE
                } else {
                    tvKV.text = ""
                    tvKV.typeface = Typeface.DEFAULT
                }
            }
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.stroeer_request_log, parent, false)
            return VH(v)
        }
        override fun onBindViewHolder(holder: VH, position: Int) { holder.bind(getItem(position)) }
    }

    private fun attachDoubleTapListenerToLogs() {
        val listener = object : OnItemDoubleTapListener {
            override fun onItemDoubleTapped(rv: RecyclerView, view: View, position: Int) {
                try {
                    val text = adapter.currentList.getOrNull(position) ?: ""
                    copyToClipboard("Log #$position", text)
                    val preview = if (text.length > 80) text.substring(0, 80) + "…" else text
                    ToastUtil.showToast(this@DebuggerActivity, "Copied log #$position")
                    Logger.i("[DebuggerActivity] Log double-tapped at $position $preview")
                } catch (e: Exception) {
                    Logger.e("[DebuggerActivity] Double-tap on logs failed", e)
                }
            }
        }
        recyclerForLog.addOnItemTouchListener(RecyclerItemDoubleTapListener(this, recyclerForLog, listener))
    }

    private fun attachDoubleTapListenerToAdUnit() {
        val listener = object : OnItemDoubleTapListener {
            override fun onItemDoubleTapped(rv: RecyclerView, view: View, position: Int) {
                try {
                    val item = adapterAdUnit.currentList.getOrNull(position)
                    val copied = collectAdUnitText(view, item)
                    copyToClipboard("AdUnit #$position", copied)
                    val titleView = view.findViewById<TextView>(R.id.tvTitle)
                    val title = titleView?.text ?: item?.description ?: ""
                    ToastUtil.showToast(this@DebuggerActivity, "Copied ad info #$position")
                    Logger.i("[DebuggerActivity] AdUnit double-tapped at $position $title")
                } catch (e: Exception) {
                    Logger.e("[DebuggerActivity] Double-tap on adUnit failed", e)
                }
            }
        }
        recyclerForAdUnit.addOnItemTouchListener(RecyclerItemDoubleTapListener(this, recyclerForAdUnit, listener))
    }

    private fun collectAdUnitText(view: View, item: ISdkDebugInfo?): String {
        val tvDate = view.findViewById<TextView>(R.id.tvDate)
        val tvTitle = view.findViewById<TextView>(R.id.tvTitle)
        val tvKV = view.findViewById<TextView>(R.id.tvKV)
        val b = StringBuilder()
        if (tvTitle != null) { b.append(tvTitle.text ?: "") }
        if (tvDate != null) { if (b.isNotEmpty()) { b.append("\n") }; b.append(tvDate.text ?: "") }
        if (tvKV != null) { if (b.isNotEmpty()) { b.append("\n") }; b.append(tvKV.text ?: "") }
        if (b.isNotEmpty()) { return b.toString() }
        if (item == null) { return "" }
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
        b.append(item.description ?: "")
        b.append("\n").append(item.adSlotId ?: "")
        b.append("\n").append(sdf.format(item.createdDate))
        item.keyValues?.toSortedMap()?.forEach { (k, v) -> b.append("\n").append(k).append(" : ").append(v ?: "") }
        if (item.requestJson != null) { b.append("\n[Request]\n").append(item.requestJson) }
        if (item.responseJson != null) { b.append("\n[Response]\n").append(item.responseJson) }
        return b.toString()
    }

    private fun copyToClipboard(label: String, text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, text)
            cm.setPrimaryClip(clip)
        } catch (e: Exception) {
            Logger.e("[DebuggerActivity] Clipboard copy failed", e)
            ToastUtil.showToast(this, "Copy failed")
        }
    }

    interface OnItemDoubleTapListener {
        fun onItemDoubleTapped(rv: RecyclerView, view: View, position: Int)
    }

    private class RecyclerItemDoubleTapListener(
        context: Context,
        private val recyclerView: RecyclerView,
        private val listener: OnItemDoubleTapListener
    ) : RecyclerView.SimpleOnItemTouchListener() {

        private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                try {
                    val child = recyclerView.findChildViewUnder(e.x, e.y)
                    if (child != null) {
                        val holder = recyclerView.getChildViewHolder(child)
                        val position = holder.bindingAdapterPosition
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemDoubleTapped(recyclerView, child, position)
                            return true
                        }
                    }
                } catch (_: Exception) {
                }
                return false
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { return false }
        })

        override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean { return gestureDetector.onTouchEvent(e) }
        override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) { gestureDetector.onTouchEvent(e) }
    }

    companion object {
        const val AD_UNIT_ID = "AD_UNIT_ID"
        @JvmStatic
        fun createIntent(context: Context): Intent { return Intent(context, DebuggerActivity::class.java) }
    }
}