package com.stroeer.ads.formats

enum class AdStatus {
    UNINITIALIZED,
    LOADING,
    LOADING_PREBID,
    LOADING_GOOGLE,
    READY,
    ERROR,
    DESTROYED,
    INACTIVE;

    fun isLoading(): Boolean = this > UNINITIALIZED && this < READY
    fun isReady(): Boolean = this == READY
    fun isError(): Boolean = this == ERROR
}