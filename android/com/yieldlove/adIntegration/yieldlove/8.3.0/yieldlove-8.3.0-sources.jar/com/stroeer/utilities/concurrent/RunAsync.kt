package com.stroeer.utilities.concurrent

import android.os.Handler
import android.os.Looper
import com.stroeer.utilities.logging.Logger
import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.function.Function

object RunAsync {

    private val executorService = Executors.newCachedThreadPool()
    private val scheduler: ScheduledExecutorService = Executors.newScheduledThreadPool(1)

    @JvmStatic
    fun run(runnable: Runnable, timeoutMs: Long, exceptionHandler: (Throwable) -> Unit): CompletableFuture<Void> {
        return wrapWithTimeoutAndException(
            CompletableFuture.runAsync(runnable, executorService),
            timeoutMs
        ) { e ->
            exceptionHandler(e)
            Logger.e("[AsyncCall] Error in async void task:", e)
            null
        }
    }

    @JvmStatic
    fun <T> supply(supplier: () -> T, timeoutMs: Long, exceptionHandler: (Throwable) -> Unit): CompletableFuture<T> {
        return wrapWithTimeoutAndException(
            CompletableFuture.supplyAsync(supplier, executorService),
            timeoutMs
        ) { e ->
            exceptionHandler(e)
            Logger.e("[AsyncCall] Error in async value task:", e)
            null
        }
    }

    private fun <T> wrapWithTimeoutAndException(
        task: CompletableFuture<T>,
        timeoutMs: Long,
        errorHandler: Function<Throwable, T?>
    ): CompletableFuture<T> {
        val wrapped = if (timeoutMs > 0) applyTimeout(task, timeoutMs, TimeUnit.MILLISECONDS) else task
        return wrapped.exceptionally(errorHandler)
    }

    private fun <T> applyTimeout(future: CompletableFuture<T>, timeout: Long, unit: TimeUnit): CompletableFuture<T> {
        val timeoutFuture = CompletableFuture<T>()
        scheduler.schedule(
            { timeoutFuture.completeExceptionally(TimeoutException("AsyncCall timed out after $timeout $unit")) },
            timeout,
            unit
        )
        return future.applyToEither(timeoutFuture, Function.identity())
    }

    @JvmStatic
    fun shutdown() {
        executorService.shutdown()
        scheduler.shutdown()
    }

    @JvmStatic
    fun runOnUiThread(runnable: Runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            runnable.run()
        } else {
            Handler(Looper.getMainLooper()).post(runnable)
        }
    }
}
