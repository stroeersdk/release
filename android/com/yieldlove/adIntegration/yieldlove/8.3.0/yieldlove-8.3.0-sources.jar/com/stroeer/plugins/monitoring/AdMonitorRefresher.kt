package com.stroeer.plugins.monitoring

import android.view.View
import com.stroeer.utilities.logging.Logger
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

class AdMonitorRefresher private constructor() {

    val MAX_RETRY_NUM = 1

    internal class ResetScheduler(var adReloader: IAdReloader) {

        val RESET_TIME = 10L

        private var reloaderCounter = 0
        private val scheduler = Executors.newSingleThreadScheduledExecutor()
        private var scheduledTask: ScheduledFuture<*>? = null
        private val lock = ReentrantLock()

        fun resetCounter() {
            lock.lock()
            try {
                reloaderCounter = 0
            } finally {
                lock.unlock()
            }
        }

        fun updateCounter() {
            lock.lock()
            try {
                reloaderCounter++
            } finally {
                lock.unlock()
            }
        }

        fun startScheduler() {
            scheduledTask?.cancel(true)
            updateCounter()
            scheduledTask = scheduler.schedule(::resetCounter, RESET_TIME, TimeUnit.SECONDS)
        }

        fun getCounter(): Int {
            lock.lock()
            try {
                return reloaderCounter
            } finally {
                lock.unlock()
            }
        }
    }

    private val monitorMaps = HashMap<String, ResetScheduler>()

    fun addNewReloader(adReloader: IAdReloader) {
        val adSlot = adReloader.getAdSlot()
        val monitor = monitorMaps[adSlot]
        if (monitor != null) {
            monitor.adReloader = adReloader
        } else {
            monitorMaps[adSlot] = ResetScheduler(adReloader)
        }
    }

    fun reload(slotView: View, placementId: String?) {
        if (placementId == null || !monitorMaps.containsKey(placementId)) {
            Logger.e("[MonitoringPlugin] AdReloader is not initialized")
            return
        }

        val monitor = monitorMaps[placementId]
        if (monitor == null || monitor.getCounter() >= MAX_RETRY_NUM) return

        monitor.startScheduler()

        Logger.i("[MonitoringPlugin] Attempted to reload - $placementId (${monitor.getCounter()} attempt)")
        monitor.adReloader.reloadAd(slotView, placementId)
    }

    internal fun getMonitorMap() = monitorMaps

    companion object {
        private val instance = AdMonitorRefresher()

        @JvmStatic
        fun getInstance() = instance
    }
}
