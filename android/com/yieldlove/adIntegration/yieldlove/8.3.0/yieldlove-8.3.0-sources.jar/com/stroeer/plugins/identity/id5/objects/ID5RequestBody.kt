package com.stroeer.plugins.identity.id5.objects

import com.stroeer.utilities.json.JsonBase

@Suppress("PropertyName", "LocalVariableName")
class ID5RequestBody  : JsonBase<ID5RequestBody>() {
    // Getters and Setters for all fields
    // Timestamp in extended ISO-8601 format
    var ts: String? = null
        set(ts) {
            checkUpdated(field, ts)
            field = ts
        }

    // Partner number provided by ID5
    var partner: Int? = null
        set(partner) {
            checkUpdated(field, partner)
            field = partner
        }

    // Application identifier (e.g., app store ID)
    var appId: String? = null
        set(appid) {
            checkUpdated(field, appid)
            field = appid
        }

    // Platform-specific app identifier (e.g., package name on Android or numeric ID on iOS)
    var bundle: String? = null
        set(bundle) {
            checkUpdated(field, bundle)
            field = bundle
        }

    // Application version
    var ver: String? = null
        set(ver) {
            checkUpdated(field, ver)
            field = ver
        }

    // IPv4 address closest to the device
    var ip: String? = null
        set(ip) {
            checkUpdated(field, ip)
            field = ip
        }

    // User Agent string from the device's default browser
    var ua: String? = null
        set(ua) {
            checkUpdated(field, ua)
            field = ua
        }

    // ID5 signature from a previous call (cached)
    var signature: String? = null
        set(signature) {
            checkUpdated(field, signature)
            field = signature
        }

    // GDPR flag: 1 if GDPR applies, 0 otherwise
    var gdpr: Int? = null
        set(gdpr) {
            checkUpdated(field, gdpr)
            field = gdpr
        }

    // TCF-compliant consent string (or allowed_vendors info) when applicable
    var gdpr_consent: String? = null
        set(gdpr_consent) {
            checkUpdated(field, gdpr_consent)
            field = gdpr_consent
        }

    // Array of allowed vendor IDs (ID5 Partner IDs or IAB Vendor IDs)
    var allowed_vendors: MutableList<String?>? = null
        set(allowed_vendors) {
            checkUpdated(field, allowed_vendors)
            field = allowed_vendors
        }

    // US Privacy consent string
    var us_privacy: String? = null
        set(us_privacy) {
            checkUpdated(field, us_privacy)
            field = us_privacy
        }

    // GPP section IDs in force for the current transaction (could be comma-separated)
    var gpp_sid: String? = null
        set(gpp_sid) {
            checkUpdated(field, gpp_sid)
            field = gpp_sid
        }

    // IAB Global Privacy Platform consent string
    var gpp_string: String? = null
        set(gpp_string) {
            checkUpdated(field, gpp_string)
            field = gpp_string
        }

    // App name (may be aliased at publisher’s request)
    var name: String? = null
        set(name) {
            checkUpdated(field, name)
            field = name
        }

    // Domain of the app
    var domain: String? = null
        set(domain) {
            checkUpdated(field, domain)
            field = domain
        }

    // The device identifier (IDFA on iOS or GAID on Android)
    var maid: String? = null
        set(maid) {
            checkUpdated(field, maid)
            field = maid
        }

    // Specifies the type of maid: "idfa" or "gaid"
    var maid_type: String? = null
        set(maid_type) {
            checkUpdated(field, maid_type)
            field = maid_type
        }

    // (Optional) IDFA field, if needed
    var idfa: String? = null
        set(idfa) {
            checkUpdated(field, idfa)
            field = idfa
        }

    // SHA256 hash of the cleansed e-mail address
    var hem: String? = null
        set(hem) {
            checkUpdated(field, hem)
            field = hem
        }

    // SHA256 hash of the cleansed phone number
    var phone: String? = null
        set(phone) {
            checkUpdated(field, phone)
            field = phone
        }

    // Apple ID for Vendors (IDFV)
    var idfv: String? = null
        set(idfv) {
            checkUpdated(field, idfv)
            field = idfv
        }

    // Partner specific user ID
    var puid: String? = null
        set(puid) {
            checkUpdated(field, puid)
            field = puid
        }

    // IPv6 address of the device
    var ipv6: String? = null
        set(ipv6) {
            checkUpdated(field, ipv6)
            field = ipv6
        }

    // Country code (ISO-3166-1-alpha-2)
    var country: String? = null
        set(country) {
            checkUpdated(field, country)
            field = country
        }

    // Region code (ISO-3166-2 or 2-letter state code if USA)
    var region: String? = null
        set(region) {
            checkUpdated(field, region)
            field = region
        }

    // City using United Nations Code for Trade & Transport Locations format
    var city: String? = null
        set(city) {
            checkUpdated(field, city)
            field = city
        }

    // "Ask App not to Track" flag (true if selected)
    var isAtt: Int? = null
        set(att) {
            checkUpdated(field, att)
            field = att
        }

    // Accept-Language string (compatible with browser Accept-Language header)
    var accept_language: String? = null
        set(accept_language) {
            checkUpdated(field, accept_language)
            field = accept_language
        }

    // Array of segment objects
    var segments: List<Segment>? = null
        set(segments) {
            checkUpdated(field, segments)
            field = segments
        }

    var isUpdated: Boolean = true
        private set

    /**
     * Check if the value has been updated
     * @param oldVal stored value
     * @param newVal new value
     */
    private fun checkUpdated(oldVal: Any?, newVal: Any?) {
        if (oldVal != newVal) {
            isUpdated = true
        }
    }

    /**
     * Reset the updated flag to false
     */
    fun resetUpdated() {
        isUpdated = false
    }

    // Nested static class representing a segment object
    class Segment {
        // Destination platform (should be the IAB Vendor ID)
        var destination: String? = null

        // Array of segment IDs to add the user to
        var ids: MutableList<String>? = null

        constructor()

        constructor(destination: String?, ids: MutableList<String>?) {
            this.destination = destination
            this.ids = ids
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other == null || javaClass != other.javaClass) return false
            val segment = other as Segment
            return destination == segment.destination &&
                    ids == segment.ids
        }
    }
}

