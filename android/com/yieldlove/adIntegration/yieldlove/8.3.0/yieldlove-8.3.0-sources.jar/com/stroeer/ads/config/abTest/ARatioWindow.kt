package com.stroeer.ads.config.abTest

import android.annotation.SuppressLint

internal abstract class ARatioWindow(
    override val slotsName: String,
    main: Int,
    test: Int
) : IRatioWindow {

    protected var main = main.coerceAtLeast(0)
    protected var test = test.coerceAtLeast(0)

    protected val window = mutableListOf<Boolean>()
    protected var index = 0

    protected var accumulatedMain = 0
    protected var accumulatedTest = 0

    init {
        if (this.main == 0 && this.test == 0) this.main = 1
    }

    override fun getConfiguredRatio(): String = "$main:$test"

    @SuppressLint("DefaultLocale")
    override fun getCurrentRunningRatio(): String {
        val total = accumulatedMain + accumulatedTest
        val mainPercent = if (total == 0) 100.0
        else accumulatedMain.toDouble() / total.toDouble() * 100
        return "(conf-$main:$test, run-$accumulatedMain:$accumulatedTest, ${scopeLabel()}-${String.format("%.1f", mainPercent)}% Main in the group of $slotsName)"
    }

    protected abstract fun scopeLabel(): String

    protected fun rebuildWindow() {
        window.clear()
        repeat(main) { window.add(true) }
        repeat(test) { window.add(false) }
        window.shuffle()
        index = 0
    }
}
