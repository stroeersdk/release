package com.stroeer.ads.config

import android.content.Context
import com.stroeer.ads.config.abTest.ConfigurationRatioManager
import com.stroeer.ads.config.loaders.IFetcher
import com.stroeer.ads.config.loaders.PreferenceFetcher
import com.stroeer.ads.config.objects.Configuration
import com.stroeer.ads.config.objects.Configuration.Companion.fromJson
import com.stroeer.utilities.logging.Logger
import org.jetbrains.annotations.TestOnly

internal class ABTestManager {

    private var config: Configuration? = null
    var testConfig: Configuration? = null
        private set
    private var storageFetcher: IFetcher? = null
    private var networkFetchSucceeded: Boolean = false

    fun setConfig(config: Configuration) {
        this.config = config
    }

    fun isABTestActive(): Boolean =
        config?.abTest?.active == true

    /**
     * Loads the AB test variant config and applies the ratio groups.
     *
     * Seeds from cache first so the variant is available immediately / offline. A network fetch
     * is then attempted on the first call. Once a network fetch has succeeded, subsequent calls
     * to load() are ignored entirely — no ratio group update, no cache read, no network fetch.
     */
    suspend fun load(
        applicationName: String,
        applicationContext: Context?,
        httpFetcher: IFetcher?,
        storageFetcherOverride: IFetcher?,
        maxRetries: Int
    ) {
        val config = this.config ?: return

        if (!isABTestActive()) {
            return
        }

        val abTest = config.abTest ?: return
        val testConfigName = "${applicationName}_${abTest.name.trim()}"
        Logger.i("[ABTestManager] AB test enabled, loading test config - $testConfigName")

        // Once a network fetch has succeeded, skip everything — no cache read, no network fetch,
        // and no ratio group updates.
        if (networkFetchSucceeded) {
            Logger.i("[ABTestManager] Test config already loaded from network - skipping")
            return
        }

        // Ratio groups always come from the main config and are applied on every load.
        ConfigurationRatioManager.setGroups(abTest.groups, applicationContext)

        // Resolve storage: use injected override (tests), otherwise build a keyed fetcher per test name
        val storage: IFetcher? = storageFetcherOverride
            ?: applicationContext?.let { PreferenceFetcher(it, testConfigName) }
        this.storageFetcher = storage

        // Always seed from cache first so the variant is available immediately / offline.
        loadTestConfigFromCache(storage, testConfigName)

        // Network refresh
        for (attempt in 1..maxRetries) {
            try {
                val raw = httpFetcher?.load(testConfigName)
                    ?: error("Config fetch returned null")

                val parsed = fromJson(raw)
                // Persist before committing testConfig; a store failure must not trigger a re-parse.
                runCatching { storage?.store(raw) }
                    .onFailure { Logger.e("[ABTestManager] Failed to store test config - $testConfigName", it) }
                testConfig = parsed
                networkFetchSucceeded = true

                Logger.i("[ABTestManager] Loaded test config - $testConfigName with ratio\n$ConfigurationRatioManager")
                return
            } catch (e: Exception) {
                Logger.e("[ABTestManager] Failed to load test config - $attempt/$maxRetries", e)
            }
        }
        Logger.w("[ABTestManager] Network refresh failed for $testConfigName - using cached variant")
    }

    /** Loads and parses the cached test config. Returns true when a usable config was applied. */
    private suspend fun loadTestConfigFromCache(storage: IFetcher?, testConfigName: String): Boolean {
        val cachedRaw = try {
            storage?.load(testConfigName)
        } catch (e: Exception) {
            Logger.e("[ABTestManager] Cache read failed", e)
            null
        }

        if (cachedRaw.isNullOrBlank()) return false

        return try {
            testConfig = fromJson(cachedRaw)
            Logger.i("[ABTestManager] Loaded cached test config - $testConfigName")
            testConfig != null
        } catch (e: Exception) {
            Logger.e("[ABTestManager] Failed to parse cached test config", e)
            false
        }
    }

    fun reset() {
        config = null
        testConfig = null
        networkFetchSucceeded = false
        storageFetcher?.delete()
        storageFetcher = null
        ConfigurationRatioManager.setGroups(null, null)
    }

    @TestOnly
    fun peekTestConfig(): Configuration? = testConfig
}
