package com.stroeer.ads.config

import android.content.Context
import com.stroeer.ads.config.abTest.ConfigurationRatioManager
import com.stroeer.ads.config.loaders.IFetcher
import com.stroeer.ads.config.loaders.PreferenceFetcher
import com.stroeer.ads.config.objects.Configuration
import com.stroeer.ads.config.objects.Configuration.Companion.fromJson
import com.stroeer.utilities.logging.Logger
import org.jetbrains.annotations.TestOnly

internal class ABTestManager {

    private var config: Configuration? = null
    var testConfig: Configuration? = null
        private set
    private var storageFetcher: IFetcher? = null

    fun setConfig(config: Configuration) {
        this.config = config
    }

    fun isABTestActive(): Boolean =
        config?.abTest?.active == true

    /**
     * Loads the AB test variant config and applies the ratio groups.
     *
     * Once a test config is loaded (from cache or network), subsequent calls are ignored entirely.
     * On a cache hit the config is applied immediately and no network fetch is made.
     * On a cache miss the config is fetched from the network and persisted to local storage.
     */
    suspend fun load(
        applicationName: String,
        applicationContext: Context?,
        httpFetcher: IFetcher?,
        storageFetcherOverride: IFetcher?,
        maxRetries: Int
    ) {
        val config = this.config ?: return

        if (!isABTestActive()) {
            return
        }

        val abTest = config.abTest ?: return
        val testConfigName = "${applicationName}_${abTest.name.trim()}"
        Logger.i("[ABTestManager] AB test enabled, loading test config - $testConfigName")

        // Once test config is loaded (from cache or network), skip all updates.
        if (testConfig != null) {
            Logger.i("[ABTestManager] Test config already loaded - skipping")
            return
        }

        ConfigurationRatioManager.setGroups(abTest.groups, applicationContext)

        val storage: IFetcher? = storageFetcherOverride
            ?: applicationContext?.let { PreferenceFetcher(it, testConfigName) }
        this.storageFetcher = storage

        // Cache hit: apply immediately, no network fetch needed.
        if (loadTestConfigFromCache(storage, testConfigName)) {
            Logger.i("[ABTestManager] Loaded test config - $testConfigName with ratio\n$ConfigurationRatioManager")
            // Update test config in background to ensure we have the latest version, but don't apply it to the config.
            loadTestConfigFromNetwork(httpFetcher, testConfigName, maxRetries, false)
            return
        }

        // Cache miss: fetch from network and persist to local storage.
        loadTestConfigFromNetwork(httpFetcher, testConfigName, maxRetries)
    }

    /** Loads and parses the cached test config. Returns true when a usable config was applied. */
    private suspend fun loadTestConfigFromCache(storage: IFetcher?, testConfigName: String): Boolean {
        val cachedRaw = try {
            storage?.load(testConfigName)
        } catch (e: Exception) {
            Logger.e("[ABTestManager] Cache read failed", e)
            null
        }

        if (cachedRaw.isNullOrBlank()) return false

        return try {
            testConfig = fromJson(cachedRaw)
            Logger.i("[ABTestManager] Loaded cached test config - $testConfigName")
            testConfig != null
        } catch (e: Exception) {
            Logger.e("[ABTestManager] Failed to parse cached test config", e)
            false
        }
    }

    private suspend fun loadTestConfigFromNetwork(httpFetcher: IFetcher?, testConfigName: String, maxRetries: Int, applyToConfig : Boolean = true ) {
        for (attempt in 1..maxRetries) {
            try {
                val raw = httpFetcher?.load(testConfigName)
                    ?: error("Config fetch returned null")

                val parsed = fromJson(raw)
                runCatching { storageFetcher?.store(raw) }
                    .onFailure { Logger.e("[ABTestManager] Failed to store test config - $testConfigName", it) }

                if( applyToConfig ){
                    testConfig = parsed
                }

                val applicationStatus = if (applyToConfig) "and applied to config" else "without applying to config"
                Logger.i("[ABTestManager] Loaded test config - $testConfigName from Network $applicationStatus with ratio\n$ConfigurationRatioManager")

                return
            } catch (e: Exception) {
                Logger.e("[ABTestManager] Failed to load test config - $attempt/$maxRetries", e)
            }
        }

        Logger.w("[ABTestManager] Network refresh failed for $testConfigName - using cached variant")
        return
    }

    fun reset() {
        config = null
        testConfig = null
        storageFetcher?.delete()
        storageFetcher = null
        ConfigurationRatioManager.setGroups(null, null)
    }

    @TestOnly
    fun peekTestConfig(): Configuration? = testConfig
}
