package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig

class GamRequestBuilder(
    private var localBuilder: AdManagerAdRequest.Builder,
    private val config: AAdConfiguration
) {
    private val keyValuesFromAdapter: MutableMap<String, String?> = HashMap()

    fun addKeyValuesFromAdapter(keyValues: MutableMap<String, String>?): GamRequestBuilder {
        keyValues?.let{
            for (key in keyValues.keys) {
                this.keyValuesFromAdapter[key] = keyValues[key]
            }
        }
        return this
    }

    fun build(): AdManagerAdRequest {
        val builder = GamAdRequestBuilderMerger.merge(GlobalGamManager.adRequestBuilder, localBuilder)

        // Adapter targeting values are nullable; skip nulls so a single missing
        // value can't NPE and abort the whole GAM request.
        for ((key, value) in this.keyValuesFromAdapter) {
            if (value != null) {
                builder.addCustomTargeting(key, value)
            }
        }

        // CustomTargeting
        for ((key, value) in this.config.customTargeting) {
            builder.addCustomTargeting(key, value)
        }

        // SetTimeout
        this.config.config?.gamRequestTimeout?.let { timeout->
            try {
                builder.setHttpTimeoutMillis(timeout.toInt())
            }catch(e: Exception){
                Logger.e("[GamRequestBuilder] Failed to set ad request timeout: $timeout ms - ${e.message}", e)
            }

        }


        // Adding Android SDK Version
        builder.addCustomTargeting("androidYlSdkVersion", listOf(BuildConfig.VERSION_NAME))

        return builder.build()
    }
}

