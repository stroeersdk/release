package com.stroeer.ads.config.objects

class ConfigAdSlot {
    var active: Boolean = true
    var prebidConfigId: String? = null
    var rtaAuction: Boolean? = null
    var autoRefreshTimeMs: Int? = null
    var keyValues: MutableMap<String, Array<String>>? = null
    var customAdSizes: Array<ConfigCustomAdSize>? = null

    fun isInterstitial(): Boolean =
        keyValues
            ?.values
            ?.any { it.contains("interstitial") }
            ?: false

    fun isBanner() : Boolean {
        return !isInterstitial()
    }
}
