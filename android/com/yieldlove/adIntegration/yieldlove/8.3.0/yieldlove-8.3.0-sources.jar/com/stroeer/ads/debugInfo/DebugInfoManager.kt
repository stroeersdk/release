package com.stroeer.ads.debugInfo

import android.util.Log
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.exceptions.DfpBannerLoadAdError
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.reporting.TimeSession
import com.stroeer.utilities.json.JsonPrinter
import com.stroeer.utilities.logging.Logger
import org.prebid.mobile.PrebidMobile

class DebugInfoManager {

    private val debugInfoMap: MutableMap<String, IDebugInfo> = LinkedHashMap(MAX_BUFFER_SIZE+1, 1F, true)

    private val networkDebugInfoMap : MutableMap<String, NetworkDebugInfo> = LinkedHashMap(MAX_BUFFER_SIZE+1, 1F, true)

    companion object{
        const val MAX_BUFFER_SIZE = 30
        @Volatile private var instance: DebugInfoManager? = null

        private val isInspectionMode: Boolean
            get() { return ConfigurationManager.isInspectionMode }

        fun getInstance(): DebugInfoManager {
            // Fast path: return existing instance if available
            if (instance != null) {
                return instance!!
            }
            // Slow path: synchronize and create
            synchronized(this) {
                if (instance == null) {
                    instance = DebugInfoManager()
                }
                return instance!!
            }
        }

        internal fun applyDebugModeIfNeeded() {
            val enabled = Log.isLoggable("StroeerSDK", Log.VERBOSE)
            if(enabled && !ConfigurationManager.isInspectionMode) {
                Logger.i("[DebugInfoManager] Enabling inspection mode by user request (log level VERBOSE) - to disable adb shell setprop log.tag.StroeerSDK INFO")
                ConfigurationManager.enableInspectionMode()
            }
        }

        fun createDebugInfo(adConfig : AAdConfiguration){
            if(ConfigurationManager.isInspectionMode) {
                if(adConfig is BannerConfiguration && adConfig.debugInfo == null) {
                    adConfig.debugInfo = DebugInfo().apply {
                        active = adConfig.configAdSlot?.active ?: true
                        adSlotId = adConfig.adSlotId
                        adSourceInfo = adConfig.source
                        adUnitId = adConfig.adUnitId
                        adSizes = adConfig.availableBannerSizes
                        customTargeting = adConfig.customTargeting
                        prebidActive = adConfig.realTimeAuctionEnabled
                        prebidConfigId = adConfig.configAdSlot?.prebidConfigId
                        accountId = PrebidMobile.getPrebidServerAccountId()
                        appName = ConfigurationManager.getInstance().applicationName
                        tcString = adConfig.tcString
                    }

                    getInstance().addDebugInfo(adConfig.debugInfo!!)
                }
            }
        }

        fun updateServeTime(bannerConfig: BannerConfiguration) {
            if (isInspectionMode) {
                val debugInfo = bannerConfig.debugInfo as? DebugInfo
                debugInfo?.let {
                    val timeSession = bannerConfig.session as? TimeSession
                    timeSession?.let {
                        val servedInTime = timeSession.servedInMs
                        debugInfo.servedInTime = servedInTime
                    }

                    val refreshInterval: Int? = bannerConfig.refreshTime
                    if (refreshInterval != null && refreshInterval > 0) {
                        debugInfo.autoRefreshEnabled = true
                    }
                    debugInfo.customTargeting

                    // Just safety code to avoid infinite loop
                    var counter = MAX_BUFFER_SIZE
                    while (counter-- > 0) {
                        val info = getInstance().getNetworkDebugInfo(bannerConfig.adUnitId) ?: break   // exit loop if null

                        val sdkDebugInfo =
                            debugInfo.sdkDebugInfos.findLast { it.sdkType == info.sdkType }
                        sdkDebugInfo?.requestJson = info.requestString
                        sdkDebugInfo?.responseJson = info.responseString
                    }
                }
            }
        }

        fun addDebugInfoForFail(bannerConfig: BannerConfiguration, description: String, error : StroeerException){
            if(isInspectionMode){
                bannerConfig.debugInfo?.let {
                    val gamSdkDebugInfo = SdkDebugInfo()
                    gamSdkDebugInfo.adSlotId = bannerConfig.adSlotId
                    gamSdkDebugInfo.description = description
                    gamSdkDebugInfo.keyValues = mutableMapOf("errorMessage" to error.message)
                    if (error is DfpBannerLoadAdError){
                        gamSdkDebugInfo.keyValues!!["responseJson"] = "========================\n${JsonPrinter.print(error.adError.toString())}\n========================"
                    }
                    gamSdkDebugInfo.sdkType = SdkType.GAM
                    it.sdkDebugInfos.add(gamSdkDebugInfo)
                }
            }
        }

        fun addFinalResultToDebugInfo(bannerConfig: BannerConfiguration, desc : String){
            if(ConfigurationManager.isInspectionMode) {
                bannerConfig.debugInfo?.let {
                    it.sdkDebugInfos.add( SdkDebugInfo().apply {
                        adSlotId = bannerConfig.adSlotId
                        sdkType = SdkType.GAM
                        description = "Delivered Ad"
                        keyValues = mutableMapOf( "_result" to desc ,
                                                    "responseJson" to "========================\n${JsonPrinter.print(bannerConfig.adManagerAdView?.responseInfo.toString())}\n========================")
                    })
                }
            }
        }

        fun addSendGAM(adConfig : AAdConfiguration, requestKeyValues: Map<String, String?>?){
            if (ConfigurationManager.isInspectionMode){
                val sdkDebugInfo = SdkDebugInfo().apply {
                    adSlotId = adConfig.adSlotId
                    sdkType = SdkType.GAM
                    description = "Send to GAM"
                    // Copy into a mutable map we own, so we can append the size below
                    // without mutating the caller's map.
                    val kv = requestKeyValues?.toMutableMap()
                    if(adConfig is BannerConfiguration){
                        kv?.put("size", adConfig.availableBannerSizes.joinToString { "${it.width}x${it.height}" })
                    }
                    keyValues = kv
                }
                adConfig.debugInfo?.sdkDebugInfos?.add(sdkDebugInfo)
            }
        }
    }

    fun  getDebugInfoList() : List<IDebugInfo> {
        return if (isInspectionMode) {
            synchronized(debugInfoMap) {
                debugInfoMap.values.toList()
            }
        } else {
            emptyList()
        }
    }

    fun addDebugInfo(debugInfo: IDebugInfo) {
        if (!isInspectionMode) return
        synchronized(this.debugInfoMap) {
            try {
                val key = debugInfo.adSlotId
                if (key != null) {
                    this.debugInfoMap[key] = debugInfo

                    if(debugInfoMap.size > MAX_BUFFER_SIZE){
                        val firstKey = debugInfoMap.keys.first()
                        debugInfoMap.remove(firstKey)
                    }
                } else {
                    Logger.e("[DebugInfoManager] Publisher slot name is null, cannot add debug info.")
                }
            } catch (e: Exception) {
                Logger.e("[DebugInfoManager] Error adding debug info: ${e.message}")
            }
        }
    }


    fun getDebugInfo(adSlotId : String) : IDebugInfo? {
        return if (isInspectionMode) {
            debugInfoMap[adSlotId]
        } else {
            null
        }
    }

    fun removeDebugInfo(adSlotId : String) {
        if (isInspectionMode) {
            synchronized(debugInfoMap) {
                debugInfoMap.remove(adSlotId)
            }
        }
    }

    fun addSdkDebugInfo(adSlotId: String, sdkDebugInfo: ISdkDebugInfo) {
        if (!isInspectionMode) return

        synchronized(debugInfoMap) {
            // Ensure a (thread-safe) list exists for this key
            val debugInfo = debugInfoMap[adSlotId]

            debugInfo?.sdkDebugInfos?.add(sdkDebugInfo)
                ?: Logger.e("[DebugInfoManager] DebugInfo for key doesn't exist - $adSlotId")
        }
    }

    fun getSdkDebugInfo(adSlotId : String) : List<ISdkDebugInfo>? {
        return if (isInspectionMode) {
            debugInfoMap[adSlotId]?.sdkDebugInfos
        } else {
            null
        }
    }



    fun addNetworkDebugInfo(networkDebugInfo: NetworkDebugInfo) {
        if (!isInspectionMode) return
        synchronized(this.networkDebugInfoMap) {
            try {
                val key = networkDebugInfo.id
                this.networkDebugInfoMap[key] = networkDebugInfo

                if(networkDebugInfoMap.size > MAX_BUFFER_SIZE){
                    val firstKey = networkDebugInfoMap.keys.first()
                    networkDebugInfoMap.remove(firstKey)
                }
            } catch (e: Exception) {
                Logger.e("[DebugInfoManager] Error adding network debug info: ${e.message}")
            }
        }
    }

    fun getNetworkDebugInfo(adUnitId: String) : NetworkDebugInfo? {
        return if (isInspectionMode) {
            synchronized(this.networkDebugInfoMap) {
                networkDebugInfoMap.values
                    .firstOrNull { it.requestString?.contains(adUnitId) == true }
                    ?.also { networkDebugInfoMap.remove(it.id) }
            }
        } else null
    }
}