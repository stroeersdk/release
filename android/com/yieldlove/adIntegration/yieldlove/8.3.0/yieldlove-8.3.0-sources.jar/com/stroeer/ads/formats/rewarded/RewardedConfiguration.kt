package com.stroeer.ads.formats.rewarded

import android.content.Context
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.formats.AAdConfiguration

class RewardedConfiguration(context: Context) : AAdConfiguration(context){
    var publisherListener : IStroeerRewardedListener? = null

    var rewardedAd: RewardedAd? = null

    var loadAfterReady = true

    override fun destroy() {
        super.destroy()
        publisherListener = null
        rewardedAd?.fullScreenContentCallback = null
        rewardedAd = null
    }
}