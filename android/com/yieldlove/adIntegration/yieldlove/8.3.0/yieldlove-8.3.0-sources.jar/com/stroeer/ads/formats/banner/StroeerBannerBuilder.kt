package com.stroeer.ads.formats.banner

import android.content.Context
import android.view.View
import com.stroeer.ads.bidding.gam.GamBannerBidManager
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.exceptions.*
import com.stroeer.ads.formats.AdType
import com.stroeer.ads.reporting.events.*
import com.stroeer.plugins.monitoring.IAdReloader
import com.stroeer.plugins.monitoring.confiant.ConfiantLoader
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.formats.AStroeerAdBuilder
import com.stroeer.ads.formats.AdCategory
import com.stroeer.ads.formats.AdStatus
import com.stroeer.ads.formats.banner.refresh.RefreshTimer
import com.stroeer.ads.formats.banner.refresh.IRefreshListener
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.bidding.prebid.BannerPrebidSdkAdapter
import com.stroeer.ads.bidding.prebid.PrebidAdUnitConverter
import com.stroeer.plugins.identity.IdentityManager
import kotlinx.coroutines.*
import kotlin.time.Duration.Companion.milliseconds

internal class StroeerBannerBuilder(context: Context, bannerView: StroeerBannerView) : AStroeerAdBuilder(BannerConfiguration(context)) {

    val bannerConfig : BannerConfiguration
        get(){
            return adConfig as BannerConfiguration
        }

    init {
        bannerConfig.bannerView = bannerView

        prebidSdkAdapter = BannerPrebidSdkAdapter(bannerConfig, PrebidAdUnitConverter())
        gamBidManager = GamBannerBidManager(bannerConfig)
    }

    fun load(adSlotId: String, listener: IStroeerBannerListener?) {
        mainScope.launch {
            loadAsync(adSlotId, listener)
        }
    }


    private suspend fun loadAsync(adSlotId: String, listener: IStroeerBannerListener? = null) {
        ConfigurationManager.getInstance().getConfigAsync()

        withContext(Dispatchers.Main){
            try {
                Logger.d("[StroeerBannerBuilder] Loading banner - $adSlotId")

                // Set publisher slot and listener name for error message handling
                bannerConfig.adSlotId = adSlotId
                bannerConfig.publisherListener = listener

                if(!ConfigurationManager.getInstance().isLoaded) {
                    PublisherBannerListenerRunner.invokeOnFail(listener, bannerConfig, ConfigurationIsNotLoadedException(), true)
                    return@withContext
                }

                if(bannerConfig.status.isLoading()) {
                    PublisherBannerListenerRunner.invokeOnFail(listener, bannerConfig, PreviousAdLoadIsInProgressException(), false)
                    return@withContext
                }

                // Validate Context - must be Activity
                validateContext()

                bannerConfig.initialize(adSlotId)

                if(!checkActive()){
                    bannerConfig.bannerView?.addDebugLabel()
                    return@withContext
                }

                setupAutoRefresh()

                // Start up Session
                prepareSession(AdType.BANNER)

                // Clear variables
                cleanLocalVariables()

                // Create DebugInfo
                DebugInfoManager.createDebugInfo(bannerConfig)

                // Start Ad Monitoring
                markForMonitoring()

                val results = startBidding(listener, adSlotId)

                checkRequiresRunningGAM(results)

            }catch(e : TimeoutCancellationException){
                Logger.d("[StroeerBannerBuilder] Timeout - $adSlotId")
                destroyViews()
                handleExceptions(e)
            }catch(_ : ContextException){
                Logger.d("[StroeerBannerBuilder] Context is already dead - $adSlotId")
                destroyViews()
                // No handleExceptions call - context is dead, can't invoke callbacks or show fallback
            }
            catch (e: Exception) {
                if(bannerConfig.bannerView == null){
                    Logger.d("[StroeerBannerBuilder] BannerView is not created or already destroyed - $adSlotId. ${e.message}")
                }
                else {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception occurred in loading banner - $adSlotId",
                        e
                    )
                }
                destroyViews()
                handleExceptions(e)
            }
        }
    }

    suspend fun startBidding(listener: IStroeerBannerListener?, adSlotId : String) : Array<SdkResult>{
        delay(1.milliseconds)

        return  executeSDKAuctions()
    }

    fun stopAutoRefresh() {
        Logger.d("[StroeerBannerBuilder] stopping auto refresh ${bannerConfig.adSlotId}")
        bannerConfig.timer?.clearScheduledTasks()
    }

    private fun setupAutoRefresh() {
        bannerConfig.refreshTime?.let{
            if( it > 0) {
                Logger.i("[StroeerBannerBuilder] Auto refresh is enabled. Refresh time: ${it}ms - ${bannerConfig.adSlotId}")
                bannerConfig.timer = RefreshTimer(object : IRefreshListener {
                    override fun handleRefresh() {
                        refreshBanner()
                    }
                })
            }
        }
    }

    internal fun scheduleRefresh() {
        bannerConfig.timer?.let{
            val time: Int? = bannerConfig.refreshTime
            if (time != null && time > 0) {
                Logger.i("[RefreshTimer] Scheduling refresh in ${time}ms for ${bannerConfig.adSlotId}")
                it.scheduleRefresh(time)
            }
        }
    }

    fun refreshBanner() {
        mainScope.launch {
            if(bannerConfig.status == AdStatus.LOADING){
                Logger.e("[StroeerBannerBuilder] Refreshing fails as it is currently loading - ${bannerConfig.adSlotId}")
                return@launch
            }

            if(bannerConfig.configAdSlot?.active == false) {
                Logger.e("[StroeerBannerBuilder] Refreshing fails as it is currently inactive - ${bannerConfig.adSlotId}")
                return@launch
            }

            // Create DebugInfo
            DebugInfoManager.createDebugInfo(bannerConfig)

            try {
                Logger.i("[StroeerBannerBuilder] Refreshing -${bannerConfig.adSlotId}")
                bannerConfig.reset()

                val result = startBidding(bannerConfig.publisherListener, bannerConfig.adSlotId)

                checkRequiresRunningGAM(result)
            } catch (_: ContextException) {
                Logger.e("[StroeerBannerBuilder] Context is already dead during refresh - ${bannerConfig.adSlotId}")
                destroyViews()
            } catch(e : Exception) {
                if(bannerConfig.bannerView == null){
                    Logger.d("[StroeerBannerBuilder] BannerView is already dead. - ${bannerConfig.adSlotId}. ${e.message}")
                }
                else {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception occurred in loading banner - ${bannerConfig.adSlotId}",
                        e
                    )
                }
                destroyViews()
                handleExceptions(e)
            }
        }
    }

    private fun cleanLocalVariables() {

    }

    override suspend fun getBids(): Array<SdkResult> {
        //  Set up Identity Manager
        IdentityManager.instance.setUserIdToPrebid()
        return this.sdkManager.getBids()
    }

    private fun handleExceptions(exception: Exception) {
        bannerConfig.session?.recordEvent(UnexpectedErrorHappenDuringAdLoading(exception))
        DebugInfoManager.updateServeTime(bannerConfig)
        bannerConfig.bannerView?.addDebugLabel()

        bannerConfig.publisherBannerListenerRunner?.onAdFailedToLoad(StroeerException(exception), "Failed to Load Ad", beforeStart = null, finish = true)
    }

    // To not touch this, this may cause memory leak because of strong reference in AdListener
    private fun createGoogleAdView() {

        gamBidManager.initializeGoogleAdAViewIfNotExist()

        gamBidManager.createAdManagerAdView()
    }

    /*
        Load Confiant
     */
    private fun markForMonitoring() {
        // Monitoring
        ConfiantLoader.getInstance().mark(object : IAdReloader {
            override fun getAdSlot(): String {
                return bannerConfig.adSlotId
            }

            override fun reloadAd(slotView: View?, placementId: String?) {
                refreshBanner()
            }

            override fun getAdView(): View? {
                return bannerConfig.bannerView
            }
        })
    }



    private suspend fun executeSDKAuctions() : Array<SdkResult>{
        var bidResults = arrayOf(SdkResult.SKIPPED)
        if(bannerConfig.realTimeAuctionEnabled){
            prepareSdkManager()
            bidResults = getBids()
        }
        return bidResults
    }

    private fun checkRequiresRunningGAM(bidResults: Array<SdkResult>){
        var runGAM = true
        for(result in bidResults){
            if(result.category == AdCategory.CAMPAIGN){
                runGAM = false
                break
            }
        }
        if(runGAM){
            startGAM(bidResults)
        }
    }

    private fun startGAM(bidResults: Array<SdkResult>){
        createGoogleAdView ()
        recordAdViewPreparedEvent()
        gamBidManager.callGam(bidResults)
    }

    /**
     * Destroys all banner-related resources including timers and views.
     */
    fun destroy() {
        cancelCoroutines()
        bannerConfig.destroy()
        gamBidManager.destroy()
        stopAutoRefresh()
    }

    /**
     * Destroys only banner views while keeping configuration state intact.
     */
    fun destroyViews() {
        Logger.i("[StroeerBannerBuilder] destroyViews called - ${bannerConfig.adSlotId}")
        bannerConfig.destroyViews()
    }
}