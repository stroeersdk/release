package com.stroeer.ads.config

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebView
import com.google.gson.GsonBuilder
import com.stroeer.ads.config.abTest.ConfigurationRatioManager
import com.stroeer.ads.config.loaders.ConfigHttpFetcher
import com.stroeer.ads.config.loaders.IFetcher
import com.stroeer.ads.config.loaders.PreferenceFetcher
import com.stroeer.ads.config.objects.Configuration
import com.stroeer.ads.config.objects.Configuration.Companion.fromJson
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException
import com.stroeer.utilities.concurrent.ACoroutinable
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.jetbrains.annotations.TestOnly
import org.json.JSONObject
import org.prebid.mobile.LogUtil
import org.prebid.mobile.PrebidMobile
import java.util.Date
import kotlinx.coroutines.sync.withLock
import kotlin.time.Duration.Companion.milliseconds

class ConfigurationManager private constructor()  : ACoroutinable() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        @Volatile private var instance: ConfigurationManager? = null

        /**
         * Marks a cached config as stale so a refresh will be attempted soon.
         */
        private const val STALE_CONFIG_TIMESTAMP = 1L

        @JvmStatic
        fun getInstance(): ConfigurationManager {
            instance?.let { return it }
            synchronized(this) {
                if (instance == null) {
                    instance = ConfigurationManager()
                }
                return instance!!
            }
        }

        @TestOnly
        @JvmStatic
        fun setInstance(newInstance: ConfigurationManager) {
            instance = newInstance
        }

        @JvmStatic
        fun enableInspectionMode() {
            Logger.e("[ConfigurationManager] inspection mode enabled")
            isInspectionMode = true
            enableDebugMode()
        }

        @JvmStatic
        fun enableDebugMode() {
            Logger.e("[ConfigurationManager] debug mode enabled")
            isDebugMode = true
            Logger.enableDebugMode()
            PrebidMobile.setLogLevel(PrebidMobile.LogLevel.DEBUG)
            WebView.setWebContentsDebuggingEnabled(true)
            LogUtil.setLogLevel(LogUtil.DEBUG)
        }

        @JvmStatic val version get() = "${BuildConfig.VERSION_NAME}.${BuildConfig.VERSION_CODE} (${BuildConfig.BUILD_TYPE})"
        @JvmStatic val isDebugBuild get() = BuildConfig.DEBUG
        @JvmStatic var ignoreAdViewMemoryLeaked = true
        @JvmStatic var isInspectionMode = false
        @JvmStatic var isDebugMode = false
        @JvmStatic var forcePrebidRendering = false
        @JvmStatic var disableErrorLog = false

        private const val MAIN_CONFIG = "main"
    }

    // ------------------------------------------------------------------------
    // State
    // ------------------------------------------------------------------------

    var applicationContext: Context? = null

    private var appName: String? = null
    val applicationName get() = appName ?: ""

    private var httpFetcher: IFetcher? = null
    private var preferenceFetcher: IFetcher? = null

    private var config: Configuration? = null
    private val abTestManager = ABTestManager()

    @Volatile private var lastUpdated: Long = 0
    @Volatile private var reloadJob : Job? = null

    private val reloadMutex = Mutex()
    /**
     * Ensures only one reload() runs at a time.
     */
    private val networkReloadMutex = Mutex()

    /**
     * Cooldown to avoid hammering refresh attempts while offline.
     */
    private val nextAllowedRefreshAtMs: Long = 5_000 // 5 seconds
    @Volatile private var prevNetworkRefreshTime: Long = 0
    private var now: () -> Long = { System.currentTimeMillis() }

    private val maxRetries = 2

    private val updateIntervalMs: Int
        get() =  if (isDebugMode) 300_000 else (config?.common?.updateIntervalMs ?: 900_000)


    var contentUrl: String? = null

    @TestOnly
    fun setConfigName(name: String) {
        this.appName = name
    }

    @TestOnly
    internal fun setCurrentTimeProvider(provider: () -> Long) {
        now = provider
    }

    // ------------------------------------------------------------------------
    // Initialization
    // ------------------------------------------------------------------------

    @JvmOverloads
    fun initialize(
        applicationContext: Context,
        appName: String,
        listener: IConfigurationListener? = null,
        httpFetcher: IFetcher = ConfigHttpFetcher(),
        preferenceFetcher: IFetcher = PreferenceFetcher(applicationContext)
    ) {
        if (appName.isEmpty()) {
            Logger.e("[ConfigurationManager] appName empty")
            listener?.onFailed()
            return
        }

        this.applicationContext = applicationContext
        this.appName = appName
        this.httpFetcher = httpFetcher
        this.preferenceFetcher = preferenceFetcher

        mainScope.launch {
            try {
                if (reload()) {
                    displayConfiguration()
                    listener?.onSuccess()
                } else {
                    listener?.onFailed()
                }
            } catch (e: Exception) {
                Logger.e("[ConfigurationManager] initialize failed", e)
                listener?.onFailed()
            }
        }
    }

    // ------------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------------
    fun getResolvedConfig(adSlotId: String): Configuration? {
        val testConfig = abTestManager.testConfig
        if (isABTestActive() && testConfig != null) {
            return if (ConfigurationRatioManager.useMain(adSlotId)) config else testConfig
        }
        return config
    }


    fun getConfig(): Configuration? {
        maybeRefreshInBackground()
        return config
    }

    suspend fun getConfigAsync(timeoutMs: Long = ConfigConstants.CONFIG_TIMEOUT_MS): Configuration? {
        config?.let{
            return it
        }

        return withTimeoutOrNull(timeoutMs.milliseconds) {
            reload()
            config
        }
    }

    fun reset() {
        Logger.i("[ConfigurationManager] reset")
        preferenceFetcher?.delete()
        reloadJob?.cancel()
        cancel()

        config = null
        abTestManager.reset()
        lastUpdated = 0
        prevNetworkRefreshTime = 0L
        instance = null
        reloadJob = null
    }

    @TestOnly
    fun resetInstance() {
        Logger.e("[ConfigurationManager] instance reset, This should not be used on Production")
        instance?.mainScope?.cancel()
        instance = ConfigurationManager()
    }

    val isLoaded: Boolean get() { return config != null }

    @TestOnly
    fun getTestConfig(): Configuration? = abTestManager.peekTestConfig()

    fun ensureValid() {
        if (config == null && appName.isNullOrEmpty()) throw ConfigurationIsNotLoadedException()
    }

    // ------------------------------------------------------------------------
    // Refresh scheduling
    // ------------------------------------------------------------------------

    private fun maybeRefreshInBackground() {
        if (!needsRefresh()) return

        reloadInBackground()
    }

    private fun reloadInBackground() {
        if(reloadJob?.isActive == true) return

        reloadJob = mainScope.launch(ioDispatcher) {
            runCatching {
                reload()
            }.onFailure { Logger.e("[ConfigurationManager] reloadInBackground failed", it) }
        }
    }

    private fun needsRefresh(): Boolean {
        return config == null || lastUpdated == 0L || (now() - lastUpdated) > updateIntervalMs
    }

    private fun applyConfig(raw: String, now: Long, source: String) : Boolean{
        try {
            config = fromJson(raw)
            if(config != null){
                Logger.i("[ConfigurationManager] loaded configuration from $source")
                preferenceFetcher?.store(raw)
                lastUpdated = now

                abTestManager.setConfig(config!!)
                mainScope.launch(ioDispatcher) {
                    abTestManager.load(applicationName, applicationContext, httpFetcher, null, maxRetries)
                }
                return true
            }else{
                Logger.e("[ConfigurationManager] failed to parse configuration from $source: config is null")
                return false
            }
        }catch(e: Exception){
            Logger.e("[ConfigurationManager] failed to parse configuration from $source", e)
            return false
        }
    }

    fun loadFromJson(json: String) {
        Logger.i("[ConfigurationManager] loadFromJson")
        applyConfig(json, Date().time, "manual json")
    }

    private suspend fun refreshFromNetwork(applicationName:String): String? {
        return networkReloadMutex.withLock {
            // recheck if refresh is still needed, another coroutine might have refreshed while we were waiting for the lock
            if(!needsRefresh()){
                return null
            }

            if(now() < prevNetworkRefreshTime + nextAllowedRefreshAtMs){
                Logger.w("[ConfigurationManager] refreshFromNetwork called before cooldown - skipping refresh")
                return null
            }

            prevNetworkRefreshTime = now()

            repeat(maxRetries) { attempt ->
                Logger.i("[ConfigurationManager] $applicationName, network refresh attempt ${attempt + 1}/$maxRetries")

                val result = runCatching {
                    httpFetcher?.load(applicationName) ?: error("Config fetch returned null")
                }

                if (result.isSuccess) {
                    Logger.d("[ConfigurationManager] $applicationName, network refresh successful")
                    return@withLock result.getOrNull()
                }

                val e = result.exceptionOrNull() ?: error("Unexpected error during config fetch")

                Logger.e(
                    "[ConfigurationManager] $applicationName, network refresh failed (attempt ${attempt + 1}/$maxRetries)",
                    e
                )

                if (attempt < maxRetries - 1) {
                    delay((1000L * (attempt + 1)).milliseconds)
                }
            }
            null
        }
    }

    private fun refreshFromNetworkAsync(applicationName: String){
        mainScope.launch(ioDispatcher){
            refreshFromNetwork(applicationName)?.let { raw ->
                applyConfig(raw, Date().time, "network (async)")
            }
        }
    }

    /**
     * Performs a synchronous reload with retries. Should be called from a background thread to avoid blocking the UI.
     * Returns true if a valid configuration is loaded (either from cache or network), false otherwise.
     */
    private suspend fun reload() : Boolean {
        val app = appName
        if (app.isNullOrEmpty()) {
            Logger.e("[ConfigurationManager] appName is null")
            return false
        }

        return withContext(ioDispatcher) {
            reloadMutex.withLock {
                // Config already loaded (e.g. by a concurrent startup caller): don't re-run the
                // cache path, which would re-apply config and re-launch the AB test load. Just
                // schedule a background network refresh if one is due.
                if (config != null) {
                    if (needsRefresh()) refreshFromNetworkAsync(applicationName)
                    return@withContext true
                }

                // Load from Cache
                val cachedRaw = preferenceFetcher?.load(app)
                if (!cachedRaw.isNullOrEmpty()) {
                    applyConfig(cachedRaw, STALE_CONFIG_TIMESTAMP, "cache")
                    Logger.i("[ConfigurationManager] loaded from cache")

                    // Refresh in background
                    refreshFromNetworkAsync(applicationName)
                    return@withContext true
                } else {
                    Logger.i("[ConfigurationManager] no cached configuration available - $applicationName")
                }

                // Load from network when config is null
                refreshFromNetwork(applicationName)?.let { raw ->
                    return@withContext applyConfig(raw, Date().time, "network")
                }

                return@withContext config != null
            }
        }
    }

    fun isABTestActive(): Boolean = abTestManager.isABTestActive()

    override fun toString(): String {
        return config?.let {
            JSONObject(GsonBuilder().create().toJson(it)).toString(2)
        } ?: "Configuration not loaded"
    }

    fun displayConfiguration() {
        Logger.i(
            """[ConfigurationManager] Configuration Settings Loaded
               SDK Version : $version
               ApplicationName : $applicationName
               GAM Ad Request Timeout(ms) : ${config?.gamRequestTimeout}
               Prebid Ad Request Timeout(ms) : ${config?.prebidRequestTimeout}
               Configuration Update Interval(ms) : $updateIntervalMs
               AB Test Active : ${isABTestActive()}
               Ignore AdView Memory Leak : $ignoreAdViewMemoryLeaked
            """.trimIndent()
        )
    }
}