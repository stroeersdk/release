package com.stroeer.ads.formats

import android.content.Context
import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.bidding.gam.GamRequestBuilder
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.ConfigAdSlot
import com.stroeer.consent.ConsentManager
import com.stroeer.ads.debugInfo.IDebugInfo
import com.stroeer.ads.reporting.ISession
import com.stroeer.ads.reporting.events.BannerRefreshStarted
import com.stroeer.ads.config.objects.Configuration
import com.stroeer.utilities.logging.Logger
import java.lang.ref.WeakReference

/**
 * Base class that holds ad configuration and initialization logic for ad units.
 * Manages configuration loading, consent readers, and ad-related session data.
 *
 * @property context The Android context used for initialization.
 */
abstract class AAdConfiguration(private val context: Context){
    /** Optional debug information object used for developer/QA inspections. */
    var debugInfo: IDebugInfo? = null

    /** Prebid related properties. These are used when the ad unit is involved in a Prebid auction.
     * They hold references to the Prebid AdUnit, cache identifier, and ad size information.
     */
    var prebidAdUnit: org.prebid.mobile.AdUnit? = null
    var prebidCacheIdentifier: String? = null

    var prebidAdSize: org.prebid.mobile.AdSize? = null

    var realTimeAuctionEnabled : Boolean = true  // rtaAction
    var contentUrl: String? = null

    // Full ad unit ID. ex// "/1234567/sports/banner"
    var adUnitId : String = ""

    /** Weak reference to the activity context to avoid memory leaks. */
    private var activityContextRef: WeakReference<Context> = WeakReference(context)

    /** Returns the current activity context if still valid, otherwise null. */
    val activityContext: Context?
        get() = activityContextRef.get()

    /** Returns the application context if the activity context is available. */
    val applicationContext: Context?
        get() = activityContext?.applicationContext

    /** Name of the publisher-defined slot where this ad will be displayed. */
    var adSlotId: String = "undefined"

    @Deprecated("Use adSlotId instead")
    val publisherSlotName : String
        get() {
            return adSlotId
        }

    // var adSlotId : String = "undefined"

    var placementName : String = ""

    var config : Configuration? = null

    /** The session object that tracks reporting and analytics for this ad. */
    var session: ISession? = null
    fun sessionStart() {
        session?.start()
    }

    fun sessionEnd(){
        session?.stop()
    }

    /** current status of the ad */
    var status = AdStatus.UNINITIALIZED
        set(value) {
            if(field != value)
                Logger.d("[${this::class.simpleName}] \"$adSlotId\" status changed: ($field->$value)")
            field = value
        }

    fun setReady() {
        if(status.isLoading())
            status = AdStatus.READY
    }

    fun setError(){ status = AdStatus.ERROR }

    fun setInActive(){ status = AdStatus.INACTIVE }

    /** Information about the ad source (DSP, network, etc.). */
    var source: AdSourceInfo = AdSourceInfo()

    /** Request builder used for constructing ad requests. */
    var requestBuilder: GamRequestBuilder? = null

    /** Local builder instance for creating ad requests (lazily initialized). */
    var localBuilder : AdManagerAdRequest.Builder? = null

    /** Current IAB TCF consent string, or empty when unavailable. */
    val tcString: String
        get() = ConsentManager.getTcStringOrEmpty()

    var configAdSlot : ConfigAdSlot? = null

    var customTargeting : MutableMap<String, String> = mutableMapOf()
    /**
     * Initializes the ad configuration with a given placement name.
     *
     * @param adSlotId The publisher slot name for this ad placement.
     */
    open fun initialize(adSlotId: String) {

        this.adSlotId = adSlotId
        config = ConfigurationManager.getInstance().getResolvedConfig(adSlotId)

        status = AdStatus.LOADING

        config?.let{ config->
            placementName = config.getPlacementName(adSlotId)

            configAdSlot = config.getAdSlot(placementName)

            if(configAdSlot == null){
                Logger.e("[AdConfiguration] Failed to find ad slot for placement \"$placementName\" in config for adSlotId \"$adSlotId\"")
                throw IllegalArgumentException("Failed to find ad slot for placement \"$placementName\" in config for adSlotId \"$adSlotId\"")
            }

            configAdSlot?.let { config ->
                realTimeAuctionEnabled = config.rtaAuction ?: true
            }

            adUnitId = config.getAdUnitId(placementName)
        }
    }

    open fun reset(){
        status = AdStatus.LOADING
        session?.reset()
        session?.start()
        session?.recordEvent(BannerRefreshStarted())
    }

    /**
     * Cleans up and releases references to avoid memory leaks.
     * Should be called when the ad configuration is no longer needed.
     */
    open fun destroy() {
        Logger.d("[AdConfiguration] Destroy - $adSlotId")
        activityContextRef.clear()
        requestBuilder = null
        localBuilder = null
        status = AdStatus.DESTROYED
    }

    open fun destroyViews(){
    }
}