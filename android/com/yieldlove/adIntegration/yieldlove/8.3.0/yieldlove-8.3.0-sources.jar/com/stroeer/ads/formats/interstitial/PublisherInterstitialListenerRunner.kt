package com.stroeer.ads.formats.interstitial

import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.reporting.events.RequestFinished
import com.stroeer.utilities.concurrent.ACoroutinable
import com.stroeer.utilities.logging.Logger
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

class PublisherInterstitialListenerRunner(intConfig: InterstitialConfiguration) : IInterstitialListenerRunner, ACoroutinable(){
    val adSlotId = intConfig.adSlotId
    val weakListener = WeakReference(intConfig.publisherListener)
    val weakFullListenerRunner = WeakReference(intConfig.publisherListener as? IStroeerInterstitialFullListener)
    val weakConfig = WeakReference(intConfig)
    val weakView = WeakReference(intConfig.interstitialView)

    fun isFullListener() : Boolean {
        return weakFullListenerRunner.get() != null
    }


    override fun onAdLoaded(beforeStart: (suspend () -> Boolean)?) {
        Logger.i("[PublisherInterstitialListenerRunner] onAdLoaded has been called - ${weakConfig.get()?.adSlotId}")

        mainScope.launch {
            if (beforeStart?.invoke() == false) {
                Logger.i("[PublisherInterstitialListenerRunner] onAdLoaded has been called is cancelled. onAdLoaded beforeStart callback returned false - $adSlotId")
                return@launch
            }

            try {
                weakConfig.get()?.setReady()
                weakConfig.get()?.publisherListener?.onAdLoaded()

                if (weakConfig.get()?.loadAfterReady ?: false) {
                    weakView.get()?.show()
                }
            } catch (exception: Exception) {
                Logger.e("[PublisherInterstitialListenerRunner] Exception in onAdLoaded callback", exception)
            }
        }

    }

    override fun onAdFailedToLoad(error: StroeerException, description : String, beforeStart: (suspend () -> Unit)?, finish : Boolean){
        Logger.i("[PublisherInterstitialListenerRunner] onAdFailedToLoad has been called - ${weakConfig.get()?.adSlotId}, ${error.message}")
        weakConfig.get()?.let{
            mainScope.launch {

                beforeStart?.invoke()
                if(finish) {
                    it.session?.recordEvent(RequestFinished())
                    invokeOnFail(weakListener.get(), weakConfig.get(), error, true)
                }
            }
        }
    }

    override fun onAdClicked() {
        Logger.i("[PublisherInterstitialListenerRunner] onAdClicked has been called. - $adSlotId")
        weakFullListenerRunner.get()?.let { listener ->
            mainScope.launch {
                try {
                    listener.onAdClicked()
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherInterstitialListenerRunner] Exception is thrown during onAdClicked callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdDismissedFullScreenContent() {
        Logger.i("[PublisherInterstitialListenerRunner] onAdDismissedFullScreenContent has been called. - $adSlotId")
        weakFullListenerRunner.get()?.let { listener ->
            mainScope.launch {
                try {
                    listener.onAdDismissedFullScreenContent()
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherInterstitialListenerRunner] Exception is thrown during onAdDismissedFullScreenContent callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdFailedToShowFullScreenContent(exception : StroeerException) {
        Logger.i("[PublisherInterstitialListenerRunner] onAdFailedToShowFullScreenContent has been called. - $adSlotId")
        weakFullListenerRunner.get()?.let { listener ->
            mainScope.launch {
                try {
                    listener.onAdFailedToShowFullScreenContent(exception)
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherInterstitialListenerRunner] Exception is thrown during onAdFailedToShowFullScreenContent callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdImpression() {
        Logger.i("[PublisherInterstitialListenerRunner] onAdImpression has been called. - $adSlotId")
        weakFullListenerRunner.get()?.let { listener ->
            mainScope.launch {
                try {
                    listener.onAdImpression()
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherInterstitialListenerRunner] Exception is thrown during onAdImpression callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    override fun onAdShowedFullScreenContent() {
        Logger.i("[PublisherInterstitialListenerRunner] onAdShowedFullScreenContent has been called. - $adSlotId")
        weakFullListenerRunner.get()?.let { listener ->
            mainScope.launch {
                try {
                    listener.onAdShowedFullScreenContent()
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[PublisherInterstitialListenerRunner] Exception is thrown during onAdShowedFullScreenContent callback. - $adSlotId",
                        ex
                    )
                }
            }
        }
    }

    companion object {
        fun invokeOnFail(listener: IStroeerInterstitialListener?, config: InterstitialConfiguration?, exception: StroeerException, closeSession : Boolean) {
            Logger.e("[PublisherInterstitialListenerRunner] onAdFailedToLoad called - ${config?.adSlotId} : ${exception.message}")

            config?.let {
                if(closeSession) {
                    config.sessionEnd()
                }

                config.setError()
                try {
                    listener?.onAdFailedToLoad(exception)
                } catch (ex: Exception) {
                    Logger.e("[PublisherInterstitialListenerRunner] Exception thrown during onAdFailedToLoad callback - ${it.adSlotId}",ex)
                }
            }
        }
    }
}