package com.stroeer.ads.formats

import android.app.Activity
import android.view.View
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.bidding.gam.AGamBidManager
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.objects.AdsSoundSettingStates
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.exceptions.ContextException
import com.stroeer.ads.reporting.TimeSession
import com.stroeer.ads.reporting.events.AdViewPrepared
import com.stroeer.plugins.identity.IdentityManager
import com.stroeer.ads.bidding.SdkManager
import com.stroeer.ads.bidding.SdkResult
import com.stroeer.ads.bidding.prebid.APrebidSdkAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren

abstract class AStroeerAdBuilder(var adConfig: AAdConfiguration) {

    protected lateinit var sdkManager: SdkManager
    protected lateinit var prebidSdkAdapter: APrebidSdkAdapter
    protected lateinit var gamBidManager: AGamBidManager
    protected val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    var contentUrl: String?
        set(value) {
            adConfig.contentUrl = value
        }
        get() {
            return adConfig.contentUrl
        }

    var googleAdViewBuilder: AdManagerAdRequest.Builder?
        get() {
            return adConfig.localBuilder
        }
        set(value) {
            adConfig.localBuilder = value
        }

    protected fun validateContext() {
        DebugInfoManager.applyDebugModeIfNeeded()

        if (adConfig.activityContext !is Activity) {
            throw ContextException("Context is not instance of Activity")
        }
    }

    protected fun prepareSession(adType: AdType) {
        adConfig.applicationContext?.let{appContext->
            adConfig.session = TimeSession(adType, appContext, adConfig.publisherSlotName)
        }

        adConfig.sessionStart()
    }


    protected fun prepareSdkManager() {
        IdentityManager.instance.refreshAsync()

        this.sdkManager = SdkManager(arrayOf(this.prebidSdkAdapter))
    }

    protected fun recordAdViewPreparedEvent() {
        adConfig.session?.recordEvent(AdViewPrepared())
    }

    protected open suspend fun getBids(): Array<SdkResult> {
        IdentityManager.instance.setUserIdToPrebid()

        return this.sdkManager.getBids(adConfig)
    }

    protected suspend fun getHtml(adView: View?): String? {
        return AdAnalyzer.getHtmlFromAdView(adView)
    }

    fun useAdsSoundSettingFrom() {
        val adsSoundSetting = ConfigurationManager.getInstance().getConfig()?.common?.soundSetting
        if(adsSoundSetting != null && adsSoundSetting != AdsSoundSettingStates.RESPECT_USER_SOUND_SETTING) {
            MobileAds.setAppMuted(adsSoundSetting == AdsSoundSettingStates.MUTE)
        }
    }

    /**
     * Cancels all coroutines and cleans up resources.
     * Subclasses should call this in their destroy() method.
     */
    protected open fun cancelCoroutines() {
        coroutineScope.coroutineContext.cancelChildren()
    }

    companion object Companion {
        protected const val AD_SERVER_NAME: String = "GAM"
    }
}