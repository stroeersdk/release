package com.stroeer.ads.config.objects

class ConfigModule_Confiant {
    var active: Boolean = false
    var confiantPropertyId: String? = null
}
