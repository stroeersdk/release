package com.stroeer.ads.formats.banner

import com.stroeer.ads.exceptions.StroeerException

/**
 * Listener interface for banner ad lifecycle events.
 *
 * This interface is intended to replace the legacy `YieldloveBannerAdListener`.
 * Implement this interface to receive callbacks about ad load results, impressions,
 * clicks, and other banner lifecycle events.
 */
interface IStroeerBannerListener  {

    /**
     * Called when the banner ad has successfully loaded.
     *
     * @param banner The [StroeerBannerView] instance that received the ad.
     */
    fun onAdLoaded(banner: StroeerBannerView?)

    /**
     * Called when the banner ad fails to load.
     *
     * @param banner The [StroeerBannerView] that attempted to load the ad.
     * @param error  The [StroeerException] describing the reason for failure.
     */
    fun onAdFailedToLoad(banner: StroeerBannerView?, error: StroeerException)

    /**
     * Called when the ad opens a full-screen overlay (for example, on ad click).
     *
     * @param banner The [StroeerBannerView] that triggered the event.
     */
    fun onAdOpened(banner: StroeerBannerView?)

    /**
     * Called when the ad is closed and the user returns to the app.
     *
     * @param banner The [StroeerBannerView] that triggered the event.
     */
    fun onAdClosed(banner: StroeerBannerView?)

    /**
     * Called when the ad is clicked by the user.
     *
     * @param banner The [StroeerBannerView] that was clicked.
     */
    fun onAdClicked(banner: StroeerBannerView?)

    /**
     * Called when the ad registers an impression (i.e., becomes visible to the user).
     *
     * @param banner The [StroeerBannerView] that displayed the impression.
     */
    fun onAdImpression(banner: StroeerBannerView?)
}