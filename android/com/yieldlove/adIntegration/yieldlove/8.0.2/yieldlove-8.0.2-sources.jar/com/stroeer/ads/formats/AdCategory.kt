package com.stroeer.ads.formats

enum class AdCategory {
    REGULAR,
    CAMPAIGN
}