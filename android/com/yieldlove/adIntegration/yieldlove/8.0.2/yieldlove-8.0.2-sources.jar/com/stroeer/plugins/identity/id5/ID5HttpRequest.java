package com.stroeer.plugins.identity.id5;

import com.stroeer.plugins.identity.id5.objects.ID5Data;
import com.stroeer.plugins.identity.id5.objects.ID5RequestBody;
import com.stroeer.utilities.json.HttpJsonRequest;
import com.stroeer.utilities.logging.Logger;

import okhttp3.*;

import java.util.HashMap;

public class ID5HttpRequest {

    /**
     * Sends an ID5 request and returns the parsed response.
     *
     * @param requestBody ID5 request body.
     * @return ID5Data if successful, null otherwise.
     */
    public ID5Data send(ID5RequestBody requestBody) {

        if(!isValid(requestBody)){
            return null;
        }

        String json = sendRequest(requestBody);
        if(json != null){
            try
            {
                ID5Data data = ID5Data.fromJson(json, ID5Data.class);
                if(data != null){
                    Logger.d("[ID5HttpRequest] Received ID5Data: " + data.toPrettyJson());
                    return data;
                }
            } catch (Exception e) {
                Logger.e("[ID5HttpRequest] Failed to parse ID5Data from json", e);
            }
        }
        return null;
    }

    /**
     * Constructs and sends the HTTP request.
     *
     * @param requestBody ID5 request body.
     * @return JSON response as a string, null if the request fails.
     */
    protected String sendRequest(ID5RequestBody requestBody) {
        String url = ID5Constants.getInstance().getBaseUri();
        Logger.d("[ID5HttpRequest] Sending request to " + url + " with body " + requestBody.toPrettyJson());

        HttpJsonRequest httpJsonRequest = new HttpJsonRequest();
        int timeout = ID5Constants.getInstance().getTimeoutInSecs();

        HashMap<String, String> headers = new HashMap<>(){
            {
                put("Content-Type", "application/json");
            }
        };

        RequestBody body = RequestBody.create(requestBody.toJson(), MediaType.get("application/json; charset=utf-8"));

        return httpJsonRequest.sendPostJson(url, headers, body, timeout, this.getClass());

    }

    /**
     * Validates the request body.
     *
     * @param requestBody ID5 request body.
     * @return true if valid, false otherwise.
     */
    protected boolean isValid(ID5RequestBody requestBody) {
        if (requestBody == null) return logInvalid("Request body is null");
        if (requestBody.getTs() == null) return logInvalid("Timestamp is null");
        if (requestBody.getPartner() == null) return logInvalid("Partner is null");
        if (requestBody.getBundle() == null) return logInvalid("Bundle is null");
        if (requestBody.getVer() == null) return logInvalid("Version is null");
        if (requestBody.getIp() == null) return logInvalid("IP is null");
        if (requestBody.getUa() == null) return logInvalid("User agent is null");
        return true;
    }

    /**
     * Logs validation failures.
     *
     * @param message Error message.
     * @return Always returns false.
     */
    private boolean logInvalid(String message) {
        Logger.e("[ID5HttpRequest] " + message);
        return false;
    }
}
