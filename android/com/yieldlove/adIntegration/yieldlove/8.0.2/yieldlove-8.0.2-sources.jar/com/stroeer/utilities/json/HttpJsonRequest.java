package com.stroeer.utilities.json;

import androidx.annotation.NonNull;

import com.stroeer.utilities.http.SharedHttpClient;
import com.stroeer.utilities.logging.Logger;

import okhttp3.*;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class HttpJsonRequest {

    public String sendGetJson(String url, Map<String, String> headers, int timeoutInSecs, @NonNull Class<?> senderClass){
        Request.Builder builder = createBuilder(url, headers);
        Request request = builder.get().build();

        return sendRequest(request, timeoutInSecs, senderClass);
    }

    public  String sendPostJson(String url, Map<String, String> headers, RequestBody body, int timeoutInSecs, @NonNull Class<?> senderClass){
        Request.Builder builder = createBuilder(url, headers);

        if(body != null) {
            builder.post(body);
        }
        else {
            builder.post(RequestBody.create(new byte[0], null));
        }

        Request request = builder.build();

        return sendRequest(request, timeoutInSecs, senderClass);
    }

    protected String sendRequest(Request request, int timeoutInSecs, @NonNull Class<?> senderClass){

        if(timeoutInSecs <= 0){
            timeoutInSecs = 5;
        }

        OkHttpClient client = createClient(timeoutInSecs);
        Response response = null;
        String senderClassName = senderClass.getSimpleName();
        try {
            Call call = client.newCall(request);
            response = call.execute();

            ResponseBody responsebody = response.body();
            if(response.isSuccessful() && responsebody != null) {
                Logger.d("[" + senderClassName + "] fetched data successfully : " + request.url());
                return responsebody.string();
            }
            else{
                if(responsebody != null) {
                    Logger.e("[" + senderClassName + "] failed to fetch data - " + response.message() +"\n"+ responsebody.string());
                }
                else {
                    Logger.e("[" + senderClassName + "] failed to fetch data - " + response.message());
                }
                return null;
            }
        }catch(Exception e) {
            Logger.e("[" + senderClassName + "] failed to fetch  data" , e);
        } finally {
            if(response != null) {
                response.close();
            }
        }
        return null;
    }

    protected OkHttpClient createClient(int timeoutInSecs){
        return SharedHttpClient.INSTANCE.createClientWithTimeout(timeoutInSecs);
    }

    protected  Request.Builder createBuilder(String url, Map<String, String> headers){
        Request.Builder builder = new Request.Builder()
                .url(url);

        if(headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                builder.addHeader(entry.getKey(), entry.getValue());
            }
        }

        return builder;
    }
}
