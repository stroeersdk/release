package com.stroeer.ads.sdks

enum class SdkResultCode {
    SUCCESS,
    NO_BIDS,
    TIMEOUT,
    FAILED,
    NOT_AVAILABLE,
    SKIPPED,
    NOT_INITIALIZED
}
