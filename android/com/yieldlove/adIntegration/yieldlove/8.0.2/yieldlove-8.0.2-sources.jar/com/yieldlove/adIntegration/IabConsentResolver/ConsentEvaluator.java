package com.yieldlove.adIntegration.IabConsentResolver;

public interface ConsentEvaluator {
    boolean evaluateConsentRequired(int vendorId, int purposeId);
    boolean evaluateLegitimateInterestRequired(int vendorId, int purposeId);
}
