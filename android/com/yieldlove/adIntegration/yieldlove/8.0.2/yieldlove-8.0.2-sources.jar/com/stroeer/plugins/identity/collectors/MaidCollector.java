package com.stroeer.plugins.identity.collectors;


import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.stroeer.plugins.identity.ACollectorWithContext;
import com.stroeer.utilities.logging.Logger;

import java.util.concurrent.CompletableFuture;

/**
 * Return Mobile Advertising ID
 */
public class MaidCollector extends ACollectorWithContext<String> {

    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                AdvertisingIdClient.Info adInfo = AdvertisingIdClient.getAdvertisingIdInfo(applicationContext);
                return adInfo.getId();
            } catch (Exception e) {
                Logger.e("[MaidCollector] Failed to get MAID", e);
                return "Error";
            }
        });
    }
}
