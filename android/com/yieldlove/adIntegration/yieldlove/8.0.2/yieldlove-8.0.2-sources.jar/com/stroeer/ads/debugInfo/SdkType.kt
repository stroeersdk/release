package com.stroeer.ads.debugInfo

enum class SdkType {
    Prebid,
    GAM,
    Gravite
}