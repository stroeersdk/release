package com.stroeer.plugins.identity.collectors;

import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.concurrent.CompletableFuture;

/**
 * Return GPP SID. Collect from IABGPP_GppSID.
 */
public class GppSidCollector extends ACollectorWithContext<String> {

    private static final String GPP_SID_KEY = "IABGPP_GppSID";

    @Override
    public CompletableFuture<String> retrieveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
        return CompletableFuture.completedFuture(sharedPreferences.getString(GPP_SID_KEY, null));
    }
}
