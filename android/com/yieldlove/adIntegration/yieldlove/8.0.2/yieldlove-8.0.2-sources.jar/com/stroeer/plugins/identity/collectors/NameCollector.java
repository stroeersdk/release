package com.stroeer.plugins.identity.collectors;

import com.stroeer.ads.config.ConfigurationManager;
import com.stroeer.plugins.identity.IIdentityCollector;

import java.util.concurrent.CompletableFuture;

/**
 * Return app name
 */
public class NameCollector implements IIdentityCollector<String> {

    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.completedFuture(ConfigurationManager.getInstance().getConfig().getCommon().getDfpAndroidAppName());
    }
}
