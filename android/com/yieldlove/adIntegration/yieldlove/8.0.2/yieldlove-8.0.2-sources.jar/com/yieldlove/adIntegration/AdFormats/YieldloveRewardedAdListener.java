package com.yieldlove.adIntegration.AdFormats;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.stroeer.ads.exceptions.StroeerException;
import com.stroeer.ads.formats.rewarded.StroeerRewardedView;

@Deprecated (since = "Use com.stroeer.ads.formats.rewarded.IStroeerRewardedAdListener instead", forRemoval = true)
public abstract class YieldloveRewardedAdListener implements IAdRequestBuildListener {

    @Override
    public AdManagerAdRequest.Builder onAdRequestBuild() {
        return null;
    }

    public void onAdFailedToLoad(@NonNull StroeerException exception) {
    }

    public abstract void onAdLoaded(@NonNull StroeerRewardedView rewardedAd);

    public abstract void onUserEarnedReward(Reward reward);

}
