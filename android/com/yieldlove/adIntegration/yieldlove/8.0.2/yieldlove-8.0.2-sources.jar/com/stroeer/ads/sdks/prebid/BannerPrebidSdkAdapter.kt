package com.stroeer.ads.sdks.prebid

import android.content.Context
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.admanager.AdManagerAdView
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.exceptions.ContextException
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.sdks.SdkDebugInfo
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.sdks.SdkResult
import com.stroeer.ads.sdks.SdkResultCode
import com.stroeer.ads.sdks.SizeUtils
import com.stroeer.utilities.json.OrtbJsonHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.prebid.mobile.ResultCode
import org.prebid.mobile.api.exceptions.AdException
import org.prebid.mobile.api.rendering.BannerView
import org.prebid.mobile.api.rendering.listeners.BannerViewListener
import org.prebid.mobile.rendering.bidding.data.bid.Bid
import org.prebid.mobile.rendering.bidding.interfaces.BannerEventHandler
import org.prebid.mobile.rendering.bidding.listeners.BannerEventListener
import java.lang.ref.WeakReference
import kotlin.coroutines.resume

class BannerPrebidSdkAdapter(context: Context, adUnitConverter: AdUnitConverter) :
    APrebidSdkAdapter(context, adUnitConverter) {
    override var identifier: String? = null
        private set
    private var prebidAdSize: AdSize? = null

    override suspend fun getBid(adConfig : AAdConfiguration): SdkResult {

        if(!isSdkInitialized()){
            return SdkResult.FAILED
        }

        if(adConfig !is BannerConfiguration){
            throw IllegalArgumentException("[BannerPrebidSdkAdapter] Invalid configuration type. Expected BannerConfiguration but got " + adConfig::class.java.simpleName)
        }

        this.adConfig = adConfig

        initPrebidAdUnit()

        updateContentUrl()

        updateDebugInfoForSend()

        // Enable Cache Id
        OrtbJsonHelper.addOrUpdate(JSONObject(), "ext", "prebid", "cache", "bids")
        OrtbJsonHelper.apply()

        var sdkResult = SdkResult.SKIPPED
        return withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                var  eventListener : WeakReference<BannerEventListener>? = null

                if(adConfig.activityContext == null){
                    throw ContextException("Context is null")
                }

                adConfig.prebidBannerView = PrebidBannerView(
                    adConfig.applicationContext!!, adConfig.adUnit!!.prebidConfigId,
                    object : BannerEventHandler {
                        override fun getAdSizeArray(): Array<out org.prebid.mobile.AdSize?>? {
                            val sizes = adConfig.adUnit!!.adSizes.map { size ->
                                org.prebid.mobile.AdSize(size.width, size.height)
                            }
                            return sizes.toTypedArray()
                        }

                        override fun setBannerEventListener(bannerViewListener: BannerEventListener) {
                            eventListener = WeakReference(bannerViewListener)
                        }

                        override fun requestAdWithBid(bid: Bid?) {
                            Logger.d("[BannerPrebidSdkAdapter] requestAdWithBid is called - ${adConfig.publisherSlotName}")
                            if(bid != null) {
                                var resultCode = ResultCode.NO_BIDS
                                if(!bid.adm.isNullOrEmpty()) {
                                    // Replace the literal "${GDPR_CONSENT}" in adm
                                    bid.adm = bid.adm?.replace("\${GDPR_CONSENT}", adConfig.consentReader.tcString ?: "")
                                    resultCode = ResultCode.SUCCESS
                                }

                                adConfig.prebidBannerView?.price = bid.price
                                sdkResult = getSdkResult(resultCode, bid.prebid?.targeting)
                            } else{
                                sdkResult = getSdkResult(ResultCode.NO_BIDS, mutableMapOf())
                            }

                            identifier = getPrebidAdCacheIdFromTargeting(sdkResult.keyValues)
                            savePrebidAdSize(sdkResult.keyValues, sdkResult.resultCode)
                            updatedDebugInfoForResult(bid?.prebid?.targeting?.mapValues {mapValue-> mapValue.value }?.toMutableMap(), adConfig.prebidBannerView?.bidResponse)

                            if(adConfig.prebidBannerView?.eventListener == null){
                                Logger.e("[BannerPrebidSdkAdapter] BannerEventListener is null. Cannot proceed it further.")
                                sdkResult = SdkResult.FAILED
                            }

                            cont.resume(sdkResult)
                        }

                        override fun trackImpression() {
                        }

                        // This method will be called, if somehow the instance is dead.
                        // The reason why we call cont.resume is that when the activity is dead, suspendCancellableCoroutine will wait for timeout.
                        // This triggers the memory leak, as the thread is still alive.
                        override fun destroy() {
                            Logger.d("[BannerPrebidSdkAdapter] destroy is called - ${adConfig.publisherSlotName}")
                            if(cont.isActive) {
                                cont.resume(SdkResult.NOT_AVAILABLE)
                            }
                        }
                    } // end of event handler
                )

                adConfig.prebidBannerView?.eventListener = eventListener
                // Add PBASlot
                adConfig.prebidBannerView?.pbAdSlot = adConfig.adUnit!!.dfpAdUnitId

                // AdSlot for Prebid 2.x
                adConfig.prebidBannerView?.impOrtbConfig = """
                {
                  "ext": {
                    "data": {
                        "adslot": "${adConfig.adUnit!!.dfpAdUnitId}"
                    }
                  }
                }
                """.trimIndent()

                adConfig.prebidBannerView?.setBannerListener(object : BannerViewListener {
                    override fun onAdLoaded(bannerView: BannerView?) {

                        Logger.i("[Prebid] onAdLoaded is called - ${adConfig.publisherSlotName}")
                        //sdkResult.view = bannerView
                    }

                    override fun onAdFailed(
                        bannerView: BannerView?,
                        exception: AdException?
                    ) {
                        Logger.i("[Prebid] onAdFailed is called - ${adConfig.publisherSlotName} - ${exception?.message}")
                        sdkResult.resultCode = SdkResultCode.FAILED
                        sdkResult.errorMessage = exception?.message
                        updateDebugInfoForFail(mutableMapOf<String, String?>().apply { put("failed", exception?.message) })
                        cont.resume(sdkResult)
                    }

                    override fun onAdDisplayed(bannerView: BannerView?) {
                        Logger.i("[Prebid] onAdDisplayed (onAdImpression) is called - ${adConfig.publisherSlotName}")
                        try {
                            adConfig.userListener?.onAdImpression(adConfig.bannerView)
                        } catch (e: Exception) {
                            Logger.e("[Prebid] Exception is thrown during onAdFailedToLoad callback. - ${adConfig.publisherSlotName}", e)
                        }
                    }

                    override fun onAdClicked(bannerView: BannerView?) {
                        Logger.i("[Prebid] onAdClicked is called - ${adConfig.publisherSlotName}")
                        try {
                            adConfig.userListener?.onAdClicked(adConfig.bannerView)
                        } catch (e: Exception) {
                            Logger.e("[Prebid] Exception is thrown during onAdFailedToLoad callback. - ${adConfig.publisherSlotName}", e)
                        }
                    }

                    override fun onAdClosed(bannerView: BannerView?) {
                        Logger.i("[Prebid] onAdClosed is called - ${adConfig.publisherSlotName}")
                        try {
                            adConfig.userListener?.onAdClosed(adConfig.bannerView)
                        } catch (e: Exception) {
                            Logger.e("[Prebid] Exception is thrown during onAdClosed callback. - ${adConfig.publisherSlotName}", e)
                        }
                    }
                })

                Logger.d("[BannerPrebidSdkAdapter] Prebid loadAd is called - ${adConfig.publisherSlotName}")
                adConfig.prebidBannerView?.loadAd()
            }
        }
    }

    private fun updateDebugInfoForFail(keyValues : MutableMap<String, String?>?){
        if(ConfigurationManager.isInspectionMode) {
            // Add debugInfo
            adConfig.debugInfo?.let {
                val prebidDebugInfo = SdkDebugInfo()
                prebidDebugInfo.publisherSlotName = adConfig.publisherSlotName
                prebidDebugInfo.description = "Failed from Prebid"
                prebidDebugInfo.keyValues = keyValues
                it.sdkDebugInfos.add(prebidDebugInfo)

            }
        }
    }

    override fun initPrebidAdUnit() {
        if(adConfig.adUnit!= null) {
            adConfig.prebidAdUnit = this.adUnitConverter.convertToBannerAdUnit(adConfig.adUnit!!)
        } else{
          Logger.e("[BannerPrebidSdkAdapter] AdUnit is null. Cannot initialize")
        }
    }

    private fun savePrebidAdSize(
        keyValuesFromPrebid: MutableMap<String, String>?,
        resultCode: SdkResultCode
    ) {
        keyValuesFromPrebid?.let {
            if (resultCode == SdkResultCode.SUCCESS) {
                val size =
                    keyValuesFromPrebid[PrebidToGAMKeyValueMapper.CustomTargetingMapping.size.ylKey]
                this.prebidAdSize = SizeUtils.parseSize(size)
            }
        }
    }

    fun resizeAd(adManagerAdView: AdManagerAdView?) {
        adManagerAdView?.let {
            if (prebidAdSize != null && SizeUtils.isNoZeroPixel(prebidAdSize!!)) {
                adManagerAdView.setAdSizes(prebidAdSize!!)
                adConfig.adSize = prebidAdSize?.let{
                    org.prebid.mobile.AdSize(it.width, it.height)
                }
                Logger.i("[BannerPrebidSdkAdapter] Resizing ad to: " + prebidAdSize!!.width + "x" + prebidAdSize!!.height)
            }
        }
    }
}
