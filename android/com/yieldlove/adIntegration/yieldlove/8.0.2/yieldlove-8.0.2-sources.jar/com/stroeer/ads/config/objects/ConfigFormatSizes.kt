package com.stroeer.ads.config.objects

import com.google.android.gms.ads.AdSize

class ConfigFormatSizes {
    @JvmField
    var androidAdSizes: Array<String>? = null
    @JvmField
    var customAdSizes: Array<ConfigCustomAdSize>? = null

    companion object {
        @JvmStatic
        fun getBannerSize(androidSize: String): AdSize? {
            return when (androidSize) {
                "BANNER" -> AdSize.BANNER
                "FULL_BANNER" -> AdSize.FULL_BANNER
                "LARGE_BANNER" -> AdSize.LARGE_BANNER
                "MEDIUM_RECTANGLE" -> AdSize.MEDIUM_RECTANGLE
                "LEADERBOARD" -> AdSize.LEADERBOARD
                "WIDE_SKYSCRAPER" -> AdSize.WIDE_SKYSCRAPER
                "FLUID" -> AdSize.FLUID
                else -> null
            }
        }
    }
}

