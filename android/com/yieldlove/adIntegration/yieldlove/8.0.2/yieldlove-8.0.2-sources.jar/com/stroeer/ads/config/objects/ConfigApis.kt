package com.stroeer.ads.config.objects

/**
 * "openRtb": {
 * "apis": [
 * {
 * "framework": 3
 * },
 * {
 * "framework": 5
 * },
 * {
 * "framework": 6
 * },
 * {
 * "framework": 7
 * }
 * ]
 */
class ConfigApis (@JvmField var framework: Int){
}
