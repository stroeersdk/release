package com.stroeer.ads.exceptions

import com.google.android.gms.ads.LoadAdError

class DfpBannerLoadAdError(val adError: LoadAdError) : StroeerException(){
    override val message: String?
        get() = adError.message
}