package com.stroeer.ads.reporting.events

class GamRequested : TimeEvent()
