package com.yieldlove.adIntegration.AdUnit;

import com.google.android.gms.ads.AdSize;

public interface AdUnit {
    String getPrebidConfigId();

    String getCriteoAdUnitId();

    String getDfpAdUnitId();

    Boolean getRtaAuction();

    AdSize[] getAdSizes();

    Integer[] getOpenRtbApi();

    Integer getAutoRefreshTimeInMs();
}
