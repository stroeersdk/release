package com.stroeer.plugins.backfill.error;

public class DirectCallToGravite extends Exception{

}
