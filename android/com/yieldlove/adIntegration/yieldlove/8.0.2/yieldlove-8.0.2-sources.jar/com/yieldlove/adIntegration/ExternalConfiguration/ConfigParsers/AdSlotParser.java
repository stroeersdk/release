package com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigAdSlot;

public class AdSlotParser {
    JsonObject parsedJson;

    public AdSlotParser(JsonObject json) {
        this.parsedJson = json;
    }

    public JsonObject getSlots() {
        return this.parsedJson.getAsJsonObject("adSlots");
    }

    public ConfigAdSlot getSlot(String slotName) {
        JsonObject slots = this.getSlots();

        if (slots.has(slotName)) {
            JsonObject data = slots.get(slotName).getAsJsonObject();
            Gson gson = new Gson();
            return gson.fromJson(data.toString(), ConfigAdSlot.class);
        } else {
            return null;
        }
    }

}
