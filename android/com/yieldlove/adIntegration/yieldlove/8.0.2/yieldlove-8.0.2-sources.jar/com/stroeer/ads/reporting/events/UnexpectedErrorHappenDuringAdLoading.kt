package com.stroeer.ads.reporting.events

class UnexpectedErrorHappenDuringAdLoading(error: Exception) : TimeErrorEvent(error)
