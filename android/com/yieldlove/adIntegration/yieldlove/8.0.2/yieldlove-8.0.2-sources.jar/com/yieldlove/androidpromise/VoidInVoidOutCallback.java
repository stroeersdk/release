package com.yieldlove.androidpromise;

public interface VoidInVoidOutCallback extends PromiseCallback {
    void run() throws Exception;
}
