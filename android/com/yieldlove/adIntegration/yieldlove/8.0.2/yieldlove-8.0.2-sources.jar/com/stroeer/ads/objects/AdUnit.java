package com.stroeer.ads.objects;

import com.google.android.gms.ads.AdSize;
import com.stroeer.ads.config.ConfigurationManager;
import com.stroeer.ads.config.objects.ConfigAdSlot;
import com.stroeer.ads.config.objects.ConfigCustomAdSize;
import com.stroeer.ads.config.objects.ConfigFormat;
import com.stroeer.ads.config.objects.ConfigFormatSizes;
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException;
import com.stroeer.ads.exceptions.InValidAdUnitException;
import com.stroeer.ads.formats.AdType;
import com.stroeer.utilities.logging.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class AdUnit {

    // AdSlotName = "core?adslotname"
    private final String adSlotName;
    // AdUnitPath /dfpAppNetwork/dfpAndroidAppName/core?adslotname
    private String adUnitPath;
    // placement name,. core
    private final String placementName;

    public List<AdSize> availableBannerSizes = new ArrayList<>();
    private final HashMap<String, String> customTargeting = new HashMap<>();
    public String contentUrl = null;
    private ConfigAdSlot configAdSlot;

    private AdType adType = AdType.BANNER;

    private final static String filterSuffixRegex = "\\?.*";

    public static AdUnit loadFromSlotName(String placementName) throws Exception {
        if(!ConfigurationManager.getInstance().isLoaded()){
            throw new ConfigurationIsNotLoadedException();
        }

        String adUnitPath = ConfigurationManager.getInstance().getConfig().getCommon().getDfpAppNetwork() + "/" + ConfigurationManager.getInstance().getConfig().getCommon().getDfpAndroidAppName() + "/" + placementName;
        return new AdUnit(adUnitPath);
    }

    // Create the empty AdUnit
    protected AdUnit(){
        adSlotName = null;
        placementName = null;
    }

    public static AdUnit createEmptyAdUnit(){
        return new AdUnit();
    }

    public AdUnit(String adUnitPath) throws Exception {

        this.adUnitPath = adUnitPath;

        this.adSlotName = populateAdSlotName();
        this.adUnitPath = removeSuffixFromSlotName(adUnitPath);

        this.adUnitPath = populateDfpAdUnitId();
        this.placementName = populatePlacementName();

        if(ConfigurationManager.getInstance().getConfig().getAdSlots() != null) {
            configAdSlot = ConfigurationManager.getInstance().getConfig().getAdSlots().get(placementName);
        }

        if(configAdSlot == null) {
            Logger.e("[AdUnit] Failed to get prebidConfigId - adSlot:" + adSlotName);
            throw new InValidAdUnitException("AdSlot \""+this.placementName +"\" was not found in config");
        }

        // Update Ad Sizes
        setAdSizes();

        // update custom key from Zone
        addKeyValuesFromZone();

        // update custom key from AdSlot
        addKeyValuesFromAdSlot();

        // update adType
        if(configAdSlot.keyValues != null && configAdSlot.keyValues.containsKey("as")){
            try {
                if("interstitial".equals(Objects.requireNonNull(configAdSlot.keyValues.get("as"))[0])){
                    adType = AdType.INTERSTITIAL;
                }
            }catch(Exception e){
                Logger.e("[AdUnit] Failed to get adType - adSlot:"+ adSlotName);
            }
        }

    }

    protected void setAdSizes(){

        addCustomAdSizes();

        for(Map.Entry<String, ConfigFormat> entry : ConfigurationManager.getInstance().getConfig().getFormats().entrySet()){
            ConfigFormat format = entry.getValue();

            if(format != null && format.active && format.availableOn != null){
                if(Arrays.asList(format.availableOn).contains(placementName)){

                    // Custom Size
                    if (format.dfpSizes.customAdSizes != null) {
                        for (ConfigCustomAdSize customAdSize : format.dfpSizes.customAdSizes) {
                            availableBannerSizes.add(new AdSize(customAdSize.w, customAdSize.h));
                        }
                    }

                    // GAM Size
                    if(format.dfpSizes.androidAdSizes != null) {
                        for (String androidSize : format.dfpSizes.androidAdSizes) {
                            AdSize size = ConfigFormatSizes.getBannerSize(androidSize);
                            if(size != null) {
                                availableBannerSizes.add(size);
                            }
                        }
                    }
                }
            }
        }
    }

    protected void addCustomAdSizes() {
        if(this.configAdSlot.customAdSizes != null){
            for (ConfigCustomAdSize size: this.configAdSlot.customAdSizes){
                availableBannerSizes.add(new AdSize(size.w, size.h));
            }
        }
    }


    public AdUnit(String id, AdSize size) throws Exception {
        this(id);
        this.availableBannerSizes.clear();
        this.availableBannerSizes.add(size);
    }

    public AdUnit(String id, AdSize[] sizes) throws Exception {
        this(id);
        this.availableBannerSizes.clear();
        this.availableBannerSizes.addAll(Arrays.asList(sizes));
    }

    protected String getAdSlot(){
        return adSlotName;
    }

    public String getPrebidConfigId() {
        return configAdSlot.prebidConfigId;
    }

    public List<AdSize> getAdSizes() {
        return this.availableBannerSizes;
    }

    public String getAdUnitPath() {
        return this.adUnitPath;
    }

    public String getAdSlotName(){
        return this.adSlotName;
    }

    public void addCustomTargeting(String key, String value) {
        this.customTargeting.put(key, value);
    }

    public HashMap<String, String> getCustomTargeting() {
        return this.customTargeting;
    }

    public Boolean getRtaAuction() {
        return this.configAdSlot.rtaAuction;
    }

    public Integer getDfpAdRequestTimeoutInMs() {
        return ConfigurationManager.getInstance().getConfig().getCommon().getDfpAdRequestTimeoutMs();
    }

    public Integer getAutoRefreshTimeInMs() {
        return configAdSlot.autoRefreshTimeMs;
    }

    private void validateParameters(String id) throws InValidAdUnitException {
        if (id == null) {
            throw new InValidAdUnitException("Ad unit id cannot be null");
        }

        if (!id.startsWith("/")) {
            throw new InValidAdUnitException("Ad unit id must start with \"/\"");
        }
    }

    public String getStoreUrl() {
        return ConfigurationManager.getInstance().getConfig().getCommon().getAndroidStoreUrl() == null ? "" : ConfigurationManager.getInstance().getConfig().getCommon().getAndroidStoreUrl();
    }

    public String getBundleId() {
        return ConfigurationManager.getInstance().getConfig().getCommon().getAndroidBundleId();
    }

    public Integer[] getOpenRtbApi() {
        if(ConfigurationManager.getInstance().getConfig().getOpenRtb() == null)
        {
            return new Integer[]{};
        }

        return ConfigurationManager.getInstance().getConfig().getOpenRtb().getFramework();
    }

    protected String populateAdSlotName() throws InValidAdUnitException {
        if(adUnitPath != null && !adUnitPath.isEmpty())
        {
            String[] subStr = adUnitPath.split("/");
            try{
                return subStr[subStr.length-1];
            }catch(Exception e){
                throw new InValidAdUnitException("Failed to get AdSlotName - adUnit:"+ adUnitPath);
            }
        }

        return "";
    }

    protected String populatePlacementName() {
        try{
            String[] zoneNPlacement = adSlotName.split("_");
            return zoneNPlacement[zoneNPlacement.length-1];
        }catch (Exception e){
            Logger.e("[AdUnit] Failed to get placement name - adSlot:"+ adSlotName);
        }
        return adSlotName;
    }

    public String getPlacementName() {
        return placementName;
    }

    protected String populateDfpAdUnitId() {
        String dfpAppNetwork = ConfigurationManager.getInstance().getConfig().getCommon().getDfpAppNetwork();
        String adSlotNameWithoutSuffix = this.removeSuffixFromSlotName(adUnitPath);

        if (ConfigurationManager.getInstance().getConfig().getCommon().isSDI()) {
            return "/" + dfpAppNetwork + "/" + ConfigurationManager.getInstance().getConfig().getCommon().getDfpAndroidAppName()+ "/" + adSlotNameWithoutSuffix;
        }

        return "/" + dfpAppNetwork + "/" + adSlotNameWithoutSuffix;
    }

    private String removeSuffixFromSlotName(String adSlotName) {
        return adSlotName.replaceFirst(this.filterSuffixRegex, "");
    }

    private String getSlotNameWithoutSdiPrefix(String adSlotName) {
        if (ConfigurationManager.getInstance().getConfig().getCommon().isSDI()) {
            String[] adSlotNameParts = adSlotName.split("_");
            return adSlotNameParts[adSlotNameParts.length - 1];
        }
        return adSlotName;
    }

    protected  void addKeyValuesFromZone(){
        String[] zoneNames = adSlotName.split("_");

        for (String zoneName : zoneNames) {
            getKeyValues(zoneName, ConfigurationManager.getInstance().getConfig().getZonesAndPageTypes().getLevel1());
            getKeyValues(zoneName, ConfigurationManager.getInstance().getConfig().getZonesAndPageTypes().getLevel2());
            getKeyValues(zoneName, ConfigurationManager.getInstance().getConfig().getZonesAndPageTypes().getPageType());
        }
    }

    protected void getKeyValues(String zoneName, Map<String, Map<String, Map<String, String>>> zone) {
        if(zone != null && zone.containsKey(zoneName)){
            Map<String, Map<String, String>> entry = zone.get(zoneName);
            Map<String, String> keyValues = entry.get("keyValues");

            if(keyValues != null)
            {
                for(Map.Entry<String, String> keyValSet : keyValues.entrySet()) {
                    if(!customTargeting.containsKey(keyValSet.getKey()))// KeyValues
                        customTargeting.put(keyValSet.getKey(), keyValSet.getValue());
                }
            }
        }
    }

    protected void addKeyValuesFromAdSlot(){
        if(configAdSlot != null && configAdSlot.keyValues != null){
            for(Map.Entry<String, String[]> entry : configAdSlot.keyValues.entrySet()){
                if(entry != null && entry.getValue() != null && entry.getValue().length > 0){
                    if(!customTargeting.containsKey(entry.getKey())){
                        String value = String.join(",", entry.getValue());
                        customTargeting.put(entry.getKey(), value);
                    }

                }
            }
        }
    }

    public boolean isInterstitial(){
        return  adType == AdType.INTERSTITIAL;
    }

    public String getPrebidAccountId(){
        try {
            return ConfigurationManager.getInstance().getConfig().getModules().getPrebid().getYieldloveAccountId();
        }catch (Exception e){
            Logger.e("[AdUnit] Failed to get prebidAccountId - adSlot:"+ adSlotName);
            return "";
        }
    }
}
