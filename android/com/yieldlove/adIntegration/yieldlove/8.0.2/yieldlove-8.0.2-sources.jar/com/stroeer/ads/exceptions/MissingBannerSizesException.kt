package com.stroeer.ads.exceptions

class MissingBannerSizesException(adUnitId: String?) :
    StroeerException("No banner sizes provided with " + adUnitId)
