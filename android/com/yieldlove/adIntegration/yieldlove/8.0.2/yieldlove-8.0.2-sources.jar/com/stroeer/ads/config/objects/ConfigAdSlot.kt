package com.stroeer.ads.config.objects

class ConfigAdSlot {
    @JvmField
    var prebidConfigId: String? = null
    @JvmField
    var rtaAuction: Boolean? = null
    @JvmField
    var autoRefreshTimeMs: Int? = null
    @JvmField
    var keyValues: MutableMap<String, Array<String>>? = null
    @JvmField
    var customAdSizes: Array<ConfigCustomAdSize>? = null

    fun isInterstitial(): Boolean =
        keyValues
            ?.values
            ?.any { it.contains("interstitial") }
            ?: false

    fun isBanner() : Boolean {
        return !isInterstitial()
    }
}
