package com.stroeer.ads.reporting

import com.stroeer.ads.reporting.events.TimeEvent

interface Session {
    fun start(): Long

    fun stop(): Int

    fun recordEvent(event: TimeEvent): Int

    fun toJsonString(): String

    val id: String

    fun reset()
}
