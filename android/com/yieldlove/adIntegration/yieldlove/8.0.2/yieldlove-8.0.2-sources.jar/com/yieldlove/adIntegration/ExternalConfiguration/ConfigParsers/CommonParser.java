package com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigCommon;

public class CommonParser {

    private final JsonObject parsedJson;
    private final ConfigCommon common;

    public CommonParser(JsonObject json){
        this.parsedJson = json;
        Gson gson = new Gson();
        this.common = gson.fromJson(this.parsedJson.getAsJsonObject("common"), ConfigCommon.class);
    }

    public ConfigCommon getCommon(){
        return this.common;
    }

}
