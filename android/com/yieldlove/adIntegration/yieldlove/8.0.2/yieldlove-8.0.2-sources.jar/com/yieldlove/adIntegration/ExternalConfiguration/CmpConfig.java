package com.yieldlove.adIntegration.ExternalConfiguration;

import java.util.HashMap;

public class CmpConfig {
    private String privacyManagerId;
    private String propertyName;
    private int propertyId;
    private int sourcepointAccountId;
    private boolean consentIsActive;
    private final HashMap<String, HashMap<String,String>> consentOverrides = new HashMap<>();

    public HashMap<String, HashMap<String,String>> getConsentOverrides() {
        return this.consentOverrides;
    }

    public String getPrivacyManagerId() {
        return this.privacyManagerId;
    }

    public void setPrivacyManagerId(String privacyManagerId) {
        this.privacyManagerId = privacyManagerId;
    }

    public String getPropertyName() {
        return this.propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public int getSourcepointAccountId() {
        return sourcepointAccountId;
    }

    public void setSourcepointAccountId(int sourcepointAccountId) {
        this.sourcepointAccountId = sourcepointAccountId;
    }

    public boolean isConsentActive() {
        return consentIsActive;
    }

    public void setConsentIsActive(boolean consentIsActive) {
        this.consentIsActive = consentIsActive;
    }
}
