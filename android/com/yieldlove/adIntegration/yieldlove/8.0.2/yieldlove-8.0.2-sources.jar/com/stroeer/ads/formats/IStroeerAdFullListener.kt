package com.stroeer.ads.formats

import com.stroeer.ads.exceptions.StroeerException

interface IStroeerAdFullListener {
    /**
     * Called when the interstitial ad is clicked by the user.
     */
    fun onAdClicked()

    /**
     * Called when the interstitial ad is dismissed and full-screen content is closed.
     * This indicates that the user has returned to the app.
     */
    fun onAdDismissedFullScreenContent()

    /**
     * Called when the interstitial ad fails to display.
     *
     * @param e An [Exception] containing details about the error (may be `null`).
     */
    fun onAdFailedToShowFullScreenContent(e: StroeerException?)

    /**
     * Called when the interstitial ad records an impression (i.e., is visible to the user).
     */
    fun onAdImpression()

    /**
     * Called when the interstitial ad has successfully shown full-screen content.
     */
    fun onAdShowedFullScreenContent()
}