package com.yieldlove.adIntegration.ConsentReader;

public interface ConsentReader {
    String getVendorConsents();
    String getPurposeConsents();
    String getVendorLIConsents();
    String getPurposeLIConsents();
    String getPublisherRestrictionsFor(int purposeId);
}
