package com.yieldlove.adIntegration.ExternalConfiguration;

import com.yieldlove.androidpromise.Promise;

public interface ExternalConfigFetcher {
    Promise<String> getConfiguration(String url);
}
