package com.stroeer.ads.config.objects

class ConfigCustomAdSize(@JvmField val w: Int, @JvmField val h: Int) {
}
