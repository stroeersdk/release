package com.stroeer.plugins.identity.collectors;

import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.concurrent.CompletableFuture;

/**
 * Return GPP. Collect from IABTCF_GPP.
 */
public class GppCollector extends ACollectorWithContext<String> {

    private static final String PREFERENCES_NAME = "IABTCF_GPP";

    @Override
    public CompletableFuture<String> retrieveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
        String consentString = sharedPreferences.getString(PREFERENCES_NAME, null);
        if(consentString == null || consentString.isEmpty())
        {
            return CompletableFuture.completedFuture(null);
        }
        else
        {
            return CompletableFuture.completedFuture(consentString);
        }
    }
}
