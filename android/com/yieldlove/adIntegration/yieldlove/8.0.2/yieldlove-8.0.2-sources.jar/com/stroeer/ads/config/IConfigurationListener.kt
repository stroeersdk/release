package com.stroeer.ads.config

interface IConfigurationListener {
    fun onSuccess()
    fun onFailed()
}
