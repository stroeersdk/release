package com.stroeer.ads.sdks.prebid

import com.google.android.gms.ads.AdSize
import com.stroeer.utilities.json.OrtbJsonHelper
import org.prebid.mobile.AdUnit
import org.prebid.mobile.BannerAdUnit
import org.prebid.mobile.BannerBaseAdUnit
import org.prebid.mobile.BannerParameters
import org.prebid.mobile.InterstitialAdUnit
import org.prebid.mobile.Signals

class PrebidAdUnitConverter : AdUnitConverter {
    override fun convertToBannerAdUnit(ylAdUnit: com.yieldlove.adIntegration.AdUnit.AdUnit): AdUnit {
        val sizes = ylAdUnit.getAdSizes()
        val mainAdSize = sizes[0] // main size is like 31 * 37

        val bannerAdUnit = BannerAdUnit(
            ylAdUnit.getPrebidConfigId(),
            mainAdSize.width,
            mainAdSize.height
        )

        for (adSize in sizes) {
            addAdditionalSizeIfAllowed(mainAdSize, bannerAdUnit, adSize)
        }

        setPrebidAdUnitParameters(ylAdUnit, bannerAdUnit)
        setPrebidAdUnitAdSlot(ylAdUnit, bannerAdUnit)
        return bannerAdUnit
    }

    override fun convertToPrebidInterstitialAdUnit(ylAdUnit: com.yieldlove.adIntegration.AdUnit.AdUnit): AdUnit {
        val interstitialAdUnit = InterstitialAdUnit(ylAdUnit.getPrebidConfigId(), 10, 10)
        setPrebidAdUnitParameters(ylAdUnit, interstitialAdUnit)
        setPrebidAdUnitAdSlot(ylAdUnit, interstitialAdUnit)
        return interstitialAdUnit
    }

    private fun addAdditionalSizeIfAllowed(
        mainAdSize: AdSize,
        adUnit: BannerAdUnit,
        adSize: AdSize
    ) {
        if (adSize.width != mainAdSize.width && adSize.height != mainAdSize.height) {
            adUnit.addAdditionalSize(adSize.width, adSize.height)
        }
    }

    private fun setPrebidAdUnitParameters(
        ylAdUnit: com.yieldlove.adIntegration.AdUnit.AdUnit,
        adUnit: BannerBaseAdUnit
    ) {
        val parameters = BannerParameters()
        val openRtbApi = ylAdUnit.getOpenRtbApi()
        val signals: MutableList<Signals.Api> = ArrayList()
        for (api in openRtbApi) {
            signals.add(Signals.Api(api))
        }
        parameters.api = signals

        adUnit.bannerParameters = parameters
    }

    private fun setPrebidAdUnitAdSlot(
        ylAdUnit: com.yieldlove.adIntegration.AdUnit.AdUnit,
        adUnit: AdUnit
    ) {
        //adUnit.pbAdSlot = ylAdUnit.dfpAdUnitId
        adUnit.impOrtbConfig = """
                {
                  "ext": {
                    "data": {
                        "adslot": "${ylAdUnit.dfpAdUnitId}",
                        "pbadslot": "${ylAdUnit.dfpAdUnitId}"
                    }
                  }
                }
                """.trimIndent()
    }
}
