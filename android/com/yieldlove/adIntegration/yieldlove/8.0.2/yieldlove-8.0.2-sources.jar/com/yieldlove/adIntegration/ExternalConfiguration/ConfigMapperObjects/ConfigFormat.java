package com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects;

public class ConfigFormat {

    public Boolean active;
    public String[] availableOn;
    public ConfigFormatSizes dfpSizes;

}
