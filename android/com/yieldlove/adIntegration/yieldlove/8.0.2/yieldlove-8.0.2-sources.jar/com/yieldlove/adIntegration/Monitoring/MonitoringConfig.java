package com.yieldlove.adIntegration.Monitoring;

public interface MonitoringConfig {
    Boolean isMonitoringActive();
    Integer getFrequency();
    Integer getSendingIntervalInMs();
    Integer getMaxSessionsForSending();
}
