package com.stroeer.ads.sdks.prebid

import android.content.Context
import com.stroeer.utilities.logging.Logger

class InterstitialPrebidSdkAdapter(context: Context, adUnitConverter: PrebidAdUnitConverter) :
    APrebidSdkAdapter(context, adUnitConverter) {
    override fun initPrebidAdUnit() {
        if(adConfig.adUnit != null){
            adConfig.prebidAdUnit = this.adUnitConverter.convertToPrebidInterstitialAdUnit(adConfig.adUnit!!)
        }else{
            Logger.e("[InterstitialPrebidSdkAdapter] AdUnit is null. Cannot initialize")
        }
    }

    override val identifier: String?
        get() = null
}
