package com.yieldlove.adIntegration.AdFormats;

import com.stroeer.ads.exceptions.StroeerException;

@Deprecated (since = "Use com.stroeer.ads.formats.interstitial.IStroeerInterstitialListener instead")
public interface YieldloveInterstitialAdListener extends IAdRequestBuildListener {

    void onAdLoaded(YieldloveInterstitialAdView interstitial);

    void onAdFailedToLoad(YieldloveInterstitialAdView interstitial, StroeerException exception);
}
