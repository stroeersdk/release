package com.yieldlove.adIntegration;

import com.stroeer.ads.config.ConfigurationManager;
import com.stroeer.ads.exceptions.MissingApplicationNameException;

public class Configuration extends ConfigurationBase {
    private static final String applicationNamePlaceholder = "{APPLICATION_NAME}";
    private static Configuration config;
    private String applicationName;

    private static Configuration getInstance() {
        if (Configuration.config == null) {
            Configuration.config = new Configuration();
        }
        return Configuration.config;
    }

    public static String getOmidPartnerName() {
        return Configuration.getInstance().OmidPartnerName;
    }

    public static String getOmidPartnerVersion() {
        return Configuration.getInstance().OmidPartnerVersion;
    }

    public static String getAppName() {
        return Configuration.getInstance().applicationName;
    }

    public static String getPrebidUrl() {
        return Configuration.getInstance().prebidUrl;
    }

    public static String getExternalConfigUrl() throws MissingApplicationNameException {
        String appName = Configuration.getInstance().applicationName;
        if (appName == null) {
            throw new MissingApplicationNameException();
        }

        return Configuration.getInstance().externalConfigUrl
                .replace(Configuration.applicationNamePlaceholder, appName);
    }

    public static String getYieldloveDfpId() {
        return Configuration.getInstance().yieldloveDfpId;
    }

    public static boolean getSourcepointIsStagingCampaign() {
        return Configuration.getInstance().sourcepointIsStagingCampaign;
    }

    public static String getExternalConfigSharedPrefsFileKey() {
        return Configuration.getInstance().externalConfigSharedPrefsFileKey;
    }

    public static String getExternalConfigContentKey() {
        return Configuration.getInstance().externalConfigContentKey;
    }

    public static String getExternalConfigLastFetchInMillisKey() {
        return Configuration.getInstance().externalConfigLastFetchInMillisKey;
    }

    public static void setApplicationName(String applicationName) {
        Configuration.getInstance().applicationName = applicationName;
    }

    public static String getErrorReporterUrl() {
        return Configuration.getInstance().errorReporterUrl;
    }

    public static String getErrorReporterApiKey() {
        return Configuration.getInstance().errorReporterApiKey;
    }

    public static String getMonitoringReporterUrl() {
        return Configuration.getInstance().monitoringReporterUrl;
    }

    public static String getMonitoringReporterApiKey() {
        return Configuration.getInstance().monitoringReporterApiKey;
    }

    public static int getPrebidTimeout() {
        try{
            return ConfigurationManager.getInstance().getConfig().getCommon().getDfpAdRequestTimeoutMs();
        }catch(Exception e)
        {
            return 3000;
        }
    }

}
