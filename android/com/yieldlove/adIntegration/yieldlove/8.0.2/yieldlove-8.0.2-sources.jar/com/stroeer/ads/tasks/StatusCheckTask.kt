package com.stroeer.ads.tasks

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException
import com.stroeer.ads.exceptions.PreviousAdLoadIsInProgressException
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.utilities.logging.Logger

internal class StatusCheckTask(caller: String): AdTask(caller) {
    override suspend fun <Param> execute(adConfig :Param) {

        if(adConfig !is AAdConfiguration) {
            throw IllegalArgumentException("[$caller-StatusCheckTask] Param must be of type AAdConfiguration")
        }

        if(!ConfigurationManager.getInstance().isLoaded) {
            throw ConfigurationIsNotLoadedException()
        }

        if(adConfig.status.isLoading()) {
            Logger.e("[$caller] Previous ad load is still in progress - ${adConfig.publisherSlotName}")
            throw PreviousAdLoadIsInProgressException()
        }
    }
}