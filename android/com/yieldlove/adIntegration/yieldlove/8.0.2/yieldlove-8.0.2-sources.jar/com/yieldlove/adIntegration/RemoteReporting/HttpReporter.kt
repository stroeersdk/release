package com.yieldlove.adIntegration.RemoteReporting

import android.os.Build
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.utilities.http.SharedHttpClient
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.Configuration
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

abstract class HttpReporter(
    private val reportingUrl: String,
    private val apiKey: String,
    private val client: OkHttpClient = SharedHttpClient.client
) {
    suspend fun report(bodyString: String) = withContext(Dispatchers.IO) {
        val body = bodyString.toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(reportingUrl)
            .post(body)
            .addHeader("X-API-Key", apiKey)
            .build()

        val response = client.newCall(request).await() // cancellable await
        response.use { resp ->
            if (resp.isSuccessful) {
                // success: return Unit
                return@withContext
            } else {
                Logger.e("[HttpReporter] Server returns error: ${resp.code}")
                throw StroeerException("Report server returns with code: ${resp.code}")
            }
        }
    }

    protected val appName: String?
        get() = Configuration.getAppName()

    protected val OS: String
        get() = "Android ${Build.VERSION.RELEASE}(SDK ${Build.VERSION.SDK_INT})"
}

/** Cancellable await for OkHttp */
private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isCancelled) return
            cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            cont.resume(response)
        }
    })
    cont.invokeOnCancellation { cancel() }
}