package com.yieldlove.adIntegration.Monitoring

import com.stroeer.ads.reporting.Session

interface SessionsCollector {
    suspend fun addSession(session: Session)
}
