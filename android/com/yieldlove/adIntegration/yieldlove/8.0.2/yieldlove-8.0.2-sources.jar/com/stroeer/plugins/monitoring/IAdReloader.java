package com.stroeer.plugins.monitoring;

import android.view.View;

/**
 * IAdReloader defines an interface for handling ad reloading operations.
 * It provides methods for retrieving ad slot information, reloading ads,
 * and accessing the associated ad view.
 */
public interface IAdReloader {

    /**
     * Retrieves the unique identifier for the ad slot.
     *
     * @return a String representing the ad slot ID.
     */
    String getAdSlot();

    /**
     * Reloads the ad associated with the specified view and placement ID.
     *
     * @param slotView    the view representing the ad slot.
     * @param placementId the unique identifier for the ad placement.
     */
    void reloadAd(View slotView, String placementId);

    /**
     * Retrieves the view associated with the ad.
     *
     * @return the View object representing the ad.
     */
    View getAdView();
}