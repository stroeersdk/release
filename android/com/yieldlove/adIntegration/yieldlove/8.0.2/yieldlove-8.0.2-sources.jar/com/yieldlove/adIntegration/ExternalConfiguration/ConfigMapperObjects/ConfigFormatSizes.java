package com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects;

public class ConfigFormatSizes {
    public String[] androidAdSizes;
    public ConfigCustomAdSize[] customAdSizes;
}
