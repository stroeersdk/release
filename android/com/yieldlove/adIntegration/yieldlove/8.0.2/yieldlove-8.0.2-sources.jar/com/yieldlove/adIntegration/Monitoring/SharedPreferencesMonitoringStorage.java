package com.yieldlove.adIntegration.Monitoring;

import android.content.Context;
import android.content.SharedPreferences;

import com.yieldlove.adIntegration.Configuration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SharedPreferencesMonitoringStorage implements MonitoringStorage {

    public static final String SESSIONS_KEY = "MonitoringSessions";
    public static final String TIMESTAMP_KEY = "MonitoringReportTimestamp";

    private final SharedPreferences sharedPreferences;

    public SharedPreferencesMonitoringStorage(Context context) {
        this.sharedPreferences = context.getSharedPreferences(
                Configuration.getExternalConfigSharedPrefsFileKey(),
                Context.MODE_PRIVATE
        );
    }

    @Override
    public void putSessions(ArrayList<String> sessions) {
        HashSet<String> set = new HashSet<>();
        set.addAll(sessions);
        this.sharedPreferences.edit().putStringSet(SESSIONS_KEY, set).apply();
    }

    @Override
    public ArrayList<String> getSessions() {
        return new ArrayList<>(this.sharedPreferences.getStringSet(SESSIONS_KEY, Collections.emptySet()));
    }

    @Override
    public int getSessionsSize() {
        return this.getSessions().size();
    }

    @Override
    public void setLastReportTime(long time) {
        this.sharedPreferences.edit().putLong(TIMESTAMP_KEY, time).apply();
    }

    @Override
    public long getLastReportTime() {
        return this.sharedPreferences.getLong(TIMESTAMP_KEY, 0);
    }
}
