package com.stroeer.ads.sdks.prebid

import com.yieldlove.adIntegration.AdUnit.AdUnit
import org.prebid.mobile.ResultCode

object PrebidToGAMKeyValueMapper {
    fun addBidsIntoAdRequestBuilder(keyValuesFromPrebid: Map<String, String?>?, resultMap: HashMap<String, String>) {
        keyValuesFromPrebid?.let{
            for (mapping in CustomTargetingMapping.entries) {
                keyValuesFromPrebid[mapping.hbKey]?.let{
                    resultMap.put(mapping.ylKey, it)
                }
            }
        }
    }

    @Suppress("SpellCheckingInspection")
    fun addPrebidMetadata(resultMap: HashMap<String, String>, adUnit: AdUnit, prebidResult: ResultCode) {
        if (prebidResult == ResultCode.SUCCESS) {
            resultMap["yieldlove_sucbid"] = "true"
            resultMap["yieldlove_meta"] = "pid:${adUnit.getPrebidConfigId()}.sb:t.pr:t"
        } else {
            resultMap["yieldlove_sucbid"] = "false"
            resultMap["yieldlove_meta"] = "pid:${adUnit.getPrebidConfigId()}.sb:f"
        }
    }

    @Suppress("EnumEntryName")
    enum class CustomTargetingMapping(hb: String, yl: String) {
        env(PrebidBidKeys.env.key, "yl_app_env"),
        pb(PrebidBidKeys.pb.key, "yl_app_pb"),
        bidder(PrebidBidKeys.bidder.key, "yl_app_bidder"),
        cache_id(PrebidBidKeys.cache_id.key, "yl_app_cache_id"),
        size(PrebidBidKeys.size.key, "yl_app_size");

        val hbKey: String = hb
        val ylKey: String = yl
    }
}
