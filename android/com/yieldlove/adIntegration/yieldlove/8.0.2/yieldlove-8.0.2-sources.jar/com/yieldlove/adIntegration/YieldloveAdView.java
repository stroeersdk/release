package com.yieldlove.adIntegration;

import android.content.Context;
import android.util.AttributeSet;
import com.stroeer.ads.formats.banner.StroeerBannerView;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Deprecated (since = "Use com.stroeer.ads.formats.banner.StroeerBannerView instead", forRemoval = true)
public class YieldloveAdView extends StroeerBannerView {
    public YieldloveAdView(@NotNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public YieldloveAdView(@NotNull Context context) {
        super(context);
    }
}
