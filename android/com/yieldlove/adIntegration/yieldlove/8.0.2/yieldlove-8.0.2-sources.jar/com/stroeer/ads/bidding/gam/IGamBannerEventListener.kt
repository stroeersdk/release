package com.stroeer.ads.bidding.gam

import com.stroeer.ads.exceptions.StroeerException

interface IGamBannerEventListener {
    fun onAdClosed()
    fun onAdFailedToLoad(error:StroeerException)
    fun onAdOpened()
    fun onAdLoaded()
    fun onAdClicked()
    fun onAdImpression()
}