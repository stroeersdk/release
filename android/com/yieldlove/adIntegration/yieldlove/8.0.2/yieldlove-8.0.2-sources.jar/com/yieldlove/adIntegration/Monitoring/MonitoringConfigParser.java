package com.yieldlove.adIntegration.Monitoring;

import androidx.annotation.NonNull;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class MonitoringConfigParser {
    private static final Integer defaultFrequency = 1;
    private static final Integer defaultSendingIntervalInMs = 24 * 60 * 60 * 1000;
    private static final Integer defaultMaxSessionsForSending = 1000;
    private static final String ACTIVE = "active";
    private static final String FREQUENCY = "frequency";
    private static final String MAX_SESSIONS_FOR_SENDING = "maxSessionsForSending";
    private static final String SENDING_INTERVAL_IN_MS = "sendingIntervalInMs";


    public static YieldloveMonitoringConfig parse(JsonObject jsonMonitoring) {
        if (jsonMonitoring != null) {
            boolean active = jsonMonitoring.get(ACTIVE).getAsBoolean();
            if (active) {
                return createMonitoringConfig(jsonMonitoring);
            }
        }

        return new YieldloveMonitoringConfig(false, null, null, null);
    }

    @NonNull
    private static YieldloveMonitoringConfig createMonitoringConfig(JsonObject jsonMonitoring) {
        JsonElement frequency = jsonMonitoring.get(FREQUENCY);
        JsonElement maxSessionsForSending = jsonMonitoring.get(MAX_SESSIONS_FOR_SENDING);
        JsonElement sendingIntervalInMs = jsonMonitoring.get(SENDING_INTERVAL_IN_MS);
        return new YieldloveMonitoringConfig(
                true,
                frequency == null ? defaultFrequency : frequency.getAsInt(),
                sendingIntervalInMs == null ? defaultSendingIntervalInMs : sendingIntervalInMs.getAsInt(),
                maxSessionsForSending == null ? defaultMaxSessionsForSending : maxSessionsForSending.getAsInt()
        );
    }
}
