package com.stroeer.ads.debugInfo

import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.exceptions.DfpBannerLoadAdError
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.reporting.TimeSession
import com.stroeer.ads.sdks.SdkDebugInfo
import com.stroeer.utilities.json.JsonPrinter
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.Configuration
import org.prebid.mobile.PrebidMobile

class DebugInfoManager {

    private val debugInfoMap: MutableMap<String, IDebugInfo> = LinkedHashMap(MAX_BUFFER_SIZE+1, 1F, true)

    private val networkDebugInfoMap : MutableMap<String, NetworkDebugInfo> = LinkedHashMap(MAX_BUFFER_SIZE+1, 1F, true)

    companion object{
        @Volatile private var instance: DebugInfoManager? = null
        private val isInspectionMode: Boolean
            get() { return ConfigurationManager.isInspectionMode }

        fun getInstance(): DebugInfoManager {
            // Fast path: return existing instance if available
            if (instance != null) {
                return instance!!
            }
            // Slow path: synchronize and create
            synchronized(this) {
                if (instance == null) {
                    instance = DebugInfoManager()
                }
                return instance!!
            }
        }

        const val MAX_BUFFER_SIZE = 20

        fun createDebugInfo(adConfig : AAdConfiguration){
            if(ConfigurationManager.isInspectionMode) {
                adConfig.debugInfo = DebugInfo().apply {
                    publisherSlotName = adConfig.publisherSlotName
                    adSourceInfo = adConfig.source

                    adConfig.adUnit?.let {
                        adUnitId = it.dfpAdUnitId
                        adSizes = it.adSizes
                        customTargeting = it.customTargeting
                        prebidActive = it.rtaAuction
                        prebidConfigId = it.prebidConfigId
                    }
                    accountId = PrebidMobile.getPrebidServerAccountId()
                    appName = Configuration.getAppName()
                    tcString = adConfig.consentReader.tcString
                }
            }
        }

        fun updateServeTime(bannerConfig: BannerConfiguration) {
            if (isInspectionMode) {
                val debugInfo = bannerConfig.debugInfo as? DebugInfo
                debugInfo?.let {
                    val timeSession = bannerConfig.session as? TimeSession
                    timeSession?.let {
                        val servedInTime = timeSession.servedInMs
                        debugInfo.servedInTime = servedInTime
                    }

                    val refreshInterval: Int? = bannerConfig.refreshTime
                    if (refreshInterval != null && refreshInterval > 0) {
                        debugInfo.autoRefreshEnabled = true
                    }
                    debugInfo.customTargeting

                    // Just safety code to avoid infinite loop
                    var counter = DebugInfoManager.MAX_BUFFER_SIZE
                    while (bannerConfig.adUnitId != null && counter-- > 0) {
                        val info = getInstance().getNetworkDebugInfo(bannerConfig.adUnitId!!) ?: break   // exit loop if null

                        val sdkDebugInfo =
                            debugInfo.sdkDebugInfos.findLast { it.sdkType == info.sdkType }
                        sdkDebugInfo?.requestJson = info.requestString
                        sdkDebugInfo?.responseJson = info.responseString
                    }
                }
            }
        }

        fun addDebugInfoForFail(bannerConfig: BannerConfiguration, description: String, error : StroeerException){
            if(isInspectionMode){
                bannerConfig.debugInfo?.let {
                    val gamSdkDebugInfo = SdkDebugInfo()
                    gamSdkDebugInfo.publisherSlotName = bannerConfig.publisherSlotName
                    gamSdkDebugInfo.description = description
                    gamSdkDebugInfo.keyValues = mutableMapOf("errorMessage" to error.message)
                    if (error is DfpBannerLoadAdError){
                        gamSdkDebugInfo.keyValues!!.put("responseJson", "========================\n${JsonPrinter.print(error.adError.toString())}\n========================")
                    }
                    gamSdkDebugInfo.sdkType = SdkType.GAM
                    it.sdkDebugInfos.add(gamSdkDebugInfo)
                }
            }
        }

        fun addFinalResultToDebugInfo(bannerConfig: BannerConfiguration, desc : String){
            if(ConfigurationManager.isInspectionMode) {
                bannerConfig.debugInfo?.let {
                    it.sdkDebugInfos.add( SdkDebugInfo().apply {
                        publisherSlotName = bannerConfig.publisherSlotName
                        sdkType = SdkType.GAM
                        description = "Delivered Ad"
                        keyValues = mutableMapOf( "_result" to desc ,
                                                    "responseJson" to "========================\n${JsonPrinter.print(bannerConfig.adManagerAdView?.responseInfo.toString())}\n========================")
                    })
                }
            }
        }

        fun addSendGAM(adConfig : AAdConfiguration, requestKeyValues: MutableMap<String, String?>?){
            if (ConfigurationManager.isInspectionMode){
                val sdkDebugInfo = SdkDebugInfo().apply {
                    publisherSlotName = adConfig.publisherSlotName
                    sdkType = SdkType.GAM
                    description = "Send to GAM"
                    @Suppress("UNNECESSARY_SAFE_CALL")
                    keyValues = requestKeyValues
                }
                adConfig.debugInfo?.sdkDebugInfos?.add(sdkDebugInfo)
            }
        }
    }

    fun getDebugInfoList() : List<IDebugInfo> {
        return if (isInspectionMode) {
            synchronized(debugInfoMap) {
                debugInfoMap.values.toList()
            }
        } else {
            emptyList()
        }
    }

    fun addDebugInfo(debugInfo: IDebugInfo) {
        if (!isInspectionMode) return
        synchronized(this.debugInfoMap) {
            try {
                val key = debugInfo.publisherSlotName
                if (key != null) {
                    this.debugInfoMap[key] = debugInfo

                    if(debugInfoMap.size > MAX_BUFFER_SIZE){
                        val firstKey = debugInfoMap.keys.first()
                        debugInfoMap.remove(firstKey)
                    }
                } else {
                    Logger.e("[DebugInfoManager] Publisher slot name is null, cannot add debug info.")
                }
            } catch (e: Exception) {
                Logger.e("[DebugInfoManager] Error adding debug info: ${e.message}")
            }
        }
    }


    fun getDebugInfo(publisherSlotName : String) : IDebugInfo? {
        return if (isInspectionMode) {
            debugInfoMap[publisherSlotName]
        } else {
            null
        }
    }

    fun removeDebugInfo(publisherSlotName : String) {
        if (isInspectionMode) {
            synchronized(debugInfoMap) {
                debugInfoMap.remove(publisherSlotName)
            }
        }
    }

    fun addSdkDebugInfo(publisherSlotName: String, sdkDebugInfo: ISdkDebugInfo) {
        if (!isInspectionMode) return

        synchronized(debugInfoMap) {
            val key = publisherSlotName
            // Ensure a (thread-safe) list exists for this key
            val debugInfo = debugInfoMap[key]

            debugInfo?.sdkDebugInfos?.add(sdkDebugInfo)
                ?: Logger.e("[DebugInfoManager] DebugInfo for key doesn't exist - $publisherSlotName")
        }
    }

    fun getSdkDebugInfo(publisherSlotName : String) : List<ISdkDebugInfo>? {
        return if (isInspectionMode) {
            debugInfoMap[publisherSlotName]?.sdkDebugInfos
        } else {
            null
        }
    }



    fun addNetworkDebugInfO(networkDebugInfo: NetworkDebugInfo) {
        if (!isInspectionMode) return
        synchronized(this.networkDebugInfoMap) {
            try {
                val key = networkDebugInfo.id
                this.networkDebugInfoMap[key] = networkDebugInfo

                if(networkDebugInfoMap.size > MAX_BUFFER_SIZE){
                    val firstKey = networkDebugInfoMap.keys.first()
                    networkDebugInfoMap.remove(firstKey)
                }
            } catch (e: Exception) {
                Logger.e("[DebugInfoManager] Error adding network debug info: ${e.message}")
            }
        }
    }

    fun getNetworkDebugInfo(adUnitId: String) : NetworkDebugInfo? {
        return if (isInspectionMode) {
            synchronized(this.networkDebugInfoMap) {
                networkDebugInfoMap.values
                    .firstOrNull { it.requestString?.contains(adUnitId) == true }
                    ?.also { networkDebugInfoMap.remove(it.id) }
            }
        } else null
    }
}