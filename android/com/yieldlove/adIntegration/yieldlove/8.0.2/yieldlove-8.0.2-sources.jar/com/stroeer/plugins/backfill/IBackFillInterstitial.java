package com.stroeer.plugins.backfill;

import com.stroeer.ads.formats.interstitial.IStroeerInterstitialListener;
import com.yieldlove.adIntegration.AdFormats.YieldloveInterstitialAdListener;
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit;

public interface IBackFillInterstitial {
    void loadInterstitial(YieldloveAdUnit ylAdUnitData, IStroeerInterstitialListener listener);
    void showInterstitial(YieldloveAdUnit ylAdunitData);
    boolean isInterstitialAvailable(YieldloveAdUnit ylAdunitData);
}
