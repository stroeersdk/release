package com.yieldlove.adIntegration.ExternalConfiguration;

public enum AdsSoundSettingStates {
    MUTE, UNMUTE, RESPECT_USER_SOUND_SETTING
}
