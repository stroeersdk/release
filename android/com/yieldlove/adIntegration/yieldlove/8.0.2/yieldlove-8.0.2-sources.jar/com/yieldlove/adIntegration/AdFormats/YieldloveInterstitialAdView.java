package com.yieldlove.adIntegration.AdFormats;

import com.google.android.gms.ads.admanager.AdManagerInterstitialAd;
import com.stroeer.ads.formats.AdSourceInfo;

@Deprecated (since = "Use com.stroeer.ads.formats.interstitial.IStroeerInterstitialAdView instead")
public interface YieldloveInterstitialAdView {
    AdManagerInterstitialAd getAdView();

    String getAdUnitId();

    boolean isLoaded();

    void show();

    AdSourceInfo getAdSource();
}
