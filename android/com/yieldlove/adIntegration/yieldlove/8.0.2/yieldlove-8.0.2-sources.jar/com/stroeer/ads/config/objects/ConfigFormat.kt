package com.stroeer.ads.config.objects

class ConfigFormat {
    @JvmField
    var active: Boolean? = null
    @JvmField
    var availableOn: Array<String>? = null
    @JvmField
    var dfpSizes: ConfigFormatSizes? = null
}

