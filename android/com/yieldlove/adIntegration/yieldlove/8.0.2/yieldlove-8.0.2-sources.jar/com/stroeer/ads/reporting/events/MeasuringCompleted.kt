package com.stroeer.ads.reporting.events

class MeasuringCompleted : TimeEvent()
