package com.yieldlove.adIntegration.RemoteReporting

import com.yieldlove.androidpromise.Promise

interface ExceptionReporter {
    fun report(e: Exception?): Promise<Void?>?
}
