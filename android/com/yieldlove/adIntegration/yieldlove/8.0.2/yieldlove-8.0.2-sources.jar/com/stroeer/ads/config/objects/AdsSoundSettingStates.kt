package com.stroeer.ads.config.objects

enum class AdsSoundSettingStates {
    MUTE,
    UNMUTE,
    RESPECT_USER_SOUND_SETTING
}
