package com.stroeer.utilities.logging

import android.content.Context
import android.util.Log
import com.stroeer.utilities.logging.timber.TimberLogger
import org.jetbrains.annotations.TestOnly
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.*

class Logger private constructor() {

    companion object {
        private const val TAG = "StroeerSDK"
        private const val MAX_LOG_FILE_SIZE = 10 * 1024 * 1024L // 10 MB
        private val instance = Logger()
        private var isDebugMode = false
        private var appContext : Context? = null

        @TestOnly
        internal fun getInstance(): ILogger? {
            return instance.loggerInstance
        }

        @JvmStatic
        fun initialize() {
            initialize(null)
        }

        @JvmStatic
        fun initialize(context: Context?) {
            appContext = context

            if( instance.loggerInstance == null) {
                instance.loggerInstance = TimberLogger(isDebugMode)
                appContext?.let { instance.initializeFileLogging(it) }
            }

            instance.startUncaughtExceptionHandler()
            instance.startPeriodicFlush()

            i("Logger initialized with debug=$isDebugMode, logfile=${instance.isFileLoggingEnabled}")

        }

        @TestOnly
        @JvmStatic
        fun initializeForTest(){
             instance.loggerInstance = object: ILogger {
                 override fun d(tag: String, message: String) {
                     println("D/$tag: $message")
                 }
                 override fun i(tag: String, message: String) {
                     println("I/$tag: $message")
                 }
                 override fun w(tag: String, message: String) {
                     System.err.println("W/$tag: $message")
                 }
                 override fun e(tag: String, message: String) {
                     System.err.println("E/$tag: $message")
                 }
                 override fun e(tag: String, message: String, throwable: Throwable?) {
                     System.err.println("E/$tag: $message")
                     throwable?.printStackTrace(System.err)
                 }
                 override fun dispose() {}
             }

            instance.startUncaughtExceptionHandler()
            instance.startPeriodicFlush()
        }

        @JvmStatic
        fun enableDebugMode() {
            if (isDebugMode) return
            isDebugMode = true

            // If already initialized, swap the logger to debug; avoid re-running full initialize() unless needed.
            instance.loggerInstance?.dispose()
            instance.loggerInstance = TimberLogger(true)
        }

        @JvmStatic
        fun setContext(context: Context) {
            if (instance.loggerInstance != null) {
                instance.initializeFileLogging(context)
            } else {
                Log.wtf(TAG, "Logger not initialized. Call Logger.initialize() first.")
            }
        }

        private fun initializeIfNot() {
            if (instance.loggerInstance == null) {
                initialize(appContext)
            }
        }

        @JvmStatic
        fun d(message: String) {
            initializeIfNot()
            instance.loggerInstance?.d(TAG, message)
            instance.writeLog("DEBUG", message, false)
        }

        @JvmStatic
        fun d(message: String, flush: Boolean = false) {
            initializeIfNot()
            instance.loggerInstance?.d(TAG, message)
            instance.writeLog("DEBUG", message, flush)
        }

        @JvmStatic
        fun d(message: String, throwable: Throwable? = null) {
            initializeIfNot()
            instance.loggerInstance?.d(TAG, message)
            instance.writeLog("DEBUG", message, false, throwable)
        }

        @JvmStatic
        fun d(message: String, throwable: Throwable? = null, flush: Boolean = false) {
            initializeIfNot()
            instance.loggerInstance?.d(TAG, message)
            instance.writeLog("DEBUG", message, flush, throwable)
        }

        @JvmStatic
        fun i(message: String) {
            initializeIfNot()
            instance.loggerInstance?.i(TAG, message)
            instance.writeLog("INFO", message, false)
        }

        @JvmStatic
        fun i(message: String, flush: Boolean = false) {
            initializeIfNot()
            instance.loggerInstance?.i(TAG, message)
            instance.writeLog("INFO", message, flush)
        }

        @JvmStatic
        fun w(message: String) {
            initializeIfNot()
            instance.loggerInstance?.w(TAG, message)
            instance.writeLog("WARN", message, false)
        }

        @JvmStatic
        fun w(message: String, flush: Boolean = false) {
            initializeIfNot()
            instance.loggerInstance?.w(TAG, message)
            instance.writeLog("WARN", message, flush)
        }

        @JvmStatic
        fun e(message: String) {
            initializeIfNot()
            instance.loggerInstance?.e(TAG, message)
            instance.writeLog("ERROR", message, false)
        }

        @JvmStatic
        fun e(throwable: Throwable) {
            initializeIfNot()
            val message = throwable.message ?: "Unknown error"
            instance.loggerInstance?.e(TAG, message)
            instance.writeLog("ERROR", message, false)
        }

        @JvmStatic
        fun e(message: String, throwable: Throwable? = null) {
            initializeIfNot()
            instance.loggerInstance?.e(TAG, message, throwable)
            instance.writeLog("ERROR", message, false, throwable)
        }

        @JvmStatic
        fun e(message: String, throwable: Throwable? = null, flush: Boolean = false) {
            initializeIfNot()
            instance.loggerInstance?.e(TAG, message, throwable)
            instance.writeLog("ERROR", message, flush, throwable)
        }

        @JvmStatic
        fun flush() {
            if (!instance.isFileLoggingEnabled) return
            val latch = CountDownLatch(1)
            instance.executor.execute {
                try {
                    instance.bufferedWriter?.flush()
                } catch (e: IOException) {
                    e("[Logger] Error flushing log file", e)
                } finally {
                    latch.countDown()
                }
            }
            latch.await()
        }

        @JvmStatic
        fun close() {
            if (!instance.isFileLoggingEnabled) return
            instance.stopPeriodicFlush()
            val latch = CountDownLatch(1)
            instance.executor.execute {
                try {
                    instance.bufferedWriter?.flush()
                    instance.bufferedWriter?.close()
                } catch (e: IOException) {
                    e("[Logger] Error closing log file", e)
                } finally {
                    instance.bufferedWriter = null
                    latch.countDown()
                }
            }
            latch.await()
            instance.loggerInstance = null
        }
    }

    var loggerInstance: ILogger? = null
    var isFileLoggingEnabled: Boolean = false
    var bufferedWriter: BufferedWriter? = null
    var logFile: File? = null
    private val executor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private val scheduledExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var periodicFlushTask: ScheduledFuture<*>? = null

    @Synchronized
    private fun initializeFileLogging(context: Context) {
        if (isFileLoggingEnabled) {
            // Already initialized; no-op to avoid duplicate "[StroeerSDK] Log file initialized" lines.
            return
        }
        try {
            val logDir = File(context.filesDir, "logs")
            if (!logDir.exists()) logDir.mkdirs()
            logFile = File(logDir, "stroeer.log")
            bufferedWriter = BufferedWriter(FileWriter(logFile, true), 1024)
            writeNewSession()
            isFileLoggingEnabled = true
            i("[StroeerSDK] Log file initialized - $logFile")
        } catch (e: IOException) {
            e("[Logger] Error initializing log file", e)
        }
    }

    @Throws(IOException::class)
    private fun writeNewSession() {
        bufferedWriter?.apply {
            newLine(); newLine(); newLine()
            write("=============================================================")
            newLine()
            write("New session started")
            newLine()
            write("=============================================================")
            newLine()
        }
    }

    private fun writeLog(level: String, message: String, flush: Boolean, throwable: Throwable? = null) {
        val formattedMessage = formatLogMessage(level, message)
        writeLogToFile(formattedMessage, throwable)
        if (flush) flush()
    }

    private fun formatLogMessage(level: String, message: String): String {
        val timeStamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        return "$timeStamp [$level] $TAG: $message"
    }

    private fun getLogFileSize(): Long {
        return logFile?.length() ?: 0L
    }

    private fun writeLogToFile(message: String, throwable: Throwable?) {
        if (!isFileLoggingEnabled) return
        val throwableStr = throwable?.let { "\n" + Log.getStackTraceString(it) } ?: ""
        val logMessage = "$message$throwableStr\n"

        executor.execute {
            try {
                bufferedWriter?.apply {
                    write(logMessage)
                    if (getLogFileSize() >= MAX_LOG_FILE_SIZE) {
                        rotateLogFile()
                    }
                }
            } catch (e: IOException) {
                e("[Logger] Error writing log message", e)
            }
        }
    }

    @Synchronized
    private fun rotateLogFile() {
        if (!isFileLoggingEnabled || logFile == null) return

        try {
            bufferedWriter?.flush()
            bufferedWriter?.close()
            val rotatedFile = File(logFile!!.parent, "stroeer_old.log")
            if(rotatedFile.exists()){
                rotatedFile.delete()
            }
            logFile!!.renameTo(rotatedFile)
            logFile = File(logFile!!.parent, "stroeer.log")
            bufferedWriter = BufferedWriter(FileWriter(logFile, true), 1024)
        } catch (e: IOException) {
            e("[Logger] Error rotating log file", e)
        }
    }

    private fun startUncaughtExceptionHandler() {
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            e("Uncaught exception in thread ${thread.name}", throwable)
            flush()
            previousHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun startPeriodicFlush() {
        if (isFileLoggingEnabled) {
            periodicFlushTask = scheduledExecutor.scheduleWithFixedDelay({ flush() }, 10, 10, TimeUnit.SECONDS)
        }
    }

    private fun stopPeriodicFlush() {
        periodicFlushTask?.cancel(true)
        scheduledExecutor.shutdown()
    }
}
