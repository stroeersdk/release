package com.stroeer.plugins.identity.collectors;

import android.annotation.SuppressLint;
import android.os.LocaleList;

import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;

/**
 * Return language
 */
public class LanguageCollector extends ACollectorWithContext<String> {

    @SuppressLint("DefaultLocale")
    @Override
    public CompletableFuture<String> retrieveData() {
        StringBuilder acceptLanguage = new StringBuilder();
        LocaleList locales;

        // Get list of locales (API 24+)
        locales = applicationContext.getResources().getConfiguration().getLocales();

        for (int i = 0; i < locales.size(); i++) {
            Locale locale = locales.get(i);
            acceptLanguage.append(locale.toLanguageTag()); // e.g., en-US, fr-FR

            if (i == 0) {
                acceptLanguage.append(","); // Primary language (default q=1.0)
            } else {
                acceptLanguage.append(";q=").append(String.format("%.1f", 1.0 - (i * 0.1))); // Lower priority for secondary
                if (i < locales.size() - 1) {
                    acceptLanguage.append(",");
                }
            }
        }
        return CompletableFuture.completedFuture(acceptLanguage.toString());
    }
}
