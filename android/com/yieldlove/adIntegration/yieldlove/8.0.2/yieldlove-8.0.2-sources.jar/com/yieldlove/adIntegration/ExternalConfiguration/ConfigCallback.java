package com.yieldlove.adIntegration.ExternalConfiguration;

public interface ConfigCallback {
    void callback(String data);
}
