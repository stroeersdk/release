package com.yieldlove.adIntegration.ExternalConfiguration;

import android.os.Handler;
import android.os.Looper;

import com.stroeer.utilities.http.SharedHttpClient;
import com.stroeer.utilities.logging.Logger;
import com.yieldlove.androidpromise.Promise;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HttpExternalConfigFetcher implements ExternalConfigFetcher {
    private final OkHttpClient client = SharedHttpClient.INSTANCE.getClient();
    private static Promise<String> activePromise;
    private static final ArrayList<Promise<String>> resultPromises = new ArrayList<>();

    public Promise<String> getConfiguration(String url) {
        return new Promise<>(resultPromise -> {
            resultPromises.add(resultPromise);

            if (activePromise == null) {
                activePromise = this.callServer(url)
                        .done(responseBody -> {
                            this.resolveWaitingPromises(responseBody);
                            this.resetActivePromise();
                        });
            }
        });
    }

    private void resetActivePromise() {
        activePromise = null;
    }

    private void resolveWaitingPromises(String responseBody) {
        while(resultPromises.size() > 0) {
            resultPromises.get(0).resolve(responseBody);
            resultPromises.remove(0);
        }
    }

    private Promise<String> callServer(String url) {
        return new Promise<>((promise) -> {
            Handler mHandler = new Handler(Looper.getMainLooper());
            Request request = new Request.Builder()
                    .url(url)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    mHandler.post(() -> {
                        Logger.e("[HttpExternalConfigFetcher] IOException is thrown while fetching external configuration", e);
                        promise.resolve(null);
                    });
                }

                @Override
                public void onResponse(Call call, Response response) {
                    mHandler.post(() -> handleResponse(promise, response));
                }
            });
        });
    }

    private void handleResponse(Promise<String> promise, Response response) {
        try {
            if (response.isSuccessful() && response.body() != null) {
                try {
                    String body = response.body().string();
                    promise.resolve(body);
                } catch (IOException e) {
                    Logger.e("[HttpExternalConfigFetcher] IOException is thrown while handling response", e);
                    promise.resolve(null);
                }
            } else {
                Logger.e("[HttpExternalConfigFetcher] Server returns error: " + response.code());
                promise.resolve(null);
            }
        } finally {
            response.close();
        }
    }
}
