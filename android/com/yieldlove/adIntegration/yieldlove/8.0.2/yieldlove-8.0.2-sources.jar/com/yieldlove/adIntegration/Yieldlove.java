package com.yieldlove.adIntegration;

import com.stroeer.ads.StroeerSDK;

@Deprecated (since = "Use com.stroeer.ads.StroeerSDK instead, This may not work properly", forRemoval = true)
public class Yieldlove extends StroeerSDK {

}
