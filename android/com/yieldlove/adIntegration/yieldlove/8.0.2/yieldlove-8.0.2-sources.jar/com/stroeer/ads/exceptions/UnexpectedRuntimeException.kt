package com.stroeer.ads.exceptions

class UnexpectedRuntimeException(exception: Exception?) : StroeerException(exception)
