package com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers;

import com.google.gson.JsonObject;
import com.yieldlove.adIntegration.ExternalConfiguration.YieldloveAdUnitData;

public class ZoneAndPageTypeParser {

    private final JsonObject parsedJson;

    public ZoneAndPageTypeParser(JsonObject json){
        this.parsedJson = json;
    }

    public void addKeyValues(YieldloveAdUnitData adUnit, String adSlotName) {
        String[] zoneNames = adSlotName.split("_");

        for (String zoneName : zoneNames) {
            addKeyValuesForZone1IfExists(adUnit, zoneName);
            addKeyValuesForZone2IfExists(adUnit, zoneName);
            addKeyValuesForPageTypeIfExists(adUnit, zoneName);
            addKeyValuesForSlotIfExists(adUnit, zoneName);
        }
    }

    private JsonObject getSlotData(String slotName) {
        return this.getSlots().getAsJsonObject(slotName);
    }
    private JsonObject getSlots() {
        return this.parsedJson.getAsJsonObject("adSlots");
    }

    private void addKeyValuesForZone1IfExists(YieldloveAdUnitData adUnit, String zoneName) {
        JsonObject zone = this.getZone1(zoneName);

        if (zone != null) {
            this.addKeyValuesForZone(adUnit, zone);
        }
    }

    private void addKeyValuesForZone2IfExists(YieldloveAdUnitData adUnit, String zoneName) {
        JsonObject zone = this.getZone2(zoneName);

        if (zone != null) {
            this.addKeyValuesForZone(adUnit, zone);
        }
    }

    private void addKeyValuesForPageTypeIfExists(YieldloveAdUnitData adUnit, String zoneName) {
        JsonObject pageType = this.getPageType(zoneName);

        if (pageType != null) {
            this.addKeyValuesForZone(adUnit, pageType);
        }
    }

    private void addKeyValuesForSlotIfExists(YieldloveAdUnitData adUnit, String zoneName) {
        JsonObject slotData = this.getSlotData(zoneName);

        if (slotData != null) {
            this.addKeyValuesForZone(adUnit, slotData);
        }
    }

    private JsonObject getPageType(String zoneName) {
        return this.getPageTypes().getAsJsonObject(zoneName);
    }

    private void addKeyValuesForZone(YieldloveAdUnitData adUnit, JsonObject zoneData) {
        JsonObject keyValues = zoneData.getAsJsonObject("keyValues");
        if (keyValues != null) {
            for (String key : keyValues.keySet()) {
                adUnit.addCustomTargeting(key, keyValues.get(key).getAsString());
            }
        }
    }

    private JsonObject getZone1(String zoneName) {
        return this.getZonesL1().getAsJsonObject(zoneName);
    }

    private JsonObject getZone2(String zoneName) {
        return this.getZonesL2().getAsJsonObject(zoneName);
    }

    private JsonObject getZonesL1() {
        return this.getZonesAndPageTypes().getAsJsonObject("level1");
    }

    private JsonObject getZonesL2() {
        return this.getZonesAndPageTypes().getAsJsonObject("level2");
    }

    private JsonObject getPageTypes() {
        return this.getZonesAndPageTypes().getAsJsonObject("pageType");
    }

    private JsonObject getZonesAndPageTypes() {
        return this.parsedJson.getAsJsonObject("zonesAndPageTypes");
    }

}
