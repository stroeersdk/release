package com.stroeer.ads.formats.rewarded

import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.exceptions.StroeerException

open class StroeerRewardedFullListener : IStroeerRewardedFullListener{
    override fun onAdLoaded(rewardedAd: RewardedAd?) {
    }

    override fun onAdFailedToLoad(exception: StroeerException) {
    }

    override fun onUserEarnedReward(item: RewardItem?) {
    }

    override fun onAdClicked() {
    }

    override fun onAdDismissedFullScreenContent() {
    }

    override fun onAdFailedToShowFullScreenContent(e: StroeerException?) {
    }

    override fun onAdImpression() {
    }

    override fun onAdShowedFullScreenContent() {
    }
}