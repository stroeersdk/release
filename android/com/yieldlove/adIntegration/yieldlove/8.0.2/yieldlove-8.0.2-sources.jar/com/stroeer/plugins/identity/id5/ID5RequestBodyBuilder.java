package com.stroeer.plugins.identity.id5;


import com.stroeer.plugins.identity.IIdentityCollector;
import com.stroeer.plugins.identity.collectors.*;
import com.stroeer.plugins.identity.id5.collectors.*;
import com.stroeer.plugins.identity.id5.objects.ID5RequestBody;
import com.stroeer.utilities.logging.Logger;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class ID5RequestBodyBuilder {

    private static ID5RequestBodyBuilder _instance = new ID5RequestBodyBuilder();
    public static ID5RequestBodyBuilder getInstance() {
        return _instance;
    }
    protected ID5RequestBody requestBody = new ID5RequestBody();
    protected Map<String, IIdentityCollector<?>> collectors = new HashMap<>();

    public static void setInstance(ID5RequestBodyBuilder instance){
        Logger.e("[ID5RequestBodyBuilder] instance is set. This should not be called in Production");
        _instance = instance;
    }

    public ID5RequestBodyBuilder(){
        collectors.put("ip", new IPv4Collector());
        collectors.put("ip6", new IPv6Collector());
        collectors.put("bundle", new BundleCollector());
        collectors.put("country", new CountryCodeCollector());
        collectors.put("gdpr", new GdprCollector());
        collectors.put("gdprConsent", new GdprConsentCollector());
        collectors.put("gpp_string", new GppCollector());
        collectors.put("gppSid", new GppSidCollector());
        collectors.put("language", new LanguageCollector());
        collectors.put("maid", new MaidCollector());
        collectors.put("maidType", new MaidTypeCollector());
        collectors.put("name", new NameCollector());
        collectors.put("ts", new TimeCollector());
        collectors.put("partner", new PartnerCollector());
        collectors.put("ver", new VersionCollector());
        collectors.put("ua", new UaCollector());
        collectors.put("signature", new SignatureCollector());
        collectors.put("us_privacy", new USPrivacyCollector());
    }

    public void setEmail(String email) {
        requestBody.setHem(hash(normalizeEmail(email)));
    }

    public void setPhone(String phone) {
        requestBody.setPhone(hash(normalizePhoneNumber(phone)));
    }

    public void setPuid(String puid) {
        requestBody.setPuid(puid);
    }

    public void setRegionCode(String regionCode) {
        requestBody.setRegion(regionCode);
    }

    public void setCityCode(String cityCode) {
        requestBody.setCity(cityCode);
    }

    public void setSegments(List<ID5RequestBody.Segment> segments) {
        requestBody.setSegments(segments);
    }

    public boolean isUpdated(){

        try
        {
            // Check the consent string is updated or not
            requestBody.setGdpr_consent((String) collectors.get("gdprConsent").retrieveData().get());
            requestBody.setGpp_string((String) collectors.get("gpp_string").retrieveData().get());

        }catch (Exception e){
            Logger.e("[ID5RequestBodyBuilder] Failed to get consent string", e);
        }

        // And then the properties in the request body is updated or not
        // This is when the custom info is set, the request body is updated.
        // In fact, when the customer info is set, it is not necessary to update the ID5.
        // However, we try to get the nice "ID" as much as we can.
        // Consent is very important to update ID5. So, only when the consent is updated, we update the ID5.
        // Otherwise, the ID5 will be updated in the next refresh interval
        return  requestBody.isUpdated();
    }

    public ID5RequestBody getRequestBody(){
        // As we don't want to keep calling this again and again while it is updating.
        requestBody.resetUpdated();

        try {
            ID5RequestBody updatedRequestBody = new ID5RequestBody();
            // Execute all futures and collect them into a map
            Map<String, CompletableFuture<?>> futures = collectors.entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            entry -> entry.getValue().retrieveData()
                    ));

            Map<String, Object> results = new HashMap<>();
            //Wait for all futures to complete
            CompletableFuture.allOf(futures.values().toArray(new CompletableFuture[0]))
                    .thenRun(() -> {
                        // Process results after all futures complete
                        futures.forEach((key, future) -> {
                            try {
                                results.put(key, future.get());
                            } catch (Exception e) {
                                results.put(key, null);
                            }
                        });
                    }).join(); // Block until all futures complete

            updatedRequestBody.setIp((String) results.get("ip"));
            updatedRequestBody.setIpv6((String) results.get("ip6"));
            updatedRequestBody.setBundle((String) results.get("bundle"));
            updatedRequestBody.setAppId((String) results.get("bundle"));
            updatedRequestBody.setCountry((String) results.get("country"));
            updatedRequestBody.setGdpr((Integer) results.get("gdpr"));
            updatedRequestBody.setGdpr_consent((String) results.get("gdprConsent"));
            updatedRequestBody.setGpp_string((String) results.get("gpp_string"));
            updatedRequestBody.setGpp_sid((String) results.get("gppSid"));
            updatedRequestBody.setAccept_language((String) results.get("language"));
            updatedRequestBody.setMaid((String) results.get("maid"));
            updatedRequestBody.setMaid_type((String) results.get("maidType"));
            updatedRequestBody.setTs((String) results.get("ts"));
            updatedRequestBody.setPartner((Integer) results.get("partner"));
            updatedRequestBody.setVer((String) results.get("ver"));
            updatedRequestBody.setUa((String) results.get("ua"));
            updatedRequestBody.setSignature((String) results.get("signature"));
            updatedRequestBody.setUs_privacy((String) results.get("us_privacy"));
            updatedRequestBody.setName((String) results.get("name"));

            updatedRequestBody.setHem(requestBody.getHem());
            updatedRequestBody.setPhone(requestBody.getPhone());
            updatedRequestBody.setPuid(requestBody.getPuid());
            updatedRequestBody.setRegion(requestBody.getRegion());
            updatedRequestBody.setCity(requestBody.getCity());

            updatedRequestBody.resetUpdated();

            requestBody = updatedRequestBody;
        }catch(Exception e) {
            Logger.e("[ID5RequestBodyBuilder] Failed to get request body", e);
        }

        return requestBody;
    }

    protected String hash(String source) {
        try {

            if (source == null) return null;

            // Create SHA-256 hash
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(source.getBytes(StandardCharsets.UTF_8));

            // Convert byte array to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Logger.e("[ID5RequestBodyBuilder] SHA-256 algorithm not found", e);
        }
        return null;
    }

    protected String normalizeEmail(String email) {
        if (email == null || email.isEmpty()) {
            Logger.e("[ID5RequestBodyBuilder] Email is null or empty");
            return null;
        }

        // Trim spaces and convert to lowercase
        email = email.trim().toLowerCase();

        // Split username and domain
        int atIndex = email.indexOf("@");
        if (atIndex == -1) {
            Logger.e("[ID5RequestBodyBuilder] Invalid email format: " + email);
            return email; // Invalid email format, return as-is
        }

        String username = email.substring(0, atIndex);
        String domain = email.substring(atIndex + 1);

        // Remove everything after '+' in username
        int plusIndex = username.indexOf("+");
        if (plusIndex != -1) {
            username = username.substring(0, plusIndex);
        }

        // Remove every dot in the username
        username =  username.replaceAll("\\.", "");

        return username + "@" + domain;
    }

    protected String normalizePhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return null;
        }

        // Remove all non-numeric characters except leading "+"
        String cleanedNumber = phoneNumber.replaceAll("[^\\d+]", "");

        // If the number starts with "+", keep it; otherwise, assume it has a country code
        if (cleanedNumber.startsWith("+")) {
            cleanedNumber = cleanedNumber.substring(1);
        }

        // Remove any additional "+" if they exist (E.164 only allows one leading "+")
        cleanedNumber = cleanedNumber.replaceAll("\\++", "+");

        // Remove all non-numeric characters again (except for the leading "+")
        cleanedNumber = cleanedNumber.replaceAll("\\D", "");

        // Ensure the number is at most 15 digits (E.164 max length)
        if (cleanedNumber.length() > 15) {
            cleanedNumber = cleanedNumber.substring(0, 15);
        }

        return "+" + cleanedNumber;
    }
}
