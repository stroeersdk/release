package com.stroeer.ads.reporting.events

class AdViewPrepared : TimeEvent()
