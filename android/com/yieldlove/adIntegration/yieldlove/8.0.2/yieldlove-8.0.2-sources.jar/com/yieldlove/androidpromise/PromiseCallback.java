package com.yieldlove.androidpromise;

public interface PromiseCallback {
}
