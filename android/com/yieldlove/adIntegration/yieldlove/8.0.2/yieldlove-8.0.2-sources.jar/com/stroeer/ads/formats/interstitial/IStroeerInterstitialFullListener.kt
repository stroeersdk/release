package com.stroeer.ads.formats.interstitial

import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.IStroeerAdFullListener

/**
 * Extended listener interface for interstitial ad events.
 *
 * This interface builds on [IStroeerInterstitialListener] and adds
 * callbacks for full-screen content lifecycle events such as showing,
 * dismissal, impression, and click tracking.
 *
 * Implement this interface if you need full control over interstitial ad behavior.
 */
interface IStroeerInterstitialFullListener : IStroeerInterstitialListener, IStroeerAdFullListener {
}