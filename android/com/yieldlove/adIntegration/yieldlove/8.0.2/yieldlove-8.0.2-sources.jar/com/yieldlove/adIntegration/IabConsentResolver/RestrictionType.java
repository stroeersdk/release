package com.yieldlove.adIntegration.IabConsentResolver;

public enum RestrictionType {
    NOT_ALLOWED,
    REQUIRE_CONSENT,
    REQUIRE_LEGITIMATE_INTEREST,
    UNDEFINED;

    public static RestrictionType from(int id) {
        switch (id) {
            case 0:
                return NOT_ALLOWED;
            case 1:
                return REQUIRE_CONSENT;
            case 2:
                return REQUIRE_LEGITIMATE_INTEREST;
            case 3:
                return UNDEFINED;
            default:
                return NOT_ALLOWED;
        }
    }
}
