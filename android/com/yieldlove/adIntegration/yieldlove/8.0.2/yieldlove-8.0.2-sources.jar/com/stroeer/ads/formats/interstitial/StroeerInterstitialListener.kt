package com.stroeer.ads.formats.interstitial

import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.exceptions.StroeerException

open class StroeerInterstitialListener : IStroeerInterstitialListener{
    override fun onAdLoaded() { }

    override fun onAdFailedToLoad(exception: StroeerException?) { }
}