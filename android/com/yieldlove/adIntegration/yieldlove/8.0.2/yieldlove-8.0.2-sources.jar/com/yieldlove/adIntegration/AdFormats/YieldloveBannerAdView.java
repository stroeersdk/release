package com.yieldlove.adIntegration.AdFormats;

import com.google.android.gms.ads.admanager.AdManagerAdView;
import com.stroeer.ads.debugInfo.IDebugInfo;
import com.stroeer.ads.formats.AdSourceInfo;

/**
 *
 * This interface is dprecated and should not be used.
 */
@Deprecated (since = "Use com.stroeer.ads.formats.banner.StroeerBannerView instead", forRemoval = true)
public interface YieldloveBannerAdView {
    AdManagerAdView getAdView();

    String getAdUnitId();

    IDebugInfo getDebugInfo();

    AdSourceInfo getAdSource();
}
