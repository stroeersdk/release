package com.yieldlove.adIntegration.RemoteReporting

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class HttpMonitoringReporter(url: String, apiKey: String) : HttpReporter(url, apiKey),
    MonitoringReporter {
    override suspend fun report(sessions: ArrayList<String>) {
        withContext(Dispatchers.IO) {
            report(createBody(sessions))
        }
    }

    private fun createBody(sessions: ArrayList<String>): String {
        try {
            val body = JSONObject()
                .put("appName", this.appName)
                .put("os", this.OS)
                .put("sessions", this.getJsonSessions(sessions))

            return body.toString()
        } catch (e: JSONException) {
            return "{\"ReporterException\":\"" + e.message + "\"}"
        }
    }

    private fun getJsonSessions(sessions: ArrayList<String>): JSONArray {
        val jsonArray = JSONArray()
        for (session in sessions) {
            jsonArray.put(JSONObject(session))
        }
        return jsonArray
    }
}
