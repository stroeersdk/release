package com.yieldlove.adIntegration.ExternalConfiguration;

import com.stroeer.ads.exceptions.StroeerException;

public interface CmpConfigCallback {
    void callback(CmpConfig config, StroeerException exception);
}
