package com.stroeer.ads.tasks

interface IAdTask {
    suspend fun <Param>execute(param : Param)
    suspend fun <Param1, Param2>execute(param1 : Param1, param2 : Param2)
}

open class AdTask(val caller: String) : IAdTask{
    override suspend fun <Param>execute(param : Param) {}
    override suspend fun <Param1, Param2>execute(param1 : Param1, param2 : Param2) {}
}