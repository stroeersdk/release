package com.yieldlove.adIntegration.ExternalConfiguration;

import android.content.Context;

import com.stroeer.utilities.logging.Logger;
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit;
import com.yieldlove.adIntegration.Configuration;
import com.yieldlove.adIntegration.Monitoring.MonitoringConfig;
import com.stroeer.ads.exceptions.StroeerException;
import com.yieldlove.androidpromise.Promise;

import org.prebid.mobile.PrebidMobile;
import org.prebid.mobile.TargetingParams;

import java.util.HashMap;

public class ConfigurationManager {

    private final ConfigurationStorage storage;
    private final ExternalConfigFetcher externalConfigFetcher;
    private String localConfig;
    private YieldloveConfig ylConfig = null;
    private Promise<YieldloveConfig> activeFetchPromise = null;

    public ConfigurationManager(ConfigurationStorage storage, ExternalConfigFetcher externalConfigFetcher) {
        this.storage = storage;
        this.externalConfigFetcher = externalConfigFetcher;
        this.tryToInitYlConfig();
    }

    public ConfigurationManager(Context context) {
        this.storage = new SharedPreferencesConfigurationStorage(context);
        this.externalConfigFetcher = new HttpExternalConfigFetcher();
        this.tryToInitYlConfig();
    }

    public Promise<YieldloveAdUnit> getAdUnit(String adSlotName) {
        this.localConfig = this.storage.getJsonConfig();
        if (this.localConfig == null) {
            return this.getAdUnitFromExternalConfiguration(adSlotName);
        } else {
            return this.parseAdUnitFromStoredConfiguration(adSlotName)
                    .done(this::tryToUpdateConfigOnBackground);
        }
    }

    public Promise<YieldloveConfig> getYieldloveConfig() {
        return this.loadYieldloveConfig()
                .done(this::tryToUpdateConfigOnBackground);
    }

    public Promise<CmpConfig> getCmpConfig(String overrideKey) {
        return this.getYieldloveConfig()
                .then((YieldloveConfig config) -> this.transformToCmpConfig(config, overrideKey));
    }

    public Promise<MonitoringConfig> getMonitoringConfig() {
        return this.getYieldloveConfig()
                .then((YieldloveConfig ylConfig) -> ConfigParser.parseMonitoring(this.localConfig));
    }

    public Promise<HashMap<String, String>> getModuleSettings(String moduleName) {
        return this.getYieldloveConfig()
                .then((YieldloveConfig config) -> ConfigParser.parseModuleSettings(this.localConfig, moduleName));
    }

    private void tryToInitYlConfig() {
        try {
            this.localConfig = this.storage.getJsonConfig();
            this.ylConfig = ConfigParser.parse(this.localConfig);
        } catch (StroeerException ignored) {
            Logger.e("Config was not fetched yet.");
        }
    }

    private Promise<YieldloveConfig> loadYieldloveConfig() {
        if (this.ylConfig != null) {
            return Promise.resolveValue(this.ylConfig);
        } else {
            return this.getYieldloveConfigFromExternalConfiguration();
        }
    }

    private void tryToFetchExternalConfigIfOld() {
        if (ConfigurationCacheTtl.isConfigTooOld(this.ylConfig, this.storage.getLastStorageUpdateTime())) {
            if (this.activeFetchPromise == null) {
                this.activeFetchPromise = this.getYieldloveConfigFromExternalConfiguration()
                        .done(ignored -> this.activeFetchPromise = null);
                this.activeFetchPromise.fail(Logger::e);
            }
        }
    }

    private void tryToUpdateConfigOnBackground(Object config) {
        this.tryToFetchExternalConfigIfOld();
    }

    private Promise<YieldloveAdUnit> getAdUnitFromExternalConfiguration(String adSlotName) {
        return Promise.resolveValue(Configuration::getExternalConfigUrl)
                .then(this::fetchJsonConfigFromServer)
                .done(this::checkForNull)
                .then((String configJson) -> this.parseAdUnitAndSaveNewConfig(configJson, adSlotName));
    }

    private YieldloveAdUnit parseAdUnitAndSaveNewConfig(String configJson, String adSlotName) throws StroeerException {
        YieldloveAdUnitData adUnit = ConfigParser.parseAdUnit(adSlotName, configJson);
        PrebidMobile.setPrebidServerAccountId(adUnit.getPrebidAccountId());
        TargetingParams.setStoreUrl(adUnit.getStoreUrl());
        this.setBundleIdIfExist(adUnit);
        this.storage.storeJsonConfig(configJson);
        this.localConfig = configJson;

        return adUnit;
    }

    private void setBundleIdIfExist(YieldloveAdUnit adUnit) {
        String bundleId = adUnit.getBundleId();
        if (bundleId != null) {
            TargetingParams.setBundleName(bundleId);
        }
    }

    private Promise<YieldloveAdUnit> parseAdUnitFromStoredConfiguration(String adSlotName) {
        return new Promise<>(promise -> {
            YieldloveAdUnitData adUnit = ConfigParser.parseAdUnit(adSlotName, this.localConfig);
            PrebidMobile.setPrebidServerAccountId(adUnit.getPrebidAccountId());
            TargetingParams.setStoreUrl(adUnit.getStoreUrl());
            TargetingParams.setOmidPartnerName(Configuration.getOmidPartnerName());
            TargetingParams.setOmidPartnerVersion(Configuration.getOmidPartnerVersion());
            this.setBundleIdIfExist(adUnit);
            promise.resolve(adUnit);
        });
    }

    private Promise<YieldloveConfig> getYieldloveConfigFromExternalConfiguration() {
        return Promise.resolveValue(Configuration::getExternalConfigUrl)
                .then(this::fetchJsonConfigFromServer)
                .done(this::checkForNull)
                .then(this::parseAndSaveNewConfig);
    }

    private YieldloveConfig parseAndSaveNewConfig(String configJson) throws StroeerException {
        YieldloveConfig config = ConfigParser.parse(configJson);this.storage.storeJsonConfig(configJson);
        this.localConfig = configJson;
        this.ylConfig = config;
        return config;
    }

    private void checkForNull(String configJson) throws StroeerException {
        if (configJson == null) {
            throw new StroeerException("Configuration was not fetched. Check your internet connection and application name. Is application name \"" + Configuration.getAppName() + "\" correct?");
        }
    }

    private Promise<String> fetchJsonConfigFromServer(String url) {
        return this.externalConfigFetcher.getConfiguration(url);
    }

    private CmpConfig transformToCmpConfig(YieldloveConfig ylConfig, String overrideKey) throws StroeerException {
        CmpConfig cmpConfig = new CmpConfig();
        cmpConfig.setPrivacyManagerId(ylConfig.getPrivacyManagerId());
        cmpConfig.setPropertyId(ylConfig.getPropertyId());
        cmpConfig.setSourcepointAccountId(ylConfig.getSourcepointAccountId());
        cmpConfig.setPropertyName(ylConfig.getPropertyName());
        cmpConfig.setConsentIsActive(ylConfig.isConsentActive());

        if (overrideKey != null) {
            HashMap<String, HashMap<String, String>> overrides = ylConfig.getConsentOverrides();
            if (overrides.containsKey(overrideKey)) {
                setOverrides(overrideKey, cmpConfig, overrides);
            } else {
                throw new OverrideKeyNotFoundException(overrideKey);
            }
        }

        return cmpConfig;
    }

    private void setOverrides(String overrideKey, CmpConfig cmpConfig, HashMap<String, HashMap<String, String>> overrides) {
        HashMap<String, String> overrideConfig = overrides.get(overrideKey);
        String privacyManagerId = overrideConfig.get("privacyManagerId");
        if (privacyManagerId != null) {
            cmpConfig.setPrivacyManagerId(privacyManagerId);
        }
        String propertyName = overrideConfig.get("propertyName");
        if (propertyName != null) {
            cmpConfig.setPropertyName(propertyName);
        }
        String propertyId = overrideConfig.get("propertyId");
        if (propertyId != null) {
            cmpConfig.setPropertyId(Integer.parseInt(propertyId));
        }
    }
}

