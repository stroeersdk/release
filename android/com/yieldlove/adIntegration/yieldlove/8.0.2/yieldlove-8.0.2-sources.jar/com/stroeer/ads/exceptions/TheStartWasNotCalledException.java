package com.stroeer.ads.exceptions;

public class TheStartWasNotCalledException extends RuntimeException {
    public TheStartWasNotCalledException(String eventName) {
        super("Time keeper was not started before " + eventName + " event.");
    }
}
