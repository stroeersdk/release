package com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects;

public class ConfigSourcePointOverrides {
    public String privacyManagerId;
    public String propertyName;
    public String propertyId;
}
