package com.stroeer.plugins.identity.collectors;


import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.stroeer.plugins.identity.ACollectorWithContext;
import java.util.concurrent.CompletableFuture;

/**
 * Return US Privacy String
 */
public class USPrivacyCollector extends ACollectorWithContext<String> {
    private static final String US_PRIVACY_KEY = "IABUSPrivacy_String";

    @Override
    public CompletableFuture<String> retrieveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
        return CompletableFuture.completedFuture(sharedPreferences.getString(US_PRIVACY_KEY, null));
    }
}
