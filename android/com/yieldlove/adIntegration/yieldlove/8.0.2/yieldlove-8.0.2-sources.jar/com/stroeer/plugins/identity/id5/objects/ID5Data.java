package com.stroeer.plugins.identity.id5.objects;

import com.stroeer.utilities.json.JsonBase;

import java.util.Date;

/**
 * {
 *     "signature": "ID5_AhLqPZyYb9xZ0E_hrt-mUnFMaokzPIl9bZB-nn2me3wVbcPwiiapW7O3RBW5Nz84W5CF5EoBC2iFJqhzJZmcBYwYddOOjIvPbV1-5vYV3ADVc2fuyxnafxs6qjvYPyIbSXVByP87LKifpQ1IXWPC4gQG5dt1MY6-lNMhnB1im5rOT60IcnQ",
 *     "created_at": "2025-02-10T21:24:03.253961212Z",
 *     "original_uid": "ID5*SYAgtBQv_9CNzYkeojWdT-chzArzcIkeojWdT-chzAr3hfh9YZWb-bgP4FynQ5yX",
 *     "universal_uid": "ID5*SYAgtBQv_9CNzYkeojWdT-chzArzcIkeojWdT-chzAr3hfh9YZWb-bgP4FynQ5yX",
 *     "privacy": {
 *         "jurisdiction": "other",
 *         "id5_consent": true
 *     },
 *     "ext": {
 *         "linkType": 0
 *     }
 * }
 */
public class ID5Data extends JsonBase<ID5Data> {
    public String signature;
    public Date created_at;  // This should not be used as the ID5 server response this with the different format
    public String original_uid;
    public String universal_uid;
    public ID5Data_Privacy privacy;
    public ID5Data_Ext ext;
}
