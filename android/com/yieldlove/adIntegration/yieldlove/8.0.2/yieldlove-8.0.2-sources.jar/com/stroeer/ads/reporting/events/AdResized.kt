package com.stroeer.ads.reporting.events

class AdResized : TimeEvent()
