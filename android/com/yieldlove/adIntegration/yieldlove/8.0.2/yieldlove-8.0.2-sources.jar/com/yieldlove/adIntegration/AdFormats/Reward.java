package com.yieldlove.adIntegration.AdFormats;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.rewarded.RewardItem;

@Deprecated(since = "No longer use this class.", forRemoval = true)
public class Reward {
    private int amount;
    private String type;

    Reward(RewardItem gamRewardItem) {
        this.amount = gamRewardItem.getAmount();
        this.type = gamRewardItem.getType();
    }

    public int getAmount() {
        return this.amount;
    }

    @NonNull
    public String getType() {
        return this.type;
    }
}
