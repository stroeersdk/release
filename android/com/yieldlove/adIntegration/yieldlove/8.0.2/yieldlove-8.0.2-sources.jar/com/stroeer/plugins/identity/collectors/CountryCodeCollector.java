package com.stroeer.plugins.identity.collectors;

import android.content.Context;
import android.telephony.TelephonyManager;

import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;

/**
 * Return country code. Collect from SIM card, Network, or device's default locale.
 */
public class CountryCodeCollector extends ACollectorWithContext<String> {

    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.supplyAsync(() -> {
            String countryCode = null;

            // Get the Telephony Manager
            TelephonyManager telephonyManager = (TelephonyManager) applicationContext.getSystemService(Context.TELEPHONY_SERVICE);

            if (telephonyManager != null) {
                // 1. Try getting country from SIM card
                countryCode = telephonyManager.getSimCountryIso();
                if (countryCode != null && !countryCode.isEmpty()) {
                    return countryCode.toUpperCase(); // Return uppercase ISO country code
                }

                // 2. Try getting country from Network
                countryCode = telephonyManager.getNetworkCountryIso();
                if (countryCode != null && !countryCode.isEmpty()) {
                    return countryCode.toUpperCase();
                }
            }

            // 3. Fallback: Get country from the device's default locale
            return Locale.getDefault().getCountry().toUpperCase();
        });
    }
}
