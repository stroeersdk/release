package com.stroeer.ads.reporting.events

import com.google.gson.JsonObject

class MeasuringStarted : TimeEvent() {
    @JvmField
    var startTime: Long? = null

    public override fun toJsonObject(): JsonObject {
        val jsonObject = super.toJsonObject()
        jsonObject.addProperty("startTime", 0)
        return jsonObject
    }
}
