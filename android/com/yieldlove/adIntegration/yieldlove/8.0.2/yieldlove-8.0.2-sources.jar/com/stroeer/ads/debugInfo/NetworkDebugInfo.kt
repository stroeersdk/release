package com.stroeer.ads.debugInfo

import org.json.JSONObject

data class NetworkDebugInfo (val id: String){
    val createdTime = System.currentTimeMillis()
    var sdkType : SdkType = SdkType.Prebid
    var requestString : String? = null
    var responseString : String? = null
    var request : JSONObject? = null
    var response : JSONObject? = null
}