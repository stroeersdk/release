package com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects;

public class ConfigCommon {

    public String dfpAppNetwork;
    public String dfpAndroidAppName;
    public Integer dfpAdRequestTimeoutMs;

    public Integer updateIntervalMs;
    public Boolean rtaAuction;

    public String androidStoreUrl;
    public String androidBundleId;

    public String inventoryStructure;
    public Boolean setAppMuted;

}
