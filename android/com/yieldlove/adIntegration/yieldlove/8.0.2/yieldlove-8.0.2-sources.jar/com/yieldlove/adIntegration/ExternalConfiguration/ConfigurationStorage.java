package com.yieldlove.adIntegration.ExternalConfiguration;

public interface ConfigurationStorage {
    String getJsonConfig();
    void storeJsonConfig(String json);
    long getLastStorageUpdateTime();
    void removeJsonConfig();
}
