package com.stroeer.ads.sdks

import com.stroeer.ads.formats.AAdConfiguration
import com.stroeer.ads.formats.banner.BannerConfiguration
import com.stroeer.ads.formats.interstitial.InterstitialConfiguration
import com.stroeer.ads.formats.rewarded.RewardedConfiguration

interface ISdkAdapter {
    suspend fun getBid(adConfig : AAdConfiguration): SdkResult
    suspend fun prepare()
    val identifier: String?
}
