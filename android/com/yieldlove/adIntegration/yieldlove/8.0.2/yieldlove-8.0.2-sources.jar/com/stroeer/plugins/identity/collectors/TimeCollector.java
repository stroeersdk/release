package com.stroeer.plugins.identity.collectors;

import android.annotation.SuppressLint;

import com.stroeer.plugins.identity.IIdentityCollector;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;

/**
 * Return current date-time
 */
public class TimeCollector implements IIdentityCollector<String> {

    private final String timeFormat = "yyyy-MM-dd'T'HH:mm:ssXXX";
    @Override
    public CompletableFuture<String> retrieveData() {// Current date-time
        Date now = new Date();

        // Format with SimpleDateFormat
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat(timeFormat);
        dateFormat.setTimeZone(TimeZone.getDefault());

        // Format the date-time
        String formattedDateTime = dateFormat.format(now);

        return CompletableFuture.completedFuture(formattedDateTime);
    }
}
