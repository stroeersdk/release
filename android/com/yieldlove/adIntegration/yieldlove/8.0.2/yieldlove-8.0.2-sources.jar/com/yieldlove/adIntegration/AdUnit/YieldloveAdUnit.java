package com.yieldlove.adIntegration.AdUnit;

import com.google.android.gms.ads.AdSize;
import com.stroeer.utilities.logging.Logger;
import com.stroeer.ads.exceptions.NotValidYieldloveAdUnitIdException;

import java.util.HashMap;

public class YieldloveAdUnit implements AdUnit {

    private final String fullDfpAdUnitId;
    public AdSize[] availableBannerSizes = new AdSize[]{};
    private final HashMap<String, String> customTargeting = new HashMap<>();
    private String prebidConfigId;
    private Boolean rtaAuction = true;
    private Integer dfpAdRequestTimeoutInMs = null;
    private Integer autoRefreshTimeInMs = null;
    private String storeUrl;
    private String bundleId = null;
    private Integer[] openRtbApi = new Integer[]{};

    public YieldloveAdUnit(String id, String configId) throws NotValidYieldloveAdUnitIdException {
        this.validateParameters(id, configId);

        this.fullDfpAdUnitId = id;
        this.prebidConfigId = configId;
    }

    public YieldloveAdUnit(String id, String configId, AdSize size) throws NotValidYieldloveAdUnitIdException {
        this(id, configId);
        this.availableBannerSizes = new AdSize[]{size};
    }

    public YieldloveAdUnit(String id, String configId, AdSize[] sizes) throws NotValidYieldloveAdUnitIdException {
        this(id, configId);
        this.availableBannerSizes = sizes;
    }

    @Override
    public String getPrebidConfigId() {
        return this.prebidConfigId;
    }

    @Override
    public String getCriteoAdUnitId() {
        return this.fullDfpAdUnitId;
    }

    @Override
    public AdSize[] getAdSizes() {
        return this.availableBannerSizes;
    }

    @Override
    public String getDfpAdUnitId() {
        return this.fullDfpAdUnitId;
    }

    public void addCustomTargeting(String key, String value) {
        this.customTargeting.put(key, value);
    }

    public HashMap<String, String> getCustomTargeting() {
        return this.customTargeting;
    }

    public Boolean getRtaAuction() {
        return this.rtaAuction;
    }

    public Integer getDfpAdRequestTimeoutInMs() {
        return this.dfpAdRequestTimeoutInMs;
    }

    public void setDfpAdRequestTimeoutInMs(int timeout) {
        this.dfpAdRequestTimeoutInMs = timeout;
    }

    public Integer getAutoRefreshTimeInMs() {
        return this.autoRefreshTimeInMs;
    }

    public void setAutoRefreshTimeInMs(int refreshTime) {
        this.autoRefreshTimeInMs = refreshTime;
    }

    private void validateParameters(String id, String configId) throws NotValidYieldloveAdUnitIdException {
        if (id == null) {
            throw new NotValidYieldloveAdUnitIdException("Ad unit id cannot be null");
        }

        if (!id.startsWith("/")) {
            throw new NotValidYieldloveAdUnitIdException("Ad unit id must start with \"/\"");
        }

        if (configId == null) {
            throw new NotValidYieldloveAdUnitIdException("Config id cannot be null");
        }
    }

    public void setRtaAuction(boolean rtaAuction) {
        this.rtaAuction = rtaAuction;
    }

    public void setStoreUrl(String url) {
        this.storeUrl = url;
    }

    public void setBundleId(String id) {
        this.bundleId = id;
    }

    public void setOpenRtbApi(Integer[] openRtbApi) {
        this.openRtbApi = openRtbApi;
    }

    public String getStoreUrl() {
        return this.storeUrl;
    }

    public String getBundleId() {
        return this.bundleId;
    }

    public Integer[] getOpenRtbApi() {
        return this.openRtbApi;
    }

    public String getAdSlotName()
    {
        if(fullDfpAdUnitId != null && !fullDfpAdUnitId.isEmpty())
        {
            String[] subStr = fullDfpAdUnitId.split("/");
            if(subStr.length >= 4)
            {
                return subStr[subStr.length-1];
            }
            else {
                Logger.e("Failed to get AdSlotName - adUnit:"+fullDfpAdUnitId);
                return "";
            }
        }

        return "";
    }

    public String getPlacementName(){
        try {
            String[] zoneAndPlacements = getAdSlotName().split("_");
            return zoneAndPlacements[zoneAndPlacements.length - 1];
        }catch (Exception e){
            Logger.e("Failed to get PlacementName - adUnit:"+fullDfpAdUnitId);
            return getAdSlotName();
        }
    }
}
