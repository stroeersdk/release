package com.stroeer.plugins.identity;

import android.content.Context;

import java.util.concurrent.CompletableFuture;

public abstract class ACollectorWithContext<T> implements IIdentityCollector<T> {
    protected static Context applicationContext;

    public static void setApplicationContext(Context context) {
        applicationContext = context;
    }

    @Override
    public abstract CompletableFuture<T> retrieveData();
}
