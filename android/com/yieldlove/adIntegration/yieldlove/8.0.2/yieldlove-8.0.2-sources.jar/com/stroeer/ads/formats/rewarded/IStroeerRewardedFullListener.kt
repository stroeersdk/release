package com.stroeer.ads.formats.rewarded

import com.stroeer.ads.formats.IStroeerAdFullListener

interface IStroeerRewardedFullListener : IStroeerRewardedListener, IStroeerAdFullListener {
}