package com.yieldlove.adIntegration.IabConsentResolver;

import com.yieldlove.adIntegration.ConsentReader.ConsentReader;

public class IabPublisherRestrictionResolver implements PublisherRestrictionsResolver {
    private final ConsentReader reader;
    private final ConsentEvaluator evaluator;
    private final int nonFlexiblePurpose1Id = 1;
    public IabPublisherRestrictionResolver(ConsentReader reader, ConsentEvaluator evaluator) {
        this.reader = reader;
        this.evaluator = evaluator;
    }

    @Override
    public boolean resolve(int vendorId, int purposeId) {
        RestrictionType type = this.getPublisherPurposeRestriction(vendorId, purposeId);
        switch (type) {
            case REQUIRE_CONSENT:
                return this.evaluator.evaluateConsentRequired(vendorId, purposeId);
            case REQUIRE_LEGITIMATE_INTEREST:
            case UNDEFINED:
                if (purposeId == this.nonFlexiblePurpose1Id) {
                    return this.evaluator.evaluateConsentRequired(vendorId, purposeId);
                }
                return this.evaluator.evaluateLegitimateInterestRequired(vendorId, purposeId);
            case NOT_ALLOWED:
            default:
                return false;
        }
    }

    private RestrictionType getPublisherPurposeRestriction(int vendorId, int purposeId) {
        String encodedString = this.reader.getPublisherRestrictionsFor(purposeId);
        if (!encodedString.isEmpty() && encodedString.length() >= vendorId) {
            int type = Integer.parseInt(String.valueOf(encodedString.charAt(this.convertIdToIndex(vendorId))));
            return RestrictionType.from(type);
        }
        return RestrictionType.UNDEFINED;
    }

    private int convertIdToIndex(int vendorId) {
        return vendorId - 1;
    }
}
