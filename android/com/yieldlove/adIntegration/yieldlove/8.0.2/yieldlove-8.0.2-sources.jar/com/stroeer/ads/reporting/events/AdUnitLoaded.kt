package com.stroeer.ads.reporting.events

class AdUnitLoaded : TimeEvent()
