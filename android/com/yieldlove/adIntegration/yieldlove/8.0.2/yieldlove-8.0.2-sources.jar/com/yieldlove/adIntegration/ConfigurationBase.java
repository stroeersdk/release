package com.yieldlove.adIntegration;

public class ConfigurationBase {
    protected final String prebidUrl = "https://s2s.yieldlove-ad-serving.net/openrtb2/auction";
    protected final String externalConfigUrl = "https://cdn.stroeerdigitalgroup.de/sdk/live/{APPLICATION_NAME}/config.json";
    protected final String yieldloveDfpId = "53015287";
    protected final boolean sourcepointIsStagingCampaign = false;
    protected final String externalConfigSharedPrefsFileKey = "EXTERNAL_CONFIG_FILE_KEY";
    protected final String externalConfigContentKey = "EXTERNAL_CONFIG_CONTENT_KEY";
    protected final String externalConfigLastFetchInMillisKey = "EXTERNAL_CONFIG_LAST_FETCH_IN_MILLIS_KEY";
    protected final String errorReporterUrl = "https://mobile-sdk.stroeer-labs.com/api/reporting";
    protected final String monitoringReporterUrl = "https://mobile-sdk.stroeer-labs.com/api/event-sessions";
    protected final String errorReporterApiKey = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T";
    protected final String monitoringReporterApiKey = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T";
    protected final String OmidPartnerName = "Google";
    protected final String OmidPartnerVersion = "213502000.213502000";
}
