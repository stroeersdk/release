package com.stroeer.ads.formats.banner.refresh

import com.stroeer.utilities.logging.Logger
import kotlinx.coroutines.*

class RefreshTimer(
    val listener: IRefreshListener
) {
    private val coroutineScope: CoroutineScope = MainScope()
    private var refreshJob: Job? = null

    fun scheduleRefresh(timeInMs: Int) {
        if (timeInMs <= 0) return

        // Cancel any existing refresh task
        clearScheduledTasks()

        Logger.d("[RefreshTimer] Scheduling refresh in ${timeInMs}ms")

        refreshJob = coroutineScope.launch {
            delay(timeInMs.toLong())
            listener.handleRefresh()
        }
    }

    fun clearScheduledTasks() {
        refreshJob?.cancel()
        refreshJob = null
    }

    fun cancel() = clearScheduledTasks()
}