package com.stroeer.ads.consent

interface IConsentEvaluator {
    fun evaluateConsentRequired(vendorId: Int, purposeId: Int): Boolean
    fun evaluateLegitimateInterestRequired(vendorId: Int, purposeId: Int): Boolean
}
