package com.stroeer.plugins.monitoring;

import android.view.View;

/**
 * IAdMonitoring defines the core functionalities required for an ad monitoring
 * implementation. This interface provides methods to enable certain features,
 * initialize the monitoring with specific properties, and mark ad views for monitoring.
 */
public interface IAdMonitoring {

    /**
     * Enables the reload mode for the ad monitoring system.
     * This mode allows the system to handle automatic reloading of ads.
     */
    void enableReload();

    /**
     * Enables test mode for the ad monitoring system.
     * Test mode is typically used for debugging and testing purposes, providing
     * more verbose logging or bypassing certain restrictions.
     */
    void enableTestMode();

    /**
     * Initializes the ad monitoring system with a given property ID and callback.
     *
     * @param confiantPropertyId the property ID used for initializing the monitoring system.
     * @param callback           an instance of IAdMonitorCallback to handle the response
     *                           after initialization (e.g., success or failure).
     */
    void initialize(String confiantPropertyId, IAdMonitorCallback callback);

    /**
     * Marks a specific view and placement ID for monitoring.
     * This method associates a given ad view with a placement ID for tracking purposes.
     *
     * @param view        the ad view to be monitored.
     * @param placementId the unique identifier for the ad placement.
     */
    void mark(View view, String placementId);
}