package com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigSourcePointModule;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigSourcePointOverrides;
import com.yieldlove.adIntegration.ExternalConfiguration.YieldloveConfig;

import java.util.HashMap;

public class ModuleParser {

    private final JsonObject parsedJson;

    public ModuleParser(JsonObject json){
        this.parsedJson = json;
    }

    public JsonObject getModuleConfig(String moduleName) {
        JsonArray modules = this.getModules();
        for (int i = 0; i < modules.size(); i++) {
            JsonObject module = (JsonObject) modules.get(i);
            if (module.has(moduleName)) {
                return module.getAsJsonObject(moduleName);
            }
        }

        return null;
    }

    public HashMap<String, String> parseModule(String moduleName) {
        HashMap<String, String> moduleSettings = new HashMap<>();

        JsonObject moduleJson = this.getModuleConfig(moduleName);

        if (moduleJson != null) {
            for (String key : moduleJson.keySet()) {
                moduleSettings.put(key, moduleJson.get(key).getAsString());
            }
        }

        return moduleSettings;
    }

    public void setSourcepointConfig(YieldloveConfig config) {
        JsonObject sourcepointConfig = this.getModuleConfig("SOURCEPOINT");
        Gson gson = new Gson();
        ConfigSourcePointModule sourcePoint = gson.fromJson(sourcepointConfig, ConfigSourcePointModule.class);

        if (sourcePoint != null) {
            config.setPrivacyManagerId(sourcePoint.privacyManagerId);
            config.setPropertyName(sourcePoint.propertyName);
            config.setPropertyId(sourcePoint.propertyId);
            config.setSourcepointAccountId(sourcePoint.sourcepointAccountId);
            config.setConsentIsActive(sourcePoint.active);

            this.setSourcepointOverrides(sourcePoint, config);
        }
    }

    private void setSourcepointOverrides(ConfigSourcePointModule sourcePoint, YieldloveConfig config){
        if (sourcePoint.overrides != null) {
            for (String key : sourcePoint.overrides.keySet()) {
                ConfigSourcePointOverrides overrideObject = sourcePoint.overrides.get(key);
                HashMap<String, String> override = getAvailableKeyOverrides(overrideObject);
                config.getConsentOverrides().put(key, override);
            }
        }
    }

    private JsonArray getModules() {
        return this.parsedJson.getAsJsonArray("modules");
    }

    private HashMap<String, String> getAvailableKeyOverrides(ConfigSourcePointOverrides overrides) {
        HashMap<String, String> override = new HashMap<>();

        if(overrides.privacyManagerId != null){
            override.put("privacyManagerId", overrides.privacyManagerId);
        }
        if(overrides.propertyId != null){
            override.put("propertyId", overrides.propertyId);
        }
        if(overrides.propertyName != null){
            override.put("propertyName", overrides.propertyName);
        }

        return override;
    }

}
