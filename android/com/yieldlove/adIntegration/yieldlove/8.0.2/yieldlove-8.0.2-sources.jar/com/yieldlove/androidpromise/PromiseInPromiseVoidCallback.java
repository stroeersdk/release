package com.yieldlove.androidpromise;

public interface PromiseInPromiseVoidCallback<T_NEW> extends PromiseCallback {
    Promise<T_NEW> run() throws Exception;
}
