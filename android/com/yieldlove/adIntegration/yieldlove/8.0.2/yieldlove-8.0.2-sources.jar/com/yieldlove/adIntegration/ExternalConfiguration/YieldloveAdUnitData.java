package com.yieldlove.adIntegration.ExternalConfiguration;

import com.google.android.gms.ads.AdSize;
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit;
import com.stroeer.ads.exceptions.NotValidYieldloveAdUnitIdException;

public class YieldloveAdUnitData extends YieldloveAdUnit {

    private String prebidAccountId;

    public YieldloveAdUnitData(String id, String configId, AdSize size) throws NotValidYieldloveAdUnitIdException {
        super(id, configId, size);
    }

    public YieldloveAdUnitData(String id, String configId, AdSize[] sizes) throws NotValidYieldloveAdUnitIdException {
        super(id, configId, sizes);
    }

    public String getPrebidAccountId() {
        return prebidAccountId;
    }

    public void setPrebidAccountId(String prebidAccountId) {
        this.prebidAccountId = prebidAccountId;
    }
}
