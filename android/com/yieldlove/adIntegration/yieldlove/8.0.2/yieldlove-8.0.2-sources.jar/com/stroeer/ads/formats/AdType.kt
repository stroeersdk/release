package com.stroeer.ads.formats

enum class AdType(private val text: String) {
    BANNER("banner"),
    INTERSTITIAL("interstitial"),
    REWARDED("rewarded");

    override fun toString(): String {
        return text
    }
}
