package com.yieldlove.adIntegration.AdFormats;

import com.stroeer.ads.exceptions.StroeerException;

/**
 * Listener interface for Yieldlove Banner Ad events.
 * This interface is deprecated and should not be used
 */
@Deprecated (since = "Use com.stroeer.ads.formats.banner.IStroeerBannerListener instead")
public interface YieldloveBannerAdListener extends IAdRequestBuildListener {

    void onAdLoaded(YieldloveBannerAdView banner);

    void onAdFailedToLoad(YieldloveBannerAdView banner, StroeerException error);

    void onAdOpened(YieldloveBannerAdView banner);

    void onAdClosed(YieldloveBannerAdView banner);

    void onAdClicked(YieldloveBannerAdView banner);

    void onAdImpression(YieldloveBannerAdView banner);
}

