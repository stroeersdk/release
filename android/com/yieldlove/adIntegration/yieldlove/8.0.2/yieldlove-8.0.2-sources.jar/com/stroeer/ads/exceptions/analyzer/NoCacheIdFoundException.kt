package com.stroeer.ads.exceptions.analyzer

import com.stroeer.ads.exceptions.StroeerException

class NoCacheIdFoundException : StroeerException("No cache id found in html code")
