package com.stroeer.ads.config

object ConfigConstants {

    val yieldloveDfpId: String = "53015287"
    val sourcepointIsStagingCampaign: Boolean = false
    val externalConfigSharedPrefsFileKey: String = "EXTERNAL_CONFIG_FILE_KEY"
    val externalConfigContentKey: String = "EXTERNAL_CONFIG_CONTENT_KEY"
    val externalConfigLastFetchInMillisKey: String =
        "EXTERNAL_CONFIG_LAST_FETCH_IN_MILLIS_KEY"
    val errorReporterUrl: String = "https://mobile-sdk.stroeer-labs.com/api/reporting"
    val monitoringReporterUrl: String =
        "https://mobile-sdk.stroeer-labs.com/api/event-sessions"
    val errorReporterApiKey: String = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T"
    val monitoringReporterApiKey: String = "NVR16aTdPz1sD5rS7QKK37VUzakVw10Z9fL5EZ6T"
    val omidPartnerName: String = "Google"
    val omidPartnerVersion: String = "213502000.213502000"

    val prefsConfig: String = "STROEER_CONFIG"
    val configUrl: String =
        "https://cdn.stroeerdigitalgroup.de/sdk/live/{APPLICATION_NAME}/config.json"
    val applicationNamePlaceholder: String = "{APPLICATION_NAME}"
    const val CONFIG_TIMEOUT: Int = 10
    const val CONFIG_TIMEOUT_MS : Long = CONFIG_TIMEOUT * 1000L
}
