package com.stroeer.plugins.identity.collectors;


import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.concurrent.CompletableFuture;

/**
 * Return package name
 */
public class BundleCollector extends ACollectorWithContext<String> {

    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.completedFuture(applicationContext.getPackageName());
    }
}
