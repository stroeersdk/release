package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest

object GlobalGamManager{
    var adRequestBuilder: AdManagerAdRequest.Builder = AdManagerAdRequest.Builder()
}
