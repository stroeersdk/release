package com.stroeer.ads.sdks

import com.stroeer.ads.debugInfo.ISdkDebugInfo
import com.stroeer.ads.debugInfo.SdkType
import java.util.Date

class SdkDebugInfo() : ISdkDebugInfo {
    override var publisherSlotName: String? = null
    override val createdDate: Date = Date()
    override var sdkType  = SdkType.Prebid
    override var description: String? = null
    override var keyValues: MutableMap<String, String?>? = null
    override var requestJson: String? = null
    override var responseJson: String? = null
}