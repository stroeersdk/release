package com.yieldlove.androidpromise;

public interface VoidCallbackWithoutPromise<T> {
    void run(T result) throws Exception;
}
