package com.stroeer.ads.exceptions

import com.google.android.gms.ads.AdError

class DfpRewardedLoadAdError (val adError: AdError) : StroeerException(){
    override val message: String?
        get() = adError.message
}