package com.stroeer.utilities.common

interface ISuccessFailListener<T> {
    fun onSuccess(data: T)
    fun onFailed()
}
