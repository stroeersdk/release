package com.stroeer.plugins.identity.id5;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.IntegerRes;
import androidx.preference.PreferenceManager;

import com.stroeer.ads.config.ConfigurationManager;
import com.stroeer.consent.ConsentManager;
import com.stroeer.plugins.identity.ACollectorWithContext;
import com.stroeer.plugins.identity.IIdentityManager;
import com.stroeer.plugins.identity.id5.objects.ID5RequestBody;
import com.stroeer.plugins.identity.objects.IdentityCache;
import com.stroeer.plugins.identity.id5.objects.ID5Data;
import com.stroeer.plugins.identity.objects.IdentityCustomInfo;
import com.stroeer.utilities.logging.Logger;

import org.prebid.mobile.ExternalUserId;
import org.prebid.mobile.TargetingParams;

import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class ID5Manager implements IIdentityManager{
    protected Context applicationContext;
    protected IdentityCache identityData;
    protected ID5Data data;
    protected ExternalUserId prebidUserId = new ExternalUserId(ID5Constants.getInstance().getSource(), new ArrayList<>());

    private static ID5Manager _instance = new ID5Manager();
    public static ID5Manager getInstance() {
        return _instance;
    }

    public static void setInstance(ID5Manager instance){
        Logger.e("[ID5Manager] instance is set. This should not be called in Production");
        _instance = instance;
    }

    /**
     * Initializes the ID5Manager with application context and listener.
     *
     * @param applicationContext Application context.
     */
    @Override
    public void initialize(Context applicationContext) {
        this.applicationContext = applicationContext;

        // Some collectors require the application context to be set
        // before the collectors are called
        ACollectorWithContext.setApplicationContext(applicationContext);
    }


    /**
     * Loads the consent string from shared preferences cache.
     */
    @Override
    public void loadConsentStringFromStorage() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
        String cacheString = sharedPreferences.getString(ID5Constants.getInstance().getPrefId5Cache(), null);
        long cacheDate = sharedPreferences.getLong(ID5Constants.getInstance().getPrefId5CacheDate(), 0);

        if(cacheString == null || cacheString.isEmpty()) {
            identityData = null;
            Logger.i("[ID5Manager] loadConsentStringFromStorage: No cache found");
        }
        else {
            identityData = new IdentityCache();
            identityData.setIdentityString(cacheString);
            data = ID5Data.fromJson(cacheString, ID5Data.class);
            if(data != null) {
                identityData.setCacheCreationDate(new Date(cacheDate));

                if(ConfigurationManager.isDebugMode())
                {
                    Logger.d("[ID5Manager] loadConsentStringFromStorage: Cache found - " + data.toPrettyJson());
                }
                else {
                    Logger.i("[ID5Manager] loadConsentStringFromStorage: Cache found");
                }
            }
        }
    }

    /**
     * Fetches the consent string via an HTTP request.
     *
     * @param retry Whether to retry on failure.
     */
    @Override
    public void loadConsentStringFromHttp(boolean retry) {
        try {

            ID5RequestBody requestBody = ID5RequestBodyBuilder.getInstance().getRequestBody(); // RequestBody cannot be null
            if(requestBody.getGdpr_consent() != null || requestBody.getGpp_string() != null) {

                if(!ConsentManager.hasVendorConsent(ID5Constants.getInstance().getVendorId())) {
                    Logger.d("[ID5Manager] ID5 is not allowed to use. Disabled by GDPR.");
                    identityData = null;
                    data = null;
                    return;
                }

                Logger.i("[ID5Manager] Loading ID5 from HTTP.");

                ID5HttpRequest request = new ID5HttpRequest();
                data = request.send(requestBody);
                if (data != null) {

                    // Disabled retry
//                    if ((data.getOriginal_uid() == null || data.getOriginal_uid().isEmpty() || data.getOriginal_uid().equals("0")) && !retry) {
//                        Logger.i("[ID5Manager] loadConsentStringFromHttp: Retry with empty uid");
//                        loadConsentStringFromHttp(true);
//                        return;
//                    }
                    identityData = new IdentityCache();
                    identityData.setCacheCreationDate(new Date());
                    identityData.setIdentityString(data.toJson());

                    storeIdentityData();
                }
                else{
                    Logger.d("[ID5Manager] Failed to load consent string from HTTP. gdpr : "+requestBody.getGdpr_consent()+ ", gpp : "+requestBody.getGpp_string());
                    // Still keep the previous ID5. but will not be used.
                }

            }else {
                Logger.d("[ID5Manager] No gdrp/gpp string found. Removing from request body.");
                identityData = null;
                data = null;
            }
        }catch(Exception e){
            Logger.e("[ID5Manager] Failed to load consent string from HTTP.", e);
            identityData = null;
            data = null;
        }
    }

    /**
     * Checks if the ID5 request body has been updated.
     *
     * @return true if updated, false otherwise.
     */
    @Override
    public boolean isUpdated() {
        return ID5RequestBodyBuilder.getInstance().isUpdated();
    }

    /**
     * Retrieves the identity data.
     *
     * @return IdentityCache object or null if not available.
     */
    @Override
    public IdentityCache getIdentityData() {
        return identityData;
    }

    /**
     * Sets the Prebid user ID based on ID5 data.
     */
    @Override
    public synchronized void setUserIdToPrebid() {

        if(data == null){
            return;
        }
        // Remove anyway
        List<ExternalUserId> idList = TargetingParams.getExternalUserIds();
        for (ExternalUserId id : idList) {
            if (ID5Constants.getInstance().getSource().equals(id.getSource())) {
                idList.remove(id);
                break;
            }
        }

        List<ExternalUserId.UniqueId> ids = prebidUserId.getUniqueIds();
        if(!ids.isEmpty())
        {
            ids.remove(0);
        }
        ExternalUserId.UniqueId id = new ExternalUserId.UniqueId(data.universal_uid, 1);
        HashMap<String, Object> ext = new HashMap<>();
        ext.put("linkType", data.ext.getLinkType());
        // ext.put("universal_uid", data.universal_uid);
        id.setExt(ext);
        ids.add(id);

        idList.add(prebidUserId);
        TargetingParams.setExternalUserIds(idList);
    }

    /**
     * Gets the current ID5 data.
     *
     * @return ID5Data object.
     */
    public ID5Data getData() {
        return data;
    }

    /**
     * Sets custom identity information from provided details.
     *
     * @param customInfo IdentityCustomInfo containing user data.
     */
    @Override
    public void setCustomInfo(IdentityCustomInfo customInfo) {
        if (customInfo != null) {
            if (customInfo.email != null) ID5RequestBodyBuilder.getInstance().setEmail(customInfo.email);
            if (customInfo.phone != null) ID5RequestBodyBuilder.getInstance().setPhone(customInfo.phone);
            if (customInfo.puid != null) ID5RequestBodyBuilder.getInstance().setPuid(customInfo.puid);
            if (customInfo.regionCode != null) ID5RequestBodyBuilder.getInstance().setRegionCode(customInfo.regionCode);
            if (customInfo.cityCode != null) ID5RequestBodyBuilder.getInstance().setCityCode(customInfo.cityCode);
        }
    }

    protected void storeIdentityData() {
        if (identityData != null) {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(ID5Constants.getInstance().getPrefId5Cache(), identityData.getIdentityString());
            editor.putLong(ID5Constants.getInstance().getPrefId5CacheDate(), identityData.getCacheCreationDate().getTime());
            editor.putString(ID5Constants.getInstance().getPrefId5Signature(), data.signature);
            editor.apply();
        }
    }
}
