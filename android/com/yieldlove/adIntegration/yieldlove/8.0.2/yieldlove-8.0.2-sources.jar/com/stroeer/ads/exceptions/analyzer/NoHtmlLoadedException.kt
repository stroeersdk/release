package com.stroeer.ads.exceptions.analyzer

import com.stroeer.ads.exceptions.StroeerException

class NoHtmlLoadedException : StroeerException("No html loaded")
