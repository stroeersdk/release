package com.stroeer.plugins.identity.id5;

import com.stroeer.utilities.logging.Logger;
import com.stroeer.ads.config.ConfigConstants;

public class ID5Constants {

    private static ID5Constants _instance = new ID5Constants();

    public static ID5Constants getInstance() {
        return _instance;
    }

    // This method is only used for testing purposes
    public static void setInstance(ID5Constants instance) {
        Logger.e("[ID5Constants] Setting mock instance, this should not be called in production");
        _instance = instance;
    }

    /**
     * Returns the base URI for the ID5 API
     * @return the base URI
     */
    public String getBaseUri() {
        return BASE_URI;
    }

    /**
     * Returns the name of the shared preference used to store the ID5 cache
     * @return the name of the shared preference
     */
    public String getPrefId5Cache() {
        return PREF_ID5_CACHE;
    }

    /**
     * Returns the name of the shared preference used to store the ID5 cache date
     * @return the name of the shared preference
     */
    public String getPrefId5CacheDate() {
        return PREF_ID5_CACHE_DATE;
    }

    /**
     * Returns the timeout in seconds for the ID5 API requests
     * @return the timeout in seconds
     */
    public int getTimeoutInSecs() {
        return ConfigConstants.CONFIG_TIMEOUT;
    }

    /**
     * Returns the refresh interval in seconds for the ID5 cache, default is 8 hours
     * @return the refresh interval in seconds
     */
    public int getRefreshIntervalInSecs() {
        return REFRESH_INTERVAL_IN_SECS;
    }

    /**
     * Returns the delete interval in seconds for the ID5 cache, default is 30 days
     * @return the delete interval in seconds
     */
    public long getDeleteIntervalInSecs() {
        return DELETE_INTERVAL_IN_SECS;
    }

    /**
     * Returns the source name for the ID5 API. This is used for Prebid External User ID
     * @return the source name
     */
    public String getSource() {
        return SOURCE;
    }

    public int getVendorId() {
        return VENDOR_ID;
    }

    public String getPrefId5Signature(){return PREF_ID5_SIGNATURE;}

    private static final int VENDOR_ID = 131;
    private static final String BASE_URI = "https://api.id5-sync.com/ga/v1";
    private static final String SOURCE = "id5-sync.com";
    private static final int REFRESH_INTERVAL_IN_SECS = 8 * 60 * 60;    // 8 hours
    private static final long DELETE_INTERVAL_IN_SECS = 30 * 24 * 60 * 60;   // 30 days
    private static final String PREF_ID5_CACHE = "ID5_CACHE";
    private static final String PREF_ID5_CACHE_DATE = "ID5_CACHE_DATE";
    private static final String PREF_ID5_SIGNATURE = "ID5_SIGNATURE";
}
