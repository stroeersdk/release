package com.stroeer.ads.reporting

enum class ConnectionType {
    WIFI,
    MOBILE,
    UNKNOWN
}
