package com.yieldlove.adIntegration.ExternalConfiguration;

public class ConfigurationCacheTtl {

    public static boolean isConfigTooOld(YieldloveConfig config, long lastFetchedTimestamp) {
        long syncInterval = config.getSyncInterval();
        long now = System.currentTimeMillis();
        long timeWhenConfigIsTooOld = lastFetchedTimestamp + syncInterval;

        return timeWhenConfigIsTooOld < now;
    }
}
