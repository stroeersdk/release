package com.stroeer.plugins.identity.collectors;

import com.stroeer.plugins.identity.ACollectorWithContext;
import com.stroeer.utilities.http.SharedHttpClient;
import com.stroeer.utilities.logging.Logger;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/*
    * Return IPv4 address
 */
public class IPv4Collector extends ACollectorWithContext<String> {
    protected final String emptyIP = "0.0.0.0";
    protected final int timeoutInSecs = 3;
    protected final String awsIPCheckerURL = "https://checkip.amazonaws.com/";

    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.supplyAsync(() -> {
            CompletableFuture<String> publicIp = getPublicIPAddress(awsIPCheckerURL);
            CompletableFuture<String> localIp = getIPAddress(applicationContext);

            CompletableFuture.allOf(publicIp, localIp).join();

            try {
                String pIp = publicIp.get();
                String lIp = localIp.get();

                if (pIp != null && !pIp.isEmpty() && isIPv4Format(pIp)) {
                    return pIp;
                } else if (lIp != null && !lIp.isEmpty() && isIPv4Format(lIp)) {
                    return lIp;
                }
            } catch (Exception e) {
                Logger.d("[IPv4Collector] Failed to get IP addresses", e);
            }
            return emptyIP;
        }).exceptionally(e -> {
            Logger.d("[IPv4Collector] Failed to get IP addresses", e);
            return emptyIP;
        });
    }

    protected CompletableFuture<String> getIPAddress(Context context) {
        return CompletableFuture.supplyAsync(() -> {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network activeNetwork = cm.getActiveNetwork();

            if (activeNetwork != null) {
                NetworkCapabilities capabilities = cm.getNetworkCapabilities(activeNetwork);
                if (capabilities != null) {
                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        return getMobileIPAddress();
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        return getWifiIPAddress(context);
                    }
                }
            }
            return null;
        }).exceptionally(e -> {
            Logger.d("[IPv4Collector] Failed to get IP address", e);
            return null;
        });
    }

    protected String getWifiIPAddress(Context context) {
        return getNetworkIPAddress(context, false);
    }

    protected String getMobileIPAddress() {
        return getNetworkIPAddress(null, false);
    }

    protected String getNetworkIPAddress(Context context, boolean ipv6) {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface networkInterface : Collections.list(interfaces)) {
                Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
                for (InetAddress address : Collections.list(addresses)) {
                    if (!address.isLoopbackAddress()) {
                        if (!ipv6 && address.getHostAddress().contains(".")) {
                            return address.getHostAddress();
                        } else if (ipv6 && address.getHostAddress().contains(":")) {
                            return address.getHostAddress();
                        }
                    }
                }
            }
        } catch (Exception e) {
            Logger.e("[IPv4Collector] Failed to get IP address", e);
        }
        return null;
    }

    protected CompletableFuture<String> getPublicIPAddress(String url) {
        return CompletableFuture.supplyAsync(() -> {
            OkHttpClient client = SharedHttpClient.INSTANCE.createClientWithTimeout(timeoutInSecs);

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .build();

            try (Response response = client.newCall(request).execute()) {
                ResponseBody responseBody = response.body();
                if (response.isSuccessful() && responseBody != null) {
                    return responseBody.string().trim().replace("\n", "");
                }
            } catch (Exception e) {
                Logger.d("[IPv4Collector] Failed to fetch public IP", e);
            }
            return null;
        }).exceptionally(e -> {
            Logger.d("[IPv4Collector] Failed to fetch public IP", e);
            return null;
        });
    }

    public static boolean isIPv4Format(String ip) {
        return ip.matches("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b");
    }
}
