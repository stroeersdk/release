package com.stroeer.plugins.identity;

import android.content.Context;

import com.stroeer.plugins.identity.objects.IdentityCache;
import com.stroeer.plugins.identity.objects.IdentityCustomInfo;
import com.stroeer.utilities.common.ISuccessFailListener;

public interface IIdentityManager {
    void initialize(Context applicationContext);
    void loadConsentStringFromHttp(boolean retry);
    void loadConsentStringFromStorage();
    IdentityCache getIdentityData();
    boolean isUpdated();
    void setUserIdToPrebid();
    void setCustomInfo(IdentityCustomInfo customInfo);
}
