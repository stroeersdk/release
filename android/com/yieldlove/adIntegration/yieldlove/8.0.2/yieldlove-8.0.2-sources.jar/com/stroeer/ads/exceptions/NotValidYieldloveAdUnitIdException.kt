package com.stroeer.ads.exceptions

class NotValidYieldloveAdUnitIdException : StroeerException {
    constructor(message: String?) : super(message)

    constructor(exception: Exception?) : super(exception)
}
