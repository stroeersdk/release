package com.stroeer.plugins.identity.collectors;

import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.concurrent.CompletableFuture;

/**
 * Return GDPR consent. Collect from IABTCF_TCString.
 */
public class GdprConsentCollector extends ACollectorWithContext<String> {
    public static final String GDPR_CONSENT_KEY = "IABTCF_TCString";

    @Override
    public CompletableFuture<String> retrieveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
        String consentString = sharedPreferences.getString(GDPR_CONSENT_KEY, null);
        if(consentString != null && consentString.isEmpty()) {
            return CompletableFuture.completedFuture(null);
        }
        else {
            return CompletableFuture.completedFuture(consentString);
        }
    }
}
