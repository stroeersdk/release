package com.stroeer.ads.exceptions

class ConfigurationIsNotLoadedException : StroeerException("Configuration is not loaded")
