package com.stroeer.plugins.backfill;

public interface IInitializationCallback {
    void onInitialized(boolean success);
}
