package com.stroeer.ads.reporting

class MultipleStartCalledException :
    RuntimeException("Start event was called more than once in session.")
