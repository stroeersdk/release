package com.stroeer.ads.consent

interface IPublisherRestrictionsResolver {
    fun resolve(vendorId: Int, purposeId: Int): Boolean
}
