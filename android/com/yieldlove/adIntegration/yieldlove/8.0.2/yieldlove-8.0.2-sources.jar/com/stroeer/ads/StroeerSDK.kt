package com.stroeer.ads

import android.content.Context
import com.stroeer.ads.bidding.gam.GlobalGamManager
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.config.IConfigurationListener
import com.stroeer.ads.exceptions.MissingApplicationNameException
import com.stroeer.ads.sdks.prebid.APrebidSdkAdapter
import com.stroeer.consent.ConsentManager
import com.stroeer.plugins.backfill.gravite.GraviteLoader
import com.stroeer.plugins.identity.IdentityManager
import com.stroeer.utilities.json.OrtbJsonHelper
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig
import com.yieldlove.adIntegration.Configuration
import com.yieldlove.adIntegration.ExternalConfiguration.SharedPreferencesConfigurationStorage
import org.json.JSONArray
import org.prebid.mobile.TargetingParams

open class StroeerSDK protected constructor() {
    init {
        try {
            val array = JSONArray()
            array.put(BuildConfig.VERSION_NAME)
            OrtbJsonHelper.addOrUpdate(array, "app", "ext", "data", "androidYlSdkVersion")
            OrtbJsonHelper.apply()
        } catch (e: Exception) {
            Logger.e("[StroeerSDK] Failed to set global ORTB config", e)
        }
    }


    companion object {
        @Volatile
        var instance: StroeerSDK = StroeerSDK()

        /**
         * Set Application name.
         * Publisher should know this, Stroeer server distinguishes the applications]
         * Example app name is appDpfTest
         * @param applicationName Application Name
         */
        @JvmStatic
        fun setApplicationName(applicationContext: Context, applicationName: String) {
            Logger.initialize(applicationContext)
            APrebidSdkAdapter.initialize(applicationContext)

            if (applicationName.isEmpty()) {
                throw MissingApplicationNameException()
            }

            if (ConfigurationManager.isDebugBuild) {
                Logger.e("[ConfigurationManager] This application uses the debug build of StroeerSDK. Please review the build settings")
            }

            Logger.i("StroeerSDK Version: ${ConfigurationManager.version}")

            Configuration.setApplicationName(applicationName)

            ConfigurationManager.getInstance().initialize(applicationContext,applicationName,
                object : IConfigurationListener {
                    override fun onSuccess() {
                        IdentityManager.getInstance().initialize(applicationContext, null)
                    }

                    override fun onFailed() {
                        Logger.e("[StroeerSDK] ConfigurationManager failed to load configuration")
                    }
                })

            ConsentManager.initialize(applicationContext)
        }

        @JvmStatic
        fun clearConfigurationCache(context: Context?) {
            val storage = SharedPreferencesConfigurationStorage(context)
            storage.removeJsonConfig()
        }

        @JvmStatic
        fun enableDebugMode() {
            ConfigurationManager.enableDebugMode()

        }

        @JvmStatic
        fun enableInspectionMode() {
            ConfigurationManager.enableInspectionMode()
        }

        @JvmStatic
        fun setUserTargeting(targeting: List<String>){
            // For Prebid
            TargetingParams.addUserKeywords(targeting.toSet())

            // For GAM
            GlobalGamManager.adRequestBuilder.addCustomTargeting("user_keyword",targeting)

            // Gravite
            GraviteLoader.getInstance().setCustomTargeting(mapOf("user_keyword" to targeting))
        }

        @JvmStatic
        fun setContextTargeting(targeting: List<String>){

            // For GAM
            GlobalGamManager.adRequestBuilder.addCustomTargeting("context_keyword", targeting)

            // Gravite
            GraviteLoader.getInstance().setCustomTargeting(mapOf("context_keyword" to targeting))
        }

        @JvmStatic
        @Synchronized
        fun setContextDataTargeting(targeting: MutableMap<String, MutableList<String>>) {
            try {
                //val allValues = ArrayList<String>()
                for (key in targeting.keys) {
                    val values = targeting[key]!!
                    // For GAM
                    GlobalGamManager.adRequestBuilder.addCustomTargeting(key, values)

                    // For Prebid -- but PBS doesn't accept this value
                    // OrtbJsonHelper.addOrUpdate(JSONArray(values), "app", "ext", "data", key)
                }

                // For Gravite
                GraviteLoader.getInstance().setCustomTargeting(targeting)
            } catch (e: Exception) {
                Logger.e("[StroeerSDK] Failed to set custom targeting", e)
            }
        }

        @JvmStatic
        @Synchronized
        fun setCustomTargeting(targeting: MutableMap<String, MutableList<String>>) {
            setContextDataTargeting(targeting)
        }
    }
}
