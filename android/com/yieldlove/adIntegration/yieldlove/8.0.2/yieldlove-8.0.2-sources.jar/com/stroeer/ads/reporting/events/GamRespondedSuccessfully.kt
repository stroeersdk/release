package com.stroeer.ads.reporting.events

class GamRespondedSuccessfully : TimeEvent()
