package com.stroeer.plugins.identity.id5.collectors;

import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.stroeer.plugins.identity.ACollectorWithContext;
import com.stroeer.plugins.identity.id5.ID5Constants;

import java.util.concurrent.CompletableFuture;


/**
 * Return iD5 signature
 */
public class SignatureCollector extends ACollectorWithContext<String> {
    @Override
    public CompletableFuture<String> retrieveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
        String signature = sharedPreferences.getString(ID5Constants.getInstance().getPrefId5Signature(), null);
        if(signature == null || signature.isEmpty()) {
            return CompletableFuture.completedFuture(null);
        }
        else {
            return CompletableFuture.completedFuture(signature);
        }
    }
}
