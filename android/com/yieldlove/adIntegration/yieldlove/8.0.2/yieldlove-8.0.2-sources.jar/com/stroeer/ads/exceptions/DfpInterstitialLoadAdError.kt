package com.stroeer.ads.exceptions

import com.google.android.gms.ads.AdError

class DfpInterstitialLoadAdError(val adError: AdError) : StroeerException(){
    override val message: String?
        get() = adError.message
}