package com.stroeer.ads.formats.rewarded

import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.exceptions.StroeerException


interface IStroeerRewardedListener  {
    fun onAdLoaded(rewardedAd: RewardedAd?)
    fun onAdFailedToLoad(exception: StroeerException)
    fun onUserEarnedReward(item: RewardItem?)
}