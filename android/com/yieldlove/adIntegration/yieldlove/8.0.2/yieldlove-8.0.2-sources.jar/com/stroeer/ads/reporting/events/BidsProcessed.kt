package com.stroeer.ads.reporting.events

class BidsProcessed : TimeEvent()
