package com.stroeer.ads.exceptions

class MissingApplicationNameException : RuntimeException("Application name was not set")
