package com.stroeer.utilities.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.stroeer.utilities.logging.Logger

object ToastUtil {
    @JvmStatic
    fun showToast(context: Context, message: String, duration: Int = Toast.LENGTH_SHORT) {
        Logger.d("[ToastUtil] showToast: $message")
        val appCtx = context.applicationContext
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Toast.makeText(appCtx, message, duration).show()
        } else {
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(appCtx, message, duration).show()
            }
        }
    }
}