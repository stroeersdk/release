package com.yieldlove.adIntegration.ExternalConfiguration;

import java.util.HashMap;

public class YieldloveConfig {

    private String privacyManagerId;
    private String propertyName;
    private int propertyId;
    private int sourcepointAccountId;
    private HashMap<String, HashMap<String,String>> consentOverrides = new HashMap<>();
    private Integer dfpAdRequestTimeoutInMs = null;
    private boolean consentIsActive;
    private long syncInterval;
    private AdsSoundSettingStates adsSoundSetting = AdsSoundSettingStates.RESPECT_USER_SOUND_SETTING;
    private String bundleId;

    public HashMap<String, HashMap<String,String>> getConsentOverrides() {
        return this.consentOverrides;
    }

    public AdsSoundSettingStates getAdsSoundSetting() {
        return this.adsSoundSetting;
    }

    public void setAdsSoundSetting(AdsSoundSettingStates adsSoundSetting) {
        this.adsSoundSetting = adsSoundSetting;
    }

    public String getPrivacyManagerId() {
        return this.privacyManagerId;
    }

    public void setPrivacyManagerId(String privacyManagerId) {
        this.privacyManagerId = privacyManagerId;
    }

    public String getPropertyName() {
        return this.propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public int getSourcepointAccountId() {
        return sourcepointAccountId;
    }

    public void setSourcepointAccountId(int sourcepointAccountId) {
        this.sourcepointAccountId = sourcepointAccountId;
    }

    public boolean isConsentActive() {
        return consentIsActive;
    }

    public void setConsentIsActive(boolean consentIsActive) {
        this.consentIsActive = consentIsActive;
    }

    public Integer getDfpAdRequestTimeoutInMs() {
        return this.dfpAdRequestTimeoutInMs;
    }

    public void setDfpAdRequestTimeoutInMs(Integer timeoutInMs) {
        this.dfpAdRequestTimeoutInMs = timeoutInMs;
    }

    public long getSyncInterval() {
        return syncInterval;
    }

    public void setSyncInterval(long syncInterval) {
        this.syncInterval = syncInterval;
    }

    public String getBundleId() {
        return this.bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }
}
