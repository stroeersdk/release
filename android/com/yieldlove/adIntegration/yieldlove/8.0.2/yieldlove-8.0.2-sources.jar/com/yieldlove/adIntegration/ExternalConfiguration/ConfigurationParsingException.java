package com.yieldlove.adIntegration.ExternalConfiguration;

import com.stroeer.ads.exceptions.StroeerException;

public class ConfigurationParsingException extends StroeerException {
    public ConfigurationParsingException(String message) {
        super(message);
    }
}
