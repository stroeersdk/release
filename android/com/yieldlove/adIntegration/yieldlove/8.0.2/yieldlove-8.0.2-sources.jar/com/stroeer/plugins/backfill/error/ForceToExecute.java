package com.stroeer.plugins.backfill.error;

public class ForceToExecute extends Exception {

}
