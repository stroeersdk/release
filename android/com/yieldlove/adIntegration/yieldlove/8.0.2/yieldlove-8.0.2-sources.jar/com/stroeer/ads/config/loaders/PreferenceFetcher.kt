package com.stroeer.ads.config.loaders

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import com.stroeer.ads.config.ConfigConstants.prefsConfig
import androidx.core.content.edit

class PreferenceFetcher(applicationContext: Context) : IFetcher {
    private val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)

    override fun load(appName: String?): String? {
        return sharedPreferences.getString(prefsConfig, null)
    }

    override fun store(json: String?) {
        sharedPreferences.edit { putString(prefsConfig, json) }
    }

    override fun delete() {
        sharedPreferences.edit { remove(prefsConfig) }
    }
}

