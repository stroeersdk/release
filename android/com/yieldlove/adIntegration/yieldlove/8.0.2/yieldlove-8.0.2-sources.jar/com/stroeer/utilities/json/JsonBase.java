package com.stroeer.utilities.json;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.stroeer.utilities.logging.Logger;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Objects;

public class JsonBase <T>{
    @SuppressWarnings("unchecked")
    public String toJson() {
        Type type = (Class<T>) ((ParameterizedType) Objects.requireNonNull(getClass()
                .getGenericSuperclass()))
                .getActualTypeArguments()[0];
        try
        {
            Gson gson = new Gson();
            String json =  gson.toJson(this, type);
            if(json == null || json.equals("null"))
            {
                return null;
            }
            return json;
        }catch(Exception e)
        {
            Logger.e("["+type.getClass().getName()+"] Failed to convert to json", e);
        }
        return null;
    }


    @SuppressWarnings("unchecked")
    public String toPrettyJson(){
        Type type = (Class<T>) ((ParameterizedType) Objects.requireNonNull(getClass()
                .getGenericSuperclass()))
                .getActualTypeArguments()[0];
        try
        {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String json =  gson.toJson(this, type);
            if(json == null || json.equals("null"))
            {
                return null;
            }
            return json;
        }catch(Exception e)
        {
            Logger.e("["+type.getClass().getName()+"] Failed to convert to json", e);
        }
        return null;
    }

    // ✅ Corrected Generic Static Method
    public static <T> T fromJson(String json, Class<T> clazz) {
        try {
            Gson gson = new Gson();
            return gson.fromJson(json, clazz);
        } catch (Exception e) {
            Logger.e("["+clazz.getName()+"] Failed to parse from json", e);
        }
        return null;
    }
}
