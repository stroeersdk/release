package com.yieldlove.adIntegration.ExternalConfiguration;

public enum InventoryStructureSettings {
    STROEER_DIGITAL_INVENTORY("SDI"),
    FLEXIBLE("flexible");

    private String value;

    InventoryStructureSettings(String s) {
        this.value = s;
    }

    public static InventoryStructureSettings parse(String s) {
        return s.equals(InventoryStructureSettings.FLEXIBLE.value) ? InventoryStructureSettings.FLEXIBLE : InventoryStructureSettings.STROEER_DIGITAL_INVENTORY;
    }
}
