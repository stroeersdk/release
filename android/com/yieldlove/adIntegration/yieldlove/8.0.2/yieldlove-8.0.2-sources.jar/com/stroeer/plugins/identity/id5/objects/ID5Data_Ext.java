package com.stroeer.plugins.identity.id5.objects;

/**
 * "ext": {
 *  *         "linkType": 0
 *  *     }
 */
public class ID5Data_Ext {
    public int getLinkType() {
        return linkType;
    }

    public void setLinkType(int linkType) {
        this.linkType = linkType;
    }

    protected int linkType;
}
