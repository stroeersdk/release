package com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects;

import java.util.HashMap;

public class ConfigSourcePointModule {
    public Integer sourcepointAccountId;
    public Boolean active;
    public Integer propertyId;
    public String propertyName;
    public String privacyManagerId;
    public HashMap<String, ConfigSourcePointOverrides> overrides;
}
