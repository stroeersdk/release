package com.stroeer.ads.config.objects

/**
 * "openRtb": {
 * "apis": [
 * {
 * "framework": 3
 * },
 * {
 * "framework": 5
 * },
 * {
 * "framework": 6
 * },
 * {
 * "framework": 7
 * }
 * ]
 */
class ConfigOpenRtb {
    var apis: Array<ConfigApis>? = null

    val framework: Array<Int>?
        get() {
            if (!apis.isNullOrEmpty()){
                val frameworks = Array<Int>(apis!!.size) {0}
                for (i in apis!!.indices) {
                    frameworks[i] = apis!![i].framework
                }
                return frameworks
            }
            return null
        }
}
