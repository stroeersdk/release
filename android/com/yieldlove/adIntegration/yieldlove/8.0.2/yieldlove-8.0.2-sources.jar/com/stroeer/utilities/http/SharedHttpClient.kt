package com.stroeer.utilities.http

import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Shared OkHttpClient instance for efficient resource management.
 *
 * Creating new OkHttpClient instances is expensive as each client maintains
 * its own connection pool, thread pool, and cache. This singleton ensures
 * all HTTP requests share the same underlying resources.
 */
object SharedHttpClient {

    /**
     * Default shared client with standard timeouts and connection pooling.
     * Reuses connections for better performance and resource efficiency.
     */
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectionPool(ConnectionPool(5, 5, TimeUnit.MINUTES))
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .writeTimeout(5, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Creates a customized client based on the shared client.
     * Use this when you need different timeouts while still sharing
     * the connection pool and thread pool.
     *
     * @param timeoutSecs timeout in seconds for all operations
     * @return OkHttpClient with custom timeout
     */
    fun createClientWithTimeout(timeoutSecs: Int): OkHttpClient {
        return client.newBuilder()
            .callTimeout(timeoutSecs.toLong(), TimeUnit.SECONDS)
            .connectTimeout(timeoutSecs.toLong(), TimeUnit.SECONDS)
            .readTimeout(timeoutSecs.toLong(), TimeUnit.SECONDS)
            .writeTimeout(timeoutSecs.toLong(), TimeUnit.SECONDS)
            .build()
    }
}
