package com.stroeer.ads.reporting.events

class BannerRefreshStarted : TimeEvent()
