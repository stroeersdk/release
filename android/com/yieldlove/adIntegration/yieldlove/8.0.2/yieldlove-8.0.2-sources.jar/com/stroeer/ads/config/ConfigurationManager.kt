package com.stroeer.ads.config

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebView
import com.google.gson.GsonBuilder
import com.stroeer.ads.config.loaders.ConfigHttpFetcher
import com.stroeer.ads.config.loaders.IFetcher
import com.stroeer.ads.config.loaders.PreferenceFetcher
import com.stroeer.ads.config.objects.Configuration
import com.stroeer.ads.config.objects.Configuration.Companion.fromJson
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException
import com.stroeer.utilities.logging.Logger
import com.yieldlove.adIntegration.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Mutex
import org.jetbrains.annotations.TestOnly
import org.json.JSONObject
import org.prebid.mobile.LogUtil
import org.prebid.mobile.PrebidMobile
import java.util.Date

class ConfigurationManager private constructor() {
    companion object {
        @SuppressLint("StaticFieldLeak")
        @Volatile private var instance: ConfigurationManager? = null

        /**
         * Timestamp value indicating configuration is loaded from cache (stale)
         * Set to 1ms after Unix epoch to ensure needsRefresh() returns true
         */
        private const val STALE_CONFIG_TIMESTAMP = 1L

        @JvmStatic
        fun getInstance(): ConfigurationManager {
            // Fast path: return existing instance if available
            if (instance != null) {
                return instance!!
            }
            // Slow path: synchronize and create
            synchronized(this) {
                if (instance == null) {
                    instance = ConfigurationManager()
                }
                return instance!!
            }
        }

        @TestOnly
        @JvmStatic
        fun setInstance(newInstance: ConfigurationManager) {
            instance = newInstance
        }

        @JvmStatic var isInspectionMode = false
        @JvmStatic var isDebugMode = false
        @JvmStatic fun enableInspectionMode() { Logger.e("[ConfigurationManager] inspection mode enabled"); isInspectionMode = true; enableDebugMode()}
        @JvmStatic fun enableDebugMode() {
            Logger.e("[ConfigurationManager] debug mode enabled")
            isDebugMode = true
            Logger.enableDebugMode()
            PrebidMobile.setLogLevel(PrebidMobile.LogLevel.DEBUG)
            WebView.setWebContentsDebuggingEnabled(true)
            LogUtil.setLogLevel(LogUtil.DEBUG)
        }
        @JvmStatic val version get() = "${BuildConfig.VERSION_NAME}.${BuildConfig.VERSION_CODE} (${BuildConfig.BUILD_TYPE})"

        @JvmStatic val isDebugBuild get() = BuildConfig.DEBUG

        /**
         * This flag will ignore the memory leak from Views like AdManagerView / PrebidBannerView
         * This is because each SDK uses their own memory cache management to optimize the memory and the SDKs will destroy their views later.
         * This leads the canary to detect the memory leak, which may annoy the publishers.
         * If you want to see actual memory leak from the SDKs, set false
         */
        @JvmStatic var ignoreAdViewMemoryLeaked = true
    }

    var applicationContext: Context? = null
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var appName: String? = null
    val applicationName
        get() = appName ?: ""

    private var httpFetcher: IFetcher? = null
    private var preferenceFetcher: IFetcher? = null

    // Thread-safe configuration state
    @Volatile private var config: Configuration? = null
    @Volatile private var lastUpdated: Long = 0
    private val configLock = Any()
    private val reloadMutex = Mutex()

    // Thread-safe property access
    val requestTimeout: Long
        get() = synchronized(configLock) {
            (config?.common?.dfpAdRequestTimeoutMs ?: (ConfigConstants.CONFIG_TIMEOUT_MS * 2)).toLong()
        }

    private val updateInterval: Int
        get() = synchronized(configLock) {
            if(isDebugMode){
                return 300000 // 5 minutes in debug mode
            }
            config?.common?.updateIntervalMs ?: 900000
        }

    @TestOnly
    fun setConfigName(name: String){
        this.appName = name
    }

    @JvmOverloads
    fun initialize(applicationContext: Context, appName: String, listener: IConfigurationListener? = null,
                   httpFetcher: IFetcher = ConfigHttpFetcher(),
                   preferenceFetcher: IFetcher = PreferenceFetcher(applicationContext)) {
        if (appName.isEmpty()) {
            Logger.e("[ConfigurationManager] appName empty")
            listener?.onFailed()
            return
        }

        this.applicationContext = applicationContext
        this.appName = appName
        this.httpFetcher = httpFetcher
        this.preferenceFetcher = preferenceFetcher

        // Launch reload with listener callback
        mainScope.launch {
            try {
                val success = reload()
                if (success) {
                    displayConfiguration()
                    listener?.onSuccess()
                } else {
                    listener?.onFailed()
                }
            } catch (e: Exception) {
                Logger.e("[ConfigurationManager] initialize failed", e)
                listener?.onFailed()
            }
        }
    }

    fun getConfig(): Configuration? {
        reloadNForget()
        return synchronized(configLock) { config }
    }

    suspend fun getConfigAsync(timeoutMs: Long = ConfigConstants.CONFIG_TIMEOUT_MS): Configuration? {
        val currentConfig = synchronized(configLock) { config }

        if(currentConfig != null){
            // just checking is there any update in background
            reloadNForget()
            return currentConfig
        }

        return withTimeoutOrNull(timeoutMs) {
            val success = reload()
            if (success) {
                synchronized(configLock) { config }
            } else {
                null
            }
        }
    }

    private fun reloadNForget(){
        mainScope.launch {
            reload()
        }
    }

    fun loadFromJson(json: String) {
        Logger.i("[ConfigurationManager] loadFromJson")
        synchronized(configLock) {
            config = fromJson(json)
            lastUpdated = Date().time
        }
    }

    fun reset() {
        Logger.i("[ConfigurationManager] reset")
        preferenceFetcher?.delete()
        synchronized(configLock) {
            config = null
            lastUpdated = 0
        }
    }

    fun resetInstance() {
        Logger.e("[ConfigurationManager] instance reset")
        synchronized(Companion) {
            // Cancel all running coroutines from the old instance
            instance?.mainScope?.cancel()
            instance = ConfigurationManager()
        }
    }

    val isLoaded: Boolean
        get() = synchronized(configLock) { config != null }

    /**
     * Check if the current configuration is stale (needs refresh).
     * @return true if config should be refreshed, false if current config is fresh
     */
    val isConfigStale: Boolean
        get() = needsRefresh()

    /**
     * Get the age of the current configuration in milliseconds.
     * @return milliseconds since last update, or -1 if never loaded
     */
    fun getConfigAgeMs(): Long {
        return synchronized(configLock) {
            if (lastUpdated == 0L) -1L
            else System.currentTimeMillis() - lastUpdated
        }
    }

    fun ensureValid() {
        synchronized(configLock) {
            if (config == null && appName.isNullOrEmpty()) throw ConfigurationIsNotLoadedException()
        }
    }

    private fun needsRefresh() : Boolean {
        return synchronized(configLock) {
            lastUpdated == 0L || System.currentTimeMillis() - lastUpdated > updateInterval
        }
    }

    private suspend fun reload(maxRetries: Int = 2) : Boolean {

        val owner = Any()
        val acquired = withTimeoutOrNull(ConfigConstants.CONFIG_TIMEOUT_MS * 2) { reloadMutex.lock(owner) } != null

        try {
            if(!acquired) {
                Logger.e("[ConfigurationManager] timeout waiting for another load to finish")
                return false
            }

            val app = appName
            if (app.isNullOrEmpty()) {
                Logger.e("[ConfigurationManager] appName is null")
                return false
            }

            if (!needsRefresh()) {
                return true
            }

            Logger.d("[ConfigurationManager] starting refresh (lastUpdated: $lastUpdated, updateInterval: $updateInterval, age: ${System.currentTimeMillis() - lastUpdated}ms)")

            return withContext(Dispatchers.IO) {
                // Step 1: Try to load from cache first if config is not already loaded
                val currentConfig = synchronized(configLock) { config }
                var loadedFromCache = false

                if (currentConfig == null) {
                    val cacheLoaded = runCatching {
                        val cachedRaw = preferenceFetcher?.load(app)
                        if (cachedRaw != null) {
                            val cachedConfig = fromJson(cachedRaw)
                            if (cachedConfig != null) {
                                Logger.i("[ConfigurationManager] loaded from cached configuration")

                                // Load cached config but don't update lastUpdated to indicate it's stale
                                synchronized(configLock) {
                                    config = cachedConfig
                                    // Set to stale timestamp to trigger background refresh
                                    lastUpdated = STALE_CONFIG_TIMESTAMP
                                }
                                true
                            } else {
                                Logger.w("[ConfigurationManager] cached configuration is invalid")
                                false
                            }
                        } else {
                            Logger.i("[ConfigurationManager] no cached configuration available")
                            false
                        }
                    }.onFailure { error ->
                        Logger.e("[ConfigurationManager] failed to load cached configuration", error)
                    }.getOrDefault(false)

                    loadedFromCache = cacheLoaded
                }

                // Step 2: Try to load from network to get fresh config
                var lastError: Throwable? = null
                var networkSuccess = false

                repeat(maxRetries) { attempt ->
                    if (networkSuccess) return@repeat

                    networkSuccess = runCatching {
                        val raw = httpFetcher?.load(app) ?: error("Failed to load configuration: config data is null")

                        // Store in SharedPreferences
                        preferenceFetcher?.store(raw)

                        val newConfig = fromJson(raw)
                        val now = Date().time

                        // Atomically update both config and lastUpdated together
                        synchronized(configLock) {
                            config = newConfig
                            lastUpdated = now
                        }
                        Logger.i("[ConfigurationManager] loaded configuration from network")
                        true
                    }.onFailure { error ->
                        lastError = error
                        Logger.e("[ConfigurationManager] network load error (attempt ${attempt + 1}/$maxRetries)", error)

                        // Wait before retrying (exponential backoff)
                        if (attempt < maxRetries - 1) {
                            delay(1000L * (attempt + 1))
                        }
                    }.getOrDefault(false)
                }

                // Step 3: Determine overall success
                if (networkSuccess) {
                    return@withContext true
                }

                // Network failed - check if we have cache loaded or already have config in memory
                Logger.e("[ConfigurationManager] network fetch failed after $maxRetries attempts", lastError)

                if (loadedFromCache) {
                    Logger.i("[ConfigurationManager] using cached configuration due to network failure")
                    return@withContext true
                }

                val hasConfig = synchronized(configLock) { config != null }
                if (hasConfig) {
                    Logger.i("[ConfigurationManager] using existing configuration due to network failure")
                    return@withContext true
                }

                Logger.e("[ConfigurationManager] configuration load failed - no cache and network unavailable")
                false
            }
        }finally {
            if(acquired) {
                reloadMutex.unlock(owner)
            }
        }
    }

    override fun toString(): String {
        return synchronized(configLock) {
            config?.let { JSONObject(GsonBuilder().create().toJson(it)).toString(2) }
                ?: "Configuration not loaded"
        }
    }

    fun displayConfiguration(){
        Logger.i("""[ConfigurationManager] Configuration Settings Loaded
                       SDK Version : $version
                       ApplicationName : $applicationName
                       Ad Request Timeout(ms) : $requestTimeout
                       Configuration Update Interval(ms) : $updateInterval 
                       Ignore AdView Memory Leak : $ignoreAdViewMemoryLeaked            
        """)
    }
}