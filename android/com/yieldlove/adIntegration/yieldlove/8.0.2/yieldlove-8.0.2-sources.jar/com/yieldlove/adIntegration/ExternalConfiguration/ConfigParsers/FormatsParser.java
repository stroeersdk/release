package com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers;

import com.google.android.gms.ads.AdSize;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigCustomAdSize;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigFormat;

import java.util.ArrayList;
import java.util.Arrays;

public class FormatsParser {

    private final JsonObject parsedJson;

    public FormatsParser(JsonObject json) {
        this.parsedJson = json;
    }

    public void addSizesFromAdFormats(String slot, ArrayList<AdSize> sizes) {
        JsonObject formats = this.getFormats();

        for (String name : formats.keySet()) {
            Gson gson = new Gson();
            ConfigFormat adFormat = gson.fromJson(formats.get(name), ConfigFormat.class);
            if (adFormat != null) {
                addSizesIfFormatIsActiveAndAvailableForAdSlot(slot, sizes, adFormat);
            }
        }
    }

    private JsonObject getFormats() {
        return this.parsedJson.getAsJsonObject("formats");
    }

    private void addSizesIfFormatIsActiveAndAvailableForAdSlot(String slot, ArrayList<AdSize> sizes, ConfigFormat adFormat) {
        if (adFormat.active) {
            boolean isAvailable = Arrays.asList(adFormat.availableOn).contains(slot);
            if (isAvailable) {
                sizes.addAll(this.getAllSizesFromAdFormat(adFormat));
            }
        }
    }

    private ArrayList<AdSize> getAllSizesFromAdFormat(ConfigFormat adFormat) {
        ArrayList<AdSize> sizes = new ArrayList<>();

        sizes.addAll(this.getAllAndroidSizes(adFormat));
        sizes.addAll(this.getAllCustomSizes(adFormat));

        return sizes;
    }

    private ArrayList<AdSize> getAllAndroidSizes(ConfigFormat adFormat) {
        ArrayList<AdSize> sizes = new ArrayList<>();

        if (adFormat.dfpSizes.androidAdSizes != null) {
            for (String androidSize : adFormat.dfpSizes.androidAdSizes) {
                sizes.add(getBannerSize(androidSize));
            }
        }
        return sizes;
    }

    private ArrayList<AdSize> getAllCustomSizes(ConfigFormat adFormat) {
        ArrayList<AdSize> sizes = new ArrayList<>();

        if (adFormat.dfpSizes.customAdSizes != null) {
            for (ConfigCustomAdSize customAdSize : adFormat.dfpSizes.customAdSizes) {
                sizes.add(new AdSize(customAdSize.w, customAdSize.h));
            }
        }
        return sizes;
    }

    private AdSize getBannerSize(String androidSize) {
        return switch (androidSize) {
            case "BANNER" -> AdSize.BANNER;
            case "LARGE_BANNER" -> AdSize.LARGE_BANNER;
            case "FULL_BANNER" -> AdSize.FULL_BANNER;
            case "MEDIUM_RECTANGLE" -> AdSize.MEDIUM_RECTANGLE;
            case "LEADERBOARD" -> AdSize.LEADERBOARD;
            case "WIDE_SKYSCRAPER" -> AdSize.WIDE_SKYSCRAPER;
            case "FLUID" -> AdSize.FLUID;
            default -> null;
        };
    }

}
