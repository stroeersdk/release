package com.stroeer.ads.formats.banner.refresh

interface IRefreshListener {
    fun handleRefresh()
}
