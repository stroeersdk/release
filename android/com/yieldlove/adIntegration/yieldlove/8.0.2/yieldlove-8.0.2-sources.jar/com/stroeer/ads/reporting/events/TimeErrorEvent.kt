package com.stroeer.ads.reporting.events

import com.google.gson.JsonObject
import com.stroeer.utilities.logging.Logger
import java.io.PrintWriter
import java.io.StringWriter

open class TimeErrorEvent(var error: Exception?) : TimeEvent() {
    override fun toJsonObject(): JsonObject {
        val jsonObject = super.toJsonObject()
        try {
            if(error != null) {
                val jsonError = JsonObject()
                jsonError.addProperty("message", error!!.message)
                jsonError.addProperty("type", error!!.javaClass.getSimpleName())
                jsonError.addProperty("stackTrace", this.stackTrace)

                jsonObject.add("error", jsonError)
            }
            else{
                jsonObject.addProperty("error", "empty error is delivered")
            }

        } catch (e: Exception) {
            Logger.e("[TimeErrorEvent] Error while creating JSON object from error event", e)
        }

        return jsonObject
    }

    protected val stackTrace: String
        get() {
            val sw = StringWriter()
            val pw = PrintWriter(sw)
            error?.printStackTrace(pw)
            return sw.toString()
        }
}
