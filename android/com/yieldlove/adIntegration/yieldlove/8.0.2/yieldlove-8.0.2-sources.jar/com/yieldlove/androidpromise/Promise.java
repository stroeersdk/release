package com.yieldlove.androidpromise;

import java.util.ArrayList;

public class Promise<T> {

    private PromiseCallback thenCallback;
    private ExceptionCallback errorCallback;
    private T result;
    private Throwable exeption;
    private PromiseState state;
    private Promise child;

    public static Promise<Void> resolveVoid() {
        return new Promise<>((StartCallback<Void>) Promise::resolve);
    }

    public static <T> Promise<T> resolveValue(T value) {
        return new Promise<>(promise -> {
            promise.resolve(value);
        });
    }

    public static <T> Promise<T> resolveValue(StartCallback<T> callback) {
        return new Promise<>(callback);
    }

    public static <T> Promise<T> resolveValue(StartCallbackWithoutPromise<T> callback) {
        return resolveValue(promise -> promise.resolve(callback.run()));
    }

    public static <T> Promise<Promise<T>[]> all(Promise<T>[] promises) {
        return new Promise<>(promise -> {
            for (Promise<T> p : promises) {
                p.done((T result) -> checkStatusAndResolve(promises, promise));
                p.fail(e -> checkStatusAndResolve(promises, promise));
            }
        });
    }

    public static <T, R> Promise<R>[] map(T[] array, ForEachConsumer<T, R> callback) {
        ArrayList<Promise<R>> promises = new ArrayList<>();
        for (T value : array) {
            promises.add(callback.run(value));
        }

        return (Promise<R>[]) promises.toArray(new Promise[0]);
    }

    public Promise(StartCallback<T> callback) {
        this.init(callback);
        this.run(null);
    }

    public Promise(VoidInVoidOutCallback voidCallback) {
        this.init(voidCallback);
    }

    public <T_PREV, T_NEW> Promise(ThenCallback<T_PREV, T_NEW> callback) {
        this.init(callback);
    }

    public <T_PREV, T_NEW> Promise(ThenCallbackWithoutPromise<T_PREV, T_NEW> thenCallback) {
        this.init((ThenCallback<T_PREV, T_NEW>) (result, promise) -> {
            try {
                promise.resolve(thenCallback.run(result));
            } catch (Exception e) {
                promise.reject(e);
            }
        });
    }

    public Promise(VoidCallback<T> callback) {
        this.init(callback);
    }

    public Promise<T> done(VoidCallback<T> thenCallback) {
        return this.then(new Promise<>(thenCallback));
    }

    public Promise<Void> done(VoidInVoidOutCallback voidCallback) {
        return this.then(new Promise<>(voidCallback));
    }

    public Promise<T> done(VoidCallbackWithoutPromise<T> thenCallback) {
        return this.then(new Promise<>((VoidCallback<T>) (result, promise) -> {
            try {
                thenCallback.run(result);
                promise.resolve(result);
            } catch (Exception exception) {
                promise.reject(exception);
            }
        }));
    }

    public Promise<Void> then(VoidInVoidOutCallback callback) {
        return this.then(new Promise<>(
                (ThenCallback<T, Void>) (result, promise) -> {
                    try {
                        callback.run();
                        promise.resolve(null);
                    } catch (Exception e) {
                        promise.reject(e);
                    }
                }
        ));
    }

    public <T_NEW> Promise<T_NEW> then(PromiseInPromiseVoidCallback<T_NEW> voidCallback) {
        return this.then((PromiseInPromiseCallback<T, T_NEW>) (Void) -> voidCallback.run());
    }

    public <T_NEW> Promise<T_NEW> then(PromiseInPromiseCallback<T, T_NEW> thenCallback) {
        return this.then(new Promise<>(
                (ThenCallback<T, T_NEW>) (result, promise) ->
                        thenCallback.run(result)
                                .done((VoidCallbackWithoutPromise<T_NEW>) promise::resolve)
                                .fail(promise::reject)
        ));
    }

    public <T_NEW> Promise<T_NEW> then(ThenCallback<T, T_NEW> thenCallback) {
        return this.then(new Promise<>(thenCallback));
    }

    public <T_NEW> Promise<T_NEW> then(ThenCallbackWithoutPromise<T, T_NEW> thenCallback) {
        return this.then(new Promise<>((ThenCallback<T, T_NEW>) (result, promise) -> {
            try {
                promise.resolve(thenCallback.run(result));
            } catch (Exception exception) {
                promise.reject(exception);
            }
        }));
    }

    public <T_NEW> Promise<T_NEW> then(Promise<T_NEW> newPromise) {
        this.child = newPromise;
        this.continueInChain();

        return this.child;
    }

    public Promise<Void> then(VoidCallbackWithoutPromise<T> thenCallback) {
        return this.then(new Promise<>((ThenCallback<T, Void>) (result, promise) -> {
            try {
                thenCallback.run(result);
                promise.resolve();
            } catch (Exception exception) {
                promise.reject(exception);
            }
        }));
    }

    public <E extends Throwable> void fail(ExceptionCallback<E> errorCallback) {
        this.errorCallback = errorCallback;
        this.invokeFail();
    }

    public void resolve() {
        this.resolve(null);
    }

    public void resolve(T result) {
        this.result = result;
        this.setState(PromiseState.Finished);
        this.invokeThen();
    }

    public void reject(Throwable exception) {
        this.throwException(exception);
    }

    public void setResult(T result) {
        this.result = result;
    }

    private void setState(PromiseState state) {
        if (this.state != PromiseState.Finished) {
            this.state = state;
        }
    }

    private void throwException(Throwable exeption) {
        this.exeption = exeption;
        this.state = PromiseState.Failed;
        this.invokeFail();
    }

    private void init(PromiseCallback callback) {
        this.thenCallback = callback;
        this.setState(PromiseState.Initialized);
    }

    private void run(Object resultFromPrev) {
        this.setState(PromiseState.Running);
        try {
            if (this.thenCallback != null) {
                if (this.thenCallback instanceof VoidCallback) {
                    ((VoidCallback) this.thenCallback).run(resultFromPrev, this);
                } else if (this.thenCallback instanceof ThenCallback) {
                    ((ThenCallback) this.thenCallback).run(resultFromPrev, this);
                } else if (this.thenCallback instanceof StartCallback) {
                    ((StartCallback) this.thenCallback).run(this);
                } else if (this.thenCallback instanceof PromiseInPromiseCallback) {
                    ((PromiseInPromiseCallback) this.thenCallback).run(resultFromPrev);
                }
            }
        } catch (Exception ex) {
            this.reject(ex);
        }
    }

    private void continueInChain() {
        if (this.state == PromiseState.Failed) {
            this.invokeFail();
        } else {
            this.invokeThen();
        }
    }

    private void invokeFail() {
        if (this.state == PromiseState.Failed) {
            if (this.errorCallback != null) {
                this.errorCallback.fail(this.exeption);
            } else if (this.child != null) {
                this.child.throwException(this.exeption);
            }
        }
    }

    private void invokeThen() {
        if (this.state == PromiseState.Finished && this.child != null) {
            this.child.run(this.result);
        }
    }

    private static <T> void checkStatusAndResolve(Promise<T>[] promises, Promise<Promise<T>[]> promise) {
        boolean done = true;
        for (Promise<T> pp : promises) {
            if (pp.state == PromiseState.Running || pp.state == PromiseState.Initialized) {
                done = false;
                break;
            }
        }
        if (done) {
            promise.resolve(promises);
        }
    }

    public T getResult() {
        return this.result;
    }

    enum PromiseState {
        Initialized,
        Running,
        Finished,
        Failed
    }
}

