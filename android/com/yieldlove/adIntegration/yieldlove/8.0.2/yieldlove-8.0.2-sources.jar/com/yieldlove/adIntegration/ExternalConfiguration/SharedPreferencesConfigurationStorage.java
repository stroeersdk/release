package com.yieldlove.adIntegration.ExternalConfiguration;

import android.content.Context;
import android.content.SharedPreferences;

import com.yieldlove.adIntegration.Configuration;

public class SharedPreferencesConfigurationStorage implements ConfigurationStorage {

    private final Context context;
    private final SharedPreferences sharedPreferences;

    public SharedPreferencesConfigurationStorage(Context context) {
        this.context = context;
        this.sharedPreferences = this.getSharedPreferences();
    }

    public String getJsonConfig() {
        return this.sharedPreferences.getString(Configuration.getExternalConfigContentKey(), null);
    }

    public void storeJsonConfig(String json) {
        long currentTime = System.currentTimeMillis();
        this.sharedPreferences.edit()
                .putString(Configuration.getExternalConfigContentKey(), json)
                .putLong(Configuration.getExternalConfigLastFetchInMillisKey(), currentTime)
                .apply();
    }

    public long getLastStorageUpdateTime() {
        return this.sharedPreferences.getLong(Configuration.getExternalConfigLastFetchInMillisKey(), 0);
    }

    public void removeJsonConfig() {
        this.sharedPreferences.edit()
                .remove(Configuration.getExternalConfigContentKey())
                .apply();
    }

    private SharedPreferences getSharedPreferences() {
        return this.context.getSharedPreferences(
                Configuration.getExternalConfigSharedPrefsFileKey(), Context.MODE_PRIVATE);
    }
}
