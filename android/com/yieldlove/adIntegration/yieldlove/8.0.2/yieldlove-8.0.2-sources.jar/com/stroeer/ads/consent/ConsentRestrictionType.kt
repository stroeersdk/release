package com.stroeer.ads.consent

enum class ConsentRestrictionType {
    NOT_ALLOWED,
    REQUIRE_CONSENT,
    REQUIRE_LEGITIMATE_INTEREST,
    UNDEFINED;

    companion object {
        @JvmStatic
        fun from(id: Int): ConsentRestrictionType {
            return when (id) {
                1 -> ConsentRestrictionType.REQUIRE_CONSENT
                2 -> ConsentRestrictionType.REQUIRE_LEGITIMATE_INTEREST
                3 -> ConsentRestrictionType.UNDEFINED
                else -> ConsentRestrictionType.NOT_ALLOWED
            }
        }
    }
}

