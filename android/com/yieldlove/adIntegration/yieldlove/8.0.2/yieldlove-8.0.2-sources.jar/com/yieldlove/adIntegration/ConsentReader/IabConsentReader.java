package com.yieldlove.adIntegration.ConsentReader;

import static com.yieldlove.adIntegration.ConsentReader.IabConstants.IABTCF_PublisherRestrictionsId_ReplaceHolder;
import static com.yieldlove.adIntegration.ConsentReader.IabConstants.IABTCF_PublisherRestrictionsKEY_Pattern;
import static com.yieldlove.adIntegration.ConsentReader.IabConstants.IABTCF_PurposeConsents_KEY;
import static com.yieldlove.adIntegration.ConsentReader.IabConstants.IABTCF_PurposeLIConsents_KEY;
import static com.yieldlove.adIntegration.ConsentReader.IabConstants.IABTCF_TCString_KEY;
import static com.yieldlove.adIntegration.ConsentReader.IabConstants.IABTCF_VendorConsents_KEY;
import static com.yieldlove.adIntegration.ConsentReader.IabConstants.IABTCF_VendorLIConsents_KEY;

import android.content.Context;
import androidx.preference.PreferenceManager;

public class IabConsentReader implements ConsentReader {

    // see IABTCF strings
    // in https://github.com/InteractiveAdvertisingBureau/GDPR-Transparency-and-Consent-Framework/blob/master/TCFv2/IAB%20Tech%20Lab%20-%20CMP%20API%20v2.md#in-app-details
    private final Context context;

    public IabConsentReader(Context context) {
        this.context = context;
    }

    public String getVendorConsents() {
        return this.getBinaryStringFromSharedPreferences(IABTCF_VendorConsents_KEY);
    }

    public String getPurposeConsents() {
        return this.getBinaryStringFromSharedPreferences(IABTCF_PurposeConsents_KEY);
    }

    public String getVendorLIConsents() {
        return this.getBinaryStringFromSharedPreferences(IABTCF_VendorLIConsents_KEY);
    }

    public String getPurposeLIConsents() {
        return this.getBinaryStringFromSharedPreferences(IABTCF_PurposeLIConsents_KEY);
    }

    public String getPublisherRestrictionsFor(int purposeId) {
        return this.getPublisherRestrictionsFromSharedpreferences(purposeId);
    }

    public String getTCString() {
        return this.getBinaryStringFromSharedPreferences(IABTCF_TCString_KEY);
    }

    private String getPublisherRestrictionsFromSharedpreferences(int purposeId) {
        return PreferenceManager.getDefaultSharedPreferences(context).getString(this.getPurposeRestrictionKey(purposeId), "");
    }
    private String getBinaryStringFromSharedPreferences(String keyName) {
        return PreferenceManager.getDefaultSharedPreferences(context).getString(keyName, "");
    }

    private String getPurposeRestrictionKey(Integer purposeId) {
        return IABTCF_PublisherRestrictionsKEY_Pattern.replace(IABTCF_PublisherRestrictionsId_ReplaceHolder, purposeId.toString());
    }
}
