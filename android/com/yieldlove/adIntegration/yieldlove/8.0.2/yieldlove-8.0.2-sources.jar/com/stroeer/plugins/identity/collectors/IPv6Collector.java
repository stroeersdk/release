package com.stroeer.plugins.identity.collectors;

import android.content.Context;

import com.stroeer.utilities.logging.Logger;

import java.util.concurrent.CompletableFuture;

/*
    * Return IPv6 address
 */
public class IPv6Collector extends IPv4Collector {

    protected final String checkURL = "https://api64.ipify.org";

    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.supplyAsync(() -> {
            CompletableFuture<String> publicIp = getPublicIPAddress(checkURL);
            CompletableFuture<String> localIp = getIPAddress(applicationContext);

            CompletableFuture.allOf(publicIp, localIp).join();

            try {
                String pIp = publicIp.get();
                String lIp = localIp.get();

                if (pIp != null && !pIp.isEmpty() && isIPv6Format(pIp)) {
                    return pIp;
                } else if (lIp != null && !lIp.isEmpty() && isIPv6Format(lIp)) {
                    return lIp;
                }
            } catch (Exception e) {
                Logger.e("[IPv6Collector] Failed to get IP addresses", e);
            }
            return null;
        }).exceptionally(e -> {
            Logger.e("[IPv6Collector] Failed to get IP addresses", e);
            return null;
        });
    }

    @Override
    protected String getWifiIPAddress(Context context) {
        return getNetworkIPAddress(context, true);
    }

    @Override
    protected String getMobileIPAddress() {
        return getNetworkIPAddress(null, true);
    }

    public static boolean isIPv6Format(String ip) {
        return ip.matches("([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}");
    }
}
