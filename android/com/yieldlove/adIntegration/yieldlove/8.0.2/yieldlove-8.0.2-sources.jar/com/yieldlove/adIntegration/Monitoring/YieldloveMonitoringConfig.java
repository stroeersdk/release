package com.yieldlove.adIntegration.Monitoring;

public class YieldloveMonitoringConfig implements MonitoringConfig {
    private final Boolean active;
    private final Integer frequency;
    private final Integer sendingIntervalInMs;
    private final Integer maxSessionsForSending;

    public YieldloveMonitoringConfig(Boolean active, Integer frequency, Integer sendingIntervalInMs, Integer maxSessionsForSending) {
        this.active = active;
        this.frequency = frequency;
        this.maxSessionsForSending = maxSessionsForSending;
        this.sendingIntervalInMs = sendingIntervalInMs;
    }

    @Override
    public Boolean isMonitoringActive() {
        return this.active;
    }

    @Override
    public Integer getFrequency() {
        return this.frequency;
    }

    @Override
    public Integer getSendingIntervalInMs() {
        return this.sendingIntervalInMs;
    }

    @Override
    public Integer getMaxSessionsForSending() {
        return this.maxSessionsForSending;
    }
}
