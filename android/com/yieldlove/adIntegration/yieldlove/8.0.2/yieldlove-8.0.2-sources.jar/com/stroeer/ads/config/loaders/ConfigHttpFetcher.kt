package com.stroeer.ads.config.loaders

import com.stroeer.ads.config.ConfigConstants.applicationNamePlaceholder
import com.stroeer.ads.config.ConfigConstants.CONFIG_TIMEOUT
import com.stroeer.ads.config.ConfigConstants.configUrl
import com.stroeer.utilities.json.HttpJsonRequest
import com.stroeer.utilities.logging.Logger

class ConfigHttpFetcher : IFetcher {
    private var overwriteTimeout = 0

    fun setTimeout(seconds: Int) {
        overwriteTimeout = seconds
    }

    override fun load(appName: String?): String? {
        var trimedAppName: String? = null
        if (appName == null || (appName.trim { it <= ' ' }.also { trimedAppName = it }).isEmpty()) {
            Logger.e("[Configuration-HttpFetcher] Invalid app name")
            return null
        }

        val url = configUrl.replace(applicationNamePlaceholder, trimedAppName!!)
        val httpJsonRequest = HttpJsonRequest()
        val timeout = if (overwriteTimeout > 0) overwriteTimeout else CONFIG_TIMEOUT
        return httpJsonRequest.sendGetJson(url, null, timeout, this.javaClass)
    }

    override fun store(json: String?) {
        // Nothing to do here
    }

    override fun delete() {
        // Nothing to do here
    }
}
