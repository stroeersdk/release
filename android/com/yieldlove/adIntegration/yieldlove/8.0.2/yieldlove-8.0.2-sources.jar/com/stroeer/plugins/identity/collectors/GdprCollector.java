package com.stroeer.plugins.identity.collectors;

import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.concurrent.CompletableFuture;

/**
 * Return 1 if GDPR consent is given, 0 otherwise
 */
public class GdprCollector extends ACollectorWithContext<Integer> {

    @Override
    public CompletableFuture<Integer> retrieveData() {
        String consentString = new GdprConsentCollector().retrieveData().join();
        return CompletableFuture.completedFuture(consentString == null || consentString.isEmpty() ? null : 1);
    }
}
