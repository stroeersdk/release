package com.yieldlove.adIntegration.ExternalConfiguration;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigCommon;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers.CommonParser;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers.ModuleParser;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers.AdUnitParser;
import com.yieldlove.adIntegration.Monitoring.MonitoringConfig;
import com.yieldlove.adIntegration.Monitoring.MonitoringConfigParser;
import com.stroeer.ads.exceptions.StroeerException;

import java.util.HashMap;

public class ConfigParser {
    private final JsonObject parsedJson;

    private final ConfigCommon common;
    private final ModuleParser moduleParser;

    private ConfigParser(String originalJson) throws ConfigurationParsingException {
        throwExceptionIfJsonIsNull(originalJson);
        try {
            this.parsedJson = JsonParser.parseString(originalJson).getAsJsonObject();
            moduleParser = new ModuleParser(this.parsedJson);
            this.common =  new CommonParser(this.parsedJson).getCommon();
        }catch (Exception e){
            ConfigParser.throwExceptionIfJsonIsInvalid(originalJson, e);
            throw new ConfigurationParsingException(e.getMessage());
        }
    }

    public static YieldloveConfig parse(String json) throws StroeerException {
        ConfigParser parser = new ConfigParser(json);
        return parser.CreateConfig();
    }

    public static YieldloveAdUnitData parseAdUnit(String adSlotName, String originalJson) throws StroeerException {
        ConfigParser parser = new ConfigParser(originalJson);
        return parser.getAdUnit(adSlotName);
    }

    public static HashMap<String, String> parseModuleSettings(String jsonString, String moduleName) throws ConfigurationParsingException {
        ConfigParser parser = new ConfigParser(jsonString);
        return parser.parseModule(moduleName);
    }

    public static MonitoringConfig parseMonitoring(String json) {

        JsonObject parsedJson = JsonParser.parseString(json).getAsJsonObject();
        JsonObject monitoring = parsedJson.getAsJsonObject("monitoring");

        return MonitoringConfigParser.parse(monitoring);
    }

    private static void throwExceptionIfJsonIsNull(String json) throws ConfigurationParsingException {
        if (json == null) {
            throw new ConfigurationParsingException("Configuration json is null");
        }
    }

    private static void throwExceptionIfJsonIsInvalid(String json, Exception e) throws ConfigurationParsingException {
        if (e instanceof JsonParseException) {
            throw new ConfigurationParsingException("The configuration json returned from the server is invalid: " + json);
        }
    }

    private HashMap<String, String> parseModule(String moduleName){
        return this.moduleParser.parseModule(moduleName);
    }

    private YieldloveConfig CreateConfig() throws StroeerException {
        try{
            YieldloveConfig config = new YieldloveConfig();
            this.moduleParser.setSourcepointConfig(config);
            this.setSyncInterval(config);
            this.setSoundSetting(config);
            return config;
        }catch (Exception e){
            throw new StroeerException(e.getMessage());
        }
    }

    private void setSyncInterval(YieldloveConfig config) {
        config.setSyncInterval(this.common.updateIntervalMs);
    }

    private void setSoundSetting(YieldloveConfig config) {
        if (this.common.setAppMuted != null) {
            config.setAdsSoundSetting(this.common.setAppMuted ? AdsSoundSettingStates.MUTE : AdsSoundSettingStates.UNMUTE);
        } else {
            config.setAdsSoundSetting(AdsSoundSettingStates.RESPECT_USER_SOUND_SETTING);
        }
    }

    private YieldloveAdUnitData getAdUnit(String adSlotName) throws ConfigurationParsingException {
        AdUnitParser adUnitParser = new AdUnitParser(this.parsedJson);
        return adUnitParser.getAdUnit(adSlotName);
    }
}
