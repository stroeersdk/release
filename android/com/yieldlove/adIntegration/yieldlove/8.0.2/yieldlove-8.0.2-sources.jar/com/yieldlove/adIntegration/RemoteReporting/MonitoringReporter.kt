package com.yieldlove.adIntegration.RemoteReporting

interface MonitoringReporter {
    suspend fun report(sessions: ArrayList<String>)
}
