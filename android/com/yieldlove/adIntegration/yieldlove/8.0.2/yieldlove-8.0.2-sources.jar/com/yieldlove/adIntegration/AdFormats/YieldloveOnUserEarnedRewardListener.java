package com.yieldlove.adIntegration.AdFormats;

import com.stroeer.ads.formats.rewarded.StroeerRewardedListener;

@Deprecated (since = "Use com.stroeer.ads.formats.rewarded.IStroeerOnUserEarnedRewardListener instead")
public class YieldloveOnUserEarnedRewardListener extends StroeerRewardedListener{
}
