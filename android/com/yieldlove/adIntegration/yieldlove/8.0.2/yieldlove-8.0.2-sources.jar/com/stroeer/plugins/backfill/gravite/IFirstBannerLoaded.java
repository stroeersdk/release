package com.stroeer.plugins.backfill.gravite;

/**
 * Interface to handle the first banner loaded event for Gravite.
 * The first banner takes longer to load than subsequent banners.
 * So, this should be handled otherwise to avoid showing a blank screen.
 */
public interface IFirstBannerLoaded {
    void onFirstBannerLoaded();
}
