package com.stroeer.ads.exceptions

open class StroeerException : Exception {
    constructor(message: String?) : super(message)

    constructor(exception: Exception?) : super(exception)

    constructor() : super()
}
