package com.stroeer.ads.formats.interstitial

import android.content.Context
import com.google.android.gms.ads.MobileAds
import com.stroeer.ads.bidding.gam.GamInterstitialBidManager
import com.stroeer.ads.bidding.gam.IGamInterstitialEventListener
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException
import com.stroeer.ads.exceptions.PreviousAdLoadIsInProgressException
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.AStroeerAdBuilder
import com.stroeer.ads.formats.AdType
import com.stroeer.ads.reporting.events.GamRespondedSuccessfully
import com.stroeer.ads.reporting.events.GamRespondedWithError
import com.stroeer.ads.reporting.events.UnexpectedErrorHappenDuringAdLoading
import com.stroeer.plugins.backfill.error.DirectCallToGravite
import com.stroeer.plugins.backfill.gravite.GraviteLoader
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.bidding.gravite.GraviteBidManager
import com.stroeer.ads.sdks.SdkResult
import com.stroeer.ads.sdks.prebid.InterstitialPrebidSdkAdapter
import com.stroeer.ads.sdks.prebid.PrebidAdUnitConverter
import kotlinx.coroutines.*
import java.lang.ref.WeakReference

class StroeerInterstitialView(context: Context) : AStroeerAdBuilder(InterstitialConfiguration(context)) {

    var runBackFill: Boolean = false

    val intConfig : InterstitialConfiguration
        get() = adConfig as InterstitialConfiguration

    var loadAfterReady : Boolean
        get(){ return intConfig.loadAfterReady }
        set(value){ intConfig.loadAfterReady = value}

    init {
        MobileAds.initialize(context)
        prebidSdkAdapter = InterstitialPrebidSdkAdapter(context, PrebidAdUnitConverter())
        graviteBidManager = GraviteBidManager(intConfig)
        gamBidManager = GamInterstitialBidManager(intConfig)
    }

    fun load(publisherSlotName: String, listener: IStroeerInterstitialListener?){
       coroutineScope.launch {
            loadAsync(publisherSlotName, listener)
        }
    }

    suspend fun loadAsync(publisherSlotName: String, listener: IStroeerInterstitialListener? = null) {
        com.stroeer.ads.config.ConfigurationManager.getInstance().getConfigAsync()

        withTimeout(com.stroeer.ads.config.ConfigurationManager.getInstance().requestTimeout){
            try {
                if(!com.stroeer.ads.config.ConfigurationManager.getInstance().isLoaded) {
                    Logger.e("[Interstitial] Configuration is not loaded -  $publisherSlotName")
                    invokeFailEvent(listener, ConfigurationIsNotLoadedException())
                    return@withTimeout
                }

                if (intConfig.status.isLoading()) {
                    Logger.e("[Interstitial] Previous interstitial load is still in progress -  $publisherSlotName")
                    invokeFailEvent(listener, PreviousAdLoadIsInProgressException())
                    return@withTimeout
                }

                intConfig.initialize(publisherSlotName)
                intConfig.userListener = listener
                runBackFill = false

                // Validate Context - must be Activity
                validateContext()

                prepareSession(AdType.INTERSTITIAL)

                cleanLocalVariables()

                initAdUnit()

                if(!graviteBidManager.prepareInterstitial()){
                    return@withTimeout
                }

                prepareSdkManager()

                useAdsSoundSettingFrom()

                delay(1)
                val bidResults = getBid()

                recordAdViewPreparedEvent()

                delay(1)
                startGAM(bidResults)

            }catch(e : TimeoutCancellationException){
                Logger.d("[StroeerInterstitialView] Timeout - $publisherSlotName")
                handleExceptions(e)
            }catch(_ : com.stroeer.ads.exceptions.ContextException){
                Logger.d("[StroeerInterstitialView] Context is already dead - $publisherSlotName")
                intConfig.setError()
                // No handleExceptions call - context is dead, can't invoke callbacks or show fallback
            }
            catch (e: Exception) {
                Logger.e("[StroeerInterstitialView] Exception occurred in loading interstitial - $publisherSlotName", e)
                handleExceptions(e)
                intConfig.setError()
            }
        }
    }

     fun requestGravite(exception: Exception?): Boolean {
        if (exception is DirectCallToGravite || GraviteLoader.getInstance().isGraviteStarted) {
            try {
                Logger.d("[Interstitial] The BackFill Interstitial is called")
                val interstitialLoader = GraviteLoader.getInstance().getInterstitialLoader()
                if (interstitialLoader != null) {
                    runBackFill = interstitialLoader.isInterstitialAvailable(intConfig.adUnit)
                    if (runBackFill) {
                        intConfig.source = GraviteLoader.getInstance().adSource
                        return true
                    }
                }

                Logger.e("[Interstitial] The BackFill Interstitial is not ready yet")
            } catch (e: Exception) {
                Logger.e("[Interstitial] Failed to call BackFill Interstitial", e)
            }
        }
        return false
    }

    private fun cleanLocalVariables() {

    }

    fun show() {

        if(graviteBidManager.checkForceToCallGravite()) {
            try {
                val interstitialLoader = GraviteLoader.getInstance().getInterstitialLoader()
                interstitialLoader?.showInterstitial(intConfig.adUnit)
            } catch (e: Exception) {
                Logger.e("[Interstitial] Failed to show backfill interstitial", e)
            }
        }
        else {
            if (intConfig.status.isReady()) {
                intConfig.activityContext?.let { it ->
                    (gamBidManager as? GamInterstitialBidManager)?.show()
                }
            }
        }
    }

    private fun startGAM(bidResults: Array<SdkResult>){
        createGoogleAdView ()
        recordAdViewPreparedEvent()
        callDfp(bidResults)
    }

    private fun createGoogleAdView(){
        gamBidManager.initializeGoogleAdAViewIfNotExist()

        val weakListener = WeakReference(intConfig.userListener)
        val weakView = WeakReference(this@StroeerInterstitialView)
        val weakConfig = WeakReference(intConfig)
        val weakFullListener = WeakReference(weakListener.get() as? IStroeerInterstitialFullListener)

        if(weakFullListener.get() != null) {
            Logger.i("[StroeerInterstitialView] Full Interstitial Listener is added" )
        }

        gamBidManager.createAdManagerAdView(object: IGamInterstitialEventListener{
            override fun onAdLoaded() {
                Logger.i("[StroeerInterstitialView] onAdLoaded has been called - ${weakConfig.get()?.publisherSlotName}")
                weakConfig.get()?.session?.recordEvent(GamRespondedSuccessfully())
                weakConfig.get()?.setReady()

                try {
                    weakConfig.get()?.userListener?.onAdLoaded()

                    if(weakConfig.get()?.loadAfterReady ?: false) {
                        weakView.get()?.show()
                    }
                }catch(exception : Exception) {
                    Logger.e("[StroeerInterstitialView] Exception in onAdLoaded callback", exception)
                }
            }

            override fun onAdFailedToLoad(exception: StroeerException) {
                Logger.i("[StroeerInterstitialView] onAdFailedToLoad has been called - ${weakConfig.get()?.publisherSlotName}, ${exception.message}")
                weakConfig.get()?.session?.recordEvent(GamRespondedWithError(exception))

                if (!requestGravite(exception)) {
                    weakConfig.get()?.sessionEnd()
                    try {
                        weakConfig.get()?.setError()
                        weakListener.get()?.onAdFailedToLoad(exception)
                    }catch(exception : Exception){
                        Logger.e("[StroeerInterstitialView] Exception in onAdFailedToLoad callback", exception)
                    }
                }
            }

            override fun onAdClicked() {
                try {
                    Logger.i("[StroeerInterstitialView] onAdClicked has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdClicked()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerInterstitialView] Exception in onAdClicked callback",
                        exception
                    )
                }
            }

            override fun onAdDismissedFullScreenContent() {
                try {
                    Logger.i("[StroeerInterstitialView] onAdDismissedFullScreenContent has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdDismissedFullScreenContent()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerInterstitialView] Exception in onAdDismissedFullScreenContent callback",
                        exception
                    )
                }
            }

            override fun onAdFailedToShowFullScreenContent(exception: StroeerException) {
                try {
                    Logger.i("[StroeerInterstitialView] onAdFailedToShowFullScreenContent has been called - ${weakConfig.get()?.publisherSlotName}, ${exception.message}")
                    weakFullListener.get()?.onAdFailedToShowFullScreenContent(exception)
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerInterstitialView] Exception in onAdFailedToShowFullScreenContent callback",
                        exception
                    )
                }
            }

            override fun onAdImpression() {
                try {
                    Logger.i("[StroeerInterstitialView] onAdImpression has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdImpression()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerInterstitialView] Exception in onAdImpression callback",
                        exception
                    )
                }
            }

            override fun onAdShowedFullScreenContent() {
                try {
                    Logger.i("[StroeerInterstitialView] onAdShowedFullScreenContent has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdShowedFullScreenContent()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerInterstitialView] Exception in onAdShowedFullScreenContent callback",
                        exception
                    )
                }
            }

            override fun isFullListener(): Boolean {
                return weakFullListener.get() != null
            }

        } as Any)
    }

    private fun callDfp(results: Array<SdkResult>) {
        gamBidManager.callDfp(results)
    }

    private fun handleExceptions(exception: Exception) {
        // Gravite Handle
        if (requestGravite(exception)) {
            return
        }

        Logger.e("[StroeerInterstitialView] Error caught", exception)
        intConfig.session?.recordEvent(UnexpectedErrorHappenDuringAdLoading(exception))
        invokeFailEvent(intConfig.userListener, StroeerException(exception))
    }

    private fun invokeFailEvent(listener : IStroeerInterstitialListener?, exception: StroeerException?) {
        intConfig.sessionEnd()
        intConfig.setError()
        try {
            listener?.onAdFailedToLoad( exception)
        } catch (ex: RuntimeException) {
            Logger.e("[Interstitial] Exception in onAdFailedToLoad callback", ex)
        }
    }

    /**
     * Destroys the interstitial ad and cleans up resources.
     *
     * Optional - typically not needed for one-shot interstitial loads as local variables.
     * Only necessary if storing interstitial as a field and want explicit cleanup.
     *
     * Cancels any running load operations and releases resources.
     */
    fun destroy() {
        cancelCoroutines()
        intConfig.destroy()
        gamBidManager.destroy()
    }
}