package com.stroeer.ads.reporting.events

import com.google.android.gms.ads.LoadAdError
import com.google.gson.JsonObject
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.utilities.logging.Logger

class GamRespondedWithError() : TimeEvent() {
    var error : LoadAdError? = null
    var stroeerError : StroeerException? = null

    constructor(error : LoadAdError) : this() {
        this.error = error
    }

    constructor(error : StroeerException) : this(){
        this.stroeerError = error
    }

    override fun toJsonObject(): JsonObject {

        val jsonObject = super.toJsonObject()
        try {
            val jsonError = JsonObject()
            error?.let{
                jsonError.addProperty("message", it.toString())
                jsonError.addProperty("type", it.javaClass.getSimpleName())
            }

            stroeerError?.let{
                jsonError.addProperty("message", it.toString())
                jsonError.addProperty("type", it.javaClass.getSimpleName())
            }

            jsonObject.add("error", jsonError)
        } catch (e: Exception) {
            Logger.e(
                "[GamRespondedWithError] Error while creating JSON object from GamRespondedWithError event",
                e
            )
        }
        return jsonObject
    }
}