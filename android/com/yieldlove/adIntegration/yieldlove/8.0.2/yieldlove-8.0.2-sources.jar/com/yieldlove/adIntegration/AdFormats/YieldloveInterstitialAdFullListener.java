package com.yieldlove.adIntegration.AdFormats;

@Deprecated (since = "Use com.stroeer.ads.formats.interstitial.IStroeerInterstitialFullListener instead")
public interface YieldloveInterstitialAdFullListener extends YieldloveInterstitialAdListener{
     void onAdClicked(YieldloveInterstitialAdView interstitial);
     void onAdDismissedFullScreenContent(YieldloveInterstitialAdView interstitial);
     void onAdFailedToShowFullScreenContent(Exception e);
     void onAdImpression(YieldloveInterstitialAdView interstitial);
     void onAdShowedFullScreenContent(YieldloveInterstitialAdView interstitial);
}
