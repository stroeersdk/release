package com.stroeer.plugins.backfill.gravite;

import android.app.Activity;
import android.app.Application;

import com.stroeer.ads.debugInfo.IDebugInfo;
import com.stroeer.plugins.backfill.IBackFill;
import com.stroeer.plugins.backfill.IBackFillBanner;
import com.stroeer.plugins.backfill.IBackFillInterstitial;
import com.stroeer.plugins.backfill.IInitializationCallback;
import com.stroeer.plugins.backfill.error.DirectCallToGravite;
import com.stroeer.utilities.logging.Logger;
import com.stroeer.ads.formats.AdSourceInfo;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * Singleton class to manage the integration and lifecycle of the Gravite SDK.
 */
public class GraviteLoader {
    private static GraviteLoader instance;

    private IBackFill graviteWrapperInstance;

    private boolean debugMode = false;
    private boolean testMode = false;
    private String testBundleId = null;
    private Integer testAccountId = null;
    private boolean isGraviteStarted = false;
    private boolean forceToExecute = false;
    private boolean directGraviteCall = false;
    private int cacheSize = 1;
    private Map<String, String> stroeerToGravitePlacementMapTable = null;


    // Private constructor to enforce singleton pattern
    private GraviteLoader() {}

    /**
     * Returns the singleton instance of GraviteLoader.
     *
     * @return the single instance of GraviteLoader.
     */
    public static GraviteLoader getInstance() {
        if (instance == null) {
            instance = new GraviteLoader();
        }
        return instance;
    }

    /**
     * Initializes the Gravite SDK.
     *
     * @param application The application instance.
     * @param callback    The callback to notify initialization status.
     */
    public void initialize(Application application, IInitializationCallback callback) {
        try {
            // Check if the Gravite SDK class is present
            Class.forName("com.intentsoftware.addapptr.AATKit");
        } catch (Exception e) {
            Logger.i("[Gravite] Gravite is not found");
            returnToCallback(callback, false);
            return;
        }

        Logger.i("[Gravite] Gravite is found");

        // Load the Gravite wrapper class dynamically
        try {
            Class<IBackFill> graviteClass = (Class<IBackFill>) Class.forName("com.stroeer.gravite.GraviteWrapper");
            graviteWrapperInstance = graviteClass.newInstance();
        } catch (Exception e) {
            Logger.i("[Gravite] GravitePlugin is not found");
            returnToCallback(callback, false);
            return;
        }

        // Enable debug mode if configured
        if (debugMode) {
            graviteWrapperInstance.enableDebugMode();
        }

        // Enable test mode if configured
        if (testMode) {
            graviteWrapperInstance.enableTestMode(testBundleId, testAccountId);
        }

        // Initialize the Gravite SDK
        graviteWrapperInstance.initialize(application);

        // Additional settings.
        graviteWrapperInstance.setCacheSize(cacheSize);
        graviteWrapperInstance.setPlacementMapTable(stroeerToGravitePlacementMapTable);

        isGraviteStarted = true;
        returnToCallback(callback, true);
    }

    /**
     * Helper method to return the initialization status to the callback.
     *
     * @param callback      The initialization callback.
     * @param isInitialized True if initialization was successful, false otherwise.
     */
    private void returnToCallback(IInitializationCallback callback, boolean isInitialized) {
        if (callback != null) {
            callback.onInitialized(isInitialized);
        }
    }

    /**
     * Enables debug mode for the Gravite SDK.
     */
    public void enableDebugMode() {
        debugMode = true;
    }

    /**
     * Enables test mode for the Gravite SDK.
     *
     * @param bundleId      The test bundle ID.
     * @param accountId     The test account ID.
     * @param forceToExecute If true, forces the SDK to execute in test mode.
     */
    public void enableTestMode(String bundleId, Integer accountId, boolean forceToExecute) {
        testMode = true;
        testBundleId = bundleId;
        testAccountId = accountId;
        this.forceToExecute = forceToExecute;
    }

    /**
     * Enables direct calls to Gravite, bypassing normal bidding flow.
     */
    public void enableDirectGraviteCall() {
        this.directGraviteCall = true;
    }

    /**
     * Handles activity lifecycle onResume event.
     *
     * @param activity The current activity.
     */
    public void onResume(Activity activity) {
        if (isGraviteStarted) {
            graviteWrapperInstance.onResume(activity);
        }
    }

    /**
     * Handles activity lifecycle onPause event.
     *
     * @param activity The current activity.
     */
    public void onPause(Activity activity) {
        if (isGraviteStarted) {
            graviteWrapperInstance.onPause(activity);
        }
    }

    /**
     * Returns the banner loader instance from Gravite.
     *
     * @return The banner loader instance, or null if Gravite is not started.
     */
    public IBackFillBanner getBannerLoader() {
        if (isGraviteStarted) {
            return graviteWrapperInstance.getBannerLoader();
        }
        return null;
    }

    /**
     * Returns the interstitial loader instance from Gravite.
     *
     * @return The interstitial loader instance, or null if Gravite is not started.
     */
    public IBackFillInterstitial getInterstitialLoader() {
        if (isGraviteStarted) {
            return graviteWrapperInstance.getInterstitialLoader();
        }
        return null;
    }

    /**
     * Checks if force execution mode is enabled.
     *
     * @return True if force execution is enabled and Gravite is started, false otherwise.
     */
    public boolean isForceToExecute() {
        return isGraviteStarted && forceToExecute;
    }

    /**
     * Checks if Gravite SDK is started.
     *
     * @return True if Gravite is started, false otherwise.
     */
    public boolean isGraviteStarted() {
        return isGraviteStarted;
    }

    /**
     * Checks if direct calls to Gravite are enabled.
     *
     * @return True if direct calls are enabled, false otherwise.
     */
    public boolean isDirectGraviteCall() {
        return isGraviteStarted && directGraviteCall;
    }

    /**
     * Throws a DirectCallToGravite exception if a direct call to Gravite is detected.
     *
     * @throws DirectCallToGravite if the method is invoked directly without proper setup or validation.
     */
    public void throwExceptionIfDirectGraviteCall() throws DirectCallToGravite {
        if (isDirectGraviteCall()) {
            try {
                throw new DirectCallToGravite();
            }catch(DirectCallToGravite e){
                throw e;
            }
        }
    }

    /**
     * Sets the cache size for the current instance.
     * This method allows dynamic adjustment of the cache size based on application requirements.
     *
     * @param cacheSize The size to set for the cache.
     */
    public void setCacheSize(int cacheSize) {
        this.cacheSize = cacheSize;
    }


    /**
     * Sets the mapping table between Stroeer and Gravite placements
     *
     * @param stroeerToGravite A map containing the mapping of Stroeer placements to Gravite placements.
     */
    public void setPlacementMapTable(Map<String, String> stroeerToGravite) {
        // Build a string representation of the mapping table for logging purposes
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : stroeerToGravite.entrySet()) {
            sb.append(entry.getKey())
                    .append(" : ")
                    .append(entry.getValue())
                    .append("\n");
        }

        Logger.d("[Gravite] Placement Map Table: \n" + sb);
        stroeerToGravitePlacementMapTable = stroeerToGravite;
    }

    public String getPlacementConverted(String placement){
        if(stroeerToGravitePlacementMapTable != null) {
            String converted = stroeerToGravitePlacementMapTable.get(placement);
            if(converted != null){
                return converted;
            }
        }
        return placement;
    }


    private final Map<String, List<String>> customTargeting = new Hashtable<>();

    public void setCustomTargeting(Map<String, List<String>> targeting) {
        // If Gravite isn't ready or wrapper missing, do nothing.
        if (!isGraviteStarted || graviteWrapperInstance == null) {
            return;
        }

        // If caller passes null or empty, just push current state.
        if (targeting == null || targeting.isEmpty()) {
            return;
        }

        for (Map.Entry<String, List<String>> entry : targeting.entrySet()) {
            String key = entry.getKey();
            List<String> newValues = entry.getValue();

            LinkedHashSet<String> unique = new LinkedHashSet<>();

            // Get or create current list for this key
            List<String> existing = customTargeting.get(key);
            if (existing != null) {
                unique.addAll(existing);
            }

            for (String v : newValues) {
                if (v != null && !v.isEmpty()) {
                    unique.add(v);
                }
            }

            customTargeting.put(key, new ArrayList<>(unique));
        }

        // Push a defensive copy to Gravite so external code can't mutate our map.
        graviteWrapperInstance.setCustomTargeting(new Hashtable<>(customTargeting));
    }

    /**
     * Retrieves the version of the Gravite SDK if it is initialized.
     *
     * @return The version of the Gravite SDK as a String. Returns "Unknown" if the Gravite SDK has not been started.
     */
    public String getVersion() {
        if (isGraviteStarted) {
            return graviteWrapperInstance.getVersion();
        } else {
            return "Unknown";
        }
    }

    /**
     * Creates and returns an AdSourceInfo object with the Gravite ad source and its version.
     *
     * @return An AdSourceInfo object containing the ad source and version information.
     */
    public AdSourceInfo getAdSource() {
        return graviteWrapperInstance.getAdSourceInfo();
    }

    public IDebugInfo getDebugInfo() {
        return graviteWrapperInstance.getDebugInfo();
    }

}
