package com.stroeer.plugins.identity.objects;

import com.stroeer.ads.config.ConfigurationManager;
import com.stroeer.utilities.json.JsonBase;
import com.stroeer.utilities.logging.Logger;

import java.util.Date;

public class IdentityCache extends JsonBase<IdentityCache> {
    private final long DEFAULT_REFRESH_INTERVAL = 8 * 60 * 60; // 8 hours in seconds
    protected long refreshInterval = 0;
    protected long deleteCacheInterval = 30 * 24 * 60 * 60; // 30 days in seconds
    protected String identityString = "";
    protected Date cacheCreationDate = new Date();

    public IdentityCache(){
    }

    public long getRefreshInterval() {
        if(refreshInterval == 0){
            Logger.d("[IdentityCache] Refresh interval is not set. Using the default value.");
            setDefaultRefreshInterval();
        }
        return refreshInterval;
    }

    /**
     * Set the refresh interval for the cache.
     * We don't allow to set the refresh interval manually by a publisher, it should be set by the configuration
     * Even if you are set this, this will be reset by the configuration
     * @param refreshInterval The refresh interval in seconds.
     */
    public void setRefreshInterval(long refreshInterval) {
        this.refreshInterval = refreshInterval;
    }

    public void setDefaultRefreshInterval() {
        if(ConfigurationManager.getInstance().getConfig() == null ||
                ConfigurationManager.getInstance().getConfig().getModules() == null ||
                ConfigurationManager.getInstance().getConfig().getModules().getId5() == null){
            Logger.e("[IdentityCache] ID5 configuration is not set. Using the default refresh interval.");
            this.refreshInterval = DEFAULT_REFRESH_INTERVAL;
        }
        else{
            this.refreshInterval = ConfigurationManager.getInstance().getConfig().getModules().getId5().getRefreshIntervalInSecs();
        }
    }

    public long getDeleteCacheInterval() {
        return deleteCacheInterval;
    }

    public void setDeleteCacheInterval(long deleteCacheInterval) {
        this.deleteCacheInterval = deleteCacheInterval;
    }

    public String getIdentityString() {
        return identityString;
    }

    public void setIdentityString(String identityString) {
        this.identityString = identityString;
    }

    public Date getCacheCreationDate() {
        return cacheCreationDate;
    }

    public void setCacheCreationDate(Date cacheCreationDate) {
        this.cacheCreationDate = cacheCreationDate;
    }
}
