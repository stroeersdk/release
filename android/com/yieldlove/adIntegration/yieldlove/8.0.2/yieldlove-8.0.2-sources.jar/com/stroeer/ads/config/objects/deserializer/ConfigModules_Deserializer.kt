package com.stroeer.ads.config.objects.deserializer

import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.JsonParseException
import com.stroeer.ads.config.objects.ConfigModule_ID5
import com.stroeer.ads.config.objects.ConfigModule_Prebid
import com.stroeer.ads.config.objects.ConfigModule_SourcePoint
import com.stroeer.ads.config.objects.ConfigModule_Confiant
import com.stroeer.ads.config.objects.ConfigModules
import java.lang.reflect.Type

/**
 * "modules": [
 * {
 * "PREBID": {
 * "yieldloveAccountId": "fussball-live-ticker-herzrasen"
 * },
 * "CRITEO": {
 * "accountId": "B-058707"
 * }
 * },
 * {
 * "SOURCEPOINT": {
 * "active": true,
 * "propertyId": "10629",
 * "propertyName": "android.app.herzrasen",
 * "privacyManagerId": "406840"
 * },
 * "iOSSOURCEPOINT": {
 * "active": true,
 * "propertyId": "10630",
 * "propertyName": "ios.app.herzrasen",
 * "privacyManagerId": "406870"
 * }
 * }
 * ],
 */
class ConfigModules_Deserializer : JsonDeserializer<ConfigModules?> {
    @Throws(JsonParseException::class)
    override fun deserialize(
        json: JsonElement,
        typeOfT: Type?,
        context: JsonDeserializationContext
    ): ConfigModules {
        val jsonArray = json.getAsJsonArray()
        val module = ConfigModules()

        for (element in jsonArray) {
            val jsonObject = element.getAsJsonObject()
            if (jsonObject.has("PREBID")) {
                module.prebid = context.deserialize(
                    jsonObject.getAsJsonObject("PREBID"),
                    ConfigModule_Prebid::class.java
                )
            }
            if (jsonObject.has("SOURCEPOINT")) {
                module.sourcePoint = context.deserialize(
                    jsonObject.getAsJsonObject("SOURCEPOINT"),
                    ConfigModule_SourcePoint::class.java
                )
            }
            if (jsonObject.has("ID5")) {
                module.id5 = context.deserialize(
                    jsonObject.getAsJsonObject("ID5"),
                    ConfigModule_ID5::class.java
                )
            }
            if (jsonObject.has("CONFIANT")) {
                module.confiant = context.deserialize(
                    jsonObject.getAsJsonObject("CONFIANT"),
                    ConfigModule_Confiant::class.java
                )
            }
        }
        return module
    }
}
