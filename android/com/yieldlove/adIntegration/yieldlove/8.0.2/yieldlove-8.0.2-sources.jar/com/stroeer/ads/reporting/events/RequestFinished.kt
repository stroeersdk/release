package com.stroeer.ads.reporting.events

class RequestFinished : TimeEvent() {
}