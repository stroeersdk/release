package com.stroeer.ads.formats.rewarded

import android.content.Context
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.formats.AAdConfiguration

class RewardedConfiguration(context: Context) : AAdConfiguration(context){
    var userListener : IStroeerRewardedListener? = null

    var loadAfterReady = true

    override fun destroy() {
        super.destroy()
        userListener = null
    }
}