package com.stroeer.ads.config.objects

class ConfigModule_ID5 {
    var active: Boolean = false
    var refreshIntervalInSecs: Long = (8 * 60 * 60).toLong()
}
