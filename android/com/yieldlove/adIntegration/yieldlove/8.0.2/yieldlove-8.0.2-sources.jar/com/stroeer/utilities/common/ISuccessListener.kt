package com.stroeer.utilities.common

interface ISuccessListener<T> {
    fun onSuccess(data: T)
}
