package com.yieldlove.adIntegration.ExternalConfiguration.ConfigParsers;

import com.google.android.gms.ads.AdSize;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigAdSlot;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigCommon;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects.ConfigCustomAdSize;
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigurationParsingException;
import com.yieldlove.adIntegration.ExternalConfiguration.InventoryStructureSettings;
import com.yieldlove.adIntegration.ExternalConfiguration.YieldloveAdUnitData;
import com.stroeer.ads.exceptions.StroeerException;

import java.util.ArrayList;

public class AdUnitParser {

    private final JsonObject parsedJson;
    private final ConfigCommon common;
    private final AdSlotParser adSlotParser;
    private final FormatsParser formatsParser;
    private final ZoneAndPageTypeParser zoneAndPageTypeParser;

    private final String filterSuffixRegex = "\\?.*";


    public AdUnitParser(JsonObject json){
        this.parsedJson = json;
        this.common =  new CommonParser(this.parsedJson).getCommon();
        this.adSlotParser = new AdSlotParser(this.parsedJson);
        this.formatsParser = new FormatsParser(this.parsedJson);
        this.zoneAndPageTypeParser = new ZoneAndPageTypeParser(this.parsedJson);
    }

    public YieldloveAdUnitData getAdUnit(String adSlotName) throws ConfigurationParsingException {
        try {
            YieldloveAdUnitData adUnit = this.builtAdUnitDataFromParsedJson(adSlotName);
            this.zoneAndPageTypeParser.addKeyValues(adUnit, adSlotName);
            this.setPrebidAccountId(adUnit);
            this.setStoreUrl(adUnit);
            this.setBundleId(adUnit);
            this.setRtaAuction(adUnit, adSlotName);
            this.setDfpAdRequestTimeoutInMs(adUnit);
            this.setOpenRtbApi(adUnit);
            this.setAutoRefreshTimeIfAny(adUnit, adSlotName);

            return adUnit;
        } catch (ConfigurationParsingException parsingException) {
            throw parsingException;
        } catch (Exception e) {
            throw new ConfigurationParsingException(e.getMessage());
        }
    }

    private YieldloveAdUnitData builtAdUnitDataFromParsedJson(String adSlotName) throws StroeerException {
        String dfpId = this.getDfpId(adSlotName);

        String slot = this.getSlotNameWithoutSdiPrefix(adSlotName);

        String configId = this.getConfigId(slot);
        AdSize[] sizes = this.getAdSizes(slot);
        return new YieldloveAdUnitData(dfpId, configId, sizes);
    }

    private void setDfpAdRequestTimeoutInMs(YieldloveAdUnit adUnit) {
        if (this.common.dfpAdRequestTimeoutMs != null) {
            adUnit.setDfpAdRequestTimeoutInMs(this.common.dfpAdRequestTimeoutMs);
        }
    }

    private void setOpenRtbApi(YieldloveAdUnit adUnit) {
        ArrayList<Integer> openRtbApi = new ArrayList<>();
        JsonObject openRtbObj = this.parsedJson.getAsJsonObject("openRtb");
        if (openRtbObj != null) {
            JsonArray apis = openRtbObj.getAsJsonArray("apis");
            if (apis != null) {
                for (JsonElement element : apis) {
                    openRtbApi.add(element.getAsJsonObject().get("framework").getAsInt());
                }
            }
        }

        adUnit.setOpenRtbApi(openRtbApi.toArray(new Integer[]{}));
    }

    private void setAutoRefreshTimeIfAny(YieldloveAdUnitData adUnit, String adSlotName) throws ConfigurationParsingException {
        String slotWithoutPrefix = this.getSlotNameWithoutSdiPrefix(adSlotName);
        Integer autoRefreshTimeMs = this.adSlotParser.getSlot(slotWithoutPrefix).autoRefreshTimeMs;
        if (autoRefreshTimeMs != null) {
            adUnit.setAutoRefreshTimeInMs(autoRefreshTimeMs);
        }
    }

    private String getDfpId(String adSlotName) {
        String dfpAppNetwork = this.common.dfpAppNetwork;
        String adSlotNameWithoutSuffix = this.removeSuffixFromSlotName(adSlotName);

        if (this.getInventoryStructureSetting() == InventoryStructureSettings.STROEER_DIGITAL_INVENTORY) {
            String dfpAndroidAppName = this.getDfpAndroidAppName(adSlotName);
            return "/" + dfpAppNetwork + "/" + dfpAndroidAppName + "/" + adSlotNameWithoutSuffix;
        }

        return "/" + dfpAppNetwork + "/" + adSlotNameWithoutSuffix;
    }


    private String getConfigId(String slot) throws ConfigurationParsingException {
        ConfigAdSlot adSlot = this.adSlotParser.getSlot(slot);
        if (adSlot == null) {
            throw new ConfigurationParsingException("AdSlot \"" + slot + "\" was not found in config");
        }
        return adSlot.prebidConfigId;
    }


    private void setStoreUrl(YieldloveAdUnitData adUnit) {
        String url = this.common.androidStoreUrl != null ? this.common.androidStoreUrl : "";
        adUnit.setStoreUrl(url);
    }
    private void setBundleId(YieldloveAdUnitData adUnit) {
        adUnit.setBundleId(this.common.androidBundleId );
    }

    private void setPrebidAccountId(YieldloveAdUnitData adUnit) {
        ModuleParser moduleParser = new ModuleParser(this.parsedJson);
        JsonObject prebidConfig = moduleParser.getModuleConfig("PREBID");

        if (prebidConfig != null) {
            adUnit.setPrebidAccountId(prebidConfig.get("yieldloveAccountId").getAsString());
        }
    }

    private void setRtaAuction(YieldloveAdUnitData adUnit, String adSlotName) {
        boolean rtaAuction = false;
        String slotWithoutPrefix = this.getSlotNameWithoutSdiPrefix(adSlotName);
        ConfigAdSlot adSlot = this.adSlotParser.getSlot(slotWithoutPrefix);
        if (adSlot != null && adSlot.rtaAuction != null) {
            rtaAuction = adSlot.rtaAuction;
        }
        adUnit.setRtaAuction(rtaAuction);
    }

    private String getSlotNameWithoutSdiPrefix(String adSlotName) {
        if (isInventorySdiStructure()) {
            String[] adSlotNameParts = adSlotName.split("_");
            return adSlotNameParts[adSlotNameParts.length - 1];
        }
        return adSlotName;
    }

    private String getDfpAndroidAppName(String adSlotName) {
        String slotWithOutZones = this.getSlotNameWithoutSdiPrefix(adSlotName);

        ConfigAdSlot slot = this.adSlotParser.getSlot(slotWithOutZones);

        if (slot != null && slot.dfpAndroidAppName != null) {
            return slot.dfpAndroidAppName;
        } else {
            return this.common.dfpAndroidAppName;
        }
    }

    private AdSize[] getAdSizes(String slot) {
        ArrayList<AdSize> sizes = new ArrayList<>();

        this.addCustomAdSizes(slot, sizes);
        this.formatsParser.addSizesFromAdFormats(slot, sizes);

        if(sizes.isEmpty()){
            sizes.add(new AdSize(0, 0));
        } else if (sizes.size() == 1 && sizes.get(0) == null) {
            sizes.remove(0);
            sizes.add(new AdSize(0, 0));
        }

        return sizes.toArray(new AdSize[]{});
    }

    public void addCustomAdSizes(String slot, ArrayList<AdSize> sizes) {
        ConfigAdSlot adSlot = this.adSlotParser.getSlot(slot);
        if(adSlot.customAdSizes != null){
            for (ConfigCustomAdSize size: adSlot.customAdSizes){
                sizes.add(new AdSize(size.w, size.h));
            }
        }
    }

    private InventoryStructureSettings getInventoryStructureSetting() {

      if(this.common.inventoryStructure != null){
           return InventoryStructureSettings.parse(this.common.inventoryStructure);
      }
      return InventoryStructureSettings.STROEER_DIGITAL_INVENTORY;
    }

    private String removeSuffixFromSlotName(String adSlotName) {
        return adSlotName.replaceFirst(this.filterSuffixRegex, "");
    }

    private boolean isInventorySdiStructure() {
        return this.getInventoryStructureSetting() == InventoryStructureSettings.STROEER_DIGITAL_INVENTORY;
    }

}
