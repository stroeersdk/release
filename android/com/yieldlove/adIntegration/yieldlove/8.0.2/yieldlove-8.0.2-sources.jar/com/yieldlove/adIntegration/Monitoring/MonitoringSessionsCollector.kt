package com.yieldlove.adIntegration.Monitoring

import android.content.Context
import com.stroeer.ads.reporting.Session
import com.yieldlove.adIntegration.Configuration
import com.yieldlove.adIntegration.ConsentReader.IabConsentReader
import com.yieldlove.adIntegration.ExternalConfiguration.ConfigurationManager
import com.yieldlove.adIntegration.IabConsentResolver.IabConsentEvaluator
import com.yieldlove.adIntegration.IabConsentResolver.IabPublisherRestrictionResolver
import com.yieldlove.adIntegration.RemoteReporting.HttpMonitoringReporter
import com.yieldlove.adIntegration.RemoteReporting.MonitoringReporter
import com.yieldlove.androidpromise.Promise
import com.yieldlove.androidpromise.VoidCallbackWithoutPromise
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class MonitoringSessionsCollector(context: Context) : SessionsCollector {
    var config: MonitoringConfig? = null
    var sessions: ArrayList<String>
    var reporter: MonitoringReporter
    var storage: MonitoringStorage
    private var addSessionCalls = 0
    private val configurationManager: ConfigurationManager
    private val monitoringConsent: MonitoringConsent

    init {
        this.sessions = ArrayList<String>()
        this.configurationManager = ConfigurationManager(context)
        this.storage = SharedPreferencesMonitoringStorage(context)
        this.reporter = HttpMonitoringReporter(
            Configuration.getMonitoringReporterUrl(),
            Configuration.getMonitoringReporterApiKey()
        )
        val reader = IabConsentReader(context)
        val resolver = IabPublisherRestrictionResolver(reader, IabConsentEvaluator(reader))
        this.monitoringConsent = MonitoringConsent(resolver)
        this.loadSessionsFromStorage()
    }

    suspend fun loadConfig(): MonitoringConfig? {
        return withTimeoutOrNull(3_000) {
            suspendCancellableCoroutine { cont ->
                configurationManager.monitoringConfig
                    .done(VoidCallbackWithoutPromise { newConfig: MonitoringConfig ->
                        try {
                            config = newConfig
                            if (cont.isActive) {
                                cont.resume(newConfig) // ✅ resume coroutine with result
                            }
                        } catch (ex: Throwable) {
                            if (cont.isActive) {
                                cont.resume(null)
                            }
                        }
                    })
            }
        }
    }

    override suspend fun addSession(session: Session) {
        if (this.monitoringConsent.canWeUseMonitoring() && !isAlreadyInSessionArray(session)) {
            val config = loadConfig()
            config?.let{
                this.tryToStoreSession(session)
                this.reportSessionsIfQueueIsFullOrTimeElapsed()
            }
        }
    }

    private fun isAlreadyInSessionArray(session: Session): Boolean {
        for (sessionLoop in this.sessions) {
            if (sessionLoop.contains(session.id)) {
                return true
            }
        }
        return false
    }

    private fun tryToStoreSession(session: Session) {
        if (this.shouldStoreSession()) {
            this.sessions.add(session.toJsonString())
            this.storage.putSessions(this.sessions)
        }
    }

    private fun loadSessionsFromStorage() {
        if (this.monitoringConsent.canWeUseMonitoring()) {
            this.sessions = this.storage.getSessions()
        }
    }

    private fun doesNumOfCallsFitFrequency(): Boolean {
        return addSessionCalls % config!!.getFrequency() == 0
    }

    private suspend fun reportSessionsIfQueueIsFullOrTimeElapsed() {
        if (this.config!!.isMonitoringActive()) {
            if (this.isQueueFull || (this.timeElapsed() && this.queueIsNotEmpty())) {
                this.reporter.report(this.sessions)
                this.storage.setLastReportTime(System.currentTimeMillis())
                this.sessions.clear()
            }
        }
    }

    private fun timeElapsed(): Boolean {
        val lastSyncTime = this.storage.getLastReportTime()
        return lastSyncTime > 0 && lastSyncTime + this.config!!.getSendingIntervalInMs() < System.currentTimeMillis()
    }

    private fun shouldStoreSession(): Boolean {
        this.addSessionCalls++
        return config!!.isMonitoringActive() && this.doesNumOfCallsFitFrequency()
    }

    private fun queueIsNotEmpty(): Boolean {
        return !this.sessions.isEmpty()
    }

    private val isQueueFull: Boolean
        get() {
            val queueMax = config!!.getMaxSessionsForSending()
            return this.sessions.size >= queueMax
        }
}
