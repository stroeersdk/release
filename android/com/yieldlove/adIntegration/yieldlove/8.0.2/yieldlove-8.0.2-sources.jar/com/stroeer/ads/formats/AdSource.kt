package com.stroeer.ads.formats


enum class AdSource {
    Unknown,
    Stroeer,
    Gravite;

    companion object {
        fun fromString(source: String?): AdSource {
            if (source != null) {
                for (adSource in entries) {
                    if (source.equals(adSource.name, ignoreCase = true)) {
                        return adSource
                    }
                }
            }
            return AdSource.Unknown
        }

        const val UNKNOWN = "Unknown"
        const val STROEER = "Stroeer"
        const val GOOGLE = "Google"
        const val GRAVITE = "Gravite"
    }
}
