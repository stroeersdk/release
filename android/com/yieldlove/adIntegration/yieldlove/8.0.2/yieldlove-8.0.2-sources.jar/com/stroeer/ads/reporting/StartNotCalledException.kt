package com.stroeer.ads.reporting

class StartNotCalledException(eventName: String?) :
    RuntimeException("The event was called without starting the time keeper: $eventName")
