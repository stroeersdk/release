package com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects;

import java.util.HashMap;

public class ConfigAdSlot {
    public String prebidConfigId;
    public Boolean rtaAuction;
    public Integer autoRefreshTimeMs;
    public String dfpAndroidAppName;
    public HashMap<String, Object> keyValues;
    public ConfigCustomAdSize[] customAdSizes;
}
