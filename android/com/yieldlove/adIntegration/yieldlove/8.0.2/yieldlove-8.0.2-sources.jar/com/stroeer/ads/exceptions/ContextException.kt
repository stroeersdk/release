package com.stroeer.ads.exceptions

class ContextException(message: String?) : StroeerException(message)
