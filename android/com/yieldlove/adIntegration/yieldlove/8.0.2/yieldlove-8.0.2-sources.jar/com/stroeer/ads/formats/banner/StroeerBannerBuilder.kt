package com.stroeer.ads.formats.banner

import android.content.Context
import android.view.View
import com.google.android.gms.ads.AdSize
import com.stroeer.ads.bidding.gam.GamBannerBidManager
import com.stroeer.ads.bidding.gam.IGamBannerEventListener
import com.stroeer.ads.bidding.gravite.GraviteBidManager
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.debugInfo.DebugInfoManager
import com.stroeer.ads.exceptions.*
import com.stroeer.ads.formats.AdSource
import com.stroeer.ads.formats.AdType
import com.stroeer.ads.reporting.events.*
import com.stroeer.plugins.backfill.error.DirectCallToGravite
import com.stroeer.plugins.backfill.error.ForceToExecute
import com.stroeer.plugins.backfill.gravite.GraviteLoader
import com.stroeer.plugins.monitoring.IAdReloader
import com.stroeer.plugins.monitoring.confiant.ConfiantLoader
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.formats.AStroeerAdBuilder
import com.stroeer.ads.formats.AdCategory
import com.stroeer.ads.formats.AdStatus
import com.stroeer.ads.formats.banner.refresh.RefreshTimer
import com.stroeer.ads.formats.banner.refresh.IRefreshListener
import com.stroeer.ads.formats.BidderRecognizer
import com.stroeer.ads.reporting.events.BannerRefreshStarted
import com.stroeer.ads.sdks.SdkResult
import com.stroeer.ads.sdks.SdkResultCode
import com.stroeer.ads.sdks.prebid.BannerPrebidSdkAdapter
import com.stroeer.ads.sdks.prebid.PrebidAdUnitConverter
import com.stroeer.plugins.identity.IdentityManager
import kotlinx.coroutines.*
import java.lang.ref.WeakReference
import kotlin.coroutines.coroutineContext

internal class StroeerBannerBuilder(context: Context, bannerView: StroeerBannerView) : AStroeerAdBuilder(BannerConfiguration(context)) {

    val bannerConfig : BannerConfiguration
        get(){
            return adConfig as BannerConfiguration
        }

    init {
        bannerConfig.bannerView = bannerView

        prebidSdkAdapter = BannerPrebidSdkAdapter(context, PrebidAdUnitConverter())
        graviteBidManager = GraviteBidManager(bannerConfig)
        gamBidManager = GamBannerBidManager(bannerConfig)
    }

    fun load(publisherSlotName: String, listener: IStroeerBannerListener?) {
        coroutineScope.launch {
            loadAsync(publisherSlotName, listener)
        }
    }

    private suspend fun loadAsync(publisherSlotName: String, listener: IStroeerBannerListener? = null) {
        ConfigurationManager.getInstance().getConfigAsync()

        withContext(Dispatchers.Main){
            try {
                Logger.d("[StroeerBannerBuilder] Loading banner - $publisherSlotName")

                if(!ConfigurationManager.getInstance().isLoaded) {
                    Logger.e("[StroeerBannerBuilder] Configuration is not loaded - $publisherSlotName")
                    invokeOnFail(listener, publisherSlotName, ConfigurationIsNotLoadedException())
                    return@withContext
                }

                if(bannerConfig.status.isLoading()) {
                    Logger.e("[StroeerBannerBuilder] Previous ad load is still in progress - $publisherSlotName")
                    invokeOnFail(listener, publisherSlotName, PreviousAdLoadIsInProgressException(), false)
                    return@withContext
                }

                bannerConfig.initialize(publisherSlotName)
                bannerConfig.userListener = listener

                // Validate Context - must be Activity
                validateContext()

                setupAutoRefresh()

                // Start up Session
                prepareSession(AdType.BANNER)

                // Clear variables
                cleanLocalVariables()

                // Initialize AdUnit
                initAdUnit()

                // Start Ad Monitoring
                markForMonitoring()

                startBidding(listener, publisherSlotName)

            }catch(e : TimeoutCancellationException){
                Logger.d("[StroeerBannerBuilder] Timeout - $publisherSlotName")
                destroyViews()
                handleExceptions(e)
            }catch(_ : ContextException){
                Logger.d("[StroeerBannerBuilder] Context is already dead - $publisherSlotName")
                destroyViews()
                // No handleExceptions call - context is dead, can't invoke callbacks or show fallback
            }
            catch (e: Exception) {
                if(bannerConfig.bannerView == null){
                    Logger.d("[StroeerBannerBuilder] BannerView is already dead. - $publisherSlotName. ${e.message}")
                }
                else {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception occurred in loading banner - $publisherSlotName",
                        e
                    )
                }
                destroyViews()
                handleExceptions(e)
            }
        }
    }

    suspend fun startBidding(listener: IStroeerBannerListener?, publisherSlotName : String) : Boolean {

        // if Direct Rendering is enabled, should stop here
        if(!graviteBidManager.prepareBanner()){
            return true
        }

        delay(1)

        val bidResults = runBidding()

        val runGAM = checkIfRunGam(bidResults)

        delay(1)
        if(runGAM.first) {
            startGAM(bidResults)
        }else{
            when(runGAM.second.resultCode){
                SdkResultCode.SUCCESS -> {
                    try{
                        listener?.onAdLoaded(bannerConfig.bannerView)
                    }catch(e : Exception){
                        Logger.e("[StroeerBannerBuilder] Exception is thrown during onAdLoaded callback. - $publisherSlotName", e)
                    }
                }
                else -> {
                    invokeOnFail(listener, publisherSlotName, StroeerException("Failed to create the ads : ${runGAM.second.errorMessage}- $publisherSlotName"))
                }
            }
        }
        return false
    }

    fun stopAutoRefresh() {
        Logger.d("[StroeerBannerBuilder] stopping auto refresh ${bannerConfig.publisherSlotName}")
        bannerConfig.timer?.clearScheduledTasks()
    }

    private fun setupAutoRefresh() {
        bannerConfig.refreshTime?.let{
            if( it > 0) {
                Logger.i("[StroeerBannerBuilder] Auto refresh is enabled. Refresh time: ${it}ms - ${bannerConfig.publisherSlotName}")
                bannerConfig.timer = RefreshTimer(object : IRefreshListener {
                    override fun handleRefresh() {
                        refreshBanner()
                    }
                })
            }
        }
    }

    private fun scheduleRefresh() {
        bannerConfig.timer?.let{
            val time: Int? = bannerConfig.refreshTime
            if (time != null && time > 0) {
                it.scheduleRefresh(time)
            }
        }
    }

    private fun refreshBanner() {
        coroutineScope.launch {
            try {
                Logger.i("[StroeerBannerBuilder] Refreshing -${bannerConfig.publisherSlotName}")
                bannerConfig.isRefreshing = true
                bannerConfig.status = AdStatus.LOADING
                bannerConfig.session?.reset()
                bannerConfig.session?.start()
                bannerConfig.session?.recordEvent(BannerRefreshStarted())

                startBidding(bannerConfig.userListener, bannerConfig.publisherSlotName)
            } catch (_: DirectCallToGravite) {
                handleExceptions(DirectCallToGravite())
            }
        }
    }

    private fun cleanLocalVariables() {

    }

    override suspend fun getBid(): Array<SdkResult> {
        GraviteLoader.getInstance().throwExceptionIfDirectGraviteCall()

        IdentityManager.getInstance().setUserIdToPrebid()

        return this.sdkManager.getBids(bannerConfig)
    }

    suspend fun getAdSizes() : Array<AdSize>? {
        val adUnit = this.getAdUnit()
        return adUnit?.availableBannerSizes
    }

    private fun handleExceptions(exception: Exception) {
        if (graviteBidManager.renderGraviteBanner()) {
            invokeOnSuccess(bannerConfig.userListener, bannerConfig.bannerView, bannerConfig)
            return
        }

        bannerConfig.session?.recordEvent(UnexpectedErrorHappenDuringAdLoading(exception))
        DebugInfoManager.updateServeTime(bannerConfig)
        bannerConfig.bannerView?.addDebugLabel()
        invokeOnFail(bannerConfig.userListener, bannerConfig.publisherSlotName, StroeerException(exception))
    }

    // To not touch this, this may cause memory leak because of strong reference in AdListener
    private fun createGoogleAdView() {

        gamBidManager.initializeGoogleAdAViewIfNotExist()

        // Because Google SDK has the strong references to AdListener, we have to use WeakReference here to avoid memory leak
        val publisherSlotName = bannerConfig.publisherSlotName
        val weakListener = WeakReference(bannerConfig.userListener)
        val weakBuilder = WeakReference(this@StroeerBannerBuilder)
        val weakConfig = WeakReference(bannerConfig)
        val weakView = WeakReference(bannerConfig.bannerView)

        gamBidManager.createAdManagerAdView(object : IGamBannerEventListener {
            override fun onAdLoaded() {
                Logger.i("[StroeerBannerBuilder] onAdLoaded has been called. - $publisherSlotName")
                weakConfig.get()?.session?.recordEvent(GamRespondedSuccessfully())

                coroutineScope.launch {
                    try {
                        val html = weakBuilder.get()?.getHtml(weakView.get())
                        html?.let {
                            weakBuilder.get()?.analyzeAdBody(html)
                        }
                    } catch (exception: Exception) {
                        Logger.e("[StroeerBannerBuilder] Failed to analyze ad body - $publisherSlotName",exception)
                    }

                    Logger.d("[StroeerBannerBuilder] The size = ${weakConfig.get()?.adManagerAdView?.adSize} - $publisherSlotName")

                    weakConfig.get()?.let{
                        it.session?.recordEvent(RequestFinished())
                        DebugInfoManager.updateServeTime(it)
                    }

                    weakView.get()?.addDebugLabel()

                    if(graviteBidManager.checkForceToCallGravite()){
                        handleExceptions(ForceToExecute())
                    }else {
                        invokeOnSuccess(weakListener.get(), weakView.get())
                    }
                }
            }

            override fun onAdFailedToLoad(error: StroeerException) {
                Logger.i("[StroeerBannerBuilder] onAdFailedToLoad has been called. - $publisherSlotName : ${error.message}")

                weakConfig.get()?.let{
                    it.session?.recordEvent(GamRespondedWithError(error))

                    DebugInfoManager.updateServeTime(it)
                    DebugInfoManager.addDebugInfoForFail(it, "Failed From GAM", error)
                    weakView.get()?.addDebugLabel()
                }

                if(graviteBidManager.checkForceToCallGravite()){
                    handleExceptions(ForceToExecute())
                    return
                }

                invokeOnFail(weakListener.get(), publisherSlotName, error, true)
            }

            override fun onAdOpened() {
                Logger.i("[StroeerBannerBuilder] onAdOpened has been called. - $publisherSlotName")
                try {
                    weakListener.get()?.onAdOpened(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception is thrown during onAdOpened callback. - $publisherSlotName",
                        ex
                    )
                }
            }

            override fun onAdClosed() {
                Logger.i("[StroeerBannerBuilder] onAdClosed has been called. - $publisherSlotName")
                try {
                    weakListener.get()?.onAdClosed(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception is thrown during onAdClosed callback. - $publisherSlotName",
                        ex
                    )
                }
            }

            override fun onAdClicked() {
                Logger.i("[StroeerBannerBuilder] onAdClicked has been called. - $publisherSlotName")
                try {
                    weakListener.get()?.onAdClicked(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception is thrown during onAdClicked callback. - $publisherSlotName",
                        ex
                    )
                }
            }

            override fun onAdImpression() {
                Logger.i("[StroeerBannerBuilder] onAdImpression has been called. - $publisherSlotName")
                weakBuilder.get()?.scheduleRefresh()
                try {
                    weakListener.get()?.onAdImpression(weakView.get())
                } catch (ex: RuntimeException) {
                    Logger.e(
                        "[StroeerBannerBuilder] Exception is thrown during onAdImpression callback. - $publisherSlotName",
                        ex
                    )
                }
            }
        }) as Any// end of the event handler
    }

    private fun analyzeAdBody(html: String) {
        val prebidIdentifier = prebidSdkAdapter.identifier
        if (prebidIdentifier != null && html.contains(prebidIdentifier)) {
            DebugInfoManager.addFinalResultToDebugInfo(bannerConfig, "Prebid")
            (prebidSdkAdapter as BannerPrebidSdkAdapter).resizeAd(bannerConfig.adManagerAdView)
            bannerConfig.source.adSubSource = AdSource.Companion.STROEER
            Logger.d("[StroeerBannerBuilder] Banner contains Prebid ad in ${bannerConfig.publisherSlotName}")
            bannerConfig.session?.recordEvent(AdAnalyzed(BidderRecognizer.getBidderName(prebidSdkAdapter)))
        } else {
            DebugInfoManager.addFinalResultToDebugInfo(bannerConfig, "GAM")
            Logger.d("[StroeerBannerBuilder] Banner contains Google ad in ${bannerConfig.publisherSlotName}")
            bannerConfig.source.adSubSource = AdSource.Companion.GOOGLE
            bannerConfig.session?.recordEvent(AdAnalyzed(AD_SERVER_NAME))
        }
    }

    /*
        Load Confiant
     */
    private fun markForMonitoring() {
        // Monitoring
        ConfiantLoader.getInstance().mark(object : IAdReloader {
            override fun getAdSlot(): String? {
                return bannerConfig.publisherSlotName
            }

            override fun reloadAd(slotView: View?, placementId: String?) {
                refreshBanner()
            }

            override fun getAdView(): View? {
                return bannerConfig.adManagerAdView
            }
        })
    }



    private suspend fun runBidding() : Array<SdkResult>{
        var bidResults = arrayOf(SdkResult.SKIPPED)
        if(bannerConfig.adUnit!!.rtaAuction){
            prepareSdkManager()
            bidResults = getBid()
        }
        return bidResults
    }

    private fun checkIfRunGam(bidResults: Array<SdkResult>) : Pair<Boolean, SdkResult>{
        var runGAM = true
        var sdkBidResult = SdkResult.SKIPPED
        for(result in bidResults){
            if(result.category == AdCategory.CAMPAIGN){
                runGAM = false
            }

            if(result.resultCode == SdkResultCode.SUCCESS){
                runGAM = false
                sdkBidResult = result

                bannerConfig.prebidBannerView?.price?.let {
                    if(false) {
                        bannerConfig.bannerView?.removeAllViews()
                        bannerConfig.session?.recordEvent(RequestFinished())
                        DebugInfoManager.updateServeTime(bannerConfig)
                        bannerConfig.prebidBannerView?.let { it ->
                            // Call Load
                            bannerConfig.bannerView?.addBannerAdView(it)
                            it.eventListener?.get()?.onPrebidSdkWin()
                            bannerConfig.bannerView?.addDebugLabel()
                        }
                        bannerConfig.setReady()
                        bannerConfig.sessionEnd()
                    }else{
                        runGAM = true
                    }
                }

                // OnAdLoad will be called in BannerPrebidSdkAdapter
                break
            }
        }
        return Pair(runGAM,sdkBidResult)
    }

    private fun startGAM(bidResults: Array<SdkResult>){
        createGoogleAdView ()
        recordAdViewPreparedEvent()
        gamBidManager.callDfp(bidResults)
    }

    /**
     * Safely invokes the success callback when an ad is loaded.
     */
    private fun invokeOnSuccess(listener: IStroeerBannerListener?, view: StroeerBannerView?, config: BannerConfiguration? = null) {
        try {
            bannerConfig.sessionEnd()
            bannerConfig.setReady()
            listener?.onAdLoaded(view)
        } catch (ex: RuntimeException) {
            Logger.e("[StroeerBannerBuilder] Exception thrown during onAdLoaded callback - ${bannerConfig.publisherSlotName}", ex)
        }
    }

    /**
     * Safely invokes the failure callback when an ad fails to load.
     */
    private fun invokeOnFail(listener: IStroeerBannerListener?, publisherSlotName: String, exception: StroeerException, closeSession: Boolean = true) {
        if (closeSession) {
            bannerConfig.sessionEnd()
            bannerConfig.setError()
        }

        try {
            Logger.i("[StroeerBannerBuilder] onAdFailedToLoad called - $publisherSlotName : ${exception.message}")
            listener?.onAdFailedToLoad(bannerConfig.bannerView, exception)
        } catch (ex: Exception) {
            Logger.e("[StroeerBannerBuilder] Exception thrown during onAdFailedToLoad callback - $publisherSlotName", ex)
        }
    }

    /**
     * Destroys all banner-related resources including timers and views.
     */
    fun destroy() {
        cancelCoroutines()
        bannerConfig.destroy()
        gamBidManager.destroy()
        stopAutoRefresh()
    }

    /**
     * Destroys only banner views while keeping configuration state intact.
     */
    fun destroyViews() {
        Logger.i("[StroeerBannerBuilder] destroyViews called - ${bannerConfig.publisherSlotName}")
        bannerConfig.destroyViews()
    }
}