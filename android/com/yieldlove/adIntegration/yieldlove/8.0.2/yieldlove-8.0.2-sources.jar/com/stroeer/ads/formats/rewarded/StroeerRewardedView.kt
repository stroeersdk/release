package com.stroeer.ads.formats.rewarded


import android.content.Context
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.exceptions.ConfigurationIsNotLoadedException
import com.stroeer.ads.exceptions.PreviousAdLoadIsInProgressException
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.utilities.logging.Logger
import com.stroeer.ads.reporting.events.GamRespondedSuccessfully
import com.stroeer.ads.reporting.events.GamRespondedWithError
import com.stroeer.ads.reporting.events.UnexpectedErrorHappenDuringAdLoading
import com.stroeer.ads.formats.AdType
import com.stroeer.ads.formats.AStroeerAdBuilder
import com.stroeer.ads.bidding.gam.GamRewardedBidManager
import com.stroeer.ads.bidding.gam.IGamRewardedEventListener
import com.stroeer.ads.exceptions.DfpRewardedLoadAdError
import kotlinx.coroutines.*
import java.lang.ref.WeakReference

class StroeerRewardedView(context: Context) : AStroeerAdBuilder(RewardedConfiguration(context))  {
    private var callBackException: RuntimeException? = null

    val rewardConfig: RewardedConfiguration
        get() = adConfig as RewardedConfiguration

    var loadAfterReady : Boolean
        get(){ return rewardConfig.loadAfterReady }
        set(value){ rewardConfig.loadAfterReady = value}

    init {
        adConfig = RewardedConfiguration(context)
        MobileAds.initialize(context)
        gamBidManager = GamRewardedBidManager(rewardConfig)
    }

    fun load(publisherSlotName: String, listener: IStroeerRewardedListener? = null){
        coroutineScope.launch {
            loadAsync(publisherSlotName, listener)
        }
    }

    suspend fun loadAsync(publisherSlotName: String, listener: IStroeerRewardedListener?) {
        ConfigurationManager.getInstance().getConfigAsync()

        withContext(Dispatchers.Main) {
            try {
                if (!ConfigurationManager.getInstance().isLoaded) {
                    Logger.e("[StroeerRewarded] Configuration is not loaded - $publisherSlotName")
                    invokeFailEvent(listener, publisherSlotName, ConfigurationIsNotLoadedException())
                    return@withContext
                }

                if (adConfig.status.isLoading()) {
                    Logger.e("[StroeerRewarded] Previous ad load is in progress - $publisherSlotName")
                    invokeFailEvent(listener, publisherSlotName, PreviousAdLoadIsInProgressException(), false)
                    return@withContext
                }

                rewardConfig.initialize(publisherSlotName)
                rewardConfig.userListener = listener

                // Validate Context - must be Activity
                validateContext()

                prepareSession(AdType.REWARDED)

                cleanLocalVariables()

                initAdUnit()

                useAdsSoundSettingFrom()
                delay(1)

                startGAM()
            } catch(e : TimeoutCancellationException){
                Logger.d("[StroeerRewardedView] Timeout - $publisherSlotName")
                handleExceptions(e)
            }catch(_ : com.stroeer.ads.exceptions.ContextException){
                Logger.d("[StroeerRewardedView] Context is already dead - $publisherSlotName")
                rewardConfig.setError()
                // No handleExceptions call - context is dead, can't invoke callbacks or show fallback
            }
            catch (e: Exception) {
                Logger.e("[StroeerRewardedView] Exception occurred in loading rewarded - $publisherSlotName", e)
                handleExceptions(e)
            }
        }
    }

    private fun startGAM(){
        createGoogleAdView()
        recordAdViewPreparedEvent()
        callDfp()
    }



    private fun createGoogleAdView() {
        gamBidManager.initializeGoogleAdAViewIfNotExist()

        val weakListener = WeakReference(rewardConfig.userListener)
        val weakView = WeakReference(this@StroeerRewardedView)
        val weakConfig = WeakReference(rewardConfig)
        val weakFullListener = WeakReference(weakListener.get() as? IStroeerRewardedFullListener)

        if(weakFullListener.get() != null) {
            Logger.i("[StroeerRewardedView] Full Rewarded Listener is added" )
        }

        gamBidManager.createAdManagerAdView(object: IGamRewardedEventListener{
            override fun onAdLoaded(ad: RewardedAd){
                weakConfig.get()?.session?.recordEvent(GamRespondedSuccessfully())
                weakConfig.get()?.setReady()

                Logger.i("[StroeerRewardedView] onAdLoaded has been called - ${weakConfig.get()?.publisherSlotName}")

                try{
                    weakConfig.get()?.userListener?.onAdLoaded(ad)

                    if(weakConfig.get()?.loadAfterReady ?: false) {
                        weakView.get()?.show()
                    }
                }catch(exception: Exception){
                    Logger.e("[StroeerRewardedView] Exception happen in onAdLoaded callback - ${exception.message}", exception)
                }
            }

            override fun onAdFailedToLoad(exception: StroeerException){
                weakConfig.get()?.session?.recordEvent(GamRespondedWithError(exception))
                weakConfig.get()?.sessionEnd()
                Logger.i("[StroeerRewardedView] onAdFailedToLoad has been called - ${weakConfig.get()?.publisherSlotName}, ${exception.message}")

                try {
                    weakConfig.get()?.setError()
                    weakListener.get()?.onAdFailedToLoad(exception)
                }catch(e: Exception){
                    Logger.e("[StroeerRewardedView] Exception in onAdFailedToLoad callback", e)
                }
            }

            override fun onUserEarnedReward(rewardItem: RewardItem){
                try {
                    Logger.i("[StroeerRewardedView] onUserEarnedReward has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakListener.get()?.onUserEarnedReward(rewardItem)
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerRewardedView] Exception in onUserEarnedReward callback",
                        exception
                    )
                }
            }

            override fun onAdDismissedFullScreenContent(){
                try {
                    Logger.i("[StroeerRewardedView] onAdDismissedFullScreenContent has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdDismissedFullScreenContent()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerInterstitialView] Exception in onAdDismissedFullScreenContent callback",
                        exception
                    )
                }
            }

            override fun onAdFailedToShowFullScreenContent(exception: DfpRewardedLoadAdError){
                try {
                    Logger.i("[StroeerRewardedView] onAdFailedToShowFullScreenContent has been called - ${weakConfig.get()?.publisherSlotName}, ${exception.message}")
                    weakFullListener.get()?.onAdFailedToShowFullScreenContent(exception)
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerRewardedView] Exception in onAdFailedToShowFullScreenContent callback",
                        exception
                    )
                }
            }

            override fun onAdClicked() {
                try {
                    Logger.i("[StroeerRewardedView] onAdClicked has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdClicked()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerRewardedView] Exception in onAdClicked callback",
                        exception
                    )
                }
            }

            override fun onAdImpression() {
                try {
                    Logger.i("[StroeerRewardedView] onAdImpression has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdImpression()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerRewardedView] Exception in onAdImpression callback",
                        exception
                    )
                }
            }

            override fun onAdShowedFullScreenContent(){
                try {
                    Logger.i("[StroeerRewardedView] onAdShowedFullScreenContent has been called - ${weakConfig.get()?.publisherSlotName}")
                    weakFullListener.get()?.onAdShowedFullScreenContent()
                } catch (exception: RuntimeException) {
                    Logger.e(
                        "[StroeerRewardedView] Exception in onAdShowedFullScreenContent callback",
                        exception
                    )
                }
            }

            override fun isFullRewardEventListener() : Boolean {
                return weakFullListener.get() != null
            }

        } as Any)
    }

    private fun cleanLocalVariables() {
        this.callBackException = null
    }

    private fun callDfp() {
        gamBidManager.callDfp(arrayOf())
    }

    fun show() {
        Logger.i("[StroeerRewardedView] Show has been called")
        (gamBidManager as? GamRewardedBidManager)?.show()
    }

    private fun handleExceptions(exception: Exception) {
        Logger.e("[StroeerRewarded] Error caught", exception)
        rewardConfig.session?.recordEvent(UnexpectedErrorHappenDuringAdLoading(exception))
        invokeFailEvent(rewardConfig.userListener,rewardConfig.publisherSlotName, StroeerException(exception))
    }

    private fun invokeFailEvent(listener: IStroeerRewardedListener?, publisherSlotName: String, exception: StroeerException, closeSession : Boolean = true) {
        if(closeSession) {
            rewardConfig.sessionEnd()
            rewardConfig.setError()
        }
        try {
            listener?.onAdFailedToLoad(exception)
        } catch (ex: RuntimeException) {
            Logger.e("[StroeerRewarded] Exception happen in onAdFailedToLoad callback - $publisherSlotName", ex)
        }
    }

    /**
     * Destroys the rewarded ad and cleans up resources.
     *
     * Optional - typically not needed for one-shot rewarded ad loads as local variables.
     * Only necessary if storing rewarded ad as a field and want explicit cleanup.
     *
     * Cancels any running load operations and releases resources.
     */
    fun destroy() {
        cancelCoroutines()
        rewardConfig.destroy()
        gamBidManager.destroy()
    }
}
