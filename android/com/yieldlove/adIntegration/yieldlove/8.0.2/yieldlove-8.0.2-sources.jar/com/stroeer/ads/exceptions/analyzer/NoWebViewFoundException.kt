package com.stroeer.ads.exceptions.analyzer

import com.stroeer.ads.exceptions.StroeerException

class NoWebViewFoundException : StroeerException("No WebView found in the group")
