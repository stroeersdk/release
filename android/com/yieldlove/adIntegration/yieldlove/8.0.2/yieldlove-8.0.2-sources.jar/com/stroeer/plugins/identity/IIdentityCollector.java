package com.stroeer.plugins.identity;

import java.util.concurrent.CompletableFuture;

public interface IIdentityCollector<T>{
    CompletableFuture<T> retrieveData();
}
