package com.stroeer.ads.config.objects

class ConfigTasks :  ArrayList<ConfigTask>() {

    /**
     * Returns the first task with the specified ID.
     * @param id The ID of the task to find.
     * @return The first task with the specified ID, or null if not found.
     */
    fun getTaskById(id: String): ConfigTask? {
        return this.firstOrNull { it.id == id }
    }

    /**
     * Returns a list of tasks that are active and have a non-null order.
     * @return A list of active tasks with a defined order.
     */
    fun getActiveTasksWithOrder(): List<ConfigTask> {
        return this.filter { it.active && it.order != null }
    }

}

class ConfigTask(
    val id: String,
    val order: Int?,
    val active: Boolean,
    val onFail: List<String>? = null,
    val fallbackOnly: Boolean = false,
    val params: List<ConfigTaskParam>? = null
)

class ConfigTaskParam(
    val name: String,
    val enabled: Boolean,
    val include: List<String>? = null,
    val exclude: List<String>? = null
)