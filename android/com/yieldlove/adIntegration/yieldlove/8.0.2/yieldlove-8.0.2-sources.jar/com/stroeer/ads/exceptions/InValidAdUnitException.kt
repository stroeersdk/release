package com.stroeer.ads.exceptions

class InValidAdUnitException : StroeerException {
    constructor(message: String?) : super(message)

    constructor(exception: Exception?) : super(exception)
}
