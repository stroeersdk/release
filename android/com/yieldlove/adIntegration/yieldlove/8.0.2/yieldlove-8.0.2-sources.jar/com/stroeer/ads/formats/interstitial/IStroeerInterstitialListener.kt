package com.stroeer.ads.formats.interstitial

import com.stroeer.ads.exceptions.StroeerException

/**
 * Basic listener interface for interstitial ad load events.
 *
 * Implement this interface to receive callbacks about whether an
 * interstitial ad was successfully loaded or failed to load.
 */
interface IStroeerInterstitialListener {

    /**
     * Called when the interstitial ad has successfully loaded and is ready to be shown.
     */
    fun onAdLoaded()

    /**
     * Called when the interstitial ad fails to load.
     *
     * @param exception A [StroeerException] describing the reason for the failure,
     *                  or `null` if no additional information is available.
     */
    fun onAdFailedToLoad(exception: StroeerException?)
}