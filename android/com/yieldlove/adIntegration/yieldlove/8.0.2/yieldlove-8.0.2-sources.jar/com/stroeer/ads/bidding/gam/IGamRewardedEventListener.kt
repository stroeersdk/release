package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.exceptions.DfpRewardedLoadAdError
import com.stroeer.ads.exceptions.StroeerException

interface IGamRewardedEventListener {
    fun onAdLoaded(ad: RewardedAd)
    fun onAdFailedToLoad(error: StroeerException)
    fun onAdDismissedFullScreenContent()
    fun onAdFailedToShowFullScreenContent(err: DfpRewardedLoadAdError)
    fun onUserEarnedReward(rewardItem: RewardItem)
    fun onAdImpression()
    fun onAdClicked()
    fun onAdShowedFullScreenContent()
    fun isFullRewardEventListener() : Boolean
}