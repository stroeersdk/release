package com.stroeer.plugins.backfill;

import android.widget.FrameLayout;

import com.stroeer.plugins.backfill.gravite.IFirstBannerLoaded;
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit;

/**
 * Interface to handle loading and retrieving banners for backfill ad units.
 */
public interface IBackFillBanner {

    /**
     * Load a banner ad for backfill using the specified ad unit data.
     *
     * @param ylAdUnitData Data object containing the ad unit information needed to load the banner.
     */
    void loadBanner(YieldloveAdUnit ylAdUnitData, IFirstBannerLoaded loaded);

    /**
     * Retrieve the currently loaded banner for the specified ad unit.
     *
     * @param ylAdUnitData Data object containing the ad unit information for which the banner is being retrieved.
     * @return The FrameLayout containing the banner, or null if no banner is available.
     */
    FrameLayout getBanner(YieldloveAdUnit ylAdUnitData);
}