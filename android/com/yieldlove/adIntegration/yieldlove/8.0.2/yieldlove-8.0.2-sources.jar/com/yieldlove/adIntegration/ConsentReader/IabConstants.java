package com.yieldlove.adIntegration.ConsentReader;

public class IabConstants {
    public static final String IABTCF_VendorConsents_KEY = "IABTCF_VendorConsents";
    public static final String IABTCF_PurposeConsents_KEY = "IABTCF_PurposeConsents";
    public static final String IABTCF_VendorLIConsents_KEY = "IABTCF_VendorLegitimateInterests";
    public static final String IABTCF_PurposeLIConsents_KEY = "IABTCF_PurposeLegitimateInterests";
    public static final String IABTCF_PublisherRestrictionsKEY_Pattern = "IABTCF_PublisherRestrictions{ID}";
    public static final String IABTCF_PublisherRestrictionsId_ReplaceHolder = "{ID}";
    public static final String IABTCF_TCString_KEY = "IABTCF_TCString";
}
