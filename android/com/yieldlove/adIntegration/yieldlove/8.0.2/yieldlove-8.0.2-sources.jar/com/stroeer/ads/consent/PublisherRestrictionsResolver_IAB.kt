package com.stroeer.ads.consent

import android.content.Context
import com.stroeer.ads.consent.ConsentRestrictionType.Companion.from

class PublisherRestrictionsResolver_IAB(applicationContext: Context) :
    IPublisherRestrictionsResolver {
    private val reader: ConsentReader_IAB
    private val evaluator: ConsentEvaluator_IAB
    private val nonFlexiblePurpose1Id = 1

    init {
        this.reader = ConsentReader_IAB(applicationContext)
        this.evaluator = ConsentEvaluator_IAB(this.reader)
    }

    override fun resolve(vendorId: Int, purposeId: Int): Boolean {
        val type = this.getPublisherPurposeRestriction(vendorId, purposeId)
        return when (type) {
            ConsentRestrictionType.REQUIRE_CONSENT -> this.evaluator.evaluateConsentRequired(
                vendorId,
                purposeId
            )

            ConsentRestrictionType.REQUIRE_LEGITIMATE_INTEREST, ConsentRestrictionType.UNDEFINED -> {
                if (purposeId == this.nonFlexiblePurpose1Id) {
                    this.evaluator.evaluateConsentRequired(vendorId, purposeId)
                }
                this.evaluator.evaluateLegitimateInterestRequired(vendorId, purposeId)
            }

            else -> false
        }
    }

    private fun getPublisherPurposeRestriction(
        vendorId: Int,
        purposeId: Int
    ): ConsentRestrictionType {
        val encodedString = this.reader.getPublisherRestrictionsFor(purposeId)
        if (!encodedString.isEmpty() && encodedString.length >= vendorId) {
            val type = encodedString[this.convertIdToIndex(vendorId)].toString().toInt()
            return from(type)
        }
        return ConsentRestrictionType.UNDEFINED
    }

    private fun convertIdToIndex(vendorId: Int): Int {
        return vendorId - 1
    }
}

