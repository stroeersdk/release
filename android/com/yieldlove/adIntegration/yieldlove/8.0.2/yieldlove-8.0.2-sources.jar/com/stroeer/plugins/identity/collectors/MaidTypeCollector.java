package com.stroeer.plugins.identity.collectors;

import com.stroeer.plugins.identity.IIdentityCollector;

import java.util.concurrent.CompletableFuture;

/**
 * Return maid type, Google is gaid. Constant value.
 */
public class MaidTypeCollector implements IIdentityCollector<String> {
    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.completedFuture("gaid");
    }
}
