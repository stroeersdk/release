package com.stroeer.ads.config.objects

/**
 * "PREBID": {
 * *           "yieldloveAccountId": "fussball-live-ticker-herzrasen"
 * *         },
 */
class ConfigModule_Prebid {
    var yieldloveAccountId: String? = null
}
