package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest

internal object GamAdRequestBuilderMerger {

    fun merge(
        globalBuilder: AdManagerAdRequest.Builder,
        localBuilder: AdManagerAdRequest.Builder
    ): AdManagerAdRequest.Builder {
        val globalRequest = globalBuilder.build()
        val localRequest = localBuilder.build()

        mergeCustomTargeting(localBuilder, globalRequest, localRequest)
        mergeContentUrl(localBuilder, globalRequest, localRequest)
        mergeKeywords(localBuilder, globalRequest, localRequest)
        mergePublisherProvidedId(localBuilder, globalRequest, localRequest)

        return localBuilder
    }

    private fun mergePublisherProvidedId(
        builder: AdManagerAdRequest.Builder,
        globalRequest: AdManagerAdRequest,
        localRequest: AdManagerAdRequest
    ) {
        @Suppress("SENSELESS_COMPARISON")
        if(localRequest.publisherProvidedId == null) {
            builder.setPublisherProvidedId(globalRequest.publisherProvidedId)
        }
    }

    private fun mergeKeywords(
        builder: AdManagerAdRequest.Builder,
        globalRequest: AdManagerAdRequest,
        localRequest: AdManagerAdRequest
    ) {
        val localKeyWords = localRequest.keywords

        for (keyword in globalRequest.keywords) {
            if (!localKeyWords.contains(keyword)) {
                builder.addKeyword(keyword)
            }
        }
    }

    private fun mergeContentUrl(
        builder: AdManagerAdRequest.Builder,
        globalRequest: AdManagerAdRequest,
        localRequest: AdManagerAdRequest
    ) {
        @Suppress("SENSELESS_COMPARISON")
        if (localRequest.contentUrl == null && globalRequest.contentUrl != null) {
            builder.setContentUrl(globalRequest.contentUrl)
        }
    }

    private fun mergeCustomTargeting(
        builder: AdManagerAdRequest.Builder,
        globalRequest: AdManagerAdRequest,
        localRequest: AdManagerAdRequest
    ) {
        val globalCustomTargeting = globalRequest.customTargeting
        val localCustomTargeting = localRequest.customTargeting

        for (key in globalCustomTargeting.keySet()) {
            if (!localCustomTargeting.containsKey(key)) {
                builder.addCustomTargeting(key, globalCustomTargeting.getString(key)!!)
            }
        }
    }
}