package com.yieldlove.adIntegration.ExternalConfiguration.ConfigMapperObjects;

public class ConfigCustomAdSize {

    public Integer w;
    public Integer h;

}
