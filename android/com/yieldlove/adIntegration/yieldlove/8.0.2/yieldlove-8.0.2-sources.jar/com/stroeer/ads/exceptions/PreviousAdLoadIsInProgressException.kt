package com.stroeer.ads.exceptions

class PreviousAdLoadIsInProgressException :
    StroeerException("Previous ad load is in progress. You must wait till finish.")