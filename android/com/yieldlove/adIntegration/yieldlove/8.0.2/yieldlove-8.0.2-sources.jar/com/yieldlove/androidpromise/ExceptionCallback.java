package com.yieldlove.androidpromise;

public interface ExceptionCallback<T extends Throwable> {
    void fail(T e);
}
