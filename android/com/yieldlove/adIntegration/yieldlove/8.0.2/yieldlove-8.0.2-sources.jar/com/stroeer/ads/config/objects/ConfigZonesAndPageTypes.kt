package com.stroeer.ads.config.objects

/**
 * "zonesAndPageTypes": {
 * *         "level1": {
 * *             "homepage": {
 * *                 "keyValues": {
 * *                     "test": "testValue"
 * *                 }
 * *             }
 * *         },
 * *         "level2": {
 * *             "sport": {
 * *                 "keyValues": {
 * *                     "country": "de"
 * *                 }
 * *             }
 * *         },
 * *         "pageType": {
 * *             "rubrik": {
 * *                 "keyValues": {
 * *                     "sport": "football"
 * *                 }
 * *             }
 * *         }
 * *     },
 */
class ConfigZonesAndPageTypes {
    var level1: MutableMap<String, MutableMap<String, MutableMap<String, String>>>? = null
    var level2: MutableMap<String, MutableMap<String, MutableMap<String, String>>>? = null
    var pageType: MutableMap<String, MutableMap<String, MutableMap<String, String>>>? = null
}
