package com.stroeer.utilities.ui

import android.graphics.Rect
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView

object SizeChecker {

    data class WebViewSize(
        val webView: WebView,
        val widthPx: Int,
        val heightPx: Int,
        val widthDp: Int,
        val heightDp: Int,
        val globalBounds: Rect
    ) {
        override fun toString(): String {
            return buildString {
                appendLine("WebViewSize(")
                appendLine("  webView=${webView.hashCode()} (${webView.javaClass.simpleName})")
                appendLine("  widthPx=$widthPx, heightPx=$heightPx")
                appendLine("  widthDp=$widthDp, heightDp=$heightDp")
                appendLine("  globalBounds=[left=${globalBounds.left}, top=${globalBounds.top}, right=${globalBounds.right}, bottom=${globalBounds.bottom}]")
                append(")")
            }
        }
    }

    fun findFirstWebViewSize(root: View): WebViewSize? {
        return collectWebViewSizes(root).firstOrNull()
    }

    fun collectWebViewSizes(root: View): List<WebViewSize> {
        val out = mutableListOf<WebViewSize>()
        fun visit(v: View) {
            if (v is WebView) {
                val density = v.resources.displayMetrics.density
                val wPx = v.width
                val hPx = v.height
                val wDp = (wPx / density).toInt()
                val hDp = (hPx / density).toInt()
                val bounds = Rect().apply { v.getGlobalVisibleRect(this) }

                out += WebViewSize(v, wPx, hPx, wDp, hDp, bounds)
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) visit(v.getChildAt(i))
            }
        }
        visit(root)
        return out
    }
}