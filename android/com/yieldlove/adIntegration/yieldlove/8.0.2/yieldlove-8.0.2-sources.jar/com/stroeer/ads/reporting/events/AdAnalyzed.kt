package com.stroeer.ads.reporting.events

import com.google.gson.JsonObject

class AdAnalyzed(var winner: String?) : TimeEvent() {
    override fun toJsonObject(): JsonObject {
        val jsonObject = super.toJsonObject()
        jsonObject.addProperty("winner", this.winner)
        return jsonObject
    }
}
