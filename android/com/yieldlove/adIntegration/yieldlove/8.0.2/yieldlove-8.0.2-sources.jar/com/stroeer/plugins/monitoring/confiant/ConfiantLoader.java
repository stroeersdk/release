package com.stroeer.plugins.monitoring.confiant;

import com.stroeer.ads.config.ConfigurationManager;
import com.stroeer.ads.config.objects.ConfigModule_Confiant;
import com.stroeer.plugins.monitoring.AdMonitorRefresher;
import com.stroeer.plugins.monitoring.IAdMonitorCallback;
import com.stroeer.plugins.monitoring.IAdMonitoring;
import com.stroeer.utilities.concurrent.RunAsync;
import com.stroeer.utilities.logging.Logger;
import com.stroeer.plugins.monitoring.IAdReloader;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class ConfiantLoader {
    enum ConfiantState {
        NOT_INITIALIZED,
        INITIALIZING,
        INITIALIZED,
        FAILED_INITIALIZATION, // Initialization failed. Can be restarted

        FAILED_NOT_ACTIVATED,  // Confiant module not active in configuration
        FAILED_NO_SDK,         // Confiant SDK not found
        FAILED_NO_PLUGIN,      // Confiant plugin not found
        FAILED_INVALID_CONFIG  // Invalid configuration ex) propertyID is empty
    }

    // Singleton instance
    private static ConfiantLoader instance = null;

    // Internal state variables
    private boolean hasConfiant = false;
    private IAdMonitoring confiantWrapperInstance = null;
    private ConfiantState status = ConfiantState.NOT_INITIALIZED;
    private boolean testMode = false;
    private boolean reloadMode = false;
    private String confiantPropertyId = null;
    private IAdMonitorCallback callback = null;

    // Private constructor for singleton pattern
    private ConfiantLoader() {}

    /**
     * Returns the singleton instance of ConfiantPlugin.
     *
     * @return the single instance of ConfiantPlugin.
     */
    public static ConfiantLoader getInstance() {
        if (instance == null) {
            instance = new ConfiantLoader();
        }
        return instance;
    }



    /**
     * Initializes the Confiant plugin with the given property ID.
     * This version does not enable reload mode and does not use a callback.
     *
     * @param confiantPropertyId the property ID for initialization.
     */
    public void initialize(String confiantPropertyId) {
        initialize(confiantPropertyId, false, null);
    }

    /**
     * Initializes the Confiant plugin with advanced settings.
     *
     * @param confiantPropertyId the property ID for initialization.
     * @param enableReload       whether to enable reload mode.
     * @param callback           callback to handle initialization success/failure.
     */
    public void initialize(String confiantPropertyId, boolean enableReload, IAdMonitorCallback callback) {

        this.confiantPropertyId = confiantPropertyId;
        this.reloadMode = enableReload;
        this.callback = callback;
        initializeAsync();
    }

    protected synchronized void initializeAsync(){

        if(status.ordinal() >= ConfiantState.FAILED_NOT_ACTIVATED.ordinal() || status == ConfiantState.INITIALIZING || isRunnable()){
            return;
        }

        if(confiantPropertyId == null || confiantPropertyId.isEmpty()) {
            Logger.e("[ConfiantPlugin] Confiant property ID is null or empty. Initialization failed.");
            status = ConfiantState.FAILED_INVALID_CONFIG;
            if (callback != null) {
                callback.onInitialized(false);
            }
            return;
        }

        status = ConfiantState.INITIALIZING;
        Logger.d("[ConfiantPlugin] Confiant is initializing");

        RunAsync.run(()-> {

            // Wait for configuration to be loaded
            int timeout = 0;
            while(!ConfigurationManager.getInstance().isLoaded())
            {
                try {
                    Thread.sleep(1000);
                    if(++timeout == 3) break;
                } catch (InterruptedException e) {
                    Logger.e("[ConfiantPlugin] Failed to wait for Configuration", e);
                }
            }

            // Check if the configuration is loaded
            if(ConfigurationManager.getInstance().isLoaded()){
                if(testMode){
                    ConfigurationManager.getInstance().getConfig().getModules().getConfiant().setActive(true);
                    Logger.i("[ConfiantPlugin] Test mode enabled, Confiant module activated");
                }
                // Check if the Confiant module is active in the configuration
                ConfigModule_Confiant confiantConfig = ConfigurationManager.getInstance().getConfig().getModules().getConfiant();
                if (confiantConfig == null || !confiantConfig.getActive()) {
                    Logger.i("[ConfiantPlugin] Confiant module is not activated");
                    status = ConfiantState.FAILED_NOT_ACTIVATED;
                    if (callback != null) {
                        callback.onInitialized(false);
                    }
                    return;
                }
                else {
                    Logger.i("[ConfiantPlugin] Confiant module is activated");
                }

            } else {
                Logger.i("[ConfiantPlugin] Configuration not loaded yet");
                status = ConfiantState.NOT_INITIALIZED;
                if (callback != null) {
                    callback.onInitialized(false);
                }
                return;
            }

            // Load necessary classes for the Confiant SDK and wrapper
            if (!loadConfiantClasses()) {
                hasConfiant = false;
                return;
            }

            hasConfiant = true;

            // Enable test mode if set
            if (testMode) {
                confiantWrapperInstance.enableTestMode();
            }

            // Enable reload mode if set
            if (reloadMode) {
                confiantWrapperInstance.enableReload();
            }

            // Initialize the Confiant SDK with a callback
            confiantWrapperInstance.initialize(confiantPropertyId, success -> {
                status = success ? ConfiantState.INITIALIZED : ConfiantState.FAILED_INITIALIZATION;
                // Invoke the provided callback if not null
                if (callback != null) {
                    callback.onInitialized(success);
                }
            });
        }, 0, e -> {;
            // Handle any exceptions that occur during initialization
            Logger.e("[ConfiantPlugin] Error initializing Confiant SDK:", e);
            status = ConfiantState.NOT_INITIALIZED;
            if (callback != null) {
                callback.onInitialized(false);
            }
        });
    }

    /**
     * Checks if the Confiant SDK exists and is properly loaded.
     *
     * @return true if the SDK is available, false otherwise.
     */
    public boolean doesExist() {
        return hasConfiant;
    }

    /**
     * Enables the test mode for the Confiant plugin.
     */
    public void enableTestMode() {
        testMode = true;
    }

    /**
     * Marks an ad for monitoring using the provided IAdReloader.
     *
     * @param adReloader the reloader instance containing ad information.
     */
    public void mark(IAdReloader adReloader) {
        initializeAsync();
        if (isRunnable() && reloadMode && adReloader != null) {
            // Register the ad reloader with the monitor refresher
            AdMonitorRefresher.getInstance().addNewReloader(adReloader);
            // Mark the ad view and ad slot for monitoring
            confiantWrapperInstance.mark(adReloader.getAdView(), adReloader.getAdSlot());
        }
    }

    /**
     * Checks if the Confiant plugin is in a runnable state.
     *
     * @return true if it is ready to run, false otherwise.
     */
    public boolean isRunnable() {
        return hasConfiant && status == ConfiantState.INITIALIZED && confiantWrapperInstance != null;
    }

    /**
     * Loads the Confiant SDK and wrapper classes dynamically.
     *
     * @return true if both the SDK and wrapper are successfully loaded, false otherwise.
     */
    @SuppressWarnings("unchecked")
    private boolean loadConfiantClasses() {
        if(confiantWrapperInstance != null) {
            return true;
        }

        try {
            // Load the Confiant wrapper class
            Class<IAdMonitoring> confiantClass = (Class<IAdMonitoring>) Class.forName("com.stroeer.confiant.ConfiantWrapper");
            confiantWrapperInstance = confiantClass.getDeclaredConstructor().newInstance();
            Logger.i("[ConfiantPlugin] Confiant Plugin found");
            status = ConfiantState.FAILED_NO_PLUGIN;
        } catch (Exception e) {
            Logger.i("[ConfiantPlugin] Confiant plugin not found");
            return false;
        }

        try {
            // Check for the Confiant SDK
            Class.forName("com.confiant.android.sdk.Confiant");
            Logger.i("[ConfiantPlugin] Confiant SDK found");
            status = ConfiantState.FAILED_NO_SDK;
        } catch (ClassNotFoundException e) {
            Logger.i("[ConfiantPlugin] Confiant SDK not found");
            return false;
        }

        return true;
    }

    /**
     * Resets the Confiant plugin to its initial state. This is only for test purposes.
     */
    public static void reset(){
        Logger.e("[ConfiantPlugin] Resetting ConfiantLoader instance. This should not be called in production.");
        instance = null;
    }

    public void setConfiantWrapperInstance(IAdMonitoring confiantWrapperInstance) {
        Logger.e("[ConfiantPlugin] Setting ConfiantWrapper instance. This should not be called in production.");
        this.confiantWrapperInstance = confiantWrapperInstance;
        this.hasConfiant = true;
    }

    public void updateStatus(ConfiantState status) {
        Logger.e("[ConfiantPlugin] Updating status. This should not be called in production.");
        this.status = status;
    }
}