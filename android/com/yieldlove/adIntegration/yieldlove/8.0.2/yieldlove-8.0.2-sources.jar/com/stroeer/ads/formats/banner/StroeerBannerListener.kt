package com.stroeer.ads.formats.banner

import com.stroeer.ads.exceptions.StroeerException

/**
 * Default implementation of [IStroeerBannerListener] with empty callbacks.
 *
 * This class can be extended so that only the callbacks you care about
 * need to be overridden, avoiding the need to implement all methods manually.
 */
open class StroeerBannerListener : IStroeerBannerListener {
    /**
     * Called when the ad has successfully loaded and is ready to be displayed.
     *
     * @param banner The [StroeerBannerView] instance that received the ad.
     */
    override fun onAdLoaded(banner: StroeerBannerView?) {}

    /**
     * Called when the ad fails to load.
     *
     * @param banner The [StroeerBannerView] that attempted to load the ad.
     * @param error  The [StroeerException] describing the failure reason.
     */
    override fun onAdFailedToLoad(banner: StroeerBannerView?, error: StroeerException) {}

    /**
     * Called when the ad opens a full-screen overlay (for example, when the user clicks the ad).
     *
     * @param banner The [StroeerBannerView] that triggered the event.
     */
    override fun onAdOpened(banner: StroeerBannerView?) {}

    /**
     * Called when the ad is closed and control returns to the app.
     *
     * @param banner The [StroeerBannerView] that triggered the event.
     */
    override fun onAdClosed(banner: StroeerBannerView?) {}

    /**
     * Called when the ad is clicked by the user.
     *
     * @param banner The [StroeerBannerView] that was clicked.
     */
    override fun onAdClicked(banner: StroeerBannerView?) {}

    /**
     * Called when the ad records an impression (i.e., is visible to the user).
     *
     * @param banner The [StroeerBannerView] that displayed the impression.
     */
    override fun onAdImpression(banner: StroeerBannerView?) {}
}