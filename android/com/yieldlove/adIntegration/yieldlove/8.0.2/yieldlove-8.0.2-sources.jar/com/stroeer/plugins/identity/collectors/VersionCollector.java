package com.stroeer.plugins.identity.collectors;

import android.content.pm.PackageInfo;

import com.stroeer.plugins.identity.ACollectorWithContext;
import com.stroeer.utilities.logging.Logger;

import java.util.concurrent.CompletableFuture;
/**
 * Return version name
 */
public class VersionCollector extends ACollectorWithContext<String> {

    @Override
    public CompletableFuture<String> retrieveData() {
        try {
            PackageInfo pInfo = applicationContext.getPackageManager()
                            .getPackageInfo(applicationContext.getPackageName(), 0);

            return CompletableFuture.completedFuture(pInfo.versionName);
        } catch (Exception e) {
            Logger.e("[VersionCollector] Failed to get version name", e);
            return CompletableFuture.completedFuture("Unknown");
        }
    }
}
