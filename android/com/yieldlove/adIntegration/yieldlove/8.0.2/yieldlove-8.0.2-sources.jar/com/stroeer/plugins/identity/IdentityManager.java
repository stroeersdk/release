package com.stroeer.plugins.identity;

import android.content.Context;

import com.stroeer.ads.config.ConfigurationManager;
import com.stroeer.plugins.identity.objects.IdentityCache;
import com.stroeer.plugins.identity.objects.IdentityCustomInfo;
import com.stroeer.utilities.common.ISuccessFailListener;
import com.stroeer.utilities.logging.Logger;
import java.util.Date;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.locks.ReentrantLock;

public class IdentityManager {
    private static IdentityManager _instance = new IdentityManager();

    protected IIdentityManager identityManager;
    protected ISuccessFailListener<Object> listener;
    protected IdentityCustomInfo customInfo = null;

    protected ReentrantLock lock = new ReentrantLock();

    public static IdentityManager getInstance() {
        return _instance;
    }

    public static void setInstance(IdentityManager instance) {
        Logger.e("[IdentityManager] instance is set. This should not be called in Production");
        _instance = instance;
    }

    /**
     * Configures the identity manager to use ID5 as the default provider.
     */
    public void useID5(){
        identityManager = com.stroeer.plugins.identity.id5.ID5Manager.getInstance();
    }


    /**
     * Initializes the IdentityManager with application context and a listener.
     *
     * @param applicationContext Application context.
     * @param listener Callback listener for success or failure events.
     */
    public synchronized void initialize(Context applicationContext, ISuccessFailListener<Object> listener) {

        this.listener = listener;

        if(!ConfigurationManager.getInstance().isLoaded())
        {
            Logger.e("[IdentityManager] Configuration not loaded. Initialization skipped.");
            if(listener != null) listener.onFailed();
            return;
        }

        if(identityManager == null)
        {
            Logger.i("[IdentityManager] Identity Manager is not set by user. Trying to find a default Identity Manager");

            if(ConfigurationManager.getInstance().getConfig().getModules().getId5().getActive())
            {
                Logger.i("[IdentityManager] ID5 is active. Using ID5 as default Identity Manager");
                useID5();
            }
        }

        // Still no identity manager set
        if(identityManager == null)
        {
            Logger.e("[IdentityManager] No identity manager set. Identity Manager is disabled.");
            if(listener != null) listener.onFailed();
            return;
        }

        identityManager.initialize(applicationContext);
        loadAsync();
    }

    /**
     * Loads identity information from storage or triggers refresh if needed.
     */
    public void load(){
        if(isNotInitialized()){
            return;
        }

        // Reload Configuration
        if(ConfigurationManager.getInstance().getConfig() == null)
        {
            Logger.e("[IdentityManager] Configuration is not loaded yet. Skipping the IdentityManager until Configuration is loaded. Do not attempt to load IdentityManager before the configuration is loaded.");
            return;
        }

        Logger.i("[IdentityManager] Loading from the local storage");

        identityManager.loadConsentStringFromStorage();
        refresh();
    }

    public void loadAsync(){
        CompletableFuture.runAsync(this::load).exceptionally(e -> {
            Logger.e("[IdentityManager] Failed to load identity", e);
            return null;
        });
    }

    /**
     * Refreshes identity data by checking cache and reloading if necessary.
     */
    public void refresh() {
        if(isNotInitialized()){
            return;
        }

        if(!lock.tryLock()) {
            Logger.d("[IdentityManager] Refresh is already in progress. Skipping the fresh");
            return;
        }

        try {
            boolean shouldRefresh = true;
            IdentityCache identityData = identityManager.getIdentityData();

            if (identityData != null) {
                if (ConfigurationManager.getInstance().isDebugMode()) {
                    identityData.setRefreshInterval(300);
                    Logger.d("[IdentityManager] As the debug mode is enabled, the interval is automatically changed to " + identityData.getRefreshInterval());
                } else {
                    identityData.setDefaultRefreshInterval();
                }

                long cacheExpiryTime = identityData.getCacheCreationDate().getTime() + identityData.getRefreshInterval() * 1000;
                shouldRefresh = cacheExpiryTime < new Date().getTime() || identityManager.isUpdated();

                Logger.d("[IdentityManager] Cache check: Cache date: " + identityData.getCacheCreationDate()
                        + ", Current date: " + new Date()
                        + ", Interval: " + identityData.getRefreshInterval()
                        + ", Is request updated: " + identityManager.isUpdated()
                        + ", Refresh needed: " + shouldRefresh);
            }

            // Set Custom Information
            identityManager.setCustomInfo(customInfo);

            if (identityData == null || shouldRefresh) {
                Logger.i("[IdentityManager] Refreshing identity data from HTTP.");
                identityManager.loadConsentStringFromHttp(false);
            }

            identityData = identityManager.getIdentityData();

            if (identityData == null) {
                Logger.i("[IdentityManager] Failed to load identity, identity data is empty.");
                if (listener != null) listener.onFailed();
            } else {
                if(shouldRefresh) Logger.i("[IdentityManager] Identity successfully loaded.");
                if (listener != null) listener.onSuccess(identityData);
            }
        }finally {
            lock.unlock();
        }
    }

    /**
     * Asynchronously refreshes identity data.
     */
    public void refreshAsync(){
        CompletableFuture.runAsync(this::refresh).exceptionally(e -> {
            Logger.e("[IdentityManager] Failed to refresh identity", e);
            return null;
        });
    }

    public void setUserIdToPrebid(){
        if(isNotInitialized()){
            return;
        }

        identityManager.setUserIdToPrebid();
    }

    /**
     * Checks if the identity manager is initialized.
     *
     * @return false if initialized, true otherwise.
     */
    private boolean isNotInitialized(){
        return identityManager == null;
    }

    public void setCustomInfo(IdentityCustomInfo customInfo) {
        // This is because this custominfo can be set before initialization
        this.customInfo = customInfo;
    }
}
