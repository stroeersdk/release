package com.stroeer.ads.reporting.events

import com.google.gson.JsonObject

open class TimeEvent {
    var timeSinceMeasuringStarted: Int = 0

    open fun toJsonObject(): JsonObject {
        val jsonObject = JsonObject()
        jsonObject.addProperty("type", this.javaClass.getSimpleName())
        jsonObject.addProperty("time", this.timeSinceMeasuringStarted)
        return jsonObject
    }

    override fun toString() : String {
        return "${this.javaClass.getSimpleName()}: $timeSinceMeasuringStarted"
    }
}
