package com.yieldlove.adIntegration.Monitoring;

import com.yieldlove.adIntegration.IabConsentResolver.PublisherRestrictionsResolver;

public class MonitoringConsent {
    private static final int IabStroeerSSPVendorId = 136;
    private static final int IabStroeerVendorId = 1057;
    private static final int IabPurposeStoreAccessInformationOnDeviceId = 1;
    private static final int IabPurposeProductDevelopmentId = 10;
    private final PublisherRestrictionsResolver restrictionsResolver;

    public MonitoringConsent(PublisherRestrictionsResolver restrictionsResolver) {
        this.restrictionsResolver = restrictionsResolver;
    }

    public boolean canWeUseMonitoring() {
        boolean stroeerSSPPurpose1 = this.restrictionsResolver.resolve(IabStroeerSSPVendorId, IabPurposeStoreAccessInformationOnDeviceId);
        boolean stroeerPurpose1 = this.restrictionsResolver.resolve(IabStroeerVendorId, IabPurposeStoreAccessInformationOnDeviceId);
        boolean stroeerSSPPurpose2 = this.restrictionsResolver.resolve(IabStroeerSSPVendorId, IabPurposeProductDevelopmentId);
        boolean stroeerPurpose2 = this.restrictionsResolver.resolve(IabStroeerVendorId, IabPurposeProductDevelopmentId);

        return stroeerSSPPurpose1 && stroeerSSPPurpose2 && stroeerPurpose1 && stroeerPurpose2;
    }
}
