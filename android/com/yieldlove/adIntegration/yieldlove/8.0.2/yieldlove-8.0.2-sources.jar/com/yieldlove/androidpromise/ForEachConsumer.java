package com.yieldlove.androidpromise;

public interface ForEachConsumer<T, R> {
    Promise<R> run(T value);
}
