package com.yieldlove.adIntegration.IabConsentResolver;

public interface PublisherRestrictionsResolver {
    boolean resolve(int vendorId, int purposeId);
}
