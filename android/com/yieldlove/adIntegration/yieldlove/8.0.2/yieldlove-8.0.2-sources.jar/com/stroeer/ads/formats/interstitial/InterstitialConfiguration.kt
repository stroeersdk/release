package com.stroeer.ads.formats.interstitial

import android.content.Context
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.admanager.AdManagerInterstitialAd
import com.stroeer.ads.formats.AAdConfiguration

/**
 * Holds configuration for an interstitial ad instance.
 *
 * Extends [AAdConfiguration] to add interstitial-specific properties such as
 * the Google Ad Manager interstitial object and event listener.
 */
class InterstitialConfiguration(context: Context) : AAdConfiguration(context) {

    /** Listener for interstitial ad lifecycle events (load, show, dismiss, etc.). */
    var userListener: IStroeerInterstitialListener? = null

    /** Flag indicating whether to load the ad immediately after it's ready. */
    var loadAfterReady: Boolean = true

    /**
     * Cleans up resources used by this interstitial configuration.
     *
     * - Calls [AAdConfiguration.destroy] to release base resources.
     * - Clears the [fullScreenContentCallback] to avoid memory leaks.
     * - Releases the [adManagerInterstitialAd] reference.
     * - Clears the [userListener] reference.
     */
    override fun destroy() {
        super.destroy()
        userListener = null
    }
}