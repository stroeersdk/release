package com.stroeer.plugins.identity.collectors;

import android.webkit.WebSettings;

import com.stroeer.plugins.identity.ACollectorWithContext;

import java.util.concurrent.CompletableFuture;

/**
 * Return user agent
 */
public class UaCollector extends ACollectorWithContext<String> {

    @Override
    public CompletableFuture<String> retrieveData() {
        return CompletableFuture.completedFuture(WebSettings.getDefaultUserAgent(applicationContext));
    }
}
