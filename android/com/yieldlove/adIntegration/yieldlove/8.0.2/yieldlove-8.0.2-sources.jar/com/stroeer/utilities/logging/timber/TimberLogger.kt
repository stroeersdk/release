package com.stroeer.utilities.logging.timber

import android.util.Log
import com.stroeer.utilities.logging.ILogger
import timber.log.Timber

class TimberLogger(isDebugMode: Boolean) : ILogger {
    init {
        if (isDebugMode) {
            Timber.plant(DebugTree())
        } else {
            Timber.plant(ReleaseTree())
        }
    }

    override fun dispose(){
        Timber.uprootAll()
        Log.i("StroeerSDK", "[TimberLogger] Disposed")
    }

    override fun d(tag: String, message: String) {
        Timber.tag(tag).d(message)
    }

    override fun i(tag: String, message: String) {
        Timber.tag(tag).i(message)
    }

    override fun w(tag: String, message: String) {
        Timber.tag(tag).w(message)
    }

    override fun e(tag: String, message: String) {
        e(tag, message, null)
    }

    override fun e(tag: String, message: String, throwable: Throwable?) {
        if (throwable != null) {
            Timber.tag(tag).e(throwable, message)
        } else {
            Timber.tag(tag).e(message)
        }
    }
}

internal class DebugTree : Timber.Tree() {
    override fun isLoggable(tag: String?, priority: Int): Boolean {
        // Only log WARN, ERROR, and ASSERT levels
        return priority >= Log.DEBUG
    }

    override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
        // Optionally, log to Logcat
        Log.println(priority, tag, message)
    }
}

internal class ReleaseTree : Timber.Tree() {
    override fun isLoggable(tag: String?, priority: Int): Boolean {
        // Only log WARN, ERROR, and ASSERT levels
        return priority >= Log.INFO
    }

    override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
        // Optionally, log to Logcat
        Log.println(priority, tag, message)
    }
}