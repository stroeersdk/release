package com.yieldlove.adIntegration.RemoteReporting

import android.os.Build
import com.yieldlove.adIntegration.BuildConfig
import com.yieldlove.androidpromise.Promise
import com.yieldlove.androidpromise.StartCallback
import org.json.JSONException
import org.json.JSONObject
import java.io.PrintWriter
import java.io.StringWriter

class HttpExceptionReporter(url: String, apiKey: String) : HttpReporter(url, apiKey),
    ExceptionReporter {
    override fun report(e: Exception?): Promise<Void?> {
        // return this.report(this.createBody(e));
        return Promise<Void?>(StartCallback { promise: Promise<Void?>? ->
            promise!!.resolve(null)
        })
    }

    private fun createBody(exception: Exception): String {
        try {
            val body = JSONObject()
                .put("appName", this.appName)
                .put("os", this.OS)
                .put("device", Build.MANUFACTURER + " " + Build.BRAND + " " + Build.MODEL)
                .put("sdkVersionName", BuildConfig.VERSION_NAME)
                .put("report", this.createReport(exception))

            return body.toString()
        } catch (e: JSONException) {
            return "{\"ReporterException\":\"" + e.message + "\"}"
        }
    }

    private fun createReport(exception: Exception): JSONObject {
        return JSONObject()
            .put("type", "exception")
            .put("data", this.createReportData(exception))
    }

    private fun createReportData(exception: Exception): JSONObject {
        return JSONObject()
            .put("exceptionType", exception.javaClass.getName())
            .put("message", exception.message)
            .put("stackTrace", this.getStackTrace(exception))
    }

    private fun getStackTrace(exception: Exception): String {
        val sw = StringWriter()
        val pw = PrintWriter(sw)
        exception.printStackTrace(pw)
        return sw.toString()
    }
}
