package com.yieldlove.adIntegration.ExternalConfiguration;

import com.stroeer.ads.exceptions.StroeerException;

public class OverrideKeyNotFoundException extends StroeerException {
    public OverrideKeyNotFoundException(String keyName) {
        super("Layout name (" + keyName + ") was not found");
    }
}
