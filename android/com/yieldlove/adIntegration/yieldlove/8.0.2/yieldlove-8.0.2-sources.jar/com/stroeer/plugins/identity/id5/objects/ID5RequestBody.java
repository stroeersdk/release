package com.stroeer.plugins.identity.id5.objects;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.stroeer.utilities.json.JsonBase;
import com.stroeer.utilities.logging.Logger;

import java.util.List;
import java.util.Objects;


public class ID5RequestBody extends JsonBase<ID5RequestBody> {
    // Timestamp in extended ISO-8601 format
    private String ts;
    // Partner number provided by ID5
    private Integer partner;
    // Application identifier (e.g., app store ID)
    private String appId;
    // Platform-specific app identifier (e.g., package name on Android or numeric ID on iOS)
    private String bundle;
    // Application version
    private String ver;
    // IPv4 address closest to the device
    private String ip;
    // User Agent string from the device's default browser
    private String ua;
    // ID5 signature from a previous call (cached)
    private String signature;
    // GDPR flag: 1 if GDPR applies, 0 otherwise
    private Integer gdpr;
    // TCF-compliant consent string (or allowed_vendors info) when applicable
    private String gdpr_consent;
    // Array of allowed vendor IDs (ID5 Partner IDs or IAB Vendor IDs)
    private List<String> allowed_vendors;
    // US Privacy consent string
    private String us_privacy;
    // GPP section IDs in force for the current transaction (could be comma-separated)
    private String gpp_sid;
    // IAB Global Privacy Platform consent string
    private String gpp_string;
    // App name (may be aliased at publisher’s request)
    private String name;
    // Domain of the app
    private String domain;
    // The device identifier (IDFA on iOS or GAID on Android)
    private String maid;
    // Specifies the type of maid: "idfa" or "gaid"
    private String maid_type;
    // (Optional) IDFA field, if needed
    private String idfa;
    // SHA256 hash of the cleansed e-mail address
    private String hem;
    // SHA256 hash of the cleansed phone number
    private String phone;
    // Apple ID for Vendors (IDFV)
    private String idfv;
    // Partner specific user ID
    private String puid;
    // IPv6 address of the device
    private String ipv6;
    // Country code (ISO-3166-1-alpha-2)
    private String country;
    // Region code (ISO-3166-2 or 2-letter state code if USA)
    private String region;
    // City using United Nations Code for Trade & Transport Locations format
    private String city;
    // "Ask App not to Track" flag (true if selected)
    private Integer att;
    // Accept-Language string (compatible with browser Accept-Language header)
    private String accept_language;
    // Array of segment objects
    private List<Segment> segments;

    private boolean isUpdated = true;
    // Default constructor
    public ID5RequestBody() {}

    // Getters and Setters for all fields

    public String getTs() {
        return ts;
    }

    public void setTs(String ts) {
        checkUpdated(this.ts, ts);
        this.ts = ts;
    }

    public Integer getPartner() {
        return partner;
    }

    public void setPartner(Integer partner) {
        checkUpdated(this.partner, partner);
        this.partner = partner;
    }

    public void setAppId(String appid) {
        checkUpdated(this.appId, appid);
        this.appId = appid;
    }

    public String getAppId() {
        return appId;
    }

    public String getBundle() {
        return bundle;
    }

    public void setBundle(String bundle) {
        checkUpdated(this.bundle, bundle);
        this.bundle = bundle;
    }

    public String getVer() {
        return ver;
    }

    public void setVer(String ver) {
        checkUpdated(this.ver, ver);
        this.ver = ver;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        checkUpdated(this.ip, ip);
        this.ip = ip;
    }

    public String getUa() {
        return ua;
    }

    public void setUa(String ua) {
        checkUpdated(this.ua, ua);
        this.ua = ua;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        checkUpdated(this.signature, signature);
        this.signature = signature;
    }

    public Integer getGdpr() {
        return gdpr;
    }

    public void setGdpr(Integer gdpr) {
        checkUpdated(this.gdpr, gdpr);
        this.gdpr = gdpr;
    }

    public String getGdpr_consent() {
        return gdpr_consent;
    }

    public void setGdpr_consent(String gdpr_consent) {
        checkUpdated(this.gdpr_consent, gdpr_consent);
        this.gdpr_consent = gdpr_consent;
    }

    public List<String> getAllowed_vendors() {
        return allowed_vendors;
    }

    public void setAllowed_vendors(List<String> allowed_vendors) {
        checkUpdated(this.allowed_vendors, allowed_vendors);
        this.allowed_vendors = allowed_vendors;
    }

    public String getUs_privacy() {
        return us_privacy;
    }

    public void setUs_privacy(String us_privacy) {
        checkUpdated(this.us_privacy, us_privacy);
        this.us_privacy = us_privacy;
    }

    public String getGpp_sid() {
        return gpp_sid;
    }

    public void setGpp_sid(String gpp_sid) {
        checkUpdated(this.gpp_sid, gpp_sid);
        this.gpp_sid = gpp_sid;
    }

    public String getGpp_string() {
        return gpp_string;
    }

    public void setGpp_string(String gpp_string) {
        checkUpdated(this.gpp_string, gpp_string);
        this.gpp_string = gpp_string;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        checkUpdated(this.name, name);
        this.name = name;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        checkUpdated(this.domain, domain);
        this.domain = domain;
    }

    public String getMaid() {
        return maid;
    }

    public void setMaid(String maid) {
        checkUpdated(this.maid, maid);
        this.maid = maid;
    }

    public String getMaid_type() {
        return maid_type;
    }

    public void setMaid_type(String maid_type) {
        checkUpdated(this.maid_type, maid_type);
        this.maid_type = maid_type;
    }

    public String getIdfa() {
        return idfa;
    }

    public void setIdfa(String idfa){
        checkUpdated(this.idfa, idfa);
        this.idfa = idfa;
    }

    public String getHem() {
        return hem;
    }

    public void setHem(String hem) {
        checkUpdated(this.hem, hem);
        this.hem = hem;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        checkUpdated(this.phone, phone);
        this.phone = phone;
    }

    public String getIdfv() {
        return idfv;
    }

    public void setIdfv(String idfv) {
        checkUpdated(this.idfv, idfv);
        this.idfv = idfv;
    }

    public String getPuid() {
        return puid;
    }

    public void setPuid(String puid) {
        checkUpdated(this.puid, puid);
        this.puid = puid;
    }

    public String getIpv6() {
        return ipv6;
    }

    public void setIpv6(String ipv6) {
        checkUpdated(this.ipv6, ipv6);
        this.ipv6 = ipv6;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        checkUpdated(this.country, country);
        this.country = country;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        checkUpdated(this.region, region);
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        checkUpdated(this.city, city);
        this.city = city;
    }

    public Integer isAtt() {
        return att;
    }

    public void setAtt(Integer att) {
        checkUpdated(this.att, att);
        this.att = att;
    }

    public String getAccept_language() {
        return accept_language;
    }

    public void setAccept_language(String accept_language) {
        checkUpdated(this.accept_language, accept_language);
        this.accept_language = accept_language;
    }

    public List<Segment> getSegments() {
        return segments;
    }

    public void setSegments(List<Segment> segments) {
        checkUpdated(this.segments, segments);
        this.segments = segments;
    }

    /**
     * Check if the value has been updated
     * @param oldVal stored value
     * @param newVal new value
     */
    private void checkUpdated(Object oldVal, Object newVal) {
        if(!Objects.equals(oldVal, newVal))
        {
            isUpdated = true;
        }
    }

    public boolean isUpdated(){
        return isUpdated;
    }

    /**
     * Reset the updated flag to false
     */
    public void resetUpdated(){
        isUpdated = false;
    }

    @Override
    public String toJson() {
        try
        {
            Gson gson = new GsonBuilder().excludeFieldsWithModifiers().create();
            String json =  gson.toJson(this, ID5RequestBody.class);
            if(json == null || json.equals("null"))
            {
                return null;
            }
            return json;
        }catch(Exception e)
        {
            Logger.e("Failed to convert "+ID5RequestBody.class.getName()+" to json", e);
        }
        return null;
    }

    // Nested static class representing a segment object
    public static class Segment {
        // Destination platform (should be the IAB Vendor ID)
        private String destination;
        // Array of segment IDs to add the user to
        private List<String> ids;

        public Segment() {}

        public Segment(String destination, List<String> ids) {
            this.destination = destination;
            this.ids = ids;
        }

        public String getDestination() {
            return destination;
        }

        public void setDestination(String destination) {
            this.destination = destination;
        }

        public List<String> getIds() {
            return ids;
        }

        public void setIds(List<String> ids) {
            this.ids = ids;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Segment segment = (Segment) o;
            return Objects.equals(destination, segment.destination) &&
                    Objects.equals(ids, segment.ids);
        }
    }
}

