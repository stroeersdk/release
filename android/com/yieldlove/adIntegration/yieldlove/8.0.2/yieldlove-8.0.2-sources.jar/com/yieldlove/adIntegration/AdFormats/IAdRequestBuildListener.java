package com.yieldlove.adIntegration.AdFormats;

import com.google.android.gms.ads.admanager.AdManagerAdRequest;

@Deprecated(since = "This interface is no longer necessary and will be removed in future versions. Use AdManagerAdRequest.Builder directly, instead.", forRemoval = true)
public interface IAdRequestBuildListener {
    AdManagerAdRequest.Builder onAdRequestBuild();
}
