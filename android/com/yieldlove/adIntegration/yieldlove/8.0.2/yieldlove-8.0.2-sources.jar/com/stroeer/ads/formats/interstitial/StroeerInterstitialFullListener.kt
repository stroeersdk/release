package com.stroeer.ads.formats.interstitial

import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.stroeer.ads.exceptions.StroeerException
import java.lang.Exception

/**
 * Default no-op implementation of [IStroeerInterstitialFullListener].
 *
 * This class provides empty method bodies for all interstitial ad callbacks,
 * so that developers can extend this class and override only the callbacks
 * they care about without having to implement every method manually.
 */
open class StroeerInterstitialFullListener : IStroeerInterstitialFullListener {

    /**
     * Called when the interstitial ad is clicked by the user.
     */
    override fun onAdClicked() { }

    /**
     * Called when the interstitial ad is dismissed and the full-screen content is closed.
     */
    override fun onAdDismissedFullScreenContent() { }

    /**
     * Called when the interstitial ad fails to display full-screen content.
     *
     * @param e An [Exception] describing the reason for the failure (may be `null`).
     */
    override fun onAdFailedToShowFullScreenContent(e: StroeerException?) { }

    /**
     * Called when the interstitial ad registers an impression (i.e., is visible to the user).
     */
    override fun onAdImpression() { }

    /**
     * Called when the interstitial ad has successfully shown full-screen content.
     */
    override fun onAdShowedFullScreenContent() { }

    /**
     * Called when the interstitial ad has successfully loaded and is ready to be shown.
     */
    override fun onAdLoaded() { }

    /**
     * Called when the interstitial ad fails to load.
     *
     * @param exception A [StroeerException] describing the reason for failure, or `null` if unavailable.
     */
    override fun onAdFailedToLoad(exception: StroeerException?) { }
}