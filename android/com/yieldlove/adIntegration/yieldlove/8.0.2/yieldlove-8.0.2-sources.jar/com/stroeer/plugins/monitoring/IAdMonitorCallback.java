package com.stroeer.plugins.monitoring;

/**
 * IAdMonitorCallback is an interface for handling callbacks related to the
 * initialization status of an ad monitoring implementation.
 */
public interface IAdMonitorCallback {

    /**
     * Called when the ad monitoring system has completed initialization.
     *
     * @param success true if the initialization was successful, false otherwise.
     */
    void onInitialized(boolean success);
}