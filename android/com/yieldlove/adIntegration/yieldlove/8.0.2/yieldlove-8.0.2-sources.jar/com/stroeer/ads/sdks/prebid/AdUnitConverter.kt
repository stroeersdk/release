package com.stroeer.ads.sdks.prebid

import org.prebid.mobile.AdUnit

interface AdUnitConverter {
    fun convertToBannerAdUnit(ylAdUnit: com.yieldlove.adIntegration.AdUnit.AdUnit): AdUnit
    fun convertToPrebidInterstitialAdUnit(ylAdUnit: com.yieldlove.adIntegration.AdUnit.AdUnit): AdUnit
}
