package com.stroeer.ads.config.objects.deserializer

import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.JsonParseException
import com.stroeer.ads.config.objects.ConfigAdSlot
import com.stroeer.ads.config.objects.ConfigCustomAdSize
import com.stroeer.utilities.logging.Logger
import java.lang.reflect.Type

/**
 * "b4": {
 * "prebidConfigId": "34843",
 * "iOSPrebidConfigId":"34852",
 * "rtaAuction": true,
 * "keyValues": {
 * "af": "moad2x1,moad3x1,moad4x1,moad6x1,mmrec",
 * "adslot": "topmobile4",
 * "as": "topmobile4"
 * },
 * "customAdSizes": [
 * {
 * "w": 37,
 * "h": 34
 * }
 * ]
 * },
 */
class ConfigAdSlot_Deserializer : JsonDeserializer<ConfigAdSlot?> {
    @Throws(JsonParseException::class)
    override fun deserialize(
        json: JsonElement,
        typeOfT: Type?,
        context: JsonDeserializationContext
    ): ConfigAdSlot {
        val jsonObject = json.getAsJsonObject()
        val configAdSlot = ConfigAdSlot()
        try {
            if (jsonObject.has("prebidConfigId")) {
                configAdSlot.prebidConfigId = jsonObject.get("prebidConfigId").getAsString()
            }
        } catch (e: Exception) {
            Logger.e("[ConfigAdSlot_Deserializer] Error while deserializing ConfigAdSlot", e)
        }
        try {
            if (jsonObject.has("rtaAuction")) {
                configAdSlot.rtaAuction = jsonObject.get("rtaAuction").getAsBoolean()
            }
        } catch (e: Exception) {
            Logger.e("[ConfigAdSlot_Deserializer] Error while deserializing ConfigAdSlot", e)
        }

        try {
            if (jsonObject.has("autoRefreshTimeMs")) {
                configAdSlot.autoRefreshTimeMs = jsonObject.get("autoRefreshTimeMs").getAsInt()
            }
        } catch (e: Exception) {
            Logger.e("[ConfigAdSlot_Deserializer] Error while deserializing ConfigAdSlot", e)
        }
        try {
            if (jsonObject.has("customAdSizes")) {
                configAdSlot.customAdSizes = context.deserialize<Array<ConfigCustomAdSize>?>(
                    jsonObject.get("customAdSizes"),
                    Array<ConfigCustomAdSize>::class.java
                )
            }
        } catch (e: Exception) {
            Logger.e("[ConfigAdSlot_Deserializer] Error while deserializing ConfigAdSlot", e)
        }

        try {
            val keyValues = context.deserialize<MutableMap<String?, String?>?>(
                jsonObject.get("keyValues"),
                MutableMap::class.java
            )

            if (keyValues != null) {
                val correctedKeyValues: MutableMap<String, Array<String>> =
                    HashMap<String, Array<String>>()
                for (entry in keyValues.entries) {
                    val values: Array<String> =
                        entry.value!!.split(",".toRegex()).dropLastWhile { it.isEmpty() }
                            .toTypedArray()
                    correctedKeyValues.put(entry.key!!, values)
                }
                configAdSlot.keyValues = correctedKeyValues
            }
        } catch (e: Exception) {
            Logger.e("[ConfigAdSlot_Deserializer] Error while deserializing ConfigAdSlot", e)
        }

        return configAdSlot
    }
}
