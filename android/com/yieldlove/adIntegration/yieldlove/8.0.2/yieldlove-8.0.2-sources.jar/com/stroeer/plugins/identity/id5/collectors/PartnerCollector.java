package com.stroeer.plugins.identity.id5.collectors;

import com.stroeer.plugins.identity.IIdentityCollector;

import java.util.concurrent.CompletableFuture;

/**
 * Return partner ID
 */
public class PartnerCollector implements IIdentityCollector<Integer> {
    @Override
    public CompletableFuture<Integer> retrieveData() {
        return CompletableFuture.completedFuture(433);
    }
}
