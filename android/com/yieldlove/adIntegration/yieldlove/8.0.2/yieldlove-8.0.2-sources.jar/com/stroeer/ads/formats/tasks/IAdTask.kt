package com.stroeer.ads.formats.tasks

import com.stroeer.ads.formats.AAdConfiguration

interface IAdTask {
    fun run(config: AAdConfiguration)
}