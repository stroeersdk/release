package com.stroeer.ads.bidding.gam

import com.stroeer.ads.exceptions.StroeerException

interface IGamInterstitialEventListener {
    fun onAdLoaded()

    fun onAdFailedToLoad(error: StroeerException)

    fun onAdFailedToShowFullScreenContent(error: StroeerException)

    fun onAdShowedFullScreenContent()

    fun onAdDismissedFullScreenContent()

    fun onAdImpression()

    fun onAdClicked()

    fun isFullListener() : Boolean
}