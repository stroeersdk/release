package com.stroeer.ads.sdks

import com.google.android.gms.ads.AdSize

object SizeUtils {
    fun parseSize(size: String?): AdSize? {
        if (size == null) {
            return null
        }

        val sizes: Array<String?> =
            size.split("x".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()

        if (sizes.size != 2) {
            return null
        }

        val width = sizes[0]!!.toInt()
        val height = sizes[1]!!.toInt()

        return AdSize(width, height)
    }

    fun isNoZeroPixel(size: AdSize): Boolean {
        return size.width > 0 && size.height > 0
    }
}
