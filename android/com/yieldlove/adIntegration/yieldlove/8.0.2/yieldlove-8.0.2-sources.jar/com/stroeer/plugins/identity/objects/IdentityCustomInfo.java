package com.stroeer.plugins.identity.objects;

public class IdentityCustomInfo {
    public String email;
    public String phone;
    public String puid;
    public String regionCode;
    public String cityCode;
}
