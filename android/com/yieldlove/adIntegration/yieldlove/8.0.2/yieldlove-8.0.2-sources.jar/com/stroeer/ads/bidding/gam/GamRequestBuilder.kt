package com.stroeer.ads.bidding.gam

import com.google.android.gms.ads.admanager.AdManagerAdRequest
import com.yieldlove.adIntegration.AdUnit.YieldloveAdUnit
import com.yieldlove.adIntegration.BuildConfig

class GamRequestBuilder(
    private var localBuilder: AdManagerAdRequest.Builder,
    private val adUnit: YieldloveAdUnit
) {
    private val keyValuesFromAdapter: MutableMap<String, String?> = HashMap()

    fun addKeyValuesFromAdapter(keyValues: MutableMap<String, String>?): GamRequestBuilder {
        keyValues?.let{
            for (key in keyValues.keys) {
                this.keyValuesFromAdapter.put(key, keyValues[key])
            }
        }
        return this
    }

    fun build(): AdManagerAdRequest {
        val builder = GamAdRequestBuilderMerger.merge(GlobalGamManager.adRequestBuilder, localBuilder)

        for (key in this.keyValuesFromAdapter.keys) {
            builder.addCustomTargeting(key, this.keyValuesFromAdapter[key]!!)
        }

        this.addCustomTargetingFromAdUnit(builder)
        this.setAdRequestTimeoutIfExists(builder)
        this.addSdkVersion(builder)

        return builder.build()
    }

    private fun addSdkVersion(builder: AdManagerAdRequest.Builder) {
        builder.addCustomTargeting("androidYlSdkVersion", listOf(BuildConfig.VERSION_NAME))
    }

    private fun setAdRequestTimeoutIfExists(builder: AdManagerAdRequest.Builder) {
        val timeout = this.adUnit.dfpAdRequestTimeoutInMs
        if (timeout != null) {
            builder.setHttpTimeoutMillis(this.adUnit.dfpAdRequestTimeoutInMs)
        }
    }

    private fun addCustomTargetingFromAdUnit(builder: AdManagerAdRequest.Builder) {
        val customTargeting = this.adUnit.customTargeting
        for (key in customTargeting.keys) {
            builder.addCustomTargeting(key, customTargeting.get(key)!!)
        }
    }
}