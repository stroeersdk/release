package com.stroeer.plugins.backfill;

import android.app.Activity;
import android.app.Application;

import com.stroeer.ads.debugInfo.IDebugInfo;
import com.stroeer.ads.formats.AdSourceInfo;

import java.util.List;
import java.util.Map;

public interface IBackFill {
    void initialize(Application application);
    IBackFillBanner getBannerLoader();
    IBackFillInterstitial getInterstitialLoader();
    void enableDebugMode();
    void enableTestMode(String bundleId, Integer accountId);
    void onResume(Activity activity);
    void onPause(Activity activity);
    void setCustomTargeting(Map<String, List<String>> targeting);
    void setCacheSize(int size);
    void setPlacementMapTable(Map<String, String> stroeerToGravite);
    String getVersion();
    IDebugInfo getDebugInfo();
    AdSourceInfo getAdSourceInfo();
}