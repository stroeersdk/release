package com.yieldlove.adIntegration.IabConsentResolver;

import com.yieldlove.adIntegration.ConsentReader.ConsentReader;

public class IabConsentEvaluator implements ConsentEvaluator {
    private static final char symbolOfBinaryPermission = '1';
    private ConsentReader reader;

    public IabConsentEvaluator(ConsentReader reader) {
        this.reader = reader;
    }

    public boolean evaluateConsentRequired(int vendorId, int purposeId) {
        return this.hasVendorAndPurposeConsent(vendorId, purposeId);
    }

    public boolean evaluateLegitimateInterestRequired(int vendorId, int purposeId) {
        return this.hasVendorAndPurposeConsent(vendorId, purposeId) || this.hasLiVendorAndPurposeConsent(vendorId, purposeId);
    }

    private boolean hasVendorAndPurposeConsent(int vendorId, int purposeId) {
        String vendorsConsent = this.reader.getVendorConsents();
        String purposesConsent = this.reader.getPurposeConsents();

        return this.consentBinaryStringContains(vendorsConsent, vendorId) &&
                this.consentBinaryStringContains(purposesConsent, purposeId);
    }

    private boolean hasLiVendorAndPurposeConsent(int vendorId, int purposeId) {
        String vendorsLiConsent = this.reader.getVendorLIConsents();
        String purposesLiConsent = this.reader.getPurposeLIConsents();

        return this.consentBinaryStringContains(vendorsLiConsent, vendorId) &&
                this.consentBinaryStringContains(purposesLiConsent, purposeId);
    }

    private boolean consentBinaryStringContains(String binaryString, int id) {
        if (binaryString!= null && !binaryString.isEmpty() && binaryString.length() >= id) {
            return binaryString.charAt(this.convertIdToIndex(id)) == symbolOfBinaryPermission;
        }
        return false;
    }

    private int convertIdToIndex(int vendorId) {
        return vendorId - 1;
    }
}
