package com.stroeer.ads.sdks

import com.stroeer.ads.exceptions.StroeerException

class AllSdkAdaptersProduceExceptions(var exceptions: MutableList<Exception?>?) : StroeerException()
