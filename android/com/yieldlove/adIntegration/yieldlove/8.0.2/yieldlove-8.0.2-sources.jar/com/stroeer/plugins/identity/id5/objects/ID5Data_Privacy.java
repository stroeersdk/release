package com.stroeer.plugins.identity.id5.objects;

/**
 * "privacy": {
 *         "jurisdiction": "other",
 *         "id5_consent": true
 *
 *}, */
public class ID5Data_Privacy {
    public String getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(String jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    public boolean isId5_consent() {
        return id5_consent;
    }

    public void setId5_consent(boolean id5_consent) {
        this.id5_consent = id5_consent;
    }

    protected String jurisdiction;
    protected boolean id5_consent;
}
