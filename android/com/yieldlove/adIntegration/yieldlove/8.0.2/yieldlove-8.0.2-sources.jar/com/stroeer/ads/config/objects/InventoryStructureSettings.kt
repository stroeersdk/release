package com.stroeer.ads.config.objects

enum class InventoryStructureSettings(s: String) {
    STROEER_DIGITAL_INVENTORY("SDI"),
    FLEXIBLE("flexible");

    private val value: String? = s

    companion object {
        fun parse(s: String): InventoryStructureSettings {
            return if (s == InventoryStructureSettings.FLEXIBLE.value) InventoryStructureSettings.FLEXIBLE else InventoryStructureSettings.STROEER_DIGITAL_INVENTORY
        }
    }
}
