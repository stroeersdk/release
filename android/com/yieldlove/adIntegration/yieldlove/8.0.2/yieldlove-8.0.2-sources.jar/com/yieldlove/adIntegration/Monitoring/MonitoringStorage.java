package com.yieldlove.adIntegration.Monitoring;

import java.util.ArrayList;

public interface MonitoringStorage {
    void putSessions(ArrayList<String> sessions);

    ArrayList<String> getSessions();

    int getSessionsSize();

    void setLastReportTime(long time);

    long getLastReportTime();
}
