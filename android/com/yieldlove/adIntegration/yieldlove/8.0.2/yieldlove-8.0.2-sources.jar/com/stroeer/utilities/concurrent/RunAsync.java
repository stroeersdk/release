package com.stroeer.utilities.concurrent;

import android.os.Looper;
import android.os.Handler;

import com.stroeer.utilities.logging.Logger;

import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class RunAsync {
    private static final ExecutorService executorService = Executors.newCachedThreadPool();
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    // For void-returning tasks
    public static CompletableFuture<Void> run(Runnable runnable, long timeoutMs, Consumer<Throwable> exceptionHandler) {
        return wrapWithTimeoutAndException(
                CompletableFuture.runAsync(runnable, executorService),
                timeoutMs,
                e -> {
                    exceptionHandler.accept(e);
                    Logger.e("[AsyncCall] Error in async void task:", e);
                    return null;
                }
        );
    }

    // For value-returning tasks
    public static <T> CompletableFuture<T> supply(Supplier<T> supplier, long timeoutMs, Consumer<Throwable>  exceptionHandler) {
        return wrapWithTimeoutAndException(
                CompletableFuture.supplyAsync(supplier, executorService),
                timeoutMs,
                e -> {
                    exceptionHandler.accept(e);
                    Logger.e("[AsyncCall] Error in async value task:", e);
                    return null;
                }
        );
    }

    // Core handler for timeout and exception wrapping
    private static <T> CompletableFuture<T> wrapWithTimeoutAndException(
            CompletableFuture<T> task,
            long timeoutMs,
            Function<Throwable, T> errorHandler
    ) {
        CompletableFuture<T> wrapped = (timeoutMs > 0)
                ? applyTimeout(task, timeoutMs, TimeUnit.MILLISECONDS)
                : task;

        return wrapped.exceptionally(errorHandler);
    }

    // Timeout support
    private static <T> CompletableFuture<T> applyTimeout(
            CompletableFuture<T> future,
            long timeout,
            TimeUnit unit
    ) {
        final CompletableFuture<T> timeoutFuture = new CompletableFuture<>();
        scheduler.schedule(() ->
                timeoutFuture.completeExceptionally(
                        new TimeoutException("AsyncCall timed out after " + timeout + " " + unit)
                ), timeout, unit);
        return future.applyToEither(timeoutFuture, Function.identity());
    }

    // Optional cleanup
    public static void shutdown() {
        executorService.shutdown();
        scheduler.shutdown();
    }

    public static void runOnUiThread(Runnable runnable) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            runnable.run();
        } else {
            new Handler(Looper.getMainLooper()).post(runnable);
        }
    }
}