package com.stroeer.ads.config.objects


class ConfigModule_Gravite {
    @JvmField
    var active: Boolean = false
    @JvmField
    var direct: Boolean = false
    @JvmField
    var exclude: MutableList<String> = mutableListOf()
}